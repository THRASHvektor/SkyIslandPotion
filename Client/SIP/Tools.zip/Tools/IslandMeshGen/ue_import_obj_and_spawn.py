import json
from pathlib import Path

import unreal


DEFAULT_ARGS = {
    "source_obj": r"C:\Users\12542\Documents\Unreal Projects\SkyIslandPotion\Tools\IslandMeshGen\output\plant_regroup\CrownLily_local-upload-mr9cc1z8-Meshy_AI_Flamebound_Scepter_1783275149_part-segm-Meshy_AI_Fl\07_ue_test\CrownLily_C0_SourceProxy_25k.obj",
    "destination_path": "/Game/AIGC/Plants/CrownLily/C0_Smoke",
    "destination_name": "SM_CrownLily_C0_SourceProxy_25k",
    "label": "SIP_AIGC_CrownLily_C0_OBJProxySmoke",
    "tag": "AIGCPlantC0OBJProxySmoke",
    "location": [-1040.0, -520.0, 220.0],
    "rotation": [0.0, -18.0, 0.0],
}


def _args():
    if hasattr(unreal, "get_mcp_args"):
        incoming = unreal.get_mcp_args() or {}
        merged = dict(DEFAULT_ARGS)
        merged.update(incoming)
        return merged
    return DEFAULT_ARGS


def _load_static_mesh(asset_path):
    asset = unreal.EditorAssetLibrary.load_asset(asset_path)
    return asset if isinstance(asset, unreal.StaticMesh) else None


def _clear_previous(tag, label):
    subsystem = unreal.get_editor_subsystem(unreal.EditorActorSubsystem)
    removed = 0
    for actor in subsystem.get_all_level_actors():
        if actor.get_actor_label() == label or any(str(actor_tag) == tag for actor_tag in actor.tags):
            subsystem.destroy_actor(actor)
            removed += 1
    return removed


def _import_mesh(source_obj, destination_path, destination_name):
    if not Path(source_obj).exists():
        raise RuntimeError("Missing OBJ: {}".format(source_obj))

    asset_tools = unreal.AssetToolsHelpers.get_asset_tools()
    task = unreal.AssetImportTask()
    task.set_editor_property("filename", source_obj)
    task.set_editor_property("destination_path", destination_path)
    task.set_editor_property("destination_name", destination_name)
    task.set_editor_property("automated", True)
    task.set_editor_property("replace_existing", True)
    task.set_editor_property("save", True)

    asset_tools.import_asset_tasks([task])

    imported_paths = list(task.get_editor_property("imported_object_paths") or [])
    for path in imported_paths:
        mesh = _load_static_mesh(path)
        if mesh:
            return mesh, imported_paths

    for path in unreal.EditorAssetLibrary.list_assets(destination_path, recursive=True, include_folder=False):
        if destination_name in path:
            mesh = _load_static_mesh(path)
            if mesh:
                return mesh, imported_paths

    raise RuntimeError("OBJ import produced no StaticMesh. Imported paths: {}".format(imported_paths))


def main():
    args = _args()
    location = unreal.Vector(float(args["location"][0]), float(args["location"][1]), float(args["location"][2]))
    rotation = unreal.Rotator(float(args["rotation"][0]), float(args["rotation"][1]), float(args["rotation"][2]))
    removed = _clear_previous(args["tag"], args["label"])
    mesh, imported_paths = _import_mesh(args["source_obj"], args["destination_path"], args["destination_name"])

    subsystem = unreal.get_editor_subsystem(unreal.EditorActorSubsystem)
    actor = subsystem.spawn_actor_from_class(unreal.StaticMeshActor, location, rotation)
    actor.set_actor_label(args["label"])
    actor.tags = [
        args["tag"],
        "AIGCPreview",
        "AIGCPreview.CrownLily",
        "AIGCPreview.C0",
        "AIGCSmoke.OBJProxy",
    ]
    actor.static_mesh_component.set_static_mesh(mesh)
    unreal.EditorLevelLibrary.set_selected_level_actors([actor])

    print(
        json.dumps(
            {
                "removed_previous_test_actors": removed,
                "source_obj": args["source_obj"],
                "imported_paths": imported_paths,
                "static_mesh": mesh.get_path_name(),
                "spawned_actor": actor.get_actor_label(),
                "location": [location.x, location.y, location.z],
            },
            indent=2,
        )
    )


main()
