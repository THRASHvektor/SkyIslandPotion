from __future__ import annotations

from pathlib import Path

from island_mesh_generator import generate_island_mesh_from_layout, write_obj
from semantic_layout import default_layout
from semantic_manifest import build_unreal_manifest, write_manifest


def main() -> None:
    root = Path(__file__).resolve().parent
    layout = default_layout("fire", seed=2002)

    layout_path = root / "layouts" / "fire_volcano_demo.json"
    layout_path.parent.mkdir(parents=True, exist_ok=True)
    layout_path.write_text(layout.to_json() + "\n", encoding="utf-8")

    output_path = root / "output" / "SM_ProcIsland_Fire_VolcanoLayout_200m.obj"
    mesh = generate_island_mesh_from_layout(layout, radial_segments=96, rings=14)
    write_obj(mesh, output_path)

    manifest_path = root / "output" / "SM_ProcIsland_Fire_VolcanoLayout_200m.manifest.json"
    manifest = build_unreal_manifest(layout, mesh_path=str(output_path), layout_path=str(layout_path))
    write_manifest(manifest, manifest_path)

    print(f"Wrote {layout_path}")
    print(f"Wrote {output_path} with {len(mesh.vertices)} vertices and {len(mesh.faces)} faces")
    print(f"Wrote {manifest_path}")


if __name__ == "__main__":
    main()
