import json
from pathlib import Path

import unreal


SOURCE_GLB = Path(
    r"C:\Users\12542\Documents\Unreal Projects\SkyIslandPotion\Tools\IslandMeshGen\mesh_inbox\CrownLilyC0\Meshy_AI_Flamebound Scepter_1783275149_part-segmentation.glb"
)

DESTINATION_PATH = "/Game/AIGC/Plants/CrownLily/C0_Smoke"
DESTINATION_NAME = "SM_CrownLily_C0_SourceSegmentation"
ACTOR_TAG = "AIGCPlantC0SmokeTest"
LABEL = "SIP_AIGC_CrownLily_C0_SourceSmoke"
SPAWN_LOCATION = unreal.Vector(-1040.0, -520.0, 220.0)
SPAWN_ROTATION = unreal.Rotator(0.0, -18.0, 0.0)


def _clear_previous_test_actor():
    subsystem = unreal.get_editor_subsystem(unreal.EditorActorSubsystem)
    removed = 0
    for actor in subsystem.get_all_level_actors():
        if actor.get_actor_label() == LABEL or any(str(tag) == ACTOR_TAG for tag in actor.tags):
            subsystem.destroy_actor(actor)
            removed += 1
    return removed


def _load_static_mesh(asset_path):
    asset = unreal.EditorAssetLibrary.load_asset(asset_path)
    return asset if isinstance(asset, unreal.StaticMesh) else None


def _import_source_glb():
    if not SOURCE_GLB.exists():
        raise RuntimeError("Missing source GLB: {}".format(SOURCE_GLB))

    asset_tools = unreal.AssetToolsHelpers.get_asset_tools()
    task = unreal.AssetImportTask()
    task.set_editor_property("filename", str(SOURCE_GLB))
    task.set_editor_property("destination_path", DESTINATION_PATH)
    task.set_editor_property("destination_name", DESTINATION_NAME)
    task.set_editor_property("automated", True)
    task.set_editor_property("replace_existing", True)
    task.set_editor_property("save", True)
    asset_tools.import_asset_tasks([task])

    for path in list(task.get_editor_property("imported_object_paths") or []):
        mesh = _load_static_mesh(path)
        if mesh:
            return mesh

    for path in unreal.EditorAssetLibrary.list_assets(DESTINATION_PATH, recursive=True, include_folder=False):
        if DESTINATION_NAME in path:
            mesh = _load_static_mesh(path)
            if mesh:
                return mesh

    raise RuntimeError("Source GLB import produced no StaticMesh")


def main():
    removed = _clear_previous_test_actor()
    mesh = _import_source_glb()

    subsystem = unreal.get_editor_subsystem(unreal.EditorActorSubsystem)
    actor = subsystem.spawn_actor_from_class(unreal.StaticMeshActor, SPAWN_LOCATION, SPAWN_ROTATION)
    actor.set_actor_label(LABEL)
    actor.tags = [ACTOR_TAG, "AIGCPreview", "AIGCPreview.CrownLily", "AIGCPreview.C0", "AIGCSmoke.SourceSegmentation"]
    actor.static_mesh_component.set_static_mesh(mesh)
    unreal.EditorLevelLibrary.set_selected_level_actors([actor])

    print(
        json.dumps(
            {
                "removed_previous_test_actors": removed,
                "source_glb": str(SOURCE_GLB),
                "imported_static_mesh": mesh.get_path_name(),
                "spawned_actor": actor.get_actor_label(),
                "spawn_location": [SPAWN_LOCATION.x, SPAWN_LOCATION.y, SPAWN_LOCATION.z],
            },
            indent=2,
        )
    )


main()
