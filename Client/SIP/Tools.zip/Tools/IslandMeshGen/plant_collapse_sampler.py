import math
import random
from collections import Counter
from dataclasses import dataclass


FAMILIES = ("CrownLily", "AetherVine")
BANDS = ("Stable_C0", "Weathered_C1", "Fractured_C2", "Unstable_C3")
SLOTS = ("BodyShell", "PrimarySilhouette", "Core", "OrbitSet")

SLOT_WEIGHTS = {
    "BodyShell": 0.20,
    "PrimarySilhouette": 0.35,
    "Core": 0.25,
    "OrbitSet": 0.20,
}

BAND_PROFILES = {
    "Stable_C0": {"target_severity": 0.25, "target_dispersion": 0.05, "temperature": 0.15},
    "Weathered_C1": {"target_severity": 0.95, "target_dispersion": 0.18, "temperature": 0.35},
    "Fractured_C2": {"target_severity": 1.80, "target_dispersion": 0.38, "temperature": 0.65},
    "Unstable_C3": {"target_severity": 2.45, "target_dispersion": 0.58, "temperature": 1.00},
}

BAND_SALTS = {
    "Stable_C0": 173,
    "Weathered_C1": 431,
    "Fractured_C2": 863,
    "Unstable_C3": 1297,
}

FAMILY_INDEX = {
    "CrownLily": 0,
    "AetherVine": 1,
}


@dataclass(frozen=True)
class CollapseSample:
    family: str
    band: str
    seed: int
    vector: dict
    metrics: dict
    energy: float


def sanitize_vector(vector):
    return {slot: max(0, min(3, int(vector.get(slot, 0)))) for slot in SLOTS}


def vector_slug(vector):
    sanitized = sanitize_vector(vector)
    return "B{}_P{}_C{}_O{}".format(
        sanitized["BodyShell"],
        sanitized["PrimarySilhouette"],
        sanitized["Core"],
        sanitized["OrbitSet"],
    )


def passes_hard_constraints(vector):
    sanitized = sanitize_vector(vector)
    body = sanitized["BodyShell"]
    primary = sanitized["PrimarySilhouette"]
    core = sanitized["Core"]

    if abs(primary - body) > 2:
        return False
    if abs(core - primary) > 2:
        return False
    if core >= 3 and primary <= 1:
        return False
    if primary >= 3 and body <= 0:
        return False
    return True


def calculate_metrics(vector):
    sanitized = sanitize_vector(vector)
    severity = sum(SLOT_WEIGHTS[slot] * sanitized[slot] for slot in SLOTS)
    dispersion = sum(SLOT_WEIGHTS[slot] * (sanitized[slot] - severity) ** 2 for slot in SLOTS)
    return {
        "severity": severity,
        "dispersion": dispersion,
        "passed_hard_constraints": passes_hard_constraints(sanitized),
    }


def passes_band_envelope(metrics, band):
    severity = metrics["severity"]
    if band == "Stable_C0":
        return severity <= 0.8
    if band == "Weathered_C1":
        return 0.35 <= severity <= 1.65
    if band == "Fractured_C2":
        return 0.95 <= severity <= 2.55
    if band == "Unstable_C3":
        return severity >= 1.8
    return True


def band_penalty(vector, band):
    sanitized = sanitize_vector(vector)
    max_level = max(sanitized.values())
    min_level = min(sanitized.values())
    penalty = 0.0

    if band == "Stable_C0":
        if max_level >= 2:
            penalty += 1.2
    elif band == "Weathered_C1":
        if max_level >= 3:
            penalty += 0.55
    elif band == "Fractured_C2":
        if max_level <= 1:
            penalty += 0.75
    elif band == "Unstable_C3":
        if max_level <= 1:
            penalty += 1.2
        if min_level >= 3:
            penalty += 2.5

    return penalty


def family_penalty(vector, family):
    sanitized = sanitize_vector(vector)
    penalty = 0.0

    if family == "CrownLily":
        if sanitized["PrimarySilhouette"] >= 2 and sanitized["Core"] == 0:
            penalty += 0.45
        if sanitized["OrbitSet"] >= 3 and sanitized["PrimarySilhouette"] <= 1:
            penalty += 0.35
    elif family == "AetherVine":
        if sanitized["OrbitSet"] - sanitized["PrimarySilhouette"] >= 3:
            penalty += 0.55
        if sanitized["BodyShell"] >= 3 and sanitized["PrimarySilhouette"] <= 1:
            penalty += 0.40

    return penalty


def candidate_energy(vector, metrics, band, family):
    profile = BAND_PROFILES[band]
    severity_delta = metrics["severity"] - profile["target_severity"]
    dispersion_delta = metrics["dispersion"] - profile["target_dispersion"]
    return (
        2.0 * severity_delta * severity_delta
        + dispersion_delta * dispersion_delta
        + band_penalty(vector, band)
        + family_penalty(vector, family)
    )


def _stream_seed(seed, band, family):
    return (
        int(seed)
        ^ (BAND_SALTS[band] * 2654435761)
        ^ ((FAMILY_INDEX[family] + 1) * 2246822519)
    ) & 0xFFFFFFFF


def iter_candidates(band, family):
    for body in range(4):
        for primary in range(4):
            for core in range(4):
                for orbit in range(4):
                    vector = {
                        "BodyShell": body,
                        "PrimarySilhouette": primary,
                        "Core": core,
                        "OrbitSet": orbit,
                    }

                    if body == 3 and primary == 3 and core == 3 and orbit == 3:
                        continue

                    metrics = calculate_metrics(vector)
                    if not metrics["passed_hard_constraints"]:
                        continue
                    if not passes_band_envelope(metrics, band):
                        continue

                    yield vector, metrics, candidate_energy(vector, metrics, band, family)


def sample_collapse_vector(seed, band, family, temperature_scale=1.0):
    profile = BAND_PROFILES[band]
    effective_temperature = max(0.025, profile["temperature"] * max(0.05, min(float(temperature_scale), 2.5)))
    rng = random.Random(_stream_seed(seed, band, family))

    candidates = []
    total_weight = 0.0

    for vector, metrics, energy in iter_candidates(band, family):
        weight = math.exp(-energy / effective_temperature)
        if weight <= 1e-8:
            continue
        candidates.append((vector, metrics, energy, weight))
        total_weight += weight

    if not candidates:
        vector = {"BodyShell": 0, "PrimarySilhouette": 0, "Core": 0, "OrbitSet": 0}
        return CollapseSample(family, band, int(seed), vector, calculate_metrics(vector), 0.0)

    pick = rng.random() * total_weight
    accumulator = 0.0
    for vector, metrics, energy, weight in candidates:
        accumulator += weight
        if pick <= accumulator:
            return CollapseSample(family, band, int(seed), dict(vector), dict(metrics), energy)

    vector, metrics, energy, _weight = candidates[-1]
    return CollapseSample(family, band, int(seed), dict(vector), dict(metrics), energy)


def _summary_stats(values):
    if not values:
        return {"min": 0.0, "max": 0.0, "mean": 0.0}
    return {
        "min": min(values),
        "max": max(values),
        "mean": sum(values) / len(values),
    }


def summarize_samples(seed=7307, samples_per_band=1000, families=FAMILIES, bands=BANDS, temperature_scale=1.0):
    rows = []
    samples_per_band = max(1, int(samples_per_band))
    seed = int(seed)

    for family_index, family in enumerate(families):
        for band_index, band in enumerate(bands):
            samples = [
                sample_collapse_vector(
                    seed=seed + family_index * 100000 + band_index * 10000 + sample_index * 17,
                    band=band,
                    family=family,
                    temperature_scale=temperature_scale,
                )
                for sample_index in range(samples_per_band)
            ]
            vector_counts = Counter(vector_slug(sample.vector) for sample in samples)
            severity_values = [sample.metrics["severity"] for sample in samples]
            dispersion_values = [sample.metrics["dispersion"] for sample in samples]
            failed_hard_constraints = sum(1 for sample in samples if not sample.metrics["passed_hard_constraints"])

            rows.append(
                {
                    "family": family,
                    "band": band,
                    "count": len(samples),
                    "severity": _summary_stats(severity_values),
                    "dispersion": _summary_stats(dispersion_values),
                    "unique_vectors": len(vector_counts),
                    "top_vectors": [
                        {"vector": vector, "count": count}
                        for vector, count in vector_counts.most_common(8)
                    ],
                    "failed_hard_constraints": failed_hard_constraints,
                }
            )

    return {
        "schema": "SkyIslandPotion.PlantCollapseRandomReport.v0",
        "seed": seed,
        "samples_per_band": samples_per_band,
        "families": list(families),
        "bands": list(bands),
        "temperature_scale": temperature_scale,
        "rows": rows,
    }
