#!/usr/bin/env python3
"""Extract simple UE assembly hints from a SIP plant regroup manifest."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any


SLOT_ORDER = ("BodyShell", "PrimarySilhouette", "Core", "OrbitSet")


def _v_add(a: list[float], b: list[float]) -> list[float]:
    return [a[0] + b[0], a[1] + b[1], a[2] + b[2]]


def _v_sub(a: list[float], b: list[float]) -> list[float]:
    return [a[0] - b[0], a[1] - b[1], a[2] - b[2]]


def _v_mul(a: list[float], scalar: float) -> list[float]:
    return [a[0] * scalar, a[1] * scalar, a[2] * scalar]


def _bbox_center(minimum: list[float], maximum: list[float]) -> list[float]:
    return [(minimum[0] + maximum[0]) * 0.5, (minimum[1] + maximum[1]) * 0.5, (minimum[2] + maximum[2]) * 0.5]


def _source_y_up_to_unreal_z_up(v: list[float], scale: float) -> list[float]:
    # Meshy/glTF source is treated as X right, Y up, Z forward.
    # UE expects X forward, Y right, Z up. This convention matches SIP plant code.
    return [v[0] * scale, -v[2] * scale, v[1] * scale]


def _summarize_group(parts: list[dict[str, Any]]) -> dict[str, Any]:
    if not parts:
        raise ValueError("cannot summarize an empty semantic group")

    union_min = [float("inf"), float("inf"), float("inf")]
    union_max = [float("-inf"), float("-inf"), float("-inf")]
    weighted = [0.0, 0.0, 0.0]
    total_weight = 0.0

    for part in parts:
        bbox = part["bbox"]
        minimum = [float(x) for x in bbox["min"]]
        maximum = [float(x) for x in bbox["max"]]
        center = _bbox_center(minimum, maximum)
        weight = float(part.get("triangles") or 1.0)

        for i in range(3):
            union_min[i] = min(union_min[i], minimum[i])
            union_max[i] = max(union_max[i], maximum[i])
        weighted = _v_add(weighted, _v_mul(center, weight))
        total_weight += weight

    union_center = _bbox_center(union_min, union_max)
    weighted_center = _v_mul(weighted, 1.0 / total_weight) if total_weight > 0 else union_center

    return {
        "part_count": len(parts),
        "triangle_count": int(sum(int(part.get("triangles") or 0) for part in parts)),
        "source_bbox_min": union_min,
        "source_bbox_max": union_max,
        "source_bbox_center": union_center,
        "source_weighted_center": weighted_center,
    }


def extract_hint(regroup_dir: Path, source_to_ue_scale: float) -> dict[str, Any]:
    manifest_path = regroup_dir / "01_manifest" / "regroup_manifest.json"
    pack_report_path = regroup_dir / "05_glb_parts" / "pack_report.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))

    groups = manifest["semantic_groups"]
    summaries = {slot: _summarize_group(groups[slot]) for slot in SLOT_ORDER}

    body = summaries["BodyShell"]
    body_min = body["source_bbox_min"]
    body_center = body["source_bbox_center"]
    anchor = [body_center[0], body_min[1], body_center[2]]

    glb_paths: dict[str, str] = {}
    if pack_report_path.exists():
        pack_report = json.loads(pack_report_path.read_text(encoding="utf-8"))
        for export in pack_report.get("exports", []):
            group = export.get("group")
            file_name = export.get("fileName")
            if group and file_name:
                glb_paths[group] = str((regroup_dir / "05_glb_parts" / file_name).resolve())

    slots: dict[str, Any] = {}
    for slot in SLOT_ORDER:
        summary = summaries[slot]
        source_center = summary["source_weighted_center"] if slot in ("Core", "OrbitSet") else summary["source_bbox_center"]
        source_offset = _v_sub(source_center, anchor)
        slots[slot] = {
            **summary,
            "source_attachment_center": source_center,
            "source_offset_from_anchor": source_offset,
            "ue_offset_cm": _source_y_up_to_unreal_z_up(source_offset, source_to_ue_scale),
            "glb_path": glb_paths.get(slot, str((regroup_dir / "05_glb_parts" / f"{slot}.glb").resolve())),
        }

    all_min = [min(summaries[slot]["source_bbox_min"][i] for slot in SLOT_ORDER) for i in range(3)]
    all_max = [max(summaries[slot]["source_bbox_max"][i] for slot in SLOT_ORDER) for i in range(3)]
    source_size = _v_sub(all_max, all_min)

    return {
        "schema": "SkyIslandPotion.PlantAssemblyHint.v1",
        "plant_profile": manifest.get("plant_profile", "Unknown"),
        "collapse_state": "C0",
        "source_manifest": str(manifest_path.resolve()),
        "source_axis": "X-right, Y-up, Z-forward",
        "ue_axis_mapping": "UE = (X, -Z, Y) * source_to_ue_scale",
        "source_to_ue_scale": source_to_ue_scale,
        "source_union_bbox_min": all_min,
        "source_union_bbox_max": all_max,
        "source_union_size": source_size,
        "source_anchor": anchor,
        "ue_assembled_height_cm": source_size[1] * source_to_ue_scale,
        "slots": slots,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("regroup_dir", type=Path)
    parser.add_argument("--scale", type=float, default=2200.0)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()

    regroup_dir = args.regroup_dir.resolve()
    output = args.output or (regroup_dir / "07_ue_test" / "assembly_manifest.json")
    output.parent.mkdir(parents=True, exist_ok=True)

    hint = extract_hint(regroup_dir, args.scale)
    output.write_text(json.dumps(hint, indent=2, ensure_ascii=False), encoding="utf-8")

    print(json.dumps({"output": str(output), "height_cm": hint["ue_assembled_height_cm"], "slots": list(hint["slots"])}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
