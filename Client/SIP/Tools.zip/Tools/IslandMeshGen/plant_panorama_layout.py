import json
import math
from pathlib import Path

from plant_actor_spawn_plan import build_actor_spawn_plan
from plant_collapse_sampler import BANDS, FAMILIES


DEFAULT_PANORAMA_PRESET = {
    "origin": [15000.0, 15000.0, 520.0],
    "band_spacing_x": 1120.0,
    "family_spacing_y": 1450.0,
    "sample_spacing_y": 470.0,
    "scale": 1.7,
    "temperature_scale": 1.12,
}
DEFAULT_PANORAMA_PRESET_PATH = Path(__file__).resolve().parent / "config" / "aigc_plant_panorama_preset.json"


def load_panorama_preset(preset_path=None):
    preset = dict(DEFAULT_PANORAMA_PRESET)
    resolved_path = Path(preset_path) if preset_path else DEFAULT_PANORAMA_PRESET_PATH

    if not resolved_path.exists():
        if preset_path:
            raise FileNotFoundError(str(resolved_path))
        return preset

    with resolved_path.open("r", encoding="utf-8") as handle:
        supplied = json.load(handle)

    for key in ("origin", "band_spacing_x", "family_spacing_y", "sample_spacing_y", "scale", "temperature_scale"):
        if key in supplied:
            preset[key] = supplied[key]

    preset["origin"] = [float(value) for value in preset["origin"]]
    for key in ("band_spacing_x", "family_spacing_y", "sample_spacing_y", "scale", "temperature_scale"):
        preset[key] = float(preset[key])

    return preset


def _bounds(points):
    if not points:
        return {"min": [0.0, 0.0, 0.0], "max": [0.0, 0.0, 0.0], "center": [0.0, 0.0, 0.0]}

    mins = [min(point[index] for point in points) for index in range(3)]
    maxs = [max(point[index] for point in points) for index in range(3)]
    center = [(mins[index] + maxs[index]) * 0.5 for index in range(3)]
    return {"min": mins, "max": maxs, "center": center}


def _look_at_rotation(location, target):
    direction = [
        float(target[0]) - float(location[0]),
        float(target[1]) - float(location[1]),
        float(target[2]) - float(location[2]),
    ]
    horizontal = math.sqrt(direction[0] * direction[0] + direction[1] * direction[1])
    pitch = math.degrees(math.atan2(direction[2], horizontal))
    yaw = math.degrees(math.atan2(direction[1], direction[0]))
    return [pitch, yaw, 0.0]


def _camera_for_bounds(bounds):
    center = list(bounds["center"])
    width = max(1.0, bounds["max"][0] - bounds["min"][0])
    depth = max(1.0, bounds["max"][1] - bounds["min"][1])
    location = [
        center[0] - width * 0.18,
        center[1] - max(width * 1.05, depth * 2.25),
        center[2] + 1750.0,
    ]
    target = [center[0], center[1], center[2] + 420.0]
    return {
        "location": location,
        "rotation": _look_at_rotation(location, target),
        "target": target,
    }


def _band_zones(origin, bands, band_spacing_x):
    center_index = (len(bands) - 1) * 0.5
    return [
        {
            "band": band,
            "center": [
                float(origin[0]) + (index - center_index) * float(band_spacing_x),
                float(origin[1]),
                float(origin[2]),
            ],
        }
        for index, band in enumerate(bands)
    ]


def _family_lanes(origin, families, family_spacing_y):
    return [
        {
            "family": family,
            "center_y": float(origin[1]) + index * float(family_spacing_y),
        }
        for index, family in enumerate(families)
    ]


def build_panorama_layout(
    recipe_plan,
    families=FAMILIES,
    bands=BANDS,
    samples_per_band=3,
    seed=9103,
    origin=tuple(DEFAULT_PANORAMA_PRESET["origin"]),
    band_spacing_x=DEFAULT_PANORAMA_PRESET["band_spacing_x"],
    family_spacing_y=DEFAULT_PANORAMA_PRESET["family_spacing_y"],
    sample_spacing_y=DEFAULT_PANORAMA_PRESET["sample_spacing_y"],
    scale=DEFAULT_PANORAMA_PRESET["scale"],
    temperature_scale=DEFAULT_PANORAMA_PRESET["temperature_scale"],
):
    center_origin = (
        float(origin[0]) - (len(bands) - 1) * float(band_spacing_x) * 0.5,
        float(origin[1]) - (int(samples_per_band) - 1) * float(sample_spacing_y) * 0.5,
        float(origin[2]),
    )
    plan = build_actor_spawn_plan(
        recipe_plan,
        families=families,
        bands=bands,
        samples_per_band=samples_per_band,
        seed=seed,
        origin=center_origin,
        family_spacing_y=family_spacing_y,
        band_spacing_x=band_spacing_x,
        sample_spacing_y=sample_spacing_y,
        scale=scale,
        temperature_scale=temperature_scale,
    )
    points = [actor["location"] for actor in plan["actors"]]
    layout_bounds = _bounds(points)

    return {
        "schema": "SkyIslandPotion.AIGCPlantPanoramaLayout.v0",
        "composition": "collapse_band_panorama",
        "families": list(families),
        "bands": list(bands),
        "samples_per_band": max(1, int(samples_per_band)),
        "seed": int(seed),
        "origin": [float(origin[0]), float(origin[1]), float(origin[2])],
        "band_zones": _band_zones(origin, bands, band_spacing_x),
        "family_lanes": _family_lanes(origin, families, family_spacing_y),
        "bounds": layout_bounds,
        "camera": _camera_for_bounds(layout_bounds),
        "actors": plan["actors"],
        "skipped_missing_recipes": plan["skipped_missing_recipes"],
    }
