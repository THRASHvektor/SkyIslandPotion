from __future__ import annotations

import argparse
import json
from pathlib import Path

from island_mesh_generator import (
    BAKE_QUALITY_PROFILES,
    bake_quality_profile,
    generate_island_mesh_and_field_from_layout,
    terrain_field_preview_payload,
    write_obj,
)
from semantic_layout import IslandLayout
from semantic_manifest import build_unreal_manifest, write_manifest


def manifest_reference(path: Path) -> str:
    resolved = path.resolve()
    try:
        return resolved.relative_to(Path.cwd().resolve()).as_posix()
    except ValueError:
        return resolved.as_posix()


def main() -> None:
    parser = argparse.ArgumentParser(description="Export an OBJ from a semantic island layout JSON file.")
    parser.add_argument("--layout", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--manifest", type=Path)
    parser.add_argument("--field-json", type=Path)
    parser.add_argument("--quality", choices=sorted(BAKE_QUALITY_PROFILES), default="draft")
    parser.add_argument("--segments", type=int)
    parser.add_argument("--rings", type=int)
    args = parser.parse_args()

    layout = IslandLayout.from_json(args.layout.read_text(encoding="utf-8"))
    quality_profile = bake_quality_profile(args.quality)
    segments = args.segments or int(quality_profile["segments"])
    rings = args.rings or int(quality_profile["rings"])
    mesh, terrain_field = generate_island_mesh_and_field_from_layout(
        layout,
        radial_segments=segments,
        rings=rings,
        bake_quality=args.quality,
    )
    write_obj(mesh, args.output)
    print(f"Wrote {args.output} with {len(mesh.vertices)} vertices and {len(mesh.faces)} faces ({args.quality} quality)")

    if args.manifest:
        manifest = build_unreal_manifest(
            layout,
            mesh_path=manifest_reference(args.output),
            layout_path=manifest_reference(args.layout),
            bake_metadata={
                "quality": args.quality,
                "segments": segments,
                "rings": rings,
                "detail_intensity": quality_profile["detail_intensity"],
            },
        )
        write_manifest(manifest, args.manifest)
        print(f"Wrote {args.manifest}")

    if args.field_json:
        args.field_json.parent.mkdir(parents=True, exist_ok=True)
        args.field_json.write_text(json.dumps(terrain_field_preview_payload(terrain_field), separators=(",", ":")) + "\n", encoding="utf-8")
        print(f"Wrote {args.field_json}")


if __name__ == "__main__":
    main()
