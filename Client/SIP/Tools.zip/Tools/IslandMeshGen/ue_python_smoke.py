import unreal

print("SIP UE Python smoke OK")
print(unreal.SystemLibrary.get_engine_version())
