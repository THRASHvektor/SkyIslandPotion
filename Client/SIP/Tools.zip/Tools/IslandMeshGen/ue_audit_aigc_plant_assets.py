import json
import sys
from pathlib import Path

import unreal


def _tool_script_dir():
    script_path = globals().get("__file__")
    if script_path:
        return Path(script_path).resolve().parent

    project_dir = Path(unreal.Paths.project_dir()).resolve()
    candidates = [
        project_dir.parents[1] / "Tools" / "IslandMeshGen",
        project_dir.parent / "Tools" / "IslandMeshGen",
        Path.cwd(),
    ]
    for candidate in candidates:
        if (candidate / "plant_aigc_asset_catalog.py").exists():
            return candidate
    return candidates[0]


TOOL_DIR = _tool_script_dir()
sys.path.insert(0, str(TOOL_DIR))

from plant_aigc_asset_catalog import AIGC_PLANT_ROOT, build_asset_audit, build_recipe_plan


DEFAULT_OUTPUT_DIR = TOOL_DIR / "output" / "plant_recipe_plans"


def _get_args():
    args = {
        "output_dir": str(DEFAULT_OUTPUT_DIR),
        "output_stem": "aigc_plant_asset_audit",
    }
    if hasattr(unreal, "get_mcp_args"):
        supplied = unreal.get_mcp_args()
        if isinstance(supplied, dict):
            args.update(supplied)
    args["output_dir"] = Path(args["output_dir"])
    args["output_stem"] = str(args["output_stem"])
    return args


def _class_name(asset_data):
    if hasattr(asset_data, "asset_class_path"):
        return str(asset_data.asset_class_path.asset_name)
    return str(asset_data.asset_class)


def _collect_static_mesh_paths():
    registry = unreal.AssetRegistryHelpers.get_asset_registry()
    registry.scan_paths_synchronous([AIGC_PLANT_ROOT], True)
    assets = registry.get_assets_by_path(AIGC_PLANT_ROOT, True)
    paths = []
    ignored = []

    for asset in assets:
        package = str(asset.package_name)
        class_name = _class_name(asset)
        if class_name == "StaticMesh":
            paths.append(package)
        elif package.startswith(AIGC_PLANT_ROOT):
            ignored.append({"path": package, "class": class_name, "name": str(asset.asset_name)})

    return sorted(set(paths)), sorted(ignored, key=lambda item: (item["class"], item["path"]))


def main():
    args = _get_args()
    static_mesh_paths, ignored_assets = _collect_static_mesh_paths()
    audit = build_asset_audit(static_mesh_paths)
    recipe_plan = build_recipe_plan(audit)

    args["output_dir"].mkdir(parents=True, exist_ok=True)
    audit_path = args["output_dir"] / "{}.json".format(args["output_stem"])
    recipe_path = args["output_dir"] / "{}_recipe_plan.json".format(args["output_stem"])

    audit_payload = dict(audit)
    audit_payload["ignored_non_static_mesh_assets"] = ignored_assets

    audit_path.write_text(json.dumps(audit_payload, indent=2, ensure_ascii=False), encoding="utf-8")
    recipe_path.write_text(json.dumps(recipe_plan, indent=2, ensure_ascii=False), encoding="utf-8")

    print(
        json.dumps(
            {
                "asset_root": AIGC_PLANT_ROOT,
                "static_mesh_count": len(static_mesh_paths),
                "ignored_non_static_mesh_count": len(ignored_assets),
                "complete_families": audit["summary"]["complete_families"],
                "incomplete_families": audit["summary"]["incomplete_families"],
                "recipe_count": len(recipe_plan["recipes"]),
                "audit_path": str(audit_path),
                "recipe_plan_path": str(recipe_path),
            },
            indent=2,
            ensure_ascii=False,
        )
    )


main()
