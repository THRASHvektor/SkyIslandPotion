import json

import unreal


LABEL = "SIP_AIGC_CrownLily_C0_ProceduralProxy"


def main():
    subsystem = unreal.get_editor_subsystem(unreal.EditorActorSubsystem)
    actors = [actor for actor in subsystem.get_all_level_actors() if actor.get_actor_label() == LABEL]
    summary = {"actor_count": len(actors), "label": LABEL}
    if actors:
        actor = actors[0]
        components = actor.get_components_by_class(unreal.ProceduralMeshComponent) if hasattr(unreal, "ProceduralMeshComponent") else []
        location = actor.get_actor_location()
        summary.update(
            {
                "actor_name": actor.get_name(),
                "location": [location.x, location.y, location.z],
                "component_count": len(components),
                "sections": components[0].get_num_sections() if components and hasattr(components[0], "get_num_sections") else None,
                "component_active": components[0].is_active() if components and hasattr(components[0], "is_active") else None,
                "component_visible": components[0].is_visible() if components and hasattr(components[0], "is_visible") else None,
            }
        )
    print(json.dumps(summary, indent=2))


main()
