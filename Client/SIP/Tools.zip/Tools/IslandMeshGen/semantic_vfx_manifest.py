from __future__ import annotations

import json
from pathlib import Path
from typing import Any


SCHEMA = "SkyIslandPotion.SemanticVFXManifest.v0"


def _island_name_from_manifest(island_manifest: dict[str, Any]) -> str:
    mesh_path = str(island_manifest.get("mesh", "")).strip()
    if mesh_path:
        return Path(mesh_path).stem
    return str(island_manifest.get("id") or island_manifest.get("name") or "UnnamedIsland")


def _fire_testbed_slots() -> list[dict[str, Any]]:
    return [
        {
            "id": "FIRE_SLOT_01_LAVA_CHANNEL_LEAK",
            "source": ["material:M_ElementCrack", "mask:lava_flow", "landmark:lava_channels"],
            "intent": "AmbientLeak",
            "element": "Element.Fire",
            "spawn_mode": "mask_sample",
            "activation_policy": "distance_gated",
            "density": 0.28,
            "intensity": 0.45,
            "avoid": ["mask:path"],
            "niagara_hint": "/Game/SlashFX_SoftTofu/Niagara/Fire/NS_BottomSpark_Fire_",
            "notes": "Sample lava channel peaks and edges; keep the path core readable.",
        },
        {
            "id": "FIRE_SLOT_02_CRATER_RIM_PULSE",
            "source": ["mask:crater_loop", "path:partial_crater_loop"],
            "intent": "BoundaryPulse",
            "element": "Element.Fire",
            "spawn_mode": "timed_arc",
            "activation_policy": "distance_gated",
            "density": 0.12,
            "intensity": 0.65,
            "avoid": ["mask:path_center"],
            "niagara_hint": "/Game/SlashFX_SoftTofu/Niagara/Fire/NS_Slash_Projectile_rotate_Fire_",
            "notes": "Use short arc pulses around the crater rim instead of a full permanent ring.",
        },
        {
            "id": "FIRE_SLOT_05_CLIFF_COLLAPSE_DISTORTION",
            "source": ["mask:cliff", "mask:curvature", "quality:thinEdge", "quality:radialArtifact"],
            "intent": "CollapseAnomaly",
            "element": "Element.Collapse",
            "spawn_mode": "rare_cluster_sample",
            "activation_policy": "distance_gated",
            "density": 0.04,
            "intensity": 0.35,
            "avoid": ["mask:path", "zone:crater_arena"],
            "niagara_hint": "/Game/SlashFX_SoftTofu/Niagara/Distortion/NS_Slash_Distort_",
            "notes": "Place rarely on cliff or high-curvature edge clusters to read as world instability.",
        },
        {
            "id": "FIRE_SLOT_06_REACTION_IMPACT_BURST",
            "source": ["runtime:impact_location", "zone:lava_hazard", "material:M_ElementCrack"],
            "intent": "ReactionBurst",
            "element": "Element.Fire",
            "spawn_mode": "reaction_location",
            "activation_policy": "reaction_triggered",
            "density": 1.0,
            "intensity": 1.0,
            "avoid": [],
            "niagara_hint": "/Game/SlashFX_SoftTofu/Niagara/Fire/NS_Hit_Slash_Direction_Fire_",
            "notes": "Use ASIPElementalZoneActor reaction plumbing or a preview burst actor at the hit point.",
        },
    ]


def build_fire_vfx_manifest(island_manifest: dict[str, Any]) -> dict[str, Any]:
    biome = str(island_manifest.get("biome", "")).lower()
    if biome and biome != "fire":
        raise ValueError(f"build_fire_vfx_manifest expects biome='fire', got {biome!r}")

    scale = island_manifest.get("scale", {})
    return {
        "schema": SCHEMA,
        "tool": "IslandMeshGen",
        "island": _island_name_from_manifest(island_manifest),
        "biome": "fire",
        "biome_tag": island_manifest.get("biome_tag", "Biome.Fire"),
        "scale": {
            "radius_m": scale.get("radius_m", 100.0),
            "diameter_m": scale.get("diameter_m", 200.0),
            "unreal_units": scale.get("unreal_units", "centimeters"),
        },
        "slots": _fire_testbed_slots(),
    }


def write_vfx_manifest(manifest: dict[str, Any], output_path: Path) -> None:
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8")
