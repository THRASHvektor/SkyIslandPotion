import argparse
import csv
import json
from pathlib import Path

from plant_collapse_sampler import summarize_samples


DEFAULT_OUTPUT_DIR = Path(__file__).resolve().parent / "output" / "plant_collapse_reports"


def _write_csv(summary, path):
    fieldnames = [
        "family",
        "band",
        "count",
        "severity_min",
        "severity_mean",
        "severity_max",
        "dispersion_min",
        "dispersion_mean",
        "dispersion_max",
        "unique_vectors",
        "failed_hard_constraints",
        "top_vectors",
    ]
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        for row in summary["rows"]:
            writer.writerow(
                {
                    "family": row["family"],
                    "band": row["band"],
                    "count": row["count"],
                    "severity_min": "{:.4f}".format(row["severity"]["min"]),
                    "severity_mean": "{:.4f}".format(row["severity"]["mean"]),
                    "severity_max": "{:.4f}".format(row["severity"]["max"]),
                    "dispersion_min": "{:.4f}".format(row["dispersion"]["min"]),
                    "dispersion_mean": "{:.4f}".format(row["dispersion"]["mean"]),
                    "dispersion_max": "{:.4f}".format(row["dispersion"]["max"]),
                    "unique_vectors": row["unique_vectors"],
                    "failed_hard_constraints": row["failed_hard_constraints"],
                    "top_vectors": "; ".join(
                        "{}:{}".format(item["vector"], item["count"])
                        for item in row["top_vectors"]
                    ),
                }
            )


def _print_human_summary(summary):
    print("Plant collapse random report")
    print("seed={} samples_per_band={}".format(summary["seed"], summary["samples_per_band"]))
    for row in summary["rows"]:
        top = ", ".join("{} x{}".format(item["vector"], item["count"]) for item in row["top_vectors"][:3])
        print(
            "- {family} {band}: severity {smin:.2f}/{smean:.2f}/{smax:.2f}, "
            "dispersion {dmin:.2f}/{dmean:.2f}/{dmax:.2f}, unique={unique}, failed={failed}, top={top}".format(
                family=row["family"],
                band=row["band"],
                smin=row["severity"]["min"],
                smean=row["severity"]["mean"],
                smax=row["severity"]["max"],
                dmin=row["dispersion"]["min"],
                dmean=row["dispersion"]["mean"],
                dmax=row["dispersion"]["max"],
                unique=row["unique_vectors"],
                failed=row["failed_hard_constraints"],
                top=top,
            )
        )


def main():
    parser = argparse.ArgumentParser(description="Summarize SIP AIGC plant collapse-vector sampling.")
    parser.add_argument("--seed", type=int, default=7307)
    parser.add_argument("--samples-per-band", type=int, default=1000)
    parser.add_argument("--temperature-scale", type=float, default=1.0)
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT_DIR)
    args = parser.parse_args()

    summary = summarize_samples(
        seed=args.seed,
        samples_per_band=args.samples_per_band,
        temperature_scale=args.temperature_scale,
    )

    args.output_dir.mkdir(parents=True, exist_ok=True)
    stem = "plant_collapse_random_seed{}_n{}".format(args.seed, args.samples_per_band)
    json_path = args.output_dir / "{}.json".format(stem)
    csv_path = args.output_dir / "{}.csv".format(stem)

    json_path.write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")
    _write_csv(summary, csv_path)
    _print_human_summary(summary)
    print("json={}".format(json_path))
    print("csv={}".format(csv_path))


if __name__ == "__main__":
    main()
