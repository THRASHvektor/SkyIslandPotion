from __future__ import annotations

import json
import sys

from soft_ue_cli.client import call_tool


SCRIPT_PATH = r"C:\Users\12542\Documents\Unreal Projects\SkyIslandPotion\Tools\IslandMeshGen\ue_import_obj_and_spawn.py"

PRESETS = {
    "tiny": {
        "source_obj": "C:/Users/12542/Documents/Unreal Projects/SkyIslandPotion/Tools/IslandMeshGen/output/plant_regroup/CrownLily_local-upload-mr9cc1z8-Meshy_AI_Flamebound_Scepter_1783275149_part-segm-Meshy_AI_Fl/07_ue_test/tiny_import_probe.obj",
        "destination_path": "/Game/AIGC/Plants/CrownLily/C0_Smoke",
        "destination_name": "SM_TinyImportProbe",
        "label": "SIP_AIGC_TinyImportProbe",
        "tag": "AIGCTinyImportProbe",
        "location": [-1320.0, -520.0, 220.0],
        "rotation": [0.0, 0.0, 0.0],
    },
    "proxy": {
        "source_obj": "C:/Users/12542/Documents/Unreal Projects/SkyIslandPotion/Tools/IslandMeshGen/output/plant_regroup/CrownLily_local-upload-mr9cc1z8-Meshy_AI_Flamebound_Scepter_1783275149_part-segm-Meshy_AI_Fl/07_ue_test/CrownLily_C0_SourceProxy_25k.obj",
        "destination_path": "/Game/AIGC/Plants/CrownLily/C0_Smoke",
        "destination_name": "SM_CrownLily_C0_SourceProxy_25k",
        "label": "SIP_AIGC_CrownLily_C0_OBJProxySmoke",
        "tag": "AIGCPlantC0OBJProxySmoke",
        "location": [-1040.0, -520.0, 220.0],
        "rotation": [0.0, -18.0, 0.0],
    },
}


def main() -> int:
    preset = sys.argv[1] if len(sys.argv) > 1 else "proxy"
    if preset not in PRESETS:
        raise SystemExit(f"Unknown preset: {preset}. Use one of {sorted(PRESETS)}")
    result = call_tool(
        "run-python-script",
        {"script_path": SCRIPT_PATH, "arguments": PRESETS[preset]},
        timeout=180,
    )
    print(json.dumps(result, indent=2, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
