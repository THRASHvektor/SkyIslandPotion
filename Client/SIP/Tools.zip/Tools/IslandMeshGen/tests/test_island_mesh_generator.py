import tempfile
import unittest
import sys
import math
import statistics
from dataclasses import replace
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from island_mesh_generator import (
    bake_quality_profile,
    build_semantic_terrain_field_from_layout,
    generate_island_mesh,
    generate_island_mesh_from_layout,
    material_for_terrain_field_face,
    terrain_field_preview_payload,
    write_obj,
    _fire_lava_outer_scallop_strength,
    _fire_lava_side_overflow_strengths,
    _fire_lava_side_tongue_cooling_rib_strength,
    _path_strength,
    _terrain_detail_height,
)
from semantic_layout import IslandLayout, default_layout


TOP_SURFACE_MATERIALS = {"M_TopGrass", "M_AshPlateau"}


def _is_top_surface_material(material):
    return material in TOP_SURFACE_MATERIALS


def _top_vertex_indices(mesh):
    return {
        index
        for material, face in mesh.faces
        if material in TOP_SURFACE_MATERIALS | {"M_PathDirt", "M_ElementCrack"}
        for index in face
    }


def _top_z_values(mesh):
    return [mesh.vertices[index - 1][2] for index in _top_vertex_indices(mesh)]


def _radial_top_z_values(mesh, radius_m, min_alpha, max_alpha):
    radius_cm = radius_m * 100.0
    values = []
    for index in _top_vertex_indices(mesh):
        x, y, z = mesh.vertices[index - 1]
        radial_alpha = ((x * x + y * y) ** 0.5) / radius_cm
        if min_alpha <= radial_alpha <= max_alpha:
            values.append(z)
    return values


def _top_vertices_in_band(mesh, radius_m, min_alpha, max_alpha):
    radius_cm = radius_m * 100.0
    vertices = []
    for index in _top_vertex_indices(mesh):
        x, y, z = mesh.vertices[index - 1]
        radial_alpha = ((x * x + y * y) ** 0.5) / radius_cm
        if min_alpha <= radial_alpha <= max_alpha:
            vertices.append((x, y, z))
    return vertices


def _path_z_values(mesh, radius_m, min_alpha, max_alpha, half_width_radians):
    radius_cm = radius_m * 100.0
    values = []
    for index in _top_vertex_indices(mesh):
        x, y, z = mesh.vertices[index - 1]
        radial_alpha = ((x * x + y * y) ** 0.5) / radius_cm
        angle = abs(math.atan2(y, x))
        if min_alpha <= radial_alpha <= max_alpha and angle <= half_width_radians:
            values.append(z)
    return values


def _terrain_material_components(field, material_name):
    materials = {
        (ring, index): material_for_terrain_field_face(field, ring, index)
        for ring in range(1, field.rings + 1)
        for index in range(field.radial_segments)
    }
    components = []
    seen = set()
    for cell, material in materials.items():
        if material != material_name or cell in seen:
            continue
        stack = [cell]
        seen.add(cell)
        component = []
        while stack:
            ring, index = stack.pop()
            component.append((ring, index))
            for next_ring, next_index in (
                (ring - 1, index),
                (ring + 1, index),
                (ring, (index - 1) % field.radial_segments),
                (ring, (index + 1) % field.radial_segments),
            ):
                if next_ring < 1 or next_ring > field.rings:
                    continue
                neighbor = (next_ring, next_index)
                if neighbor in seen or materials.get(neighbor) != material_name:
                    continue
                seen.add(neighbor)
                stack.append(neighbor)
        components.append(component)
    return components


def _with_landmark(layout, landmark_id, **changes):
    return replace(
        layout,
        landmarks=tuple(
            replace(landmark, **changes) if landmark.id == landmark_id else landmark
            for landmark in layout.landmarks
        ),
    )


def _with_path(layout, path_id, **changes):
    return replace(
        layout,
        paths=tuple(
            replace(path, **changes) if path.id == path_id else path
            for path in layout.paths
        ),
    )


def _with_process(layout, **changes):
    process = dict(layout.process)
    process.update(changes)
    return replace(layout, process=process)


def _rim_peak_radius(mesh, radius_m):
    radius_cm = radius_m * 100.0
    candidates = []
    for index in _top_vertex_indices(mesh):
        x, y, z = mesh.vertices[index - 1]
        radial_alpha = ((x * x + y * y) ** 0.5) / radius_cm
        if 0.16 <= radial_alpha <= 0.58:
            candidates.append((z, radial_alpha))
    return max(candidates)[1]


def _material_faces_in_radial_band(mesh, material_name, radius_m, min_alpha, max_alpha):
    radius_cm = radius_m * 100.0
    faces = []
    for material, face in mesh.faces:
        if material != material_name:
            continue
        cx = sum(mesh.vertices[index - 1][0] for index in face) / len(face)
        cy = sum(mesh.vertices[index - 1][1] for index in face) / len(face)
        radial_alpha = ((cx * cx + cy * cy) ** 0.5) / radius_cm
        if min_alpha <= radial_alpha <= max_alpha:
            faces.append(face)
    return faces


def _material_face_radial_spans(mesh, material_name, radius_m):
    radius_cm = radius_m * 100.0
    spans = []
    for material, face in mesh.faces:
        if material != material_name:
            continue
        radii = [
            math.hypot(mesh.vertices[index - 1][0], mesh.vertices[index - 1][1]) / radius_cm
            for index in face
        ]
        spans.append(max(radii) - min(radii))
    return spans


def _material_face_outer_radii_with_inner_anchor(mesh, material_name, radius_m, inner_alpha):
    radius_cm = radius_m * 100.0
    outer_radii = []
    for material, face in mesh.faces:
        if material != material_name:
            continue
        radii = [
            math.hypot(mesh.vertices[index - 1][0], mesh.vertices[index - 1][1]) / radius_cm
            for index in face
        ]
        if min(radii) <= inner_alpha:
            outer_radii.append(max(radii))
    return outer_radii


def _fire_cliff_skirt_column_deltas(mesh, radial_segments, rings, radius_m):
    radius_cm = radius_m * 100.0
    top_vertex_count = 1 + rings * radial_segments
    columns = [[] for _ in range(radial_segments)]

    for material, face in mesh.faces:
        if material != "M_CliffRock" or not any(vertex > top_vertex_count for vertex in face):
            continue
        vertices = [mesh.vertices[index - 1] for index in face]
        center_x = sum(vertex[0] for vertex in vertices) / len(vertices)
        center_y = sum(vertex[1] for vertex in vertices) / len(vertices)
        center_z = sum(vertex[2] for vertex in vertices) / len(vertices)
        angle = math.atan2(center_y, center_x)
        if angle < 0.0:
            angle += math.tau
        column = int(angle / math.tau * radial_segments) % radial_segments
        radial_alpha = math.hypot(center_x, center_y) / radius_cm
        columns[column].append((center_z / radius_cm, radial_alpha))

    height_deltas = []
    radial_deltas = []
    for column in range(radial_segments):
        current = sorted(columns[column], key=lambda item: item[0], reverse=True)
        next_column = sorted(columns[(column + 1) % radial_segments], key=lambda item: item[0], reverse=True)
        if len(current) != 3 or len(next_column) != 3:
            continue
        height_deltas.append(sum(abs(current[index][0] - next_column[index][0]) for index in range(3)) / 3)
        radial_deltas.append(sum(abs(current[index][1] - next_column[index][1]) for index in range(3)) / 3)

    return height_deltas, radial_deltas


def _longest_run_below(values, threshold):
    if not values:
        return 0

    doubled = list(values) + list(values)
    longest = 0
    current = 0
    for value in doubled:
        if value < threshold:
            current += 1
            longest = max(longest, current)
        else:
            current = 0
        if current >= len(values):
            return len(values)
    return min(longest, len(values))


def _longest_true_run(values):
    if not values:
        return 0

    doubled = list(values) + list(values)
    longest = 0
    current = 0
    for value in doubled:
        if value:
            current += 1
            longest = max(longest, current)
        else:
            current = 0
        if current >= len(values):
            return len(values)
    return min(longest, len(values))


def _top_material_faces_in_approach_mouth(mesh, material_name, radius_m, min_alpha, max_angle):
    radius_cm = radius_m * 100.0
    faces = []
    for material, face in mesh.faces:
        if material != material_name or material not in TOP_SURFACE_MATERIALS | {"M_PathDirt", "M_ElementCrack"}:
            continue
        cx = sum(mesh.vertices[index - 1][0] for index in face) / len(face)
        cy = sum(mesh.vertices[index - 1][1] for index in face) / len(face)
        radial_alpha = ((cx * cx + cy * cy) ** 0.5) / radius_cm
        angle = abs(math.atan2(cy, cx))
        if radial_alpha >= min_alpha and angle <= max_angle:
            faces.append(face)
    return faces


def _outer_radius_deltas_m(mesh, radial_segments, rings):
    start = 1 + (rings - 1) * radial_segments
    outer = [mesh.vertices[start + index] for index in range(radial_segments)]
    return [
        abs(
            math.hypot(outer[index][0], outer[index][1])
            - math.hypot(outer[(index + 1) % radial_segments][0], outer[(index + 1) % radial_segments][1])
        ) / 100.0
        for index in range(radial_segments)
    ]


def _top_angular_height_deltas(mesh, radial_segments, rings):
    deltas = []
    for ring in range(1, rings + 1):
        start = 1 + (ring - 1) * radial_segments
        for index in range(radial_segments):
            z = mesh.vertices[start + index][2]
            next_z = mesh.vertices[start + ((index + 1) % radial_segments)][2]
            deltas.append(abs(z - next_z))
    return deltas


def _top_mesh_height_deltas_m(a, b, radial_segments, rings):
    deltas = []
    for ring in range(1, rings + 1):
        start = 1 + (ring - 1) * radial_segments
        for index in range(radial_segments):
            vertex_index = start + index
            deltas.append(abs(b.vertices[vertex_index][2] - a.vertices[vertex_index][2]) / 100.0)
    return deltas


def _percentile(values, percentile):
    ordered = sorted(values)
    return ordered[min(len(ordered) - 1, int(len(ordered) * percentile))]


class IslandMeshGeneratorTests(unittest.TestCase):
    def test_generates_human_scale_mesh_with_material_groups(self):
        mesh = generate_island_mesh(radius_m=30.0, seed=1234, radial_segments=24)

        self.assertGreater(len(mesh.vertices), 50)
        self.assertGreater(len(mesh.faces), 50)
        self.assertGreaterEqual(len(mesh.materials), 4)

        xs = [vertex[0] for vertex in mesh.vertices]
        ys = [vertex[1] for vertex in mesh.vertices]
        width_m = (max(xs) - min(xs)) / 100.0
        depth_m = (max(ys) - min(ys)) / 100.0

        self.assertGreater(width_m, 50.0)
        self.assertLess(width_m, 75.0)
        self.assertGreater(depth_m, 50.0)
        self.assertLess(depth_m, 75.0)

    def test_writes_obj_with_unreal_friendly_material_slots(self):
        mesh = generate_island_mesh(radius_m=20.0, seed=7, radial_segments=16)

        with tempfile.TemporaryDirectory() as tmp:
            output_path = Path(tmp) / "SM_ProcIsland_Test.obj"
            write_obj(mesh, output_path)
            text = output_path.read_text(encoding="utf-8")

        self.assertIn("o SM_ProcIsland", text)
        self.assertIn("usemtl M_TopGrass", text)
        self.assertIn("usemtl M_CliffRock", text)
        self.assertIn("usemtl M_UndersideRock", text)
        self.assertIn("usemtl M_PathDirt", text)
        self.assertIn("v ", text)
        self.assertIn("f ", text)

    def test_writes_obj_with_explicit_vertex_normals_for_unreal_import(self):
        mesh = generate_island_mesh(radius_m=20.0, seed=7, radial_segments=16)

        with tempfile.TemporaryDirectory() as tmp:
            output_path = Path(tmp) / "SM_ProcIsland_Test.obj"
            write_obj(mesh, output_path)
            lines = output_path.read_text(encoding="utf-8").splitlines()

        normal_lines = [line for line in lines if line.startswith("vn ")]
        face_lines = [line for line in lines if line.startswith("f ")]

        self.assertEqual(len(normal_lines), len(mesh.vertices))
        self.assertTrue(any("//" in line for line in face_lines))

    def test_heightfield_terrain_has_non_flat_topography(self):
        mesh = generate_island_mesh(radius_m=30.0, seed=99, radial_segments=64, rings=14)
        top_z_values = _top_z_values(mesh)

        self.assertGreater(max(top_z_values) - min(top_z_values), 620.0)

    def test_generates_stronger_vertical_silhouette(self):
        mesh = generate_island_mesh(radius_m=30.0, seed=99, radial_segments=64, rings=14, biome="fire")
        z_values = [vertex[2] for vertex in mesh.vertices]

        self.assertGreater(max(z_values) - min(z_values), 3400.0)

    def test_generates_ravine_material_band(self):
        mesh = generate_island_mesh(radius_m=30.0, seed=99, radial_segments=64, rings=14)
        ravine_faces = [face for material, face in mesh.faces if material == "M_ElementCrack"]

        self.assertGreater(len(ravine_faces), 20)

    def test_biome_presets_change_terrain_identity(self):
        forest = generate_island_mesh(radius_m=25.0, seed=555, radial_segments=64, rings=14, biome="forest")
        fire = generate_island_mesh(radius_m=25.0, seed=555, radial_segments=64, rings=14, biome="fire")
        ice = generate_island_mesh(radius_m=25.0, seed=555, radial_segments=64, rings=14, biome="ice")

        forest_cracks = sum(1 for material, _ in forest.faces if material == "M_ElementCrack")
        fire_cracks = sum(1 for material, _ in fire.faces if material == "M_ElementCrack")
        ice_path = sum(1 for material, _ in ice.faces if material == "M_PathDirt")
        forest_path = sum(1 for material, _ in forest.faces if material == "M_PathDirt")
        forest_z = [vertex[2] for vertex in forest.vertices]
        fire_z = [vertex[2] for vertex in fire.vertices]

        self.assertGreater(fire_cracks, forest_cracks)
        self.assertGreater(ice_path, forest_path)
        self.assertGreater(max(fire_z) - min(fire_z), (max(forest_z) - min(forest_z)) * 1.15)

    def test_fire_has_stronger_macro_relief_than_ice_and_forest(self):
        forest = generate_island_mesh(radius_m=25.0, seed=888, radial_segments=64, rings=14, biome="forest")
        fire = generate_island_mesh(radius_m=25.0, seed=888, radial_segments=64, rings=14, biome="fire")
        ice = generate_island_mesh(radius_m=25.0, seed=888, radial_segments=64, rings=14, biome="ice")

        def top_height_range(mesh):
            z_values = _top_z_values(mesh)
            return max(z_values) - min(z_values)

        self.assertGreater(top_height_range(fire), top_height_range(forest))
        self.assertGreater(top_height_range(fire), top_height_range(ice))

    def test_ice_has_fewer_cracks_than_fire(self):
        fire = generate_island_mesh(radius_m=25.0, seed=321, radial_segments=64, rings=14, biome="fire")
        ice = generate_island_mesh(radius_m=25.0, seed=321, radial_segments=64, rings=14, biome="ice")

        fire_cracks = sum(1 for material, _ in fire.faces if material == "M_ElementCrack")
        ice_cracks = sum(1 for material, _ in ice.faces if material == "M_ElementCrack")

        self.assertGreater(fire_cracks, ice_cracks * 2)

    def test_fire_uses_fewer_deeper_main_ravines_instead_of_dense_spikes(self):
        forest = generate_island_mesh(radius_m=25.0, seed=555, radial_segments=64, rings=14, biome="forest")
        fire = generate_island_mesh(radius_m=25.0, seed=555, radial_segments=64, rings=14, biome="fire")

        fire_cracks = sum(1 for material, _ in fire.faces if material == "M_ElementCrack")
        forest_span = max(_top_z_values(forest)) - min(_top_z_values(forest))
        fire_span = max(_top_z_values(fire)) - min(_top_z_values(fire))

        self.assertLessEqual(fire_cracks, 130)
        self.assertGreater(fire_span, forest_span * 1.8)

    def test_ice_keeps_a_flat_playable_center_between_crystal_spires(self):
        forest = generate_island_mesh(radius_m=25.0, seed=555, radial_segments=64, rings=14, biome="forest")
        ice = generate_island_mesh(radius_m=25.0, seed=555, radial_segments=64, rings=14, biome="ice")

        forest_inner = _radial_top_z_values(forest, 25.0, 0.0, 0.24)
        ice_inner = _radial_top_z_values(ice, 25.0, 0.0, 0.24)

        self.assertLess(max(ice_inner) - min(ice_inner), 260.0)
        self.assertLess(max(ice_inner) - min(ice_inner), (max(forest_inner) - min(forest_inner)) * 0.6)

    def test_forest_outer_band_forms_readable_terrace_shelves(self):
        forest = generate_island_mesh(radius_m=25.0, seed=555, radial_segments=64, rings=14, biome="forest")
        outer_values = _radial_top_z_values(forest, 25.0, 0.45, 0.88)

        terrace_step_cm = 160.0
        aligned = [z for z in outer_values if abs(z - round(z / terrace_step_cm) * terrace_step_cm) < 18.0]

        self.assertGreater(len(aligned) / len(outer_values), 0.36)

    def test_fire_has_a_readable_central_volcano_crater(self):
        fire = generate_island_mesh(radius_m=25.0, seed=555, radial_segments=64, rings=14, biome="fire")

        crater_floor = _radial_top_z_values(fire, 25.0, 0.0, 0.16)
        volcano_rim = _radial_top_z_values(fire, 25.0, 0.22, 0.42)
        outer_field = _radial_top_z_values(fire, 25.0, 0.55, 0.82)

        self.assertGreater(max(volcano_rim), max(outer_field) + 520.0)
        self.assertGreater(max(volcano_rim) - min(crater_floor), 820.0)

    def test_ice_has_tall_primary_crystal_spires(self):
        ice = generate_island_mesh(radius_m=25.0, seed=555, radial_segments=64, rings=14, biome="ice")
        top_z_values = _top_z_values(ice)
        spire_vertices = [z for _, _, z in _top_vertices_in_band(ice, 25.0, 0.24, 0.72) if z > 880.0]

        self.assertGreater(max(top_z_values), 1200.0)
        self.assertGreaterEqual(len(spire_vertices), 6)

    def test_forest_cliff_side_has_tree_hole_openings(self):
        forest = generate_island_mesh(radius_m=25.0, seed=555, radial_segments=64, rings=14, biome="forest")
        cliff_faces = [face for material, face in forest.faces if material == "M_CliffRock"]

        self.assertLessEqual(len(cliff_faces), 52)
        self.assertGreaterEqual(64 - len(cliff_faces), 12)

    def test_generates_200m_layout_islands(self):
        mesh = generate_island_mesh(radius_m=100.0, seed=1001, radial_segments=96, rings=14, biome="forest")
        xs = [vertex[0] for vertex in mesh.vertices]
        ys = [vertex[1] for vertex in mesh.vertices]
        width_m = (max(xs) - min(xs)) / 100.0
        depth_m = (max(ys) - min(ys)) / 100.0

        self.assertGreater(width_m, 185.0)
        self.assertLess(width_m, 230.0)
        self.assertGreater(depth_m, 185.0)
        self.assertLess(depth_m, 230.0)

    def test_fire_keeps_a_walkable_approach_path_to_the_volcano(self):
        fire = generate_island_mesh(radius_m=100.0, seed=2002, radial_segments=96, rings=14, biome="fire")
        path_values = _path_z_values(fire, 100.0, 0.34, 0.92, 0.18)
        volcano_rim = _radial_top_z_values(fire, 100.0, 0.22, 0.42)

        self.assertGreater(len(path_values), 16)
        self.assertLess(max(path_values) - min(path_values), 900.0)
        self.assertLess(max(path_values), max(volcano_rim) - 360.0)

    def test_fire_layout_volcano_dominance_controls_crater_rim_height(self):
        layout = default_layout("fire", seed=2002)
        low = _with_landmark(layout, "central_volcano", dominance=0.45)
        high = _with_landmark(layout, "central_volcano", dominance=1.05)

        low_mesh = generate_island_mesh_from_layout(low, radial_segments=96, rings=14)
        high_mesh = generate_island_mesh_from_layout(high, radial_segments=96, rings=14)
        low_rim = _radial_top_z_values(low_mesh, low.radius_m, 0.22, 0.42)
        high_rim = _radial_top_z_values(high_mesh, high.radius_m, 0.22, 0.42)

        self.assertGreater(max(high_rim), max(low_rim) + 420.0)

    def test_fire_layout_main_path_width_controls_path_material_coverage(self):
        layout = default_layout("fire", seed=2002)
        narrow = _with_path(layout, "main_approach", width=0.08)
        wide = _with_path(layout, "main_approach", width=0.22)

        narrow_mesh = generate_island_mesh_from_layout(narrow, radial_segments=96, rings=14)
        wide_mesh = generate_island_mesh_from_layout(wide, radial_segments=96, rings=14)
        narrow_path_faces = sum(1 for material, _ in narrow_mesh.faces if material == "M_PathDirt")
        wide_path_faces = sum(1 for material, _ in wide_mesh.faces if material == "M_PathDirt")

        self.assertGreater(wide_path_faces, narrow_path_faces + 18)

    def test_fire_layout_main_path_can_cover_a_broad_exit_mouth(self):
        old_max_strength = _path_strength(0.78, 0.24, "fire", 0.26)
        broad_exit_strength = _path_strength(0.78, 0.24, "fire", 0.55)

        self.assertLess(old_max_strength, 0.05)
        self.assertGreater(broad_exit_strength, 0.55)

    def test_fire_layout_max_main_path_reaches_the_outer_exit_lip(self):
        layout = default_layout("fire", seed=2002)
        broad_exit = _with_path(layout, "main_approach", width=0.55)

        mesh = generate_island_mesh_from_layout(broad_exit, radial_segments=96, rings=14)
        grass_left_in_mouth = _top_material_faces_in_approach_mouth(
            mesh,
            "M_TopGrass",
            broad_exit.radius_m,
            min_alpha=0.74,
            max_angle=0.56,
        )

        self.assertEqual(grass_left_in_mouth, [])

    def test_fire_layout_production_quality_uses_denser_detail_topology(self):
        layout = default_layout("fire", seed=2002)
        draft_profile = bake_quality_profile("draft")
        production_profile = bake_quality_profile("production")

        draft = generate_island_mesh_from_layout(
            layout,
            radial_segments=draft_profile["segments"],
            rings=draft_profile["rings"],
            bake_quality="draft",
        )
        production = generate_island_mesh_from_layout(layout, bake_quality="production")

        self.assertEqual(draft_profile["detail_intensity"], 0.0)
        self.assertGreater(production_profile["detail_intensity"], draft_profile["detail_intensity"])
        self.assertGreater(len(production.vertices), len(draft.vertices) * 3)

    def test_fire_default_layout_exposes_artist_process_controls(self):
        layout = default_layout("fire", seed=2002)

        self.assertEqual(layout.process["detail_energy"], 1.0)
        self.assertEqual(layout.process["erosion_age"], 0.45)
        self.assertEqual(layout.process["deposition_weight"], 0.55)
        self.assertEqual(type(layout).from_dict(layout.to_dict()).process["detail_energy"], 1.0)

    def test_detail_energy_artist_control_changes_high_quality_surface_roughness(self):
        layout = default_layout("fire", seed=2002)
        quiet = _with_process(layout, detail_energy=0.15)
        energetic = _with_process(layout, detail_energy=1.35)

        quiet_field = build_semantic_terrain_field_from_layout(quiet, radial_segments=96, rings=14, bake_quality="hero")
        energetic_field = build_semantic_terrain_field_from_layout(energetic, radial_segments=96, rings=14, bake_quality="hero")

        def surface_stats(field):
            values = [
                field.heights[ring][index]
                for ring in range(1, field.rings + 1)
                for index in range(field.radial_segments)
            ]
            return statistics.pstdev(values), max(values) - min(values)

        quiet_std, quiet_span = surface_stats(quiet_field)
        energetic_std, energetic_span = surface_stats(energetic_field)
        self.assertGreater(energetic_std, quiet_std + 18.0)
        self.assertGreater(energetic_span, quiet_span + 90.0)

    def test_terrain_detail_height_is_gated_by_semantic_playability_masks(self):
        controls = {
            "terrain_detail_intensity": 0.72,
            "detail_energy": 1.0,
            "volcano_radius": 0.42,
            "lava_channel_count": 3,
            "path_width": 0.72 * 6.0,
        }

        path_detail = abs(_terrain_detail_height(0.78, 0.0, 2002, "fire", controls))
        side_detail = abs(_terrain_detail_height(0.78, math.pi / 2.0, 2002, "fire", controls))
        crater_interior_detail = abs(_terrain_detail_height(0.1, 1.0, 2002, "fire", controls))

        self.assertLess(path_detail, side_detail * 0.55)
        self.assertLess(crater_interior_detail, 14.0)

    def test_erosion_and_deposition_process_controls_shape_lava_and_talus_zones(self):
        layout = default_layout("fire", seed=2002)
        young = _with_process(layout, erosion_age=0.05, deposition_weight=0.05)
        old = _with_process(layout, erosion_age=1.0, deposition_weight=1.0)

        young_field = build_semantic_terrain_field_from_layout(young, radial_segments=96, rings=14, bake_quality="hero")
        old_field = build_semantic_terrain_field_from_layout(old, radial_segments=96, rings=14, bake_quality="hero")
        lava_ring = round(old_field.rings * 0.78)
        lava_index = round(0.42 / math.tau * old_field.radial_segments)
        talus_ring = round(old_field.rings * 0.86)
        talus_index = old_field.radial_segments // 4

        self.assertGreater(old_field.lava_flow_mask[lava_ring][lava_index], young_field.lava_flow_mask[lava_ring][lava_index] + 0.12)
        self.assertGreater(old_field.talus_mask[talus_ring][talus_index], young_field.talus_mask[talus_ring][talus_index] + 0.12)
        self.assertLess(old_field.heights[lava_ring][lava_index], young_field.heights[lava_ring][lava_index] - 25.0)
        self.assertGreater(old_field.heights[talus_ring][talus_index], young_field.heights[talus_ring][talus_index] + 20.0)

    def test_erosion_and_deposition_remain_visible_when_detail_energy_is_quiet(self):
        layout = default_layout("fire", seed=2002)
        quiet_process = _with_process(layout, detail_energy=0.0, erosion_age=0.05, deposition_weight=0.05)
        weathered_process = _with_process(layout, detail_energy=0.0, erosion_age=1.0, deposition_weight=1.0)

        quiet_field = build_semantic_terrain_field_from_layout(quiet_process, radial_segments=96, rings=14, bake_quality="production")
        weathered_field = build_semantic_terrain_field_from_layout(weathered_process, radial_segments=96, rings=14, bake_quality="production")
        lava_ring = round(weathered_field.rings * 0.78)
        lava_index = round(0.42 / math.tau * weathered_field.radial_segments)
        talus_ring = round(weathered_field.rings * 0.86)
        talus_index = weathered_field.radial_segments // 4

        self.assertLess(weathered_field.heights[lava_ring][lava_index], quiet_field.heights[lava_ring][lava_index] - 80.0)
        self.assertGreater(weathered_field.heights[talus_ring][talus_index], quiet_field.heights[talus_ring][talus_index] + 45.0)

    def test_process_controls_create_visible_meter_scale_mesh_changes(self):
        layout = default_layout("fire", seed=2002)
        quiet = _with_process(layout, detail_energy=0.15, erosion_age=0.05, deposition_weight=0.05)
        strong = _with_process(layout, detail_energy=1.35, erosion_age=1.0, deposition_weight=1.0)
        profile = bake_quality_profile("production")

        quiet_mesh = generate_island_mesh_from_layout(quiet, bake_quality="production")
        strong_mesh = generate_island_mesh_from_layout(strong, bake_quality="production")
        deltas_m = _top_mesh_height_deltas_m(
            quiet_mesh,
            strong_mesh,
            int(profile["segments"]),
            int(profile["rings"]),
        )

        self.assertGreater(statistics.mean(deltas_m), 0.85)
        self.assertGreater(_percentile(deltas_m, 0.95), 2.2)
        self.assertLess(max(deltas_m), 7.5)

    def test_fire_layout_hero_quality_keeps_broken_outline_from_turning_into_dense_teeth(self):
        layout = default_layout("fire", seed=2002)
        hero_profile = bake_quality_profile("hero")
        mesh = generate_island_mesh_from_layout(layout, bake_quality="hero")
        deltas = _outer_radius_deltas_m(mesh, int(hero_profile["segments"]), int(hero_profile["rings"]))

        self.assertLess(max(deltas), 8.0)
        self.assertLess(_percentile(deltas, 0.95), 5.0)

    def test_fire_layout_hero_quality_reduces_high_frequency_top_spikes(self):
        layout = default_layout("fire", seed=2002)
        hero_profile = bake_quality_profile("hero")
        mesh = generate_island_mesh_from_layout(layout, bake_quality="hero")
        angular_deltas = _top_angular_height_deltas(mesh, int(hero_profile["segments"]), int(hero_profile["rings"]))
        top_z_values = _top_z_values(mesh)

        self.assertLess(_percentile(angular_deltas, 0.99), 560.0)
        self.assertGreater(max(top_z_values) - min(top_z_values), 3000.0)

    def test_hero_field_relaxes_rim_sawtooth_without_filling_lava_channel(self):
        layout = default_layout("fire", seed=2002)
        field = build_semantic_terrain_field_from_layout(layout, radial_segments=96, rings=14, bake_quality="hero")
        rim_ring = round(field.rings * 0.42)
        rim_deltas = [
            abs(field.heights[rim_ring][index] - field.heights[rim_ring][(index + 1) % field.radial_segments])
            for index in range(field.radial_segments)
        ]
        lava_ring = round(field.rings * 0.78)
        lava_index = round(0.42 / math.tau * field.radial_segments)
        lava_center = field.heights[lava_ring][lava_index]
        lava_shoulders = (
            field.heights[lava_ring][(lava_index - 3) % field.radial_segments],
            field.heights[lava_ring][(lava_index + 3) % field.radial_segments],
        )

        self.assertLess(_percentile(rim_deltas, 0.95), 560.0)
        self.assertGreater(min(lava_shoulders) - lava_center, 250.0)

    def test_fire_hero_volcano_rim_has_sector_collapse_asymmetry(self):
        layout = default_layout("fire", seed=2002)
        field = build_semantic_terrain_field_from_layout(layout, bake_quality="hero")
        rim_ring = round(field.rings * 0.45)
        sector_count = 8
        sector_means = []
        for sector in range(sector_count):
            start = sector * field.radial_segments // sector_count
            end = (sector + 1) * field.radial_segments // sector_count
            sector_means.append(statistics.mean(field.heights[rim_ring][start:end]))

        high_rim_sectors = sorted(sector_means)[2:]
        self.assertGreater(max(high_rim_sectors) - min(high_rim_sectors), 260.0)

    def test_fire_hero_volcano_rim_peak_radius_varies_by_sector(self):
        layout = default_layout("fire", seed=2002)
        field = build_semantic_terrain_field_from_layout(layout, bake_quality="hero")
        sector_count = 8
        peak_radii = []
        for sector in range(sector_count):
            start = sector * field.radial_segments // sector_count
            end = (sector + 1) * field.radial_segments // sector_count
            best_height = None
            best_ring = 0
            for ring in range(round(field.rings * 0.30), round(field.rings * 0.58) + 1):
                sector_height = statistics.mean(field.heights[ring][start:end])
                if best_height is None or sector_height > best_height:
                    best_height = sector_height
                    best_ring = ring
            peak_radii.append(best_ring / field.rings)

        self.assertGreater(max(peak_radii) - min(peak_radii), 0.08)

    def test_fire_hero_main_path_has_center_lane_and_rough_shoulders(self):
        layout = default_layout("fire", seed=2002)
        field = build_semantic_terrain_field_from_layout(layout, bake_quality="hero")
        ring = round(field.rings * 0.72)
        center = 0
        shoulder = round(field.radial_segments * 0.045)
        side = round(field.radial_segments * 0.09)
        center_slope = field.slope_mask[ring][center]
        shoulder_slope = max(field.slope_mask[ring][shoulder], field.slope_mask[ring][-shoulder])
        side_slope = max(field.slope_mask[ring][side], field.slope_mask[ring][-side])

        self.assertLess(center_slope, 0.18)
        self.assertGreater(shoulder_slope, center_slope + 0.14)
        self.assertGreater(side_slope, center_slope + 0.22)

    def test_fire_hero_default_path_material_stays_on_center_lane(self):
        layout = default_layout("fire", seed=2002)
        field = build_semantic_terrain_field_from_layout(layout, bake_quality="hero")
        ring = round(field.rings * 0.72)
        center = 0
        shoulder = round(field.radial_segments * 0.045)

        self.assertGreater(field.path_mask[ring][center], 0.72)
        self.assertLess(field.path_mask[ring][shoulder], 0.58)
        self.assertEqual(material_for_terrain_field_face(field, ring, center), "M_PathDirt")
        self.assertNotEqual(material_for_terrain_field_face(field, ring, shoulder), "M_PathDirt")

    def test_fire_hero_crater_loop_material_avoids_steep_wall_faces(self):
        layout = default_layout("fire", seed=2002)
        field = build_semantic_terrain_field_from_layout(layout, bake_quality="hero")
        candidates = [
            (field.slope_mask[ring][index], ring, index)
            for ring in range(round(field.rings * 0.30), round(field.rings * 0.52) + 1)
            for index in range(field.radial_segments)
            if field.crater_loop_mask[ring][index] > 0.50
            and field.path_mask[ring][index] < 0.20
            and field.slope_mask[ring][index] > 0.72
        ]

        self.assertTrue(candidates)
        _slope, ring, index = max(candidates)
        self.assertNotEqual(material_for_terrain_field_face(field, ring, index), "M_PathDirt")

    def test_fire_hero_lava_channel_has_inset_center_and_cooling_shoulders(self):
        layout = default_layout("fire", seed=2002)
        field = build_semantic_terrain_field_from_layout(layout, bake_quality="hero")
        ring = round(field.rings * 0.76)
        center = round(0.42 / math.tau * field.radial_segments)
        offset = round(field.radial_segments * 0.018)
        center_height = field.heights[ring][center]
        shoulder_height = min(
            field.heights[ring][(center - offset) % field.radial_segments],
            field.heights[ring][(center + offset) % field.radial_segments],
        )

        self.assertGreater(shoulder_height - center_height, 260.0)

    def test_fire_hero_lava_channels_breach_crater_rim_as_spillways(self):
        layout = default_layout("fire", seed=2002)
        field = build_semantic_terrain_field_from_layout(layout, bake_quality="hero")
        rim_ring = round(field.rings * float(field.controls["volcano_radius"]))
        shoulder_offset = round(field.radial_segments * 0.018)
        lava_count = int(field.controls["lava_channel_count"])
        channel_angles = [0.42 + math.tau * index / lava_count for index in range(lava_count)]

        for angle in channel_angles:
            signed_angle = abs(math.atan2(math.sin(angle), math.cos(angle)))
            if signed_angle < float(field.controls["path_width"]) * 1.25:
                continue

            center = round((angle % math.tau) / math.tau * field.radial_segments) % field.radial_segments
            center_height = field.heights[rim_ring][center]
            shoulder_average = (
                field.heights[rim_ring][(center - shoulder_offset) % field.radial_segments]
                + field.heights[rim_ring][(center + shoulder_offset) % field.radial_segments]
            ) * 0.5

            self.assertGreater(field.lava_mask[rim_ring][center], 0.10)
            self.assertGreater(shoulder_average - center_height, 220.0)

    def test_fire_demo_hero_four_lava_channels_have_rim_spillway_saddles(self):
        layout_path = Path(__file__).resolve().parents[1] / "layouts" / "fire_volcano_demo.json"
        layout = IslandLayout.from_json(layout_path.read_text(encoding="utf-8"))
        field = build_semantic_terrain_field_from_layout(layout, bake_quality="hero")
        rim_ring = round(field.rings * float(field.controls["volcano_radius"]))
        shoulder_offset = round(field.radial_segments * 0.018)
        lava_count = int(field.controls["lava_channel_count"])
        channel_angles = [0.42 + math.tau * index / lava_count for index in range(lava_count)]

        for angle in channel_angles:
            signed_angle = abs(math.atan2(math.sin(angle), math.cos(angle)))
            if signed_angle < float(field.controls["path_width"]) * 1.25:
                continue

            center = round((angle % math.tau) / math.tau * field.radial_segments) % field.radial_segments
            center_height = field.heights[rim_ring][center]
            shoulder_average = (
                field.heights[rim_ring][(center - shoulder_offset) % field.radial_segments]
                + field.heights[rim_ring][(center + shoulder_offset) % field.radial_segments]
            ) * 0.5

            self.assertGreater(field.lava_mask[rim_ring][center], 0.10)
            self.assertGreater(shoulder_average - center_height, 220.0)

    def test_fire_demo_hero_lava_channels_settle_into_continuous_terminal_fans(self):
        layout_path = Path(__file__).resolve().parents[1] / "layouts" / "fire_volcano_demo.json"
        layout = IslandLayout.from_json(layout_path.read_text(encoding="utf-8"))
        field = build_semantic_terrain_field_from_layout(layout, bake_quality="hero")
        lava_count = int(field.controls["lava_channel_count"])
        channel_angles = [0.42 + math.tau * index / lava_count for index in range(lava_count)]
        sample_rings = [round(field.rings * radial_alpha) for radial_alpha in (0.78, 0.84, 0.90, 0.94)]
        shoulder_offset = round(field.radial_segments * 0.026)

        for angle in channel_angles:
            signed_angle = abs(math.atan2(math.sin(angle), math.cos(angle)))
            if signed_angle < float(field.controls["path_width"]) * 1.25:
                continue

            center = round((angle % math.tau) / math.tau * field.radial_segments) % field.radial_segments
            center_heights = [field.heights[ring][center] for ring in sample_rings]
            radial_steps = [abs(center_heights[i + 1] - center_heights[i]) for i in range(len(center_heights) - 1)]
            terminal_ring = sample_rings[-1]
            terminal_shoulder = min(
                field.heights[terminal_ring][(center - shoulder_offset) % field.radial_segments],
                field.heights[terminal_ring][(center + shoulder_offset) % field.radial_segments],
            )

            self.assertLess(max(radial_steps), 820.0)
            self.assertGreater(terminal_shoulder - field.heights[terminal_ring][center], 420.0)

    def test_fire_demo_hero_terminal_lava_shoulders_weather_out_of_red_curtains(self):
        layout_path = Path(__file__).resolve().parents[1] / "layouts" / "fire_volcano_demo.json"
        layout = IslandLayout.from_json(layout_path.read_text(encoding="utf-8"))
        field = build_semantic_terrain_field_from_layout(layout, bake_quality="hero")
        lava_count = int(field.controls["lava_channel_count"])
        channel_angles = [0.42 + math.tau * index / lava_count for index in range(lava_count)]
        shoulder_offset = round(field.radial_segments * 0.026)
        shoulder_contrasts = []

        for angle in channel_angles:
            signed_angle = abs(math.atan2(math.sin(angle), math.cos(angle)))
            if signed_angle < float(field.controls["path_width"]) * 1.25:
                continue

            center = round((angle % math.tau) / math.tau * field.radial_segments) % field.radial_segments
            for ring in range(round(field.rings * 0.90), round(field.rings * 0.97) + 1):
                left = field.heights[ring][(center - shoulder_offset) % field.radial_segments]
                right = field.heights[ring][(center + shoulder_offset) % field.radial_segments]
                shoulder_contrasts.append(max(left, right) - field.heights[ring][center])

        self.assertGreater(_percentile(shoulder_contrasts, 0.20), 420.0)
        self.assertLess(_percentile(shoulder_contrasts, 0.90), 2200.0)

    def test_fire_demo_hero_lava_curtains_have_cooling_crust_breaks(self):
        layout_path = Path(__file__).resolve().parents[1] / "layouts" / "fire_volcano_demo.json"
        layout = IslandLayout.from_json(layout_path.read_text(encoding="utf-8"))
        field = build_semantic_terrain_field_from_layout(layout, bake_quality="hero")
        lava_count = int(field.controls["lava_channel_count"])
        path_width = float(field.controls["path_width"])
        channel_angles = [0.42 + math.tau * index / lava_count for index in range(lava_count)]
        longest_red_run = 0
        sampled_channels = 0

        for angle in channel_angles:
            signed_angle = abs(math.atan2(math.sin(angle), math.cos(angle)))
            if signed_angle < path_width * 1.25:
                continue

            sampled_channels += 1
            center = round((angle % math.tau) / math.tau * field.radial_segments) % field.radial_segments
            current_run = 0
            for ring in range(round(field.rings * 0.58), round(field.rings * 0.97) + 1):
                if material_for_terrain_field_face(field, ring, center) == "M_ElementCrack":
                    current_run += 1
                    longest_red_run = max(longest_red_run, current_run)
                else:
                    current_run = 0

        self.assertGreaterEqual(sampled_channels, 3)
        self.assertLessEqual(longest_red_run, 10)

    def test_fire_demo_hero_lava_cooling_crust_breaks_have_geometric_lips(self):
        layout_path = Path(__file__).resolve().parents[1] / "layouts" / "fire_volcano_demo.json"
        layout = IslandLayout.from_json(layout_path.read_text(encoding="utf-8"))
        field = build_semantic_terrain_field_from_layout(layout, bake_quality="hero")
        lava_count = int(field.controls["lava_channel_count"])
        path_width = float(field.controls["path_width"])
        channel_angles = [0.42 + math.tau * index / lava_count for index in range(lava_count)]
        lip_by_channel = []

        for angle in channel_angles:
            signed_angle = abs(math.atan2(math.sin(angle), math.cos(angle)))
            if signed_angle < path_width * 1.25:
                continue

            center = round((angle % math.tau) / math.tau * field.radial_segments) % field.radial_segments
            lips = []
            for ring in range(round(field.rings * 0.805), round(field.rings * 0.875) + 1):
                if material_for_terrain_field_face(field, ring, center) != "M_CliffRock":
                    continue
                height = field.heights[ring][center]
                radial_neighbor_plane = (
                    field.heights[ring - 1][center]
                    + field.heights[ring + 1][center]
                ) * 0.5
                lips.append(height - radial_neighbor_plane)

            if lips:
                lip_by_channel.append(max(lips))

        self.assertGreaterEqual(len(lip_by_channel), 3)
        self.assertGreaterEqual(min(lip_by_channel), 115.0)

    def test_fire_demo_hero_outer_basalt_shelves_break_into_broad_quiet_blocks(self):
        layout_path = Path(__file__).resolve().parents[1] / "layouts" / "fire_volcano_demo.json"
        layout = IslandLayout.from_json(layout_path.read_text(encoding="utf-8"))
        field = build_semantic_terrain_field_from_layout(layout, bake_quality="hero")
        quiet_windows_by_ring = []
        window_size = 24

        for radial_alpha in (0.74, 0.82, 0.90):
            ring = round(field.rings * radial_alpha)
            quiet_windows = 0
            for start in range(0, field.radial_segments, window_size // 2):
                indices = [(start + offset) % field.radial_segments for offset in range(window_size)]
                valid_indices = [
                    index
                    for index in indices
                    if max(field.path_mask[ring][index], field.lava_mask[ring][index], field.crater_loop_mask[ring][index]) <= 0.20
                ]
                if len(valid_indices) < window_size * 0.65:
                    continue

                heights = [field.heights[ring][index] for index in valid_indices]
                angular_deltas = [
                    abs(field.heights[ring][index] - field.heights[ring][(index + 1) % field.radial_segments])
                    for index in valid_indices
                    if max(
                        field.path_mask[ring][(index + 1) % field.radial_segments],
                        field.lava_mask[ring][(index + 1) % field.radial_segments],
                        field.crater_loop_mask[ring][(index + 1) % field.radial_segments],
                    ) <= 0.20
                ]
                if not angular_deltas:
                    continue

                if statistics.pstdev(heights) < 280.0 and _percentile(angular_deltas, 0.75) < 150.0:
                    quiet_windows += 1
            quiet_windows_by_ring.append(quiet_windows)

        self.assertGreaterEqual(quiet_windows_by_ring[0], 2)
        self.assertGreaterEqual(quiet_windows_by_ring[1], 4)
        self.assertGreaterEqual(quiet_windows_by_ring[2], 4)

    def test_fire_demo_hero_outer_apron_chatter_weathers_into_continuous_bands(self):
        layout_path = Path(__file__).resolve().parents[1] / "layouts" / "fire_volcano_demo.json"
        layout = IslandLayout.from_json(layout_path.read_text(encoding="utf-8"))
        field = build_semantic_terrain_field_from_layout(layout, bake_quality="hero")
        angular_deltas = []

        for ring in range(round(field.rings * 0.70), round(field.rings * 0.92) + 1):
            for index in range(field.radial_segments):
                next_index = (index + 1) % field.radial_segments
                semantic_guard = max(
                    field.path_mask[ring][index],
                    field.lava_mask[ring][index],
                    field.volcano_mask[ring][index],
                    field.crater_loop_mask[ring][index],
                    field.path_mask[ring][next_index],
                    field.lava_mask[ring][next_index],
                    field.volcano_mask[ring][next_index],
                    field.crater_loop_mask[ring][next_index],
                )
                if semantic_guard > 0.18:
                    continue
                angular_deltas.append(abs(field.heights[ring][index] - field.heights[ring][next_index]))

        self.assertGreater(len(angular_deltas), 3000)
        self.assertLess(_percentile(angular_deltas, 0.98), 248.0)

    def test_fire_demo_hero_lava_channels_branch_into_asymmetric_downstream_tongues(self):
        layout_path = Path(__file__).resolve().parents[1] / "layouts" / "fire_volcano_demo.json"
        layout = IslandLayout.from_json(layout_path.read_text(encoding="utf-8"))
        field = build_semantic_terrain_field_from_layout(layout, bake_quality="hero")
        lava_count = int(field.controls["lava_channel_count"])
        channel_angles = [0.42 + math.tau * index / lava_count for index in range(lava_count)]
        branch_ring = round(field.rings * 0.84)
        branch_offset = round((0.18 / math.tau) * field.radial_segments)

        for angle in channel_angles:
            signed_angle = abs(math.atan2(math.sin(angle), math.cos(angle)))
            if signed_angle < float(field.controls["path_width"]) * 1.25:
                continue

            center = round((angle % math.tau) / math.tau * field.radial_segments) % field.radial_segments
            left = field.lava_mask[branch_ring][(center - branch_offset) % field.radial_segments]
            right = field.lava_mask[branch_ring][(center + branch_offset) % field.radial_segments]

            self.assertGreater(max(left, right), 0.28)
            self.assertGreater(abs(left - right), 0.16)

    def test_fire_demo_hero_lava_side_tongues_have_black_rock_levees(self):
        layout_path = Path(__file__).resolve().parents[1] / "layouts" / "fire_volcano_demo.json"
        layout = IslandLayout.from_json(layout_path.read_text(encoding="utf-8"))
        field = build_semantic_terrain_field_from_layout(layout, bake_quality="hero")
        lava_count = int(field.controls["lava_channel_count"])
        path_width = float(field.controls["path_width"])
        channel_angles = [0.42 + math.tau * index / lava_count for index in range(lava_count)]
        tongue_offset = round((0.145 / math.tau) * field.radial_segments)
        levee_offset = round((0.205 / math.tau) * field.radial_segments)
        side_tongues_by_channel = []
        visible_levee_lifts = []

        for angle in channel_angles:
            signed_angle = abs(math.atan2(math.sin(angle), math.cos(angle)))
            if signed_angle < path_width * 1.25:
                continue

            center = round((angle % math.tau) / math.tau * field.radial_segments) % field.radial_segments
            channel_tongues = 0
            for ring in range(round(field.rings * 0.70), round(field.rings * 0.92) + 1):
                if max(field.path_mask[ring][center], field.crater_loop_mask[ring][center]) > 0.22:
                    continue

                left_tongue = (center - tongue_offset) % field.radial_segments
                right_tongue = (center + tongue_offset) % field.radial_segments
                left_levee = (center - levee_offset) % field.radial_segments
                right_levee = (center + levee_offset) % field.radial_segments
                left_flow = max(field.lava_mask[ring][left_tongue], field.lava_flow_mask[ring][left_tongue])
                right_flow = max(field.lava_mask[ring][right_tongue], field.lava_flow_mask[ring][right_tongue])
                if max(left_flow, right_flow) < 0.38 or abs(left_flow - right_flow) < 0.18:
                    continue

                tongue_index = left_tongue if left_flow > right_flow else right_tongue
                levee_index = left_levee if left_flow > right_flow else right_levee
                tongue_material = material_for_terrain_field_face(field, ring, tongue_index)
                levee_material = material_for_terrain_field_face(field, ring, levee_index)
                if tongue_material != "M_ElementCrack" or levee_material != "M_CliffRock":
                    continue

                levee_lift = field.heights[ring][levee_index] - field.heights[ring][tongue_index]
                if levee_lift < 210.0:
                    continue

                channel_tongues += 1
                visible_levee_lifts.append(levee_lift)

            side_tongues_by_channel.append(channel_tongues)

        self.assertGreaterEqual(len(side_tongues_by_channel), 3)
        self.assertGreaterEqual(sum(1 for count in side_tongues_by_channel if count >= 3), 3)
        self.assertGreaterEqual(_percentile(visible_levee_lifts, 0.20), 260.0)

    def test_fire_demo_hero_side_lava_tongues_have_internal_cooling_ribs(self):
        layout_path = Path(__file__).resolve().parents[1] / "layouts" / "fire_volcano_demo.json"
        layout = IslandLayout.from_json(layout_path.read_text(encoding="utf-8"))
        field = build_semantic_terrain_field_from_layout(layout, bake_quality="hero")
        lava_count = int(field.controls["lava_channel_count"])
        path_width = float(field.controls["path_width"])
        channel_angles = [0.42 + math.tau * index / lava_count for index in range(lava_count)]
        ribs_by_channel = []
        rib_lifts = []

        for angle in channel_angles:
            signed_angle = abs(math.atan2(math.sin(angle), math.cos(angle)))
            if signed_angle < path_width * 1.25:
                continue

            center = round((angle % math.tau) / math.tau * field.radial_segments) % field.radial_segments
            channel_ribs = 0
            for ring in range(round(field.rings * 0.72), round(field.rings * 0.93) + 1):
                radial_alpha = ring / field.rings if field.rings else 0.0
                for offset in range(-18, 19):
                    index = (center + offset) % field.radial_segments
                    sample_angle = ((index + 0.5) / field.radial_segments) * math.tau
                    side_tongue_strength, side_levee_strength = _fire_lava_side_overflow_strengths(
                        radial_alpha,
                        sample_angle,
                        field.controls,
                    )
                    rib_strength = _fire_lava_side_tongue_cooling_rib_strength(
                        radial_alpha,
                        sample_angle,
                        field.controls,
                    )
                    if side_tongue_strength < 0.28 or side_levee_strength > 0.18:
                        continue
                    if rib_strength < 0.18:
                        continue

                    neighbor_plane = (
                        field.heights[ring][index - 1]
                        + field.heights[ring][(index + 1) % field.radial_segments]
                        + field.heights[ring - 1][index]
                        + field.heights[ring + 1][index]
                    ) * 0.25
                    rib_lift = field.heights[ring][index] - neighbor_plane
                    if rib_lift < 92.0:
                        continue

                    channel_ribs += 1
                    rib_lifts.append(rib_lift)

            ribs_by_channel.append(channel_ribs)

        self.assertGreaterEqual(len(ribs_by_channel), 3)
        self.assertGreaterEqual(min(ribs_by_channel), 1)
        self.assertGreaterEqual(sum(1 for count in ribs_by_channel if count >= 2), 2)
        self.assertGreaterEqual(sum(ribs_by_channel), 6)
        self.assertGreater(_percentile(rib_lifts, 0.20), 96.0)

    def test_fire_demo_hero_terminal_lava_fans_have_cooling_finger_breaks(self):
        layout_path = Path(__file__).resolve().parents[1] / "layouts" / "fire_volcano_demo.json"
        layout = IslandLayout.from_json(layout_path.read_text(encoding="utf-8"))
        field = build_semantic_terrain_field_from_layout(layout, bake_quality="hero")
        lava_count = int(field.controls["lava_channel_count"])
        path_width = float(field.controls["path_width"])
        channel_angles = [0.42 + math.tau * index / lava_count for index in range(lava_count)]
        sample_offsets = [
            round((offset / math.tau) * field.radial_segments)
            for offset in (-0.22, -0.17, -0.12, -0.07, -0.03, 0.0, 0.03, 0.07, 0.12, 0.17, 0.22)
        ]
        broken_sections_by_channel = []

        for angle in channel_angles:
            signed_angle = abs(math.atan2(math.sin(angle), math.cos(angle)))
            if signed_angle < path_width * 1.25:
                continue

            center = round((angle % math.tau) / math.tau * field.radial_segments) % field.radial_segments
            broken_sections = 0
            for ring in range(round(field.rings * 0.76), round(field.rings * 0.91) + 1):
                materials = [
                    material_for_terrain_field_face(field, ring, (center + offset) % field.radial_segments)
                    for offset in sample_offsets
                ]
                red_count = sum(1 for material in materials if material == "M_ElementCrack")
                cliff_count = sum(1 for material in materials if material == "M_CliffRock")
                transitions = sum(
                    1
                    for left, right in zip(materials, materials[1:])
                    if {left, right} == {"M_ElementCrack", "M_CliffRock"}
                )
                if red_count >= 4 and cliff_count >= 3 and transitions >= 4:
                    broken_sections += 1

            broken_sections_by_channel.append(broken_sections)

        self.assertGreaterEqual(len(broken_sections_by_channel), 3)
        self.assertGreaterEqual(sum(1 for count in broken_sections_by_channel if count >= 3), 3)

    def test_fire_demo_hero_terminal_lava_fans_do_not_form_broad_red_slabs(self):
        layout_path = Path(__file__).resolve().parents[1] / "layouts" / "fire_volcano_demo.json"
        layout = IslandLayout.from_json(layout_path.read_text(encoding="utf-8"))
        field = build_semantic_terrain_field_from_layout(layout, bake_quality="hero")
        lava_count = int(field.controls["lava_channel_count"])
        path_width = float(field.controls["path_width"])
        channel_angles = [0.42 + math.tau * index / lava_count for index in range(lava_count)]
        worst_red_windows = []

        for angle in channel_angles:
            signed_angle = abs(math.atan2(math.sin(angle), math.cos(angle)))
            if signed_angle < path_width * 1.25:
                continue

            center = round((angle % math.tau) / math.tau * field.radial_segments) % field.radial_segments
            channel_worst_red_fraction = 0.0
            for center_ring in range(round(field.rings * 0.78), round(field.rings * 0.91) + 1):
                for center_offset in range(-8, 9):
                    red_cells = 0
                    sampled_cells = 0
                    for ring_offset in (-2, -1, 0, 1, 2):
                        ring = max(1, min(field.rings, center_ring + ring_offset))
                        for angular_offset in range(-3, 4):
                            index = (center + center_offset + angular_offset) % field.radial_segments
                            material = material_for_terrain_field_face(field, ring, index)
                            if material == "M_ElementCrack":
                                red_cells += 1
                            sampled_cells += 1
                    channel_worst_red_fraction = max(channel_worst_red_fraction, red_cells / sampled_cells)

            worst_red_windows.append(channel_worst_red_fraction)

        self.assertGreaterEqual(len(worst_red_windows), 3)
        self.assertLess(max(worst_red_windows), 0.82)

    def test_fire_demo_hero_terminal_lava_fans_keep_cooling_pockets_inside_hot_core(self):
        layout_path = Path(__file__).resolve().parents[1] / "layouts" / "fire_volcano_demo.json"
        layout = IslandLayout.from_json(layout_path.read_text(encoding="utf-8"))
        field = build_semantic_terrain_field_from_layout(layout, bake_quality="hero")
        lava_count = int(field.controls["lava_channel_count"])
        path_width = float(field.controls["path_width"])
        channel_angles = [0.42 + math.tau * index / lava_count for index in range(lava_count)]
        worst_red_windows = []

        for angle in channel_angles:
            signed_angle = abs(math.atan2(math.sin(angle), math.cos(angle)))
            if signed_angle < path_width * 1.25:
                continue

            center = round((angle % math.tau) / math.tau * field.radial_segments) % field.radial_segments
            channel_worst_red_fraction = 0.0
            for center_ring in range(round(field.rings * 0.72), round(field.rings * 0.96) + 1):
                for center_offset in range(-14, 15):
                    red_cells = 0
                    sampled_cells = 0
                    for ring_offset in range(-3, 4):
                        ring = max(1, min(field.rings, center_ring + ring_offset))
                        for angular_offset in range(-4, 5):
                            index = (center + center_offset + angular_offset) % field.radial_segments
                            material = material_for_terrain_field_face(field, ring, index)
                            if material == "M_ElementCrack":
                                red_cells += 1
                            sampled_cells += 1
                    channel_worst_red_fraction = max(channel_worst_red_fraction, red_cells / sampled_cells)

            worst_red_windows.append(channel_worst_red_fraction)

        self.assertGreaterEqual(len(worst_red_windows), 3)
        self.assertLess(max(worst_red_windows), 0.74)

    def test_fire_demo_hero_lava_mantles_are_cut_by_cooling_slabs(self):
        layout_path = Path(__file__).resolve().parents[1] / "layouts" / "fire_volcano_demo.json"
        layout = IslandLayout.from_json(layout_path.read_text(encoding="utf-8"))
        field = build_semantic_terrain_field_from_layout(layout, bake_quality="hero")
        lava_count = int(field.controls["lava_channel_count"])
        path_width = float(field.controls["path_width"])
        channel_angles = [0.42 + math.tau * index / lava_count for index in range(lava_count)]
        longest_red_runs = []

        for angle in channel_angles:
            signed_angle = abs(math.atan2(math.sin(angle), math.cos(angle)))
            if signed_angle < path_width * 1.25:
                continue

            center = round((angle % math.tau) / math.tau * field.radial_segments) % field.radial_segments
            channel_longest_run = 0
            for ring in range(round(field.rings * 0.70), round(field.rings * 0.96) + 1):
                current_run = 0
                for offset in range(-30, 31):
                    material = material_for_terrain_field_face(
                        field,
                        ring,
                        (center + offset) % field.radial_segments,
                    )
                    if material == "M_ElementCrack":
                        current_run += 1
                    else:
                        channel_longest_run = max(channel_longest_run, current_run)
                        current_run = 0
                channel_longest_run = max(channel_longest_run, current_run)

            longest_red_runs.append(channel_longest_run)

        self.assertGreaterEqual(len(longest_red_runs), 3)
        self.assertLessEqual(max(longest_red_runs), 14, longest_red_runs)

    def test_fire_demo_hero_terminal_high_slope_lava_curtains_are_cut_by_rock(self):
        layout_path = Path(__file__).resolve().parents[1] / "layouts" / "fire_volcano_demo.json"
        layout = IslandLayout.from_json(layout_path.read_text(encoding="utf-8"))
        field = build_semantic_terrain_field_from_layout(layout, bake_quality="hero")
        lava_count = int(field.controls["lava_channel_count"])
        path_width = float(field.controls["path_width"])
        channel_angles = [0.42 + math.tau * index / lava_count for index in range(lava_count)]
        high_slope_red_fractions = []

        for angle in channel_angles:
            signed_angle = abs(math.atan2(math.sin(angle), math.cos(angle)))
            if signed_angle < path_width * 1.25:
                continue

            center = round((angle % math.tau) / math.tau * field.radial_segments) % field.radial_segments
            high_slope_red = 0
            high_slope_samples = 0
            for ring in range(round(field.rings * 0.72), round(field.rings * 0.96) + 1):
                radial_alpha = ring / field.rings if field.rings else 0.0
                for offset in range(-16, 17):
                    index = (center + offset) % field.radial_segments
                    face_angle = ((index + 0.5) / field.radial_segments) * math.tau
                    side_tongue_strength, _side_levee_strength = _fire_lava_side_overflow_strengths(
                        radial_alpha,
                        face_angle,
                        field.controls,
                    )
                    if side_tongue_strength > 0.22:
                        continue
                    if field.slope_mask[ring][index] <= 0.72:
                        continue
                    if max(field.lava_mask[ring][index], field.lava_flow_mask[ring][index]) <= 0.44:
                        continue

                    high_slope_samples += 1
                    if material_for_terrain_field_face(field, ring, index) == "M_ElementCrack":
                        high_slope_red += 1

            self.assertGreater(high_slope_samples, 90)
            high_slope_red_fractions.append(high_slope_red / high_slope_samples)

        self.assertGreaterEqual(len(high_slope_red_fractions), 3)
        self.assertLess(max(high_slope_red_fractions), 0.46)

    def test_fire_demo_hero_terminal_lava_fans_have_raised_cooling_islands(self):
        layout_path = Path(__file__).resolve().parents[1] / "layouts" / "fire_volcano_demo.json"
        layout = IslandLayout.from_json(layout_path.read_text(encoding="utf-8"))
        field = build_semantic_terrain_field_from_layout(layout, bake_quality="hero")
        lava_count = int(field.controls["lava_channel_count"])
        path_width = float(field.controls["path_width"])
        channel_angles = [0.42 + math.tau * index / lava_count for index in range(lava_count)]
        cooling_islands_by_channel = []
        cooling_lifts = []

        for angle in channel_angles:
            signed_angle = abs(math.atan2(math.sin(angle), math.cos(angle)))
            if signed_angle < path_width * 1.25:
                continue

            center = round((angle % math.tau) / math.tau * field.radial_segments) % field.radial_segments
            channel_islands = 0
            for ring in range(round(field.rings * 0.79), round(field.rings * 0.93) + 1):
                for offset in (-11, -8, -5, 5, 8, 11):
                    index = (center + offset) % field.radial_segments
                    if material_for_terrain_field_face(field, ring, index) != "M_CliffRock":
                        continue

                    red_neighbors = []
                    for sample_offset in (-3, -2, -1, 1, 2, 3):
                        sample_index = (index + sample_offset) % field.radial_segments
                        if material_for_terrain_field_face(field, ring, sample_index) == "M_ElementCrack":
                            red_neighbors.append(field.heights[ring][sample_index])
                    if len(red_neighbors) < 2:
                        continue

                    island_lift = field.heights[ring][index] - statistics.mean(red_neighbors)
                    if island_lift < 190.0:
                        continue

                    channel_islands += 1
                    cooling_lifts.append(island_lift)

            cooling_islands_by_channel.append(channel_islands)

        self.assertGreaterEqual(len(cooling_islands_by_channel), 3)
        self.assertGreaterEqual(sum(1 for count in cooling_islands_by_channel if count >= 3), 3)
        self.assertGreater(_percentile(cooling_lifts, 0.35), 230.0)

    def test_fire_demo_hero_outer_lava_fans_have_scalloped_cooling_breaks(self):
        layout_path = Path(__file__).resolve().parents[1] / "layouts" / "fire_volcano_demo.json"
        layout = IslandLayout.from_json(layout_path.read_text(encoding="utf-8"))
        field = build_semantic_terrain_field_from_layout(layout, bake_quality="hero")
        lava_count = int(field.controls["lava_channel_count"])
        path_width = float(field.controls["path_width"])
        channel_angles = [0.42 + math.tau * index / lava_count for index in range(lava_count)]
        sample_offsets = [
            round((offset / math.tau) * field.radial_segments)
            for offset in (-0.30, -0.25, -0.20, -0.15, -0.10, -0.05, 0.0, 0.05, 0.10, 0.15, 0.20, 0.25, 0.30)
        ]
        scalloped_sections_by_channel = []

        for angle in channel_angles:
            signed_angle = abs(math.atan2(math.sin(angle), math.cos(angle)))
            if signed_angle < path_width * 1.25:
                continue

            center = round((angle % math.tau) / math.tau * field.radial_segments) % field.radial_segments
            scalloped_sections = 0
            for ring in range(round(field.rings * 0.94), field.rings + 1):
                materials = [
                    material_for_terrain_field_face(field, ring, (center + offset) % field.radial_segments)
                    for offset in sample_offsets
                ]
                red_count = sum(1 for material in materials if material == "M_ElementCrack")
                cliff_count = sum(1 for material in materials if material == "M_CliffRock")
                transitions = sum(
                    1
                    for left, right in zip(materials, materials[1:])
                    if {left, right} == {"M_ElementCrack", "M_CliffRock"}
                )
                red_heights = [
                    field.heights[ring][(center + offset) % field.radial_segments]
                    for offset, material in zip(sample_offsets, materials)
                    if material == "M_ElementCrack"
                ]
                cliff_heights = [
                    field.heights[ring][(center + offset) % field.radial_segments]
                    for offset, material in zip(sample_offsets, materials)
                    if material == "M_CliffRock"
                ]
                scallop_supported_cliffs = 0
                for offset, material in zip(sample_offsets, materials):
                    if material != "M_CliffRock":
                        continue
                    sample_index = (center + offset) % field.radial_segments
                    sample_angle = ((sample_index + 0.5) / field.radial_segments) * math.tau
                    if _fire_lava_outer_scallop_strength(ring / field.rings, sample_angle, field.controls) > 0.42:
                        scallop_supported_cliffs += 1
                cooling_lift = 0.0
                if red_heights and cliff_heights:
                    cooling_lift = statistics.mean(sorted(cliff_heights)[-min(4, len(cliff_heights)):]) - statistics.mean(red_heights)
                if (
                    red_count >= 2
                    and cliff_count >= 5
                    and transitions >= 2
                    and scallop_supported_cliffs >= 2
                    and cooling_lift > 900.0
                ):
                    scalloped_sections += 1

            scalloped_sections_by_channel.append(scalloped_sections)

        self.assertGreaterEqual(len(scalloped_sections_by_channel), 3)
        self.assertGreaterEqual(min(scalloped_sections_by_channel), 1)
        self.assertGreaterEqual(sum(1 for count in scalloped_sections_by_channel if count >= 3), 2)
        self.assertGreaterEqual(sum(scalloped_sections_by_channel), 7)

    def test_fire_demo_hero_lava_flow_branches_follow_low_potential_corridors(self):
        layout_path = Path(__file__).resolve().parents[1] / "layouts" / "fire_volcano_demo.json"
        layout = IslandLayout.from_json(layout_path.read_text(encoding="utf-8"))
        field = build_semantic_terrain_field_from_layout(layout, bake_quality="hero")
        lava_count = int(field.controls["lava_channel_count"])
        path_width = float(field.controls["path_width"])
        channel_angles = [0.42 + math.tau * index / lava_count for index in range(lava_count)]
        height_above_low_points = []
        bending_channels = 0

        for channel_angle in channel_angles:
            signed_channel_angle = abs(math.atan2(math.sin(channel_angle), math.cos(channel_angle)))
            if signed_channel_angle < path_width * 1.25:
                continue

            center_index = round((channel_angle % math.tau) / math.tau * field.radial_segments) % field.radial_segments
            search_radius = round((0.24 / math.tau) * field.radial_segments)
            flow_offsets = []
            channel_height_above_low = []

            for ring in range(round(field.rings * 0.58), round(field.rings * 0.94) + 1):
                candidates = []
                for offset in range(-search_radius, search_radius + 1):
                    index = (center_index + offset) % field.radial_segments
                    if max(field.path_mask[ring][index], field.crater_loop_mask[ring][index]) > 0.25:
                        continue
                    candidates.append(
                        (
                            field.lava_flow_mask[ring][index],
                            field.heights[ring][index],
                            offset / field.radial_segments * math.tau,
                        )
                    )

                if not candidates:
                    continue

                peak_flow, peak_height, flow_offset = max(candidates, key=lambda item: item[0])
                _low_flow, low_height, _low_offset = min(candidates, key=lambda item: item[1])
                if peak_flow < 0.22:
                    continue
                flow_offsets.append(flow_offset)
                channel_height_above_low.append(max(0.0, peak_height - low_height))

            if len(flow_offsets) < 8:
                continue

            turn_count = sum(
                1
                for previous_offset, current_offset, next_offset in zip(flow_offsets, flow_offsets[1:], flow_offsets[2:])
                if (current_offset - previous_offset) * (next_offset - current_offset) < 0.0
            )
            if turn_count >= 1:
                bending_channels += 1
            height_above_low_points.extend(channel_height_above_low)

        self.assertGreater(len(height_above_low_points), 40)
        self.assertLess(statistics.mean(height_above_low_points), 520.0)
        self.assertGreaterEqual(bending_channels, 1)

    def test_fire_hero_crater_inner_wall_spreads_collapse_over_multiple_steps(self):
        layout = default_layout("fire", seed=2002)
        field = build_semantic_terrain_field_from_layout(layout, bake_quality="hero")
        side_index = field.radial_segments // 4
        start = round(field.rings * 0.20)
        end = round(field.rings * 0.54)
        radial_deltas = [
            abs(field.heights[ring + 1][side_index] - field.heights[ring][side_index])
            for ring in range(start, end)
        ]
        active_steps = [delta for delta in radial_deltas if delta > 160.0]

        self.assertGreaterEqual(len(active_steps), 7)
        self.assertLess(max(radial_deltas), 560.0)

    def test_fire_hero_crater_floor_settles_into_ash_basin(self):
        layout = default_layout("fire", seed=2002)
        field = build_semantic_terrain_field_from_layout(layout, bake_quality="hero")
        angular_deltas = []
        residuals = []
        heights = []
        for ring in range(round(field.rings * 0.08), round(field.rings * 0.20) + 1):
            for index in range(field.radial_segments):
                if field.path_mask[ring][index] > 0.35 or field.lava_mask[ring][index] > 0.25:
                    continue

                height = field.heights[ring][index]
                neighbors = [
                    field.heights[ring][index - 1],
                    field.heights[ring][(index + 1) % field.radial_segments],
                    field.heights[max(0, ring - 1)][index],
                    field.heights[min(field.rings, ring + 1)][index],
                ]
                heights.append(height)
                angular_deltas.append(abs(height - field.heights[ring][(index + 1) % field.radial_segments]))
                residuals.append(abs(height - sum(neighbors) / len(neighbors)))

        self.assertLess(_percentile(angular_deltas, 0.95), 115.0)
        self.assertLess(_percentile(residuals, 0.99), 105.0)
        self.assertGreater(max(heights) - min(heights), 500.0)

    def test_fire_demo_hero_volcano_wall_ribs_weather_into_broad_strata(self):
        layout_path = Path(__file__).resolve().parents[1] / "layouts" / "fire_volcano_demo.json"
        layout = IslandLayout.from_json(layout_path.read_text(encoding="utf-8"))
        field = build_semantic_terrain_field_from_layout(layout, bake_quality="hero")
        angular_deltas = []
        radial_deltas = []
        for ring in range(round(field.rings * 0.46), round(field.rings * 0.70) + 1):
            for index in range(field.radial_segments):
                semantic_guard = max(
                    field.path_mask[ring][index],
                    field.lava_mask[ring][index],
                    field.crater_loop_mask[ring][index],
                )
                if semantic_guard > 0.20:
                    continue

                height = field.heights[ring][index]
                angular_deltas.append(abs(height - field.heights[ring][(index + 1) % field.radial_segments]))
                radial_deltas.append(abs(height - field.heights[ring + 1][index]))

        self.assertLess(_percentile(angular_deltas, 0.95), 205.0)
        self.assertGreater(_percentile(radial_deltas, 0.75), 240.0)

    def test_fire_demo_hero_outer_wall_breaks_coherent_polar_curtain_ribs(self):
        layout_path = Path(__file__).resolve().parents[1] / "layouts" / "fire_volcano_demo.json"
        layout = IslandLayout.from_json(layout_path.read_text(encoding="utf-8"))
        field = build_semantic_terrain_field_from_layout(layout, bake_quality="hero")
        worst_boundary_p80 = 0.0
        valid_boundaries = 0
        min_ring_samples = 7

        for index in range(field.radial_segments):
            next_index = (index + 1) % field.radial_segments
            deltas = []
            for ring in range(round(field.rings * 0.46), round(field.rings * 0.70) + 1):
                semantic_guard = max(
                    field.path_mask[ring][index],
                    field.lava_mask[ring][index],
                    field.crater_loop_mask[ring][index],
                    field.path_mask[ring][next_index],
                    field.lava_mask[ring][next_index],
                    field.crater_loop_mask[ring][next_index],
                )
                if semantic_guard > 0.20:
                    continue
                deltas.append(abs(field.heights[ring][index] - field.heights[ring][next_index]))

            if len(deltas) >= min_ring_samples:
                valid_boundaries += 1
                worst_boundary_p80 = max(worst_boundary_p80, _percentile(deltas, 0.80))

        self.assertGreater(valid_boundaries, 240)
        self.assertLess(worst_boundary_p80, 260.0)

    def test_fire_demo_hero_outer_wall_breaks_long_vertical_boundary_columns(self):
        layout_path = Path(__file__).resolve().parents[1] / "layouts" / "fire_volcano_demo.json"
        layout = IslandLayout.from_json(layout_path.read_text(encoding="utf-8"))
        field = build_semantic_terrain_field_from_layout(layout, bake_quality="hero")
        worst_vertical_run = 0
        valid_boundaries = 0

        for index in range(field.radial_segments):
            next_index = (index + 1) % field.radial_segments
            current_run = 0
            boundary_valid = False
            for ring in range(round(field.rings * 0.46), round(field.rings * 0.70) + 1):
                semantic_guard = max(
                    field.path_mask[ring][index],
                    field.lava_mask[ring][index],
                    field.crater_loop_mask[ring][index],
                    field.path_mask[ring][next_index],
                    field.lava_mask[ring][next_index],
                    field.crater_loop_mask[ring][next_index],
                )
                if semantic_guard > 0.20:
                    current_run = 0
                    continue

                boundary_valid = True
                delta = abs(field.heights[ring][index] - field.heights[ring][next_index])
                if delta > 160.0:
                    current_run += 1
                    worst_vertical_run = max(worst_vertical_run, current_run)
                else:
                    current_run = 0
            if boundary_valid:
                valid_boundaries += 1

        self.assertGreater(valid_boundaries, 240)
        self.assertLess(worst_vertical_run, 9)

    def test_fire_demo_hero_upper_wall_has_fewer_persistent_castle_ribs(self):
        layout_path = Path(__file__).resolve().parents[1] / "layouts" / "fire_volcano_demo.json"
        layout = IslandLayout.from_json(layout_path.read_text(encoding="utf-8"))
        field = build_semantic_terrain_field_from_layout(layout, bake_quality="hero")
        persistent_rib_boundaries = 0
        valid_boundaries = 0

        for index in range(field.radial_segments):
            next_index = (index + 1) % field.radial_segments
            medium_ribs = 0
            strong_ribs = 0
            sampled_rings = 0
            for ring in range(round(field.rings * 0.46), round(field.rings * 0.70) + 1):
                semantic_guard = max(
                    field.path_mask[ring][index],
                    field.lava_mask[ring][index],
                    field.crater_loop_mask[ring][index],
                    field.path_mask[ring][next_index],
                    field.lava_mask[ring][next_index],
                    field.crater_loop_mask[ring][next_index],
                )
                if semantic_guard > 0.20:
                    continue
                sampled_rings += 1
                delta = abs(field.heights[ring][index] - field.heights[ring][next_index])
                if delta > 110.0:
                    medium_ribs += 1
                if delta > 160.0:
                    strong_ribs += 1

            if sampled_rings < 7:
                continue
            valid_boundaries += 1
            if medium_ribs >= 7 or strong_ribs >= 4:
                persistent_rib_boundaries += 1

        self.assertGreater(valid_boundaries, 240)
        self.assertLess(persistent_rib_boundaries, 60)

    def test_fire_demo_hero_upper_wall_pushes_castle_ribs_below_extreme_target(self):
        layout_path = Path(__file__).resolve().parents[1] / "layouts" / "fire_volcano_demo.json"
        layout = IslandLayout.from_json(layout_path.read_text(encoding="utf-8"))
        field = build_semantic_terrain_field_from_layout(layout, bake_quality="hero")
        persistent_rib_boundaries = 0
        valid_boundaries = 0

        for index in range(field.radial_segments):
            next_index = (index + 1) % field.radial_segments
            medium_ribs = 0
            strong_ribs = 0
            sampled_rings = 0
            for ring in range(round(field.rings * 0.46), round(field.rings * 0.70) + 1):
                semantic_guard = max(
                    field.path_mask[ring][index],
                    field.lava_mask[ring][index],
                    field.crater_loop_mask[ring][index],
                    field.path_mask[ring][next_index],
                    field.lava_mask[ring][next_index],
                    field.crater_loop_mask[ring][next_index],
                )
                if semantic_guard > 0.20:
                    continue
                sampled_rings += 1
                delta = abs(field.heights[ring][index] - field.heights[ring][next_index])
                if delta > 110.0:
                    medium_ribs += 1
                if delta > 160.0:
                    strong_ribs += 1

            if sampled_rings < 7:
                continue
            valid_boundaries += 1
            if medium_ribs >= 7 or strong_ribs >= 4:
                persistent_rib_boundaries += 1

        self.assertGreater(valid_boundaries, 240)
        self.assertLess(persistent_rib_boundaries, 54)

    def test_fire_demo_hero_upper_wall_radial_blinds_are_broken_by_lateral_shelves(self):
        layout_path = Path(__file__).resolve().parents[1] / "layouts" / "fire_volcano_demo.json"
        layout = IslandLayout.from_json(layout_path.read_text(encoding="utf-8"))
        field = build_semantic_terrain_field_from_layout(layout, bake_quality="hero")
        steep_columns = []
        valid_columns = 0

        for index in range(field.radial_segments):
            steep_steps = 0
            sampled_steps = 0
            for ring in range(round(field.rings * 0.36), round(field.rings * 0.54)):
                semantic_guard = max(
                    field.path_mask[ring][index],
                    field.lava_mask[ring][index],
                    field.crater_loop_mask[ring][index],
                    field.path_mask[ring + 1][index],
                    field.lava_mask[ring + 1][index],
                    field.crater_loop_mask[ring + 1][index],
                )
                if semantic_guard > 0.25:
                    continue
                sampled_steps += 1
                if abs(field.heights[ring + 1][index] - field.heights[ring][index]) > 240.0:
                    steep_steps += 1

            if sampled_steps < 5:
                steep_columns.append(False)
                continue

            valid_columns += 1
            steep_columns.append(steep_steps >= 7)

        self.assertGreater(valid_columns, 90)
        self.assertLess(_longest_true_run(steep_columns), 48)

    def test_fire_demo_hero_upper_wall_radial_blinds_do_not_form_dense_combs(self):
        layout_path = Path(__file__).resolve().parents[1] / "layouts" / "fire_volcano_demo.json"
        layout = IslandLayout.from_json(layout_path.read_text(encoding="utf-8"))
        field = build_semantic_terrain_field_from_layout(layout, bake_quality="hero")
        window_size = 24
        worst_window_run = 0
        worst_window_comb_count = 0
        valid_windows = 0

        for start in range(0, field.radial_segments, window_size):
            window_flags = []
            for offset in range(window_size):
                index = (start + offset) % field.radial_segments
                steep_steps = 0
                sampled_steps = 0
                for ring in range(round(field.rings * 0.40), round(field.rings * 0.54)):
                    semantic_guard = max(
                        field.path_mask[ring][index],
                        field.lava_mask[ring][index],
                        field.crater_loop_mask[ring][index],
                        field.path_mask[ring + 1][index],
                        field.lava_mask[ring + 1][index],
                        field.crater_loop_mask[ring + 1][index],
                    )
                    if semantic_guard > 0.25:
                        continue
                    sampled_steps += 1
                    if abs(field.heights[ring + 1][index] - field.heights[ring][index]) > 240.0:
                        steep_steps += 1

                window_flags.append(sampled_steps >= 5 and steep_steps >= 5)

            if sum(window_flags) < 3:
                continue

            valid_windows += 1
            worst_window_comb_count = max(worst_window_comb_count, sum(window_flags))
            worst_window_run = max(worst_window_run, _longest_true_run(window_flags))

        self.assertGreaterEqual(valid_windows, 4)
        self.assertLessEqual(worst_window_run, 10)
        self.assertLessEqual(worst_window_comb_count, 14)

    def test_fire_demo_hero_upper_wall_visual_windows_have_crosscut_shelves(self):
        layout_path = Path(__file__).resolve().parents[1] / "layouts" / "fire_volcano_demo.json"
        layout = IslandLayout.from_json(layout_path.read_text(encoding="utf-8"))
        field = build_semantic_terrain_field_from_layout(layout, bake_quality="hero")
        window_size = 24
        bad_blind_windows = 0
        window_metrics = []

        for start in range(0, field.radial_segments, window_size):
            crosscut_rows = 0
            vertical_rows = 0
            for ring in range(round(field.rings * 0.36), round(field.rings * 0.54)):
                row_drops = []
                for offset in range(window_size):
                    index = (start + offset) % field.radial_segments
                    semantic_guard = max(
                        field.path_mask[ring][index],
                        field.lava_mask[ring][index],
                        field.crater_loop_mask[ring][index],
                        field.path_mask[ring + 1][index],
                        field.lava_mask[ring + 1][index],
                        field.crater_loop_mask[ring + 1][index],
                    )
                    if semantic_guard > 0.25:
                        continue
                    row_drops.append(abs(field.heights[ring + 1][index] - field.heights[ring][index]))

                if len(row_drops) < 8:
                    continue

                row_median = statistics.median(row_drops)
                row_q75 = _percentile(row_drops, 0.75)
                if row_median > 240.0:
                    vertical_rows += 1
                if row_median < 210.0 and row_q75 < 300.0:
                    crosscut_rows += 1

            if vertical_rows < 6:
                continue

            window_metrics.append((start, vertical_rows, crosscut_rows))
            if crosscut_rows < 2:
                bad_blind_windows += 1

        self.assertGreaterEqual(len(window_metrics), 4)
        self.assertLessEqual(bad_blind_windows, 1, window_metrics)

    def test_fire_demo_hero_upper_wall_crosscuts_stagger_diagonally_inside_visual_windows(self):
        layout_path = Path(__file__).resolve().parents[1] / "layouts" / "fire_volcano_demo.json"
        layout = IslandLayout.from_json(layout_path.read_text(encoding="utf-8"))
        field = build_semantic_terrain_field_from_layout(layout, bake_quality="hero")
        window_size = 24
        rigid_windows = 0
        window_metrics = []

        for start in range(0, field.radial_segments, window_size):
            strongest_break_rings = []
            for offset in range(window_size):
                index = (start + offset) % field.radial_segments
                candidates = []
                for ring in range(round(field.rings * 0.36), round(field.rings * 0.54)):
                    semantic_guard = max(
                        field.path_mask[ring][index],
                        field.lava_mask[ring][index],
                        field.crater_loop_mask[ring][index],
                        field.path_mask[ring + 1][index],
                        field.lava_mask[ring + 1][index],
                        field.crater_loop_mask[ring + 1][index],
                    )
                    if semantic_guard > 0.25:
                        continue
                    drop = abs(field.heights[ring + 1][index] - field.heights[ring][index])
                    if drop > 225.0:
                        candidates.append((drop, ring))

                if candidates:
                    _drop, break_ring = max(candidates)
                    strongest_break_rings.append(break_ring)

            if len(strongest_break_rings) < window_size * 0.50:
                continue

            adjacent_shifts = [
                abs(strongest_break_rings[index + 1] - strongest_break_rings[index])
                for index in range(len(strongest_break_rings) - 1)
            ]
            big_diagonal_steps = sum(1 for shift in adjacent_shifts if shift >= 2)
            ring_spread = max(strongest_break_rings) - min(strongest_break_rings)
            dominant_ring_coverage = max(
                strongest_break_rings.count(ring) for ring in set(strongest_break_rings)
            ) / len(strongest_break_rings)

            window_metrics.append((start, len(strongest_break_rings), ring_spread, big_diagonal_steps, dominant_ring_coverage))
            if ring_spread < 4 or big_diagonal_steps < 3 or dominant_ring_coverage > 0.58:
                rigid_windows += 1

        self.assertGreaterEqual(len(window_metrics), 4)
        self.assertLessEqual(rigid_windows, 2, window_metrics)

    def test_fire_demo_hero_upper_wall_crestline_has_nonconcentric_collapse_bays(self):
        layout_path = Path(__file__).resolve().parents[1] / "layouts" / "fire_volcano_demo.json"
        layout = IslandLayout.from_json(layout_path.read_text(encoding="utf-8"))
        field = build_semantic_terrain_field_from_layout(layout, bake_quality="hero")
        window_size = 24
        rigid_windows = 0
        window_metrics = []

        for start in range(0, field.radial_segments, window_size):
            crest_rings = []
            for offset in range(window_size):
                index = (start + offset) % field.radial_segments
                candidates = []
                for ring in range(round(field.rings * 0.32), round(field.rings * 0.58) + 1):
                    semantic_guard = max(
                        field.path_mask[ring][index],
                        field.lava_mask[ring][index],
                        field.crater_loop_mask[ring][index],
                    )
                    if semantic_guard > 0.45:
                        continue
                    candidates.append((field.heights[ring][index], ring))

                if candidates:
                    _height, crest_ring = max(candidates)
                    crest_rings.append(crest_ring)

            if len(crest_rings) < window_size * 0.50:
                continue

            ring_spread = max(crest_rings) - min(crest_rings)
            adjacent_shifts = [
                abs(crest_rings[index + 1] - crest_rings[index])
                for index in range(len(crest_rings) - 1)
            ]
            big_shifts = sum(1 for shift in adjacent_shifts if shift >= 2)
            dominant_ring_coverage = max(crest_rings.count(ring) for ring in set(crest_rings)) / len(crest_rings)

            window_metrics.append((start, len(crest_rings), ring_spread, big_shifts, dominant_ring_coverage))
            if ring_spread < 4 or big_shifts < 2 or dominant_ring_coverage > 0.74:
                rigid_windows += 1

        self.assertGreaterEqual(len(window_metrics), 12)
        self.assertLessEqual(rigid_windows, 7, window_metrics)

    def test_fire_demo_hero_outer_wall_breaks_are_not_one_circular_ring(self):
        layout_path = Path(__file__).resolve().parents[1] / "layouts" / "fire_volcano_demo.json"
        layout = IslandLayout.from_json(layout_path.read_text(encoding="utf-8"))
        field = build_semantic_terrain_field_from_layout(layout, bake_quality="hero")
        break_ring_counts = {}
        valid_columns = 0

        for index in range(field.radial_segments):
            candidates = []
            for ring in range(round(field.rings * 0.46), round(field.rings * 0.70)):
                semantic_guard = max(
                    field.path_mask[ring][index],
                    field.lava_mask[ring][index],
                    field.crater_loop_mask[ring][index],
                    field.path_mask[ring + 1][index],
                    field.lava_mask[ring + 1][index],
                    field.crater_loop_mask[ring + 1][index],
                )
                if semantic_guard > 0.20:
                    continue
                candidates.append((abs(field.heights[ring + 1][index] - field.heights[ring][index]), ring))

            if not candidates:
                continue
            valid_columns += 1
            _drop, break_ring = max(candidates)
            break_ring_counts[break_ring] = break_ring_counts.get(break_ring, 0) + 1

        dominant_ring_coverage = max(break_ring_counts.values()) / valid_columns
        self.assertGreater(valid_columns, 240)
        self.assertGreaterEqual(len(break_ring_counts), 10)
        self.assertLess(dominant_ring_coverage, 0.60)

    def test_fire_demo_hero_outer_wall_breaks_have_local_arc_variation(self):
        layout_path = Path(__file__).resolve().parents[1] / "layouts" / "fire_volcano_demo.json"
        layout = IslandLayout.from_json(layout_path.read_text(encoding="utf-8"))
        field = build_semantic_terrain_field_from_layout(layout, bake_quality="hero")
        window_size = 24
        rigid_windows = 0
        valid_windows = 0

        for start in range(0, field.radial_segments, window_size):
            window_break_rings = []
            for offset in range(window_size):
                index = (start + offset) % field.radial_segments
                candidates = []
                for ring in range(round(field.rings * 0.46), round(field.rings * 0.70)):
                    semantic_guard = max(
                        field.path_mask[ring][index],
                        field.lava_mask[ring][index],
                        field.crater_loop_mask[ring][index],
                        field.path_mask[ring + 1][index],
                        field.lava_mask[ring + 1][index],
                        field.crater_loop_mask[ring + 1][index],
                    )
                    if semantic_guard > 0.20:
                        continue
                    candidates.append((abs(field.heights[ring + 1][index] - field.heights[ring][index]), ring))

                if candidates:
                    _drop, break_ring = max(candidates)
                    window_break_rings.append(break_ring)

            if len(window_break_rings) < window_size * 0.55:
                continue

            valid_windows += 1
            ring_spread = max(window_break_rings) - min(window_break_rings)
            dominant_ring_coverage = max(window_break_rings.count(ring) for ring in set(window_break_rings)) / len(
                window_break_rings
            )
            if ring_spread < 2 and dominant_ring_coverage > 0.88:
                rigid_windows += 1

        self.assertGreater(valid_windows, 10)
        self.assertEqual(rigid_windows, 0)

    def test_fire_demo_hero_outer_wall_broad_collapse_windows_are_not_rigid_bands(self):
        layout_path = Path(__file__).resolve().parents[1] / "layouts" / "fire_volcano_demo.json"
        layout = IslandLayout.from_json(layout_path.read_text(encoding="utf-8"))
        field = build_semantic_terrain_field_from_layout(layout, bake_quality="hero")
        window_size = 24
        rigid_windows = 0
        valid_windows = 0

        for start in range(0, field.radial_segments, window_size):
            window_break_rings = []
            for offset in range(window_size):
                index = (start + offset) % field.radial_segments
                candidates = []
                for ring in range(round(field.rings * 0.46), round(field.rings * 0.70)):
                    semantic_guard = max(
                        field.path_mask[ring][index],
                        field.lava_mask[ring][index],
                        field.crater_loop_mask[ring][index],
                        field.path_mask[ring + 1][index],
                        field.lava_mask[ring + 1][index],
                        field.crater_loop_mask[ring + 1][index],
                    )
                    if semantic_guard > 0.20:
                        continue
                    candidates.append((abs(field.heights[ring + 1][index] - field.heights[ring][index]), ring))

                if candidates:
                    _drop, break_ring = max(candidates)
                    window_break_rings.append(break_ring)

            if len(window_break_rings) < window_size * 0.55:
                continue

            valid_windows += 1
            ring_spread = max(window_break_rings) - min(window_break_rings)
            dominant_ring_coverage = max(window_break_rings.count(ring) for ring in set(window_break_rings)) / len(
                window_break_rings
            )
            if ring_spread < 3 and dominant_ring_coverage > 0.72:
                rigid_windows += 1

        self.assertGreater(valid_windows, 10)
        self.assertLessEqual(rigid_windows, 2)

    def test_fire_demo_hero_underside_uses_broken_lower_ring_instead_of_single_radial_fan(self):
        layout_path = Path(__file__).resolve().parents[1] / "layouts" / "fire_volcano_demo.json"
        layout = IslandLayout.from_json(layout_path.read_text(encoding="utf-8"))
        mesh = generate_island_mesh_from_layout(layout, bake_quality="hero")
        underside_spans = _material_face_radial_spans(mesh, "M_UndersideRock", layout.radius_m)

        self.assertGreater(len(underside_spans), 500)
        self.assertLess(_percentile(underside_spans, 0.95), 0.42)

    def test_fire_demo_hero_bottom_cap_keeps_central_underside_fan_short(self):
        layout_path = Path(__file__).resolve().parents[1] / "layouts" / "fire_volcano_demo.json"
        layout = IslandLayout.from_json(layout_path.read_text(encoding="utf-8"))
        mesh = generate_island_mesh_from_layout(layout, bake_quality="hero")
        central_fan_outer_radii = _material_face_outer_radii_with_inner_anchor(
            mesh,
            "M_UndersideRock",
            layout.radius_m,
            inner_alpha=0.025,
        )

        self.assertGreater(len(central_fan_outer_radii), 300)
        self.assertLess(_percentile(central_fan_outer_radii, 0.95), 0.14)

    def test_fire_demo_hero_bottom_cap_breaks_long_smooth_triangular_fan_shadows(self):
        layout_path = Path(__file__).resolve().parents[1] / "layouts" / "fire_volcano_demo.json"
        layout = IslandLayout.from_json(layout_path.read_text(encoding="utf-8"))
        field = build_semantic_terrain_field_from_layout(layout, bake_quality="hero")
        mesh = generate_island_mesh_from_layout(layout, bake_quality="hero")
        radius_cm = layout.radius_m * 100.0
        top_vertex_count = 1 + field.rings * field.radial_segments
        underside_start = top_vertex_count + 1
        cliff_skirt_start = underside_start + field.radial_segments
        bottom_tip = cliff_skirt_start + 2 * field.radial_segments
        first_lower_underside = bottom_tip + 1
        bottom_cap_profile = []

        for index in range(field.radial_segments):
            cap_vertex_index = first_lower_underside + index * 2 + 1
            x, y, z = mesh.vertices[cap_vertex_index - 1]
            bottom_cap_profile.append((math.hypot(x, y) / radius_cm, z / radius_cm))

        smooth_steps = []
        for index in range(field.radial_segments):
            next_index = (index + 1) % field.radial_segments
            radial_delta = abs(bottom_cap_profile[index][0] - bottom_cap_profile[next_index][0])
            height_delta = abs(bottom_cap_profile[index][1] - bottom_cap_profile[next_index][1])
            smooth_steps.append(max(radial_delta / 0.0025, height_delta / 0.0015))

        self.assertLess(_longest_run_below(smooth_steps, 1.0), 84)

    def test_fire_demo_hero_bottom_cap_has_undercut_breaks_in_each_visual_window(self):
        layout_path = Path(__file__).resolve().parents[1] / "layouts" / "fire_volcano_demo.json"
        layout = IslandLayout.from_json(layout_path.read_text(encoding="utf-8"))
        field = build_semantic_terrain_field_from_layout(layout, bake_quality="hero")
        mesh = generate_island_mesh_from_layout(layout, bake_quality="hero")
        radius_cm = layout.radius_m * 100.0
        top_vertex_count = 1 + field.rings * field.radial_segments
        underside_start = top_vertex_count + 1
        cliff_skirt_start = underside_start + field.radial_segments
        bottom_tip = cliff_skirt_start + 2 * field.radial_segments
        first_lower_underside = bottom_tip + 1
        bottom_cap_profile = []

        for index in range(field.radial_segments):
            cap_vertex_index = first_lower_underside + index * 2 + 1
            x, y, z = mesh.vertices[cap_vertex_index - 1]
            bottom_cap_profile.append((math.hypot(x, y) / radius_cm, z / radius_cm))

        weak_windows = 0
        window_size = 24
        for start in range(0, field.radial_segments, window_size):
            broken_steps = 0
            window_steps = 0
            for offset in range(window_size):
                index = (start + offset) % field.radial_segments
                next_index = (index + 1) % field.radial_segments
                radial_delta = abs(bottom_cap_profile[index][0] - bottom_cap_profile[next_index][0])
                height_delta = abs(bottom_cap_profile[index][1] - bottom_cap_profile[next_index][1])
                step_score = max(radial_delta / 0.0025, height_delta / 0.0015)
                if step_score >= 1.0:
                    broken_steps += 1
                window_steps += 1

            if window_steps >= window_size and broken_steps < 4:
                weak_windows += 1

        self.assertEqual(weak_windows, 0)

    def test_fire_demo_hero_cliff_skirt_uses_terraced_faces_instead_of_long_vertical_curtains(self):
        layout_path = Path(__file__).resolve().parents[1] / "layouts" / "fire_volcano_demo.json"
        layout = IslandLayout.from_json(layout_path.read_text(encoding="utf-8"))
        mesh = generate_island_mesh_from_layout(layout, bake_quality="hero")
        cliff_spans = _material_face_radial_spans(mesh, "M_CliffRock", layout.radius_m)

        self.assertGreater(len(cliff_spans), 6000)
        self.assertLess(_percentile(cliff_spans, 0.95), 0.24)

    def test_fire_demo_hero_cliff_skirt_breaks_side_back_shadow_rhythm(self):
        layout_path = Path(__file__).resolve().parents[1] / "layouts" / "fire_volcano_demo.json"
        layout = IslandLayout.from_json(layout_path.read_text(encoding="utf-8"))
        field = build_semantic_terrain_field_from_layout(layout, bake_quality="hero")
        mesh = generate_island_mesh_from_layout(layout, bake_quality="hero")
        height_deltas, radial_deltas = _fire_cliff_skirt_column_deltas(
            mesh,
            field.radial_segments,
            field.rings,
            layout.radius_m,
        )

        self.assertEqual(len(height_deltas), field.radial_segments)
        self.assertLess(_longest_run_below(height_deltas, 0.015), 44)
        self.assertLess(_longest_run_below(radial_deltas, 0.015), 44)

    def test_fire_demo_hero_cliff_skirt_has_collapse_events_in_each_visual_window(self):
        layout_path = Path(__file__).resolve().parents[1] / "layouts" / "fire_volcano_demo.json"
        layout = IslandLayout.from_json(layout_path.read_text(encoding="utf-8"))
        field = build_semantic_terrain_field_from_layout(layout, bake_quality="hero")
        mesh = generate_island_mesh_from_layout(layout, bake_quality="hero")
        height_deltas, radial_deltas = _fire_cliff_skirt_column_deltas(
            mesh,
            field.radial_segments,
            field.rings,
            layout.radius_m,
        )

        weak_windows = 0
        window_size = 24
        for start in range(0, field.radial_segments, window_size):
            height_window = height_deltas[start : start + window_size]
            radial_window = radial_deltas[start : start + window_size]
            if max(height_window) < 0.028 and max(radial_window) < 0.034:
                weak_windows += 1

        self.assertEqual(weak_windows, 0)

    def test_fire_demo_hero_cliff_skirt_ledges_shear_instead_of_vertical_sync(self):
        layout_path = Path(__file__).resolve().parents[1] / "layouts" / "fire_volcano_demo.json"
        layout = IslandLayout.from_json(layout_path.read_text(encoding="utf-8"))
        field = build_semantic_terrain_field_from_layout(layout, bake_quality="hero")
        mesh = generate_island_mesh_from_layout(layout, bake_quality="hero")
        radius_cm = layout.radius_m * 100.0
        top_vertex_count = 1 + field.rings * field.radial_segments
        underside_start = top_vertex_count + 1
        first_skirt_ring = underside_start + field.radial_segments
        second_skirt_ring = first_skirt_ring + field.radial_segments
        skirt_profiles = []

        for ring_start in (first_skirt_ring, second_skirt_ring):
            profile = []
            for index in range(field.radial_segments):
                x, y, z = mesh.vertices[ring_start + index - 1]
                profile.append((math.hypot(x, y) / radius_cm, z / radius_cm))
            skirt_profiles.append(profile)

        bad_sync_windows = 0
        window_size = 24
        window_sync_counts = []
        for start in range(0, field.radial_segments, window_size):
            aligned_steps = 0
            strong_steps = 0
            for offset in range(window_size):
                index = (start + offset) % field.radial_segments
                next_index = (index + 1) % field.radial_segments
                first_radial_delta = skirt_profiles[0][next_index][0] - skirt_profiles[0][index][0]
                second_radial_delta = skirt_profiles[1][next_index][0] - skirt_profiles[1][index][0]
                first_height_delta = skirt_profiles[0][next_index][1] - skirt_profiles[0][index][1]
                second_height_delta = skirt_profiles[1][next_index][1] - skirt_profiles[1][index][1]
                first_score = max(abs(first_radial_delta) / 0.006, abs(first_height_delta) / 0.006)
                second_score = max(abs(second_radial_delta) / 0.006, abs(second_height_delta) / 0.006)
                if first_score <= 1.0 or second_score <= 1.0:
                    continue

                strong_steps += 1
                if first_radial_delta * second_radial_delta > 0.0 or first_height_delta * second_height_delta > 0.0:
                    aligned_steps += 1

            if strong_steps < 12:
                continue

            window_sync_counts.append((start, aligned_steps, strong_steps))
            if aligned_steps > 18:
                bad_sync_windows += 1

        self.assertGreaterEqual(len(window_sync_counts), 10)
        self.assertLessEqual(bad_sync_windows, 3, window_sync_counts)

    def test_fire_demo_hero_cliff_skirt_continues_upper_wall_collapse_history(self):
        layout_path = Path(__file__).resolve().parents[1] / "layouts" / "fire_volcano_demo.json"
        layout = IslandLayout.from_json(layout_path.read_text(encoding="utf-8"))
        field = build_semantic_terrain_field_from_layout(layout, bake_quality="hero")
        mesh = generate_island_mesh_from_layout(layout, bake_quality="hero")
        radius_cm = layout.radius_m * 100.0
        top_vertex_count = 1 + field.rings * field.radial_segments
        columns = [[] for _ in range(field.radial_segments)]

        for material, face in mesh.faces:
            if material != "M_CliffRock" or not any(vertex > top_vertex_count for vertex in face):
                continue
            vertices = [mesh.vertices[index - 1] for index in face]
            center_x = sum(vertex[0] for vertex in vertices) / len(vertices)
            center_y = sum(vertex[1] for vertex in vertices) / len(vertices)
            center_z = sum(vertex[2] for vertex in vertices) / len(vertices)
            column = int(((math.atan2(center_y, center_x) % math.tau) / math.tau) * field.radial_segments)
            columns[column % field.radial_segments].append((center_z / radius_cm, math.hypot(center_x, center_y) / radius_cm))

        mismatch_windows = 0
        valid_upper_windows = 0
        window_size = 24
        for start in range(0, field.radial_segments, window_size):
            break_rings = []
            for offset in range(window_size):
                index = (start + offset) % field.radial_segments
                candidates = []
                for ring in range(round(field.rings * 0.46), round(field.rings * 0.70)):
                    semantic_guard = max(
                        field.path_mask[ring][index],
                        field.lava_mask[ring][index],
                        field.crater_loop_mask[ring][index],
                        field.path_mask[ring + 1][index],
                        field.lava_mask[ring + 1][index],
                        field.crater_loop_mask[ring + 1][index],
                    )
                    if semantic_guard > 0.20:
                        continue
                    candidates.append((abs(field.heights[ring + 1][index] - field.heights[ring][index]), ring))
                if candidates:
                    _drop, break_ring = max(candidates)
                    break_rings.append(break_ring)

            if len(break_rings) < window_size * 0.55 or max(break_rings) - min(break_rings) < 3:
                continue
            valid_upper_windows += 1

            smooth_height_columns = 0
            smooth_radial_columns = 0
            for offset in range(window_size):
                column = (start + offset) % field.radial_segments
                next_column = (column + 1) % field.radial_segments
                current = sorted(columns[column], key=lambda item: item[0], reverse=True)
                next_values = sorted(columns[next_column], key=lambda item: item[0], reverse=True)
                if len(current) != 3 or len(next_values) != 3:
                    continue
                height_delta = sum(abs(current[index][0] - next_values[index][0]) for index in range(3)) / 3
                radial_delta = sum(abs(current[index][1] - next_values[index][1]) for index in range(3)) / 3
                if height_delta < 0.015:
                    smooth_height_columns += 1
                if radial_delta < 0.015:
                    smooth_radial_columns += 1

            if smooth_height_columns >= 14 and smooth_radial_columns >= 18:
                mismatch_windows += 1

        self.assertGreaterEqual(valid_upper_windows, 8)
        self.assertLessEqual(mismatch_windows, 6)

    def test_fire_demo_hero_inner_wall_breach_ribs_slump_out_of_machine_teeth(self):
        layout_path = Path(__file__).resolve().parents[1] / "layouts" / "fire_volcano_demo.json"
        layout = IslandLayout.from_json(layout_path.read_text(encoding="utf-8"))
        field = build_semantic_terrain_field_from_layout(layout, bake_quality="hero")
        window_size = 20
        worst_window_p95 = 0.0

        for start in range(0, field.radial_segments, 4):
            angular_deltas = []
            for ring in range(round(field.rings * 0.28), round(field.rings * 0.40) + 1):
                for offset in range(window_size):
                    index = (start + offset) % field.radial_segments
                    next_index = (index + 1) % field.radial_segments
                    semantic_guard = max(
                        field.path_mask[ring][index],
                        field.lava_mask[ring][index],
                        field.crater_loop_mask[ring][index],
                        field.path_mask[ring][next_index],
                        field.lava_mask[ring][next_index],
                        field.crater_loop_mask[ring][next_index],
                    )
                    if semantic_guard > 0.20:
                        continue
                    angular_deltas.append(abs(field.heights[ring][index] - field.heights[ring][next_index]))
            if len(angular_deltas) >= 40:
                worst_window_p95 = max(worst_window_p95, _percentile(angular_deltas, 0.95))

        self.assertLess(worst_window_p95, 285.0)

    def test_fire_demo_hero_inner_wall_breaks_long_vertical_machine_columns(self):
        layout_path = Path(__file__).resolve().parents[1] / "layouts" / "fire_volcano_demo.json"
        layout = IslandLayout.from_json(layout_path.read_text(encoding="utf-8"))
        field = build_semantic_terrain_field_from_layout(layout, bake_quality="hero")
        worst_vertical_run = 0
        persistent_boundaries = 0
        valid_boundaries = 0

        for index in range(field.radial_segments):
            next_index = (index + 1) % field.radial_segments
            current_run = 0
            strong_steps = 0
            sampled_steps = 0
            for ring in range(round(field.rings * 0.28), round(field.rings * 0.46) + 1):
                semantic_guard = max(
                    field.path_mask[ring][index],
                    field.lava_mask[ring][index],
                    field.crater_loop_mask[ring][index],
                    field.path_mask[ring][next_index],
                    field.lava_mask[ring][next_index],
                    field.crater_loop_mask[ring][next_index],
                )
                if semantic_guard > 0.20:
                    current_run = 0
                    continue

                sampled_steps += 1
                delta = abs(field.heights[ring][index] - field.heights[ring][next_index])
                if delta > 132.0:
                    strong_steps += 1
                    current_run += 1
                    worst_vertical_run = max(worst_vertical_run, current_run)
                else:
                    current_run = 0

            if sampled_steps < 6:
                continue
            valid_boundaries += 1
            if strong_steps >= 5:
                persistent_boundaries += 1

        self.assertGreater(valid_boundaries, 100)
        self.assertLessEqual(worst_vertical_run, 4)
        self.assertLess(persistent_boundaries, 4)

    def test_fire_demo_hero_inner_wall_primary_breakline_is_not_radially_locked(self):
        layout_path = Path(__file__).resolve().parents[1] / "layouts" / "fire_volcano_demo.json"
        layout = IslandLayout.from_json(layout_path.read_text(encoding="utf-8"))
        field = build_semantic_terrain_field_from_layout(layout, bake_quality="hero")
        window_size = 24
        bad_locked_windows = 0
        valid_windows = 0

        for start in range(0, field.radial_segments, window_size):
            break_rings = []
            for offset in range(window_size):
                index = (start + offset) % field.radial_segments
                candidates = []
                for ring in range(round(field.rings * 0.28), round(field.rings * 0.46)):
                    semantic_guard = max(
                        field.path_mask[ring][index],
                        field.lava_mask[ring][index],
                        field.crater_loop_mask[ring][index],
                        field.path_mask[ring + 1][index],
                        field.lava_mask[ring + 1][index],
                        field.crater_loop_mask[ring + 1][index],
                    )
                    if semantic_guard > 0.20:
                        continue

                    drop = abs(field.heights[ring + 1][index] - field.heights[ring][index])
                    if drop > 260.0:
                        candidates.append((drop, ring))
                if candidates:
                    _drop, break_ring = max(candidates)
                    break_rings.append(break_ring)

            if len(break_rings) < window_size * 0.45:
                continue

            valid_windows += 1
            ring_counts = {ring: break_rings.count(ring) for ring in set(break_rings)}
            dominant_coverage = max(ring_counts.values()) / len(break_rings)
            ring_spread = max(break_rings) - min(break_rings)
            if dominant_coverage > 0.86 and ring_spread < 3:
                bad_locked_windows += 1

        self.assertGreaterEqual(valid_windows, 8)
        self.assertEqual(bad_locked_windows, 0)

    def test_fire_demo_hero_front_inner_breach_keeps_wall_drop_without_vertical_teeth(self):
        layout_path = Path(__file__).resolve().parents[1] / "layouts" / "fire_volcano_demo.json"
        layout = IslandLayout.from_json(layout_path.read_text(encoding="utf-8"))
        field = build_semantic_terrain_field_from_layout(layout, bake_quality="hero")
        angular_deltas = []
        radial_deltas = []

        for ring in range(round(field.rings * 0.30), round(field.rings * 0.38) + 1):
            for index in range(356, 375):
                wrapped_index = index % field.radial_segments
                semantic_guard = max(
                    field.path_mask[ring][wrapped_index],
                    field.lava_mask[ring][wrapped_index],
                    field.crater_loop_mask[ring][wrapped_index],
                )
                if semantic_guard > 0.22:
                    continue

                height = field.heights[ring][wrapped_index]
                angular_deltas.append(abs(height - field.heights[ring][(wrapped_index + 1) % field.radial_segments]))
                radial_deltas.append(abs(height - field.heights[ring + 1][wrapped_index]))

        self.assertGreater(len(angular_deltas), 40)
        self.assertLess(_percentile(angular_deltas, 0.95), 260.0)
        self.assertGreater(_percentile(radial_deltas, 0.50), 300.0)

    def test_fire_demo_hero_front_crater_shoulder_ash_drape_reduces_entry_curtains(self):
        layout_path = Path(__file__).resolve().parents[1] / "layouts" / "fire_volcano_demo.json"
        layout = IslandLayout.from_json(layout_path.read_text(encoding="utf-8"))
        field = build_semantic_terrain_field_from_layout(layout, bake_quality="hero")
        angular_deltas = []
        radial_deltas = []

        for ring in range(round(field.rings * 0.33), round(field.rings * 0.41) + 1):
            for index in list(range(0, 24)) + list(range(field.radial_segments - 24, field.radial_segments)):
                angle = (index / field.radial_segments) * math.tau
                signed_angle = abs(math.atan2(math.sin(angle), math.cos(angle)))
                if signed_angle > 0.30:
                    continue
                if field.path_mask[ring][index] > 0.26 or field.lava_mask[ring][index] > 0.18:
                    continue
                if not 0.12 <= field.crater_loop_mask[ring][index] <= 0.86:
                    continue

                height = field.heights[ring][index]
                angular_deltas.append(abs(height - field.heights[ring][(index + 1) % field.radial_segments]))
                radial_deltas.append(abs(field.heights[ring + 1][index] - height))

        self.assertGreater(len(angular_deltas), 60)
        self.assertLess(_percentile(angular_deltas, 0.95), 260.0)
        self.assertGreater(_percentile(radial_deltas, 0.50), 36.0)

    def test_fire_demo_hero_front_ash_plateau_limits_local_machine_curtain_range(self):
        layout_path = Path(__file__).resolve().parents[1] / "layouts" / "fire_volcano_demo.json"
        layout = IslandLayout.from_json(layout_path.read_text(encoding="utf-8"))
        field = build_semantic_terrain_field_from_layout(layout, bake_quality="hero")
        local_ranges = []

        for ring in range(round(field.rings * 0.33), round(field.rings * 0.38) + 1):
            for index in list(range(0, 18)) + list(range(field.radial_segments - 22, field.radial_segments)):
                if field.path_mask[ring][index] > 0.28 or field.lava_mask[ring][index] > 0.12:
                    continue
                if not 0.08 <= field.crater_loop_mask[ring][index] <= 0.58:
                    continue
                values = []
                for ring_offset in (-1, 0, 1):
                    sample_ring = max(0, min(field.rings, ring + ring_offset))
                    for index_offset in (-2, -1, 0, 1, 2):
                        values.append(field.heights[sample_ring][(index + index_offset) % field.radial_segments])
                local_ranges.append(max(values) - min(values))

        self.assertGreater(len(local_ranges), 12)
        self.assertLess(max(local_ranges), 1405.0)

    def test_fire_demo_hero_front_ash_toe_softens_approach_curtain(self):
        layout_path = Path(__file__).resolve().parents[1] / "layouts" / "fire_volcano_demo.json"
        layout = IslandLayout.from_json(layout_path.read_text(encoding="utf-8"))
        field = build_semantic_terrain_field_from_layout(layout, bake_quality="hero")
        angular_deltas = []
        radial_deltas = []

        for ring in range(round(field.rings * 0.30), round(field.rings * 0.36) + 1):
            for index in list(range(0, 24)) + list(range(field.radial_segments - 28, field.radial_segments)):
                angle = (index / field.radial_segments) * math.tau
                signed_angle = abs(math.atan2(math.sin(angle), math.cos(angle)))
                if signed_angle > 0.34:
                    continue
                if field.path_mask[ring][index] > 0.16 or field.lava_mask[ring][index] > 0.16:
                    continue
                if field.crater_loop_mask[ring][index] > 0.08 or field.volcano_mask[ring][index] > 0.24:
                    continue

                height = field.heights[ring][index]
                angular_deltas.append(abs(height - field.heights[ring][(index + 1) % field.radial_segments]))
                radial_deltas.append(abs(field.heights[ring + 1][index] - height))

        self.assertGreater(len(angular_deltas), 40)
        self.assertLess(_percentile(angular_deltas, 0.95), 248.0)
        self.assertGreater(_percentile(radial_deltas, 0.75), 330.0)

    def test_fire_demo_hero_non_front_ash_plateau_settles_into_deposition_bands(self):
        layout_path = Path(__file__).resolve().parents[1] / "layouts" / "fire_volcano_demo.json"
        layout = IslandLayout.from_json(layout_path.read_text(encoding="utf-8"))
        field = build_semantic_terrain_field_from_layout(layout, bake_quality="hero")
        angular_deltas = []
        residuals = []

        for ring in range(round(field.rings * 0.46), round(field.rings * 0.62) + 1):
            for index in range(field.radial_segments):
                angle = (index / field.radial_segments) * math.tau
                signed_angle = abs(math.atan2(math.sin(angle), math.cos(angle)))
                if signed_angle < 0.34:
                    continue
                semantic_guard = max(
                    field.path_mask[ring][index],
                    field.lava_mask[ring][index],
                    field.crater_loop_mask[ring][index],
                )
                if semantic_guard > 0.22:
                    continue
                if material_for_terrain_field_face(field, ring, index) != "M_AshPlateau":
                    continue

                height = field.heights[ring][index]
                previous_height = field.heights[ring][index - 1]
                next_height = field.heights[ring][(index + 1) % field.radial_segments]
                inner_height = field.heights[ring - 1][index]
                outer_height = field.heights[ring + 1][index]
                outer_2 = field.heights[ring + 2][index]
                inward_drop = abs(height - inner_height)
                outward_drop = abs(outer_height - height)
                next_outward_drop = abs(outer_2 - outer_height)
                preserves_secondary_shelf = min(inward_drop, outward_drop) < 152.0 and max(
                    inward_drop,
                    outward_drop,
                    next_outward_drop,
                ) > 226.0
                if preserves_secondary_shelf:
                    continue
                angular_deltas.append(max(abs(height - previous_height), abs(height - next_height)))
                residuals.append(abs(height - (previous_height + next_height + inner_height + outer_height) * 0.25))

        self.assertGreater(len(residuals), 200)
        self.assertLess(_percentile(angular_deltas, 0.95), 212.0)
        self.assertLess(_percentile(residuals, 0.95), 145.0)

    def test_fire_demo_hero_ash_plateau_hotspots_weather_into_broader_bands(self):
        layout_path = Path(__file__).resolve().parents[1] / "layouts" / "fire_volcano_demo.json"
        layout = IslandLayout.from_json(layout_path.read_text(encoding="utf-8"))
        field = build_semantic_terrain_field_from_layout(layout, bake_quality="hero")
        residuals = []

        for ring in range(round(field.rings * 0.46), round(field.rings * 0.64) + 1):
            for index in range(field.radial_segments):
                angle = (index / field.radial_segments) * math.tau
                signed_angle = abs(math.atan2(math.sin(angle), math.cos(angle)))
                if signed_angle < 0.34:
                    continue
                semantic_guard = max(
                    field.path_mask[ring][index],
                    field.lava_mask[ring][index],
                    field.crater_loop_mask[ring][index],
                )
                if semantic_guard > 0.22:
                    continue
                if material_for_terrain_field_face(field, ring, index) != "M_AshPlateau":
                    continue

                height = field.heights[ring][index]
                previous_height = field.heights[ring][index - 1]
                next_height = field.heights[ring][(index + 1) % field.radial_segments]
                inner_height = field.heights[ring - 1][index]
                outer_height = field.heights[ring + 1][index]
                residual = abs(height - (previous_height + next_height + inner_height + outer_height) * 0.25)
                residuals.append(residual)

        self.assertGreater(len(residuals), 340)
        self.assertLess(_percentile(residuals, 0.90), 111.0)
        self.assertLess(_percentile(residuals, 0.95), 145.0)

    def test_fire_demo_hero_volcano_wall_has_incomplete_secondary_collapse_shelves(self):
        layout_path = Path(__file__).resolve().parents[1] / "layouts" / "fire_volcano_demo.json"
        layout = IslandLayout.from_json(layout_path.read_text(encoding="utf-8"))
        field = build_semantic_terrain_field_from_layout(layout, bake_quality="hero")
        shelf_band_coverages = []
        max_ring_coverage = 0.0
        for start_alpha, end_alpha in ((0.52, 0.58), (0.60, 0.70)):
            active = 0
            valid = 0
            for ring in range(round(field.rings * start_alpha), round(field.rings * end_alpha) + 1):
                ring_active = 0
                ring_valid = 0
                for index in range(field.radial_segments):
                    semantic_guard = max(
                        field.path_mask[ring][index],
                        field.lava_mask[ring][index],
                        field.crater_loop_mask[ring][index],
                    )
                    if semantic_guard > 0.20:
                        continue

                    inward_drop = abs(field.heights[ring][index] - field.heights[ring - 1][index])
                    outward_drop = abs(field.heights[ring + 1][index] - field.heights[ring][index])
                    next_outward_drop = abs(field.heights[min(field.rings, ring + 2)][index] - field.heights[ring + 1][index])
                    is_shelf = min(inward_drop, outward_drop) < 145.0 and max(
                        inward_drop,
                        outward_drop,
                        next_outward_drop,
                    ) > 230.0
                    ring_valid += 1
                    valid += 1
                    if is_shelf:
                        ring_active += 1
                        active += 1
                if ring_valid:
                    max_ring_coverage = max(max_ring_coverage, ring_active / ring_valid)
            shelf_band_coverages.append(active / valid)

        self.assertGreater(shelf_band_coverages[0], 0.16)
        self.assertGreater(shelf_band_coverages[1], 0.25)
        self.assertLess(max_ring_coverage, 0.56)

    def test_fire_hero_lava_material_stays_on_channel_center_not_cooling_shoulder(self):
        layout = default_layout("fire", seed=2002)
        field = build_semantic_terrain_field_from_layout(layout, bake_quality="hero")
        ring = round(field.rings * 0.76)
        center = round(0.42 / math.tau * field.radial_segments)
        shoulder = center + round(field.radial_segments * 0.014)

        self.assertEqual(material_for_terrain_field_face(field, ring, center), "M_ElementCrack")
        self.assertNotEqual(material_for_terrain_field_face(field, ring, shoulder), "M_ElementCrack")

    def test_fire_semantic_terrain_field_exposes_houdini_style_masks(self):
        layout = default_layout("fire", seed=2002)
        field = build_semantic_terrain_field_from_layout(layout, radial_segments=96, rings=14, bake_quality="hero")
        outer_ring = int(field.rings * 0.78)
        lava_index = round(0.42 / math.tau * field.radial_segments)
        side_index = field.radial_segments // 4

        self.assertGreater(field.path_mask[outer_ring][0], 0.6)
        self.assertLess(field.path_mask[outer_ring][side_index], 0.15)
        self.assertGreater(field.lava_mask[outer_ring][lava_index], 0.55)
        self.assertLess(field.lava_mask[outer_ring][side_index], 0.25)
        self.assertGreater(field.cliff_mask[field.rings][0], 0.5)
        self.assertLess(field.cliff_mask[2][0], 0.1)
        self.assertGreater(field.volcano_mask[round(field.rings * 0.42)][0], 0.55)

    def test_fire_top_materials_are_classified_from_semantic_field_masks(self):
        layout = default_layout("fire", seed=2002)
        field = build_semantic_terrain_field_from_layout(layout, radial_segments=96, rings=14)
        outer_ring = int(field.rings * 0.78)
        lava_index = round(0.42 / math.tau * field.radial_segments)
        side_index = field.radial_segments // 4

        self.assertEqual(material_for_terrain_field_face(field, outer_ring, 0), "M_PathDirt")
        self.assertEqual(material_for_terrain_field_face(field, outer_ring, lava_index), "M_ElementCrack")
        self.assertEqual(material_for_terrain_field_face(field, outer_ring, side_index), "M_AshPlateau")

    def test_fire_demo_hero_exports_ash_plateau_not_generic_topgrass_for_meshy(self):
        layout_path = Path(__file__).resolve().parents[1] / "layouts" / "fire_volcano_demo.json"
        layout = IslandLayout.from_json(layout_path.read_text(encoding="utf-8"))

        mesh = generate_island_mesh_from_layout(layout, bake_quality="hero")
        materials = {material for material, _face in mesh.faces}

        self.assertIn("M_AshPlateau", mesh.materials)
        self.assertIn("M_AshPlateau", materials)
        self.assertNotIn("M_TopGrass", mesh.materials)
        self.assertNotIn("M_TopGrass", materials)
        self.assertLessEqual(len(mesh.materials), 5)

    def test_fire_demo_hero_element_crack_exports_as_compact_meshy_regions(self):
        layout_path = Path(__file__).resolve().parents[1] / "layouts" / "fire_volcano_demo.json"
        layout = IslandLayout.from_json(layout_path.read_text(encoding="utf-8"))
        field = build_semantic_terrain_field_from_layout(layout, bake_quality="hero")
        components = _terrain_material_components(field, "M_ElementCrack")
        tiny_components = [component for component in components if len(component) < 8]

        self.assertGreaterEqual(max(len(component) for component in components), 850)
        self.assertEqual([len(component) for component in tiny_components], [])

    def test_fire_demo_hero_element_crack_components_do_not_become_broad_side_wall_carpets(self):
        layout_path = Path(__file__).resolve().parents[1] / "layouts" / "fire_volcano_demo.json"
        layout = IslandLayout.from_json(layout_path.read_text(encoding="utf-8"))
        field = build_semantic_terrain_field_from_layout(layout, bake_quality="hero")
        worst_row_run = 0
        worst_broad_rows = 0

        for component in _terrain_material_components(field, "M_ElementCrack"):
            cells = set(component)
            component_broad_rows = 0
            for ring in range(round(field.rings * 0.56), round(field.rings * 0.96) + 1):
                row_run = _longest_true_run([(ring, index) in cells for index in range(field.radial_segments)])
                worst_row_run = max(worst_row_run, row_run)
                if row_run >= 18:
                    component_broad_rows += 1
            worst_broad_rows = max(worst_broad_rows, component_broad_rows)

        self.assertLessEqual(worst_row_run, 34)
        self.assertLessEqual(worst_broad_rows, 18)

    def test_fire_demo_hero_side_wall_material_windows_have_visible_cooling_breaks(self):
        layout_path = Path(__file__).resolve().parents[1] / "layouts" / "fire_volcano_demo.json"
        layout = IslandLayout.from_json(layout_path.read_text(encoding="utf-8"))
        field = build_semantic_terrain_field_from_layout(layout, bake_quality="hero")
        window_size = 24
        worst_mid_wall_red_fraction = 0.0
        worst_outer_wall_red_fraction = 0.0

        for start in range(0, field.radial_segments, window_size):
            mid_red = 0
            mid_total = 0
            for ring in range(round(field.rings * 0.56), round(field.rings * 0.74) + 1):
                for offset in range(window_size):
                    mid_total += 1
                    if material_for_terrain_field_face(field, ring, (start + offset) % field.radial_segments) == "M_ElementCrack":
                        mid_red += 1
            worst_mid_wall_red_fraction = max(worst_mid_wall_red_fraction, mid_red / mid_total)

            outer_red = 0
            outer_total = 0
            for ring in range(round(field.rings * 0.70), round(field.rings * 0.96) + 1):
                for offset in range(window_size):
                    outer_total += 1
                    if material_for_terrain_field_face(field, ring, (start + offset) % field.radial_segments) == "M_ElementCrack":
                        outer_red += 1
            worst_outer_wall_red_fraction = max(worst_outer_wall_red_fraction, outer_red / outer_total)

        self.assertLess(worst_mid_wall_red_fraction, 0.80)
        self.assertLess(worst_outer_wall_red_fraction, 0.84)

    def test_fire_hero_uses_slope_masks_for_exposed_rim_rock(self):
        layout = default_layout("fire", seed=2002)
        field = build_semantic_terrain_field_from_layout(layout, bake_quality="hero")
        rim_start = round(field.rings * 0.34)
        rim_end = round(field.rings * 0.48)
        candidates = [
            (field.slope_mask[ring][index], ring, index)
            for ring in range(rim_start, rim_end + 1)
            for index in range(field.radial_segments)
            if field.path_mask[ring][index] < 0.2
            and field.lava_mask[ring][index] < 0.2
            and field.crater_loop_mask[ring][index] < 0.2
            and field.strata_mask[ring][index] > 0.42
        ]

        self.assertTrue(candidates)
        _slope, ring, index = max(candidates)
        self.assertEqual(material_for_terrain_field_face(field, ring, index), "M_CliffRock")

    def test_fire_demo_hero_high_slope_lava_shoulders_do_not_export_as_topgrass(self):
        layout_path = Path(__file__).resolve().parents[1] / "layouts" / "fire_volcano_demo.json"
        layout = IslandLayout.from_json(layout_path.read_text(encoding="utf-8"))
        field = build_semantic_terrain_field_from_layout(layout, bake_quality="hero")
        candidates = []
        topgrass_shoulders = []

        for ring in range(round(field.rings * 0.30), round(field.rings * 0.62) + 1):
            for index in range(field.radial_segments):
                if field.path_mask[ring][index] > 0.16 or field.crater_loop_mask[ring][index] > 0.20:
                    continue
                if field.slope_mask[ring][index] <= 0.78:
                    continue
                if max(field.strata_mask[ring][index], field.lava_mask[ring][index], field.volcano_mask[ring][index]) <= 0.28:
                    continue

                material = material_for_terrain_field_face(field, ring, index)
                candidates.append(material)
                if _is_top_surface_material(material):
                    topgrass_shoulders.append((ring, index))

        self.assertGreater(len(candidates), 1000)
        self.assertLess(len(topgrass_shoulders) / len(candidates), 0.06)

    def test_fire_demo_hero_mid_apron_rock_shoulders_keep_rock_material(self):
        layout_path = Path(__file__).resolve().parents[1] / "layouts" / "fire_volcano_demo.json"
        layout = IslandLayout.from_json(layout_path.read_text(encoding="utf-8"))
        field = build_semantic_terrain_field_from_layout(layout, bake_quality="hero")
        candidates = []
        topgrass_shoulders = []

        for ring in range(round(field.rings * 0.56), round(field.rings * 0.66) + 1):
            for index in range(field.radial_segments):
                if field.path_mask[ring][index] > 0.16 or field.crater_loop_mask[ring][index] > 0.18:
                    continue
                if field.lava_mask[ring][index] > 0.62:
                    continue
                if field.slope_mask[ring][index] <= 0.86 or field.talus_mask[ring][index] <= 0.38:
                    continue
                if max(field.strata_mask[ring][index], field.lava_mask[ring][index]) <= 0.26:
                    continue

                material = material_for_terrain_field_face(field, ring, index)
                candidates.append(material)
                if _is_top_surface_material(material):
                    topgrass_shoulders.append((ring, index))

        self.assertGreater(len(candidates), 400)
        self.assertLess(len(topgrass_shoulders) / len(candidates), 0.02)

    def test_fire_demo_hero_inner_strata_wall_exports_as_rock_not_topgrass(self):
        layout_path = Path(__file__).resolve().parents[1] / "layouts" / "fire_volcano_demo.json"
        layout = IslandLayout.from_json(layout_path.read_text(encoding="utf-8"))
        field = build_semantic_terrain_field_from_layout(layout, bake_quality="hero")
        candidates = []
        topgrass_wall_faces = []

        for ring in range(round(field.rings * 0.30), round(field.rings * 0.38) + 1):
            for index in range(field.radial_segments):
                if field.path_mask[ring][index] > 0.12 or field.lava_mask[ring][index] > 0.12:
                    continue
                if field.crater_loop_mask[ring][index] > 0.22:
                    continue
                if field.slope_mask[ring][index] <= 0.70 or field.strata_mask[ring][index] <= 0.42:
                    continue

                material = material_for_terrain_field_face(field, ring, index)
                candidates.append(material)
                if _is_top_surface_material(material):
                    topgrass_wall_faces.append((ring, index))

        self.assertGreater(len(candidates), 100)
        self.assertLess(len(topgrass_wall_faces) / len(candidates), 0.15)

    def test_fire_demo_hero_moderate_inner_strata_wall_is_not_exported_as_topgrass(self):
        layout_path = Path(__file__).resolve().parents[1] / "layouts" / "fire_volcano_demo.json"
        layout = IslandLayout.from_json(layout_path.read_text(encoding="utf-8"))
        field = build_semantic_terrain_field_from_layout(layout, bake_quality="hero")
        candidates = []
        topgrass_wall_faces = []

        for ring in range(round(field.rings * 0.31), round(field.rings * 0.36) + 1):
            for index in range(field.radial_segments):
                if field.path_mask[ring][index] > 0.12 or field.lava_mask[ring][index] > 0.12:
                    continue
                if field.crater_loop_mask[ring][index] > 0.18:
                    continue
                if field.slope_mask[ring][index] <= 0.66 or field.strata_mask[ring][index] <= 0.38:
                    continue

                material = material_for_terrain_field_face(field, ring, index)
                candidates.append(material)
                if _is_top_surface_material(material):
                    topgrass_wall_faces.append((ring, index))

        self.assertGreater(len(candidates), 70)
        self.assertLess(len(topgrass_wall_faces) / len(candidates), 0.08)

    def test_fire_demo_hero_steep_crater_loop_wall_exports_as_rock_not_topgrass(self):
        layout_path = Path(__file__).resolve().parents[1] / "layouts" / "fire_volcano_demo.json"
        layout = IslandLayout.from_json(layout_path.read_text(encoding="utf-8"))
        field = build_semantic_terrain_field_from_layout(layout, bake_quality="hero")
        candidates = []
        topgrass_loop_walls = []

        def face_average(mask, ring, index):
            next_index = (index + 1) % field.radial_segments
            previous_ring = max(0, ring - 1)
            return (
                mask[ring][index]
                + mask[ring][next_index]
                + mask[previous_ring][index]
                + mask[previous_ring][next_index]
            ) * 0.25

        def face_peak(mask, ring, index):
            next_index = (index + 1) % field.radial_segments
            previous_ring = max(0, ring - 1)
            return max(
                mask[ring][index],
                mask[ring][next_index],
                mask[previous_ring][index],
                mask[previous_ring][next_index],
            )

        for ring in range(round(field.rings * 0.37), round(field.rings * 0.50) + 1):
            for index in range(field.radial_segments):
                if face_average(field.path_mask, ring, index) > 0.28:
                    continue
                if face_average(field.lava_mask, ring, index) > 0.22:
                    continue
                if face_average(field.crater_loop_mask, ring, index) <= 0.46:
                    continue
                if face_peak(field.slope_mask, ring, index) <= 0.72:
                    continue
                if face_peak(field.strata_mask, ring, index) <= 0.58:
                    continue

                material = material_for_terrain_field_face(field, ring, index)
                candidates.append(material)
                if _is_top_surface_material(material):
                    topgrass_loop_walls.append((ring, index))

        self.assertGreater(len(candidates), 1200)
        self.assertLess(len(topgrass_loop_walls) / len(candidates), 0.02)

    def test_fire_demo_hero_volcano_strata_transition_wall_exports_as_rock(self):
        layout_path = Path(__file__).resolve().parents[1] / "layouts" / "fire_volcano_demo.json"
        layout = IslandLayout.from_json(layout_path.read_text(encoding="utf-8"))
        field = build_semantic_terrain_field_from_layout(layout, bake_quality="hero")
        candidates = []
        topgrass_strata_walls = []

        def face_average(mask, ring, index):
            next_index = (index + 1) % field.radial_segments
            previous_ring = max(0, ring - 1)
            return (
                mask[ring][index]
                + mask[ring][next_index]
                + mask[previous_ring][index]
                + mask[previous_ring][next_index]
            ) * 0.25

        def face_peak(mask, ring, index):
            next_index = (index + 1) % field.radial_segments
            previous_ring = max(0, ring - 1)
            return max(
                mask[ring][index],
                mask[ring][next_index],
                mask[previous_ring][index],
                mask[previous_ring][next_index],
            )

        for ring in range(round(field.rings * 0.37), round(field.rings * 0.52) + 1):
            for index in range(field.radial_segments):
                if face_average(field.path_mask, ring, index) > 0.42:
                    continue
                if face_average(field.lava_mask, ring, index) > 0.22:
                    continue
                if face_average(field.volcano_mask, ring, index) <= 0.46:
                    continue
                if face_peak(field.slope_mask, ring, index) <= 0.68:
                    continue
                if face_peak(field.strata_mask, ring, index) <= 0.64:
                    continue

                material = material_for_terrain_field_face(field, ring, index)
                candidates.append(material)
                if _is_top_surface_material(material):
                    topgrass_strata_walls.append((ring, index))

        self.assertGreater(len(candidates), 2400)
        self.assertLess(len(topgrass_strata_walls) / len(candidates), 0.02)

    def test_fire_demo_hero_outer_volcano_strata_shoulders_keep_rock_material(self):
        layout_path = Path(__file__).resolve().parents[1] / "layouts" / "fire_volcano_demo.json"
        layout = IslandLayout.from_json(layout_path.read_text(encoding="utf-8"))
        field = build_semantic_terrain_field_from_layout(layout, bake_quality="hero")
        candidates = []
        topgrass_strata_shoulders = []

        def face_average(mask, ring, index):
            next_index = (index + 1) % field.radial_segments
            previous_ring = max(0, ring - 1)
            return (
                mask[ring][index]
                + mask[ring][next_index]
                + mask[previous_ring][index]
                + mask[previous_ring][next_index]
            ) * 0.25

        def face_peak(mask, ring, index):
            next_index = (index + 1) % field.radial_segments
            previous_ring = max(0, ring - 1)
            return max(
                mask[ring][index],
                mask[ring][next_index],
                mask[previous_ring][index],
                mask[previous_ring][next_index],
            )

        for ring in range(round(field.rings * 0.46), round(field.rings * 0.54) + 1):
            for index in range(field.radial_segments):
                if face_average(field.path_mask, ring, index) > 0.22:
                    continue
                if face_average(field.lava_mask, ring, index) > 0.18:
                    continue
                if face_average(field.volcano_mask, ring, index) <= 0.88:
                    continue
                if face_peak(field.slope_mask, ring, index) <= 0.68:
                    continue
                if face_peak(field.strata_mask, ring, index) <= 0.60:
                    continue

                material = material_for_terrain_field_face(field, ring, index)
                candidates.append(material)
                if _is_top_surface_material(material):
                    topgrass_strata_shoulders.append((ring, index))

        self.assertGreater(len(candidates), 800)
        self.assertLess(len(topgrass_strata_shoulders) / len(candidates), 0.003)

    def test_fire_demo_hero_moderate_lava_shoulders_keep_rock_material(self):
        layout_path = Path(__file__).resolve().parents[1] / "layouts" / "fire_volcano_demo.json"
        layout = IslandLayout.from_json(layout_path.read_text(encoding="utf-8"))
        field = build_semantic_terrain_field_from_layout(layout, bake_quality="hero")
        candidates = []
        topgrass_lava_shoulders = []

        def face_average(mask, ring, index):
            next_index = (index + 1) % field.radial_segments
            previous_ring = max(0, ring - 1)
            return (
                mask[ring][index]
                + mask[ring][next_index]
                + mask[previous_ring][index]
                + mask[previous_ring][next_index]
            ) * 0.25

        def face_peak(mask, ring, index):
            next_index = (index + 1) % field.radial_segments
            previous_ring = max(0, ring - 1)
            return max(
                mask[ring][index],
                mask[ring][next_index],
                mask[previous_ring][index],
                mask[previous_ring][next_index],
            )

        for ring in range(round(field.rings * 0.54), round(field.rings * 0.72) + 1):
            for index in range(field.radial_segments):
                lava = face_average(field.lava_mask, ring, index)
                if face_average(field.path_mask, ring, index) > 0.22:
                    continue
                if face_average(field.crater_loop_mask, ring, index) > 0.24:
                    continue
                if lava <= 0.28 or lava > 0.68:
                    continue
                if face_peak(field.slope_mask, ring, index) <= 0.70:
                    continue
                if face_peak(field.talus_mask, ring, index) <= 0.16:
                    continue

                material = material_for_terrain_field_face(field, ring, index)
                candidates.append(material)
                if _is_top_surface_material(material):
                    topgrass_lava_shoulders.append((ring, index))

        self.assertGreater(len(candidates), 220)
        self.assertLess(len(topgrass_lava_shoulders) / len(candidates), 0.01)

    def test_fire_demo_hero_blackrock_talus_shoulders_keep_rock_material(self):
        layout_path = Path(__file__).resolve().parents[1] / "layouts" / "fire_volcano_demo.json"
        layout = IslandLayout.from_json(layout_path.read_text(encoding="utf-8"))
        field = build_semantic_terrain_field_from_layout(layout, bake_quality="hero")
        candidates = []
        topgrass_talus_shoulders = []

        for ring in range(round(field.rings * 0.54), round(field.rings * 0.70) + 1):
            for index in range(field.radial_segments):
                if field.path_mask[ring][index] > 0.20 or field.crater_loop_mask[ring][index] > 0.18:
                    continue
                if field.lava_mask[ring][index] > 0.20:
                    continue
                if field.slope_mask[ring][index] <= 0.72 or field.talus_mask[ring][index] <= 0.32:
                    continue

                material = material_for_terrain_field_face(field, ring, index)
                candidates.append(material)
                if _is_top_surface_material(material):
                    topgrass_talus_shoulders.append((ring, index))

        self.assertGreater(len(candidates), 650)
        self.assertLess(len(topgrass_talus_shoulders) / len(candidates), 0.015)

    def test_fire_semantic_terrain_field_derives_houdini_like_process_masks(self):
        layout = default_layout("fire", seed=2002)
        field = build_semantic_terrain_field_from_layout(layout, radial_segments=96, rings=14, bake_quality="hero")
        outer_ring = round(field.rings * 0.86)
        inner_ring = 2
        lava_index = round(0.42 / math.tau * field.radial_segments)
        side_index = field.radial_segments // 4

        self.assertGreater(field.slope_mask[outer_ring][side_index], 0.45)
        self.assertGreater(field.talus_mask[outer_ring][side_index], 0.35)
        self.assertLess(field.talus_mask[inner_ring][0], 0.12)
        self.assertGreater(field.lava_flow_mask[outer_ring][lava_index], 0.55)
        self.assertLess(field.lava_flow_mask[outer_ring][side_index], 0.3)

    def test_fire_hero_talus_apron_absorbs_random_angular_spikes(self):
        layout = default_layout("fire", seed=2002)
        field = build_semantic_terrain_field_from_layout(layout, bake_quality="hero")
        outer_ring = round(field.rings * 0.86)
        angular_deltas = [
            abs(field.heights[outer_ring][index] - field.heights[outer_ring][(index + 1) % field.radial_segments])
            for index in range(field.radial_segments)
            if field.path_mask[outer_ring][index] < 0.15 and field.lava_mask[outer_ring][index] < 0.20
        ]

        self.assertGreater(statistics.mean(field.talus_mask[outer_ring]), 0.45)
        self.assertLess(_percentile(angular_deltas, 0.90), 235.0)

    def test_fire_hero_weathering_cleanup_removes_isolated_knife_points(self):
        layout = default_layout("fire", seed=2002)
        field = build_semantic_terrain_field_from_layout(layout, bake_quality="hero")
        residuals = []
        for ring in range(round(field.rings * 0.32), round(field.rings * 0.92) + 1):
            for index in range(field.radial_segments):
                if field.path_mask[ring][index] > 0.20 or field.lava_mask[ring][index] > 0.35:
                    continue
                height = field.heights[ring][index]
                neighbors = [
                    field.heights[ring][index - 1],
                    field.heights[ring][(index + 1) % field.radial_segments],
                    field.heights[max(0, ring - 1)][index],
                    field.heights[min(field.rings, ring + 1)][index],
                ]
                residuals.append(abs(height - sum(neighbors) / len(neighbors)))

        self.assertLess(_percentile(residuals, 0.99), 190.0)

    def test_fire_hero_outer_apron_weathers_knife_edges_without_filling_lava_channels(self):
        layout = default_layout("fire", seed=2002)
        field = build_semantic_terrain_field_from_layout(layout, bake_quality="hero")
        outer_ring = round(field.rings * 0.86)
        angular_deltas = [
            abs(field.heights[outer_ring][index] - field.heights[outer_ring][(index + 1) % field.radial_segments])
            for index in range(field.radial_segments)
            if field.path_mask[outer_ring][index] < 0.15 and field.lava_mask[outer_ring][index] < 0.20
        ]
        lava_ring = round(field.rings * 0.76)
        lava_index = round(0.42 / math.tau * field.radial_segments)
        shoulder_offset = round(field.radial_segments * 0.018)
        lava_center = field.heights[lava_ring][lava_index]
        lava_shoulder = min(
            field.heights[lava_ring][(lava_index - shoulder_offset) % field.radial_segments],
            field.heights[lava_ring][(lava_index + shoulder_offset) % field.radial_segments],
        )

        self.assertLess(_percentile(angular_deltas, 0.95), 230.0)
        self.assertGreater(lava_shoulder - lava_center, 250.0)

    def test_fire_hero_mid_blackrock_weathers_into_broad_talus_bands(self):
        layout = default_layout("fire", seed=2002)
        field = build_semantic_terrain_field_from_layout(layout, bake_quality="hero")
        angular_deltas = []
        residuals = []
        for ring in range(round(field.rings * 0.52), round(field.rings * 0.76) + 1):
            for index in range(field.radial_segments):
                semantic_guard = max(
                    field.path_mask[ring][index],
                    field.lava_mask[ring][index],
                    field.volcano_mask[ring][index],
                    field.crater_loop_mask[ring][index],
                )
                if semantic_guard > 0.18:
                    continue

                height = field.heights[ring][index]
                neighbors = [
                    field.heights[ring][index - 1],
                    field.heights[ring][(index + 1) % field.radial_segments],
                    field.heights[ring - 1][index],
                    field.heights[ring + 1][index],
                ]
                angular_deltas.append(abs(height - field.heights[ring][(index + 1) % field.radial_segments]))
                residuals.append(abs(height - sum(neighbors) / len(neighbors)))

        self.assertLess(_percentile(angular_deltas, 0.95), 225.0)
        self.assertLess(_percentile(residuals, 0.99), 200.0)

    def test_forest_hero_root_ridges_read_above_soft_shelves(self):
        layout = default_layout("forest", seed=2002)
        field = build_semantic_terrain_field_from_layout(layout, bake_quality="hero")
        ring = round(field.rings * 0.46)
        root_angles = (0.35, 2.45, 4.65)
        root_heights = [
            field.heights[ring][round(angle / math.tau * field.radial_segments) % field.radial_segments]
            for angle in root_angles
        ]
        shelf_heights = [
            field.heights[ring][index]
            for index in range(field.radial_segments)
            if field.path_mask[ring][index] < 0.12
        ]

        self.assertGreater(statistics.mean(root_heights), statistics.mean(shelf_heights) + 220.0)

    def test_forest_hero_canopy_platform_has_calm_organic_center(self):
        layout = default_layout("forest", seed=2002)
        field = build_semantic_terrain_field_from_layout(layout, bake_quality="hero")
        ring = round(field.rings * 0.22)
        heights = field.heights[ring]
        angular_deltas = [
            abs(heights[index] - heights[(index + 1) % field.radial_segments])
            for index in range(field.radial_segments)
        ]

        self.assertLess(_percentile(angular_deltas, 0.90), 70.0)
        self.assertLess(max(heights) - min(heights), 280.0)

    def test_forest_hero_tree_stump_cave_has_hollow_and_lip(self):
        layout = default_layout("forest", seed=2002)
        field = build_semantic_terrain_field_from_layout(layout, bake_quality="hero")
        ring = round(field.rings * 0.34)
        cave_index = round(2.36 / math.tau * field.radial_segments) % field.radial_segments
        side_offset = round(field.radial_segments * 0.045)
        cave_height = field.heights[ring][cave_index]
        lip_height = max(
            field.heights[ring][(cave_index - side_offset) % field.radial_segments],
            field.heights[ring][(cave_index + side_offset) % field.radial_segments],
        )

        self.assertGreater(lip_height - cave_height, 180.0)

    def test_forest_hero_tree_stump_cave_is_semantic_crack_material(self):
        layout = default_layout("forest", seed=2002)
        field = build_semantic_terrain_field_from_layout(layout, bake_quality="hero")
        ring = round(field.rings * 0.34)
        cave_index = round(2.36 / math.tau * field.radial_segments) % field.radial_segments

        self.assertEqual(material_for_terrain_field_face(field, ring, cave_index), "M_ElementCrack")

    def test_forest_hero_mushroom_pocket_has_bowl_and_living_rim(self):
        layout = default_layout("forest", seed=2002)
        field = build_semantic_terrain_field_from_layout(layout, bake_quality="hero")
        pocket_radius = math.sqrt(0.28 * 0.28 + 0.34 * 0.34)
        pocket_angle = math.atan2(0.34, 0.28) % math.tau
        ring = round(field.rings * pocket_radius)
        center = round(pocket_angle / math.tau * field.radial_segments) % field.radial_segments
        offset = round(field.radial_segments * 0.052)
        bowl_height = field.heights[ring][center]
        rim_height = max(
            field.heights[ring][(center - offset) % field.radial_segments],
            field.heights[ring][(center + offset) % field.radial_segments],
        )

        self.assertGreater(rim_height - bowl_height, 320.0)
        self.assertEqual(material_for_terrain_field_face(field, ring, center), "M_TopGrass")

    def test_forest_erosion_age_deepens_stump_and_mushroom_collapse_pits(self):
        layout = default_layout("forest", seed=2002)
        young = build_semantic_terrain_field_from_layout(_with_process(layout, erosion_age=0.05), bake_quality="hero")
        old = build_semantic_terrain_field_from_layout(_with_process(layout, erosion_age=1.0), bake_quality="hero")

        stump_radius = math.sqrt((-0.25) * (-0.25) + 0.25 * 0.25)
        stump_angle = math.atan2(0.25, -0.25) % math.tau
        stump_ring = round(old.rings * stump_radius)
        stump_index = round(stump_angle / math.tau * old.radial_segments) % old.radial_segments
        stump_lip_offset = round(old.radial_segments * 0.045)

        mushroom_radius = math.sqrt(0.28 * 0.28 + 0.34 * 0.34)
        mushroom_angle = math.atan2(0.34, 0.28) % math.tau
        mushroom_ring = round(old.rings * mushroom_radius)
        mushroom_index = round(mushroom_angle / math.tau * old.radial_segments) % old.radial_segments
        mushroom_lip_offset = round(old.radial_segments * 0.052)

        young_stump = young.heights[stump_ring][stump_index]
        old_stump = old.heights[stump_ring][stump_index]
        young_stump_lip = max(
            young.heights[stump_ring][(stump_index - stump_lip_offset) % young.radial_segments],
            young.heights[stump_ring][(stump_index + stump_lip_offset) % young.radial_segments],
        )
        old_stump_lip = max(
            old.heights[stump_ring][(stump_index - stump_lip_offset) % old.radial_segments],
            old.heights[stump_ring][(stump_index + stump_lip_offset) % old.radial_segments],
        )

        young_mushroom = young.heights[mushroom_ring][mushroom_index]
        old_mushroom = old.heights[mushroom_ring][mushroom_index]
        young_mushroom_lip = max(
            young.heights[mushroom_ring][(mushroom_index - mushroom_lip_offset) % young.radial_segments],
            young.heights[mushroom_ring][(mushroom_index + mushroom_lip_offset) % young.radial_segments],
        )
        old_mushroom_lip = max(
            old.heights[mushroom_ring][(mushroom_index - mushroom_lip_offset) % old.radial_segments],
            old.heights[mushroom_ring][(mushroom_index + mushroom_lip_offset) % old.radial_segments],
        )

        self.assertLess(old_stump, young_stump - 140.0)
        self.assertGreater(old_stump_lip - old_stump, young_stump_lip - young_stump + 120.0)
        self.assertLess(old_mushroom, young_mushroom - 140.0)
        self.assertGreater(old_mushroom_lip - old_mushroom, young_mushroom_lip - young_mushroom + 120.0)

    def test_forest_hero_vine_anchor_is_a_projecting_walkable_ledge(self):
        layout = default_layout("forest", seed=2002)
        field = build_semantic_terrain_field_from_layout(layout, bake_quality="hero")
        anchor_radius = math.sqrt(0.62 * 0.62 + 0.18 * 0.18)
        anchor_angle = math.atan2(0.18, 0.62) % math.tau
        ring = round(field.rings * anchor_radius)
        center = round(anchor_angle / math.tau * field.radial_segments) % field.radial_segments
        offset = round(field.radial_segments * 0.070)
        ledge_height = field.heights[ring][center]
        side_height = max(
            field.heights[ring][(center - offset) % field.radial_segments],
            field.heights[ring][(center + offset) % field.radial_segments],
        )

        self.assertGreater(ledge_height, side_height + 220.0)
        self.assertEqual(material_for_terrain_field_face(field, ring, center), "M_PathDirt")

    def test_forest_hero_vine_bridge_midpoint_is_mapped_as_walkable_route(self):
        layout = default_layout("forest", seed=2002)
        field = build_semantic_terrain_field_from_layout(layout, bake_quality="hero")
        midpoint_x = (0.62 + 0.20) * 0.5
        midpoint_y = (0.18 + 0.42) * 0.5
        midpoint_radius = math.sqrt(midpoint_x * midpoint_x + midpoint_y * midpoint_y)
        midpoint_angle = math.atan2(midpoint_y, midpoint_x) % math.tau
        ring = round(field.rings * midpoint_radius)
        index = round(midpoint_angle / math.tau * field.radial_segments) % field.radial_segments

        self.assertGreater(field.path_mask[ring][index], 0.38)
        self.assertEqual(material_for_terrain_field_face(field, ring, index), "M_PathDirt")

    def test_ice_hero_crevasses_are_deeper_than_broken_shelf_shoulders(self):
        layout = default_layout("ice", seed=2002)
        field = build_semantic_terrain_field_from_layout(layout, bake_quality="hero")
        ring = round(field.rings * 0.66)
        crack_angles = (0.78, 2.55, 4.75)
        differences = []
        offset = round(field.radial_segments * 0.018)
        for angle in crack_angles:
            index = round(angle / math.tau * field.radial_segments) % field.radial_segments
            crack_height = field.heights[ring][index]
            shoulder_height = max(
                field.heights[ring][(index - offset) % field.radial_segments],
                field.heights[ring][(index + offset) % field.radial_segments],
            )
            differences.append(shoulder_height - crack_height)

        self.assertGreater(statistics.mean(differences), 220.0)

    def test_ice_hero_crevasse_centers_are_semantic_crack_material(self):
        layout = default_layout("ice", seed=2002)
        field = build_semantic_terrain_field_from_layout(layout, bake_quality="hero")
        ring = round(field.rings * 0.66)
        crack_angles = (0.78, 2.55, 4.75)

        for angle in crack_angles:
            index = round(angle / math.tau * field.radial_segments) % field.radial_segments
            self.assertEqual(material_for_terrain_field_face(field, ring, index), "M_ElementCrack")

    def test_ice_hero_crystal_wall_builds_a_distinct_skyline(self):
        layout = default_layout("ice", seed=2002)
        field = build_semantic_terrain_field_from_layout(layout, bake_quality="hero")
        wall_angles = (1.18, 4.18)
        quiet_angles = (0.0, 3.4)
        ring_start = round(field.rings * 0.32)
        ring_end = round(field.rings * 0.72)

        wall_peaks = []
        for angle in wall_angles:
            index = round(angle / math.tau * field.radial_segments) % field.radial_segments
            wall_peaks.append(max(field.heights[ring][index] for ring in range(ring_start, ring_end)))

        quiet_peaks = []
        for angle in quiet_angles:
            index = round(angle / math.tau * field.radial_segments) % field.radial_segments
            quiet_peaks.append(max(field.heights[ring][index] for ring in range(ring_start, ring_end)))

        self.assertGreater(statistics.mean(wall_peaks), statistics.mean(quiet_peaks) + 520.0)

    def test_ice_hero_resource_crystal_clusters_are_sharp_functional_landmarks(self):
        layout = default_layout("ice", seed=2002)
        field = build_semantic_terrain_field_from_layout(layout, bake_quality="hero")
        cluster_angles = (0.28, 2.05, 5.25)
        ring = round(field.rings * 0.48)
        offset = round(field.radial_segments * 0.028)
        prominence = []
        for angle in cluster_angles:
            index = round(angle / math.tau * field.radial_segments) % field.radial_segments
            peak = field.heights[ring][index]
            shoulder = max(
                field.heights[ring][(index - offset) % field.radial_segments],
                field.heights[ring][(index + offset) % field.radial_segments],
            )
            prominence.append(peak - shoulder)

        self.assertGreater(statistics.mean(prominence), 260.0)

    def test_ice_hero_resource_crystal_clusters_are_hard_material_regions(self):
        layout = default_layout("ice", seed=2002)
        field = build_semantic_terrain_field_from_layout(layout, bake_quality="hero")
        ring = round(field.rings * 0.48)

        for angle in (0.28, 2.05, 5.25):
            index = round(angle / math.tau * field.radial_segments) % field.radial_segments
            self.assertEqual(material_for_terrain_field_face(field, ring, index), "M_CliffRock")

    def test_ice_hero_broken_plate_edges_form_angular_shelves(self):
        layout = default_layout("ice", seed=2002)
        field = build_semantic_terrain_field_from_layout(layout, bake_quality="hero")
        ring = round(field.rings * 0.58)
        plate_angles = (0.0, 1.62, 3.26, 4.86)
        step_deltas = []
        offset = round(field.radial_segments * 0.022)
        for angle in plate_angles:
            index = round(angle / math.tau * field.radial_segments) % field.radial_segments
            step_deltas.append(
                abs(field.heights[ring][(index + offset) % field.radial_segments] - field.heights[ring][(index - offset) % field.radial_segments])
            )

        self.assertGreater(statistics.mean(step_deltas), 180.0)
        self.assertGreater(min(step_deltas), 220.0)

    def test_fine_terrain_field_exports_flow_curvature_and_strata_masks(self):
        layout = default_layout("fire", seed=2002)
        field = build_semantic_terrain_field_from_layout(layout, radial_segments=96, rings=14, bake_quality="hero")
        payload = terrain_field_preview_payload(field)

        self.assertEqual(len(field.flow_accumulation_mask), field.rings + 1)
        self.assertEqual(len(field.curvature_mask), field.rings + 1)
        self.assertEqual(len(field.strata_mask), field.rings + 1)
        self.assertIn("flow_accumulation", payload["masks"])
        self.assertIn("curvature", payload["masks"])
        self.assertIn("strata", payload["masks"])

    def test_flow_accumulation_prefers_lava_channels_over_side_shelves(self):
        layout = default_layout("fire", seed=2002)
        field = build_semantic_terrain_field_from_layout(layout, radial_segments=96, rings=14, bake_quality="hero")
        outer_ring = round(field.rings * 0.78)
        lava_index = round(0.42 / math.tau * field.radial_segments)
        side_index = field.radial_segments // 4

        self.assertGreater(
            field.flow_accumulation_mask[outer_ring][lava_index],
            field.flow_accumulation_mask[outer_ring][side_index] + 0.25,
        )

    def test_strata_mask_prefers_exposed_cliffs_and_rim_shoulders(self):
        layout = default_layout("fire", seed=2002)
        field = build_semantic_terrain_field_from_layout(layout, radial_segments=96, rings=14, bake_quality="hero")
        outer_ring = round(field.rings * 0.86)
        rim_ring = round(field.rings * 0.42)
        path_index = 0
        side_index = field.radial_segments // 4

        self.assertGreater(field.strata_mask[outer_ring][side_index], field.strata_mask[outer_ring][path_index] + 0.2)
        self.assertGreater(field.strata_mask[rim_ring][side_index], field.strata_mask[2][side_index] + 0.2)

    def test_terrain_field_preview_payload_serializes_process_masks_compactly(self):
        layout = default_layout("fire", seed=2002)
        field = build_semantic_terrain_field_from_layout(layout, radial_segments=12, rings=4, bake_quality="draft")
        payload = terrain_field_preview_payload(field)

        self.assertEqual(payload["radial_segments"], 12)
        self.assertEqual(payload["rings"], 4)
        self.assertEqual(payload["biome"], "fire")
        self.assertIn("slope", payload["masks"])
        self.assertIn("talus", payload["masks"])
        self.assertIn("lava_flow", payload["masks"])
        self.assertIn("heights", payload)
        self.assertEqual(len(payload["heights"]), 5)
        self.assertEqual(len(payload["heights"][0]), 12)
        self.assertEqual(len(payload["masks"]["slope"]), 5)
        self.assertEqual(len(payload["masks"]["slope"][0]), 12)
        self.assertIsInstance(payload["masks"]["slope"][0][0], float)
        self.assertLessEqual(len(str(payload["masks"]["slope"][0][0]).split(".")[-1]), 3)
        self.assertLessEqual(len(str(payload["heights"][0][0]).split(".")[-1]), 1)

    def test_fire_layout_volcano_radius_controls_crater_footprint(self):
        layout = default_layout("fire", seed=2002)
        small = _with_landmark(layout, "central_volcano", radius=0.32)
        large = _with_landmark(layout, "central_volcano", radius=0.54)

        small_mesh = generate_island_mesh_from_layout(small, radial_segments=96, rings=14)
        large_mesh = generate_island_mesh_from_layout(large, radial_segments=96, rings=14)

        self.assertGreater(_rim_peak_radius(large_mesh, large.radius_m), _rim_peak_radius(small_mesh, small.radius_m) + 0.08)

    def test_fire_layout_lava_channel_count_controls_crack_coverage(self):
        layout = default_layout("fire", seed=2002)
        two_channels = _with_landmark(layout, "lava_channels", count=2)
        four_channels = _with_landmark(layout, "lava_channels", count=4)

        two_mesh = generate_island_mesh_from_layout(two_channels, radial_segments=96, rings=14)
        four_mesh = generate_island_mesh_from_layout(four_channels, radial_segments=96, rings=14)
        two_cracks = _material_faces_in_radial_band(two_mesh, "M_ElementCrack", two_channels.radius_m, 0.34, 0.9)
        four_cracks = _material_faces_in_radial_band(four_mesh, "M_ElementCrack", four_channels.radius_m, 0.34, 0.9)

        self.assertGreater(len(four_cracks), len(two_cracks) + 18)

    def test_fire_layout_crater_loop_coverage_controls_ring_path(self):
        layout = default_layout("fire", seed=2002)
        no_loop = _with_path(layout, "partial_crater_loop", coverage=0.0)
        broad_loop = _with_path(layout, "partial_crater_loop", coverage=0.78)

        no_loop_mesh = generate_island_mesh_from_layout(no_loop, radial_segments=96, rings=14)
        broad_loop_mesh = generate_island_mesh_from_layout(broad_loop, radial_segments=96, rings=14)
        no_loop_faces = _material_faces_in_radial_band(no_loop_mesh, "M_PathDirt", no_loop.radius_m, 0.26, 0.46)
        broad_loop_faces = _material_faces_in_radial_band(broad_loop_mesh, "M_PathDirt", broad_loop.radius_m, 0.26, 0.46)

        self.assertGreater(len(broad_loop_faces), len(no_loop_faces) + 12)

    def test_forest_layout_mushroom_pocket_center_controls_bowl_position(self):
        layout = default_layout("forest", seed=2002)
        shifted = replace(
            layout,
            zones=tuple(
                replace(zone, center=(-0.42, 0.18)) if zone.id == "mushroom_pocket" else zone
                for zone in layout.zones
            ),
        )

        field = build_semantic_terrain_field_from_layout(shifted, bake_quality="hero")
        ring = round(field.rings * math.sqrt((-0.42) * (-0.42) + 0.18 * 0.18))
        center = round(math.atan2(0.18, -0.42) / math.tau * field.radial_segments) % field.radial_segments
        old_center = round(math.atan2(0.34, 0.28) / math.tau * field.radial_segments) % field.radial_segments
        old_ring = round(field.rings * math.sqrt(0.28 * 0.28 + 0.34 * 0.34))
        offset = round(field.radial_segments * 0.052)
        shifted_bowl = field.heights[ring][center]
        shifted_rim = max(field.heights[ring][(center - offset) % field.radial_segments], field.heights[ring][(center + offset) % field.radial_segments])
        old_bowl = field.heights[old_ring][old_center]
        old_rim = max(field.heights[old_ring][(old_center - offset) % field.radial_segments], field.heights[old_ring][(old_center + offset) % field.radial_segments])

        self.assertGreater(shifted_rim - shifted_bowl, 260.0)
        self.assertGreater((shifted_rim - shifted_bowl) - (old_rim - old_bowl), 140.0)

    def test_forest_layout_vine_bridge_width_controls_route_mask(self):
        layout = default_layout("forest", seed=2002)
        narrow = _with_path(layout, "vine_bridge", width=0.035)
        wide = _with_path(layout, "vine_bridge", width=0.16)
        narrow_field = build_semantic_terrain_field_from_layout(narrow, bake_quality="hero")
        wide_field = build_semantic_terrain_field_from_layout(wide, bake_quality="hero")
        sample_x = 0.40
        sample_y = 0.21
        ring = round(wide_field.rings * math.sqrt(sample_x * sample_x + sample_y * sample_y))
        index = round(math.atan2(sample_y, sample_x) / math.tau * wide_field.radial_segments) % wide_field.radial_segments

        self.assertGreater(wide_field.path_mask[ring][index], narrow_field.path_mask[ring][index] + 0.35)

    def test_ice_layout_crystal_wall_radius_controls_skyline_ring(self):
        layout = default_layout("ice", seed=2002)
        inner = _with_landmark(layout, "primary_crystal_wall", radius=0.42)
        outer = _with_landmark(layout, "primary_crystal_wall", radius=0.66)
        inner_field = build_semantic_terrain_field_from_layout(inner, bake_quality="hero")
        outer_field = build_semantic_terrain_field_from_layout(outer, bake_quality="hero")
        wall_index = round(1.18 / math.tau * inner_field.radial_segments) % inner_field.radial_segments

        def peak_ring(field):
            start = round(field.rings * 0.30)
            end = round(field.rings * 0.76)
            return max(range(start, end), key=lambda ring: field.heights[ring][wall_index]) / field.rings

        self.assertGreater(peak_ring(outer_field), peak_ring(inner_field) + 0.12)

    def test_ice_default_layout_uses_four_crystal_wall_blades_for_layered_skyline(self):
        layout = default_layout("ice", seed=2002)
        wall = next(landmark for landmark in layout.landmarks if landmark.id == "primary_crystal_wall")

        self.assertGreaterEqual(wall.count, 4)

    def test_ice_erosion_age_opens_deep_crevasses_with_raised_shoulders(self):
        layout = default_layout("ice", seed=2002)
        young = build_semantic_terrain_field_from_layout(_with_process(layout, erosion_age=0.05), bake_quality="hero")
        old = build_semantic_terrain_field_from_layout(_with_process(layout, erosion_age=1.0), bake_quality="hero")
        ring = round(old.rings * 0.66)
        center_index = round(0.78 / math.tau * old.radial_segments) % old.radial_segments
        shoulder_offset = round(old.radial_segments * 0.018)

        young_center = young.heights[ring][center_index]
        old_center = old.heights[ring][center_index]
        young_shoulder = max(
            young.heights[ring][(center_index - shoulder_offset) % young.radial_segments],
            young.heights[ring][(center_index + shoulder_offset) % young.radial_segments],
        )
        old_shoulder = max(
            old.heights[ring][(center_index - shoulder_offset) % old.radial_segments],
            old.heights[ring][(center_index + shoulder_offset) % old.radial_segments],
        )

        self.assertLess(old_center, young_center - 220.0)
        self.assertGreater(old_shoulder - old_center, young_shoulder - young_center + 180.0)

    def test_ice_crystal_wall_has_serrated_skyline_peaks(self):
        layout = default_layout("ice", seed=2002)
        field = build_semantic_terrain_field_from_layout(_with_process(layout, erosion_age=1.0, detail_energy=1.35), bake_quality="hero")
        ring = round(field.rings * 0.54)
        heights = field.heights[ring]
        median = statistics.median(heights)
        peaks = [
            index
            for index, height in enumerate(heights)
            if height > median + 520.0
            and height > heights[index - 1] + 140.0
            and height > heights[(index + 1) % field.radial_segments] + 140.0
        ]

        self.assertGreaterEqual(len(peaks), 4)

    def test_ice_hero_has_dense_crystal_forest_skyline(self):
        layout = _with_process(default_layout("ice", seed=2002), erosion_age=0.86, detail_energy=1.35, deposition_weight=0.34)
        field = build_semantic_terrain_field_from_layout(layout, bake_quality="hero")
        ring_start = round(field.rings * 0.46)
        ring_end = round(field.rings * 0.62)
        peaks = set()

        for ring in range(ring_start, ring_end + 1):
            heights = field.heights[ring]
            median = statistics.median(heights)
            for index, height in enumerate(heights):
                if (
                    height > median + 560.0
                    and height > heights[index - 1] + 150.0
                    and height > heights[(index + 1) % field.radial_segments] + 150.0
                ):
                    peaks.add(index)

        self.assertGreaterEqual(len(peaks), 10)

    def test_ice_hero_has_icefall_cliff_drop_against_inner_shelf(self):
        layout = _with_process(default_layout("ice", seed=2002), erosion_age=0.86, detail_energy=1.35, deposition_weight=0.34)
        field = build_semantic_terrain_field_from_layout(layout, bake_quality="hero")
        inner_ring = round(field.rings * 0.72)
        edge_ring = round(field.rings * 0.96)
        drops = []

        for angle in (1.55, 4.95):
            index = round(angle / math.tau * field.radial_segments) % field.radial_segments
            drops.append(field.heights[inner_ring][index] - field.heights[edge_ring][index])

        self.assertGreater(statistics.mean(drops), 760.0)

    def test_ice_hero_center_remains_playable_despite_exaggeration(self):
        layout = _with_process(default_layout("ice", seed=2002), erosion_age=0.86, detail_energy=1.35, deposition_weight=0.34)
        field = build_semantic_terrain_field_from_layout(layout, bake_quality="hero")
        center_heights = []

        for radial_alpha in (0.08, 0.16, 0.24, 0.32):
            center_heights.extend(field.heights[round(field.rings * radial_alpha)])

        self.assertLess(max(center_heights) - min(center_heights), 260.0)

    def test_ice_layout_resource_cluster_count_controls_hard_material_regions(self):
        layout = default_layout("ice", seed=2002)
        two = _with_landmark(layout, "secondary_spire_clusters", count=2)
        five = _with_landmark(layout, "secondary_spire_clusters", count=5)
        two_field = build_semantic_terrain_field_from_layout(two, bake_quality="hero")
        five_field = build_semantic_terrain_field_from_layout(five, bake_quality="hero")
        ring = round(two_field.rings * 0.48)

        two_hard = sum(
            1
            for index in range(two_field.radial_segments)
            if material_for_terrain_field_face(two_field, ring, index) == "M_CliffRock"
        )
        five_hard = sum(
            1
            for index in range(five_field.radial_segments)
            if material_for_terrain_field_face(five_field, ring, index) == "M_CliffRock"
        )

        self.assertGreater(five_hard, two_hard + 10)


if __name__ == "__main__":
    unittest.main()
