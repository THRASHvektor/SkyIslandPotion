import sys
import tempfile
import unittest
import json
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from plant_aigc_asset_catalog import (
    build_asset_audit,
    build_recipe_plan,
    load_presentation_scales,
    parse_aigc_static_mesh_path,
)


def _complete_family_paths(family):
    slots = ("BodyShell", "PrimarySilhouette", "Core", "OrbitSet")
    return [
        "/Game/AIGC/Plants/{}/C{}/{}".format(family, level, slot)
        for level in range(4)
        for slot in slots
    ]


class PlantAIGCAssetCatalogTests(unittest.TestCase):
    def test_parse_static_mesh_path_extracts_family_level_and_slot(self):
        parsed = parse_aigc_static_mesh_path("/Game/AIGC/Plants/CrownLily/C2/Core")

        self.assertEqual(
            parsed,
            {
                "family": "CrownLily",
                "collapse": "C2",
                "level": 2,
                "slot": "Core",
                "path": "/Game/AIGC/Plants/CrownLily/C2/Core",
            },
        )
        self.assertIsNone(parse_aigc_static_mesh_path("/Game/AIGC/Plants/CrownLily/C2/Core_texture_0"))
        self.assertIsNone(parse_aigc_static_mesh_path("/Game/Other/Plants/CrownLily/C2/Core"))

    def test_asset_audit_reports_complete_and_missing_families(self):
        asset_paths = _complete_family_paths("CrownLily") + _complete_family_paths("AetherVine")
        asset_paths.remove("/Game/AIGC/Plants/AetherVine/C3/OrbitSet")

        audit = build_asset_audit(asset_paths)

        self.assertEqual(audit["schema"], "SkyIslandPotion.AIGCPlantAssetAudit.v0")
        self.assertTrue(audit["families"]["CrownLily"]["is_complete"])
        self.assertFalse(audit["families"]["AetherVine"]["is_complete"])
        self.assertEqual(
            audit["families"]["AetherVine"]["missing"],
            ["/Game/AIGC/Plants/AetherVine/C3/OrbitSet"],
        )
        self.assertEqual(audit["summary"]["complete_families"], ["CrownLily"])
        self.assertEqual(audit["summary"]["incomplete_families"], ["AetherVine"])

    def test_recipe_plan_groups_four_collapse_variants_per_slot(self):
        audit = build_asset_audit(_complete_family_paths("CrownLily"))
        plans = build_recipe_plan(audit)

        self.assertEqual(plans["schema"], "SkyIslandPotion.AIGCPlantRecipePlan.v0")
        self.assertEqual(len(plans["recipes"]), 1)

        recipe = plans["recipes"][0]
        self.assertEqual(recipe["recipe_id"], "AIGC_CrownLily")
        self.assertEqual(recipe["family"], "CrownLily")
        self.assertEqual(recipe["default_collapse_band"], "Weathered_C1")
        self.assertEqual(recipe["assembly_hint"]["mode"], "shared_origin_identity")
        self.assertEqual(
            recipe["mesh_slots"]["BodyShell"]["variants"]["C3"],
            "/Game/AIGC/Plants/CrownLily/C3/BodyShell",
        )
        self.assertEqual(
            recipe["mesh_slots"]["OrbitSet"]["runtime_slot_tag"],
            "Runtime.OrbitSet.AIGC",
        )

    def test_recipe_plan_balances_large_visual_slots_with_family_scale_hints(self):
        asset_paths = _complete_family_paths("CrownLily") + _complete_family_paths("AetherVine")
        audit = build_asset_audit(asset_paths, families=("CrownLily", "AetherVine"))
        plans = build_recipe_plan(audit)
        recipes = {recipe["family"]: recipe for recipe in plans["recipes"]}

        crown = recipes["CrownLily"]["mesh_slots"]
        vine = recipes["AetherVine"]["mesh_slots"]

        self.assertLess(crown["BodyShell"]["local_adjustment"]["scale"][0], 1.0)
        self.assertLess(crown["PrimarySilhouette"]["local_adjustment"]["scale"][0], 1.0)
        self.assertLess(crown["OrbitSet"]["local_adjustment"]["scale"][0], crown["PrimarySilhouette"]["local_adjustment"]["scale"][0])
        self.assertLess(vine["PrimarySilhouette"]["local_adjustment"]["scale"][0], 1.0)
        self.assertLess(vine["OrbitSet"]["local_adjustment"]["scale"][0], 1.0)
        self.assertLess(vine["Core"]["local_adjustment"]["scale"][0], vine["BodyShell"]["local_adjustment"]["scale"][0])

    def test_recipe_plan_can_use_external_presentation_profile_file(self):
        asset_paths = _complete_family_paths("CrownLily")
        audit = build_asset_audit(asset_paths, families=("CrownLily",))

        with tempfile.TemporaryDirectory() as temp_dir:
            profile_path = Path(temp_dir) / "presentation_profile.json"
            profile_path.write_text(
                json.dumps(
                    {
                        "schema": "SkyIslandPotion.AIGCPlantPresentationProfile.v0",
                        "families": {
                            "CrownLily": {
                                "BodyShell": 0.25,
                                "PrimarySilhouette": 0.33,
                                "Core": 1.10,
                                "OrbitSet": 0.12,
                            }
                        },
                    }
                ),
                encoding="utf-8",
            )

            plans = build_recipe_plan(audit, presentation_profile_path=profile_path)

        slots = plans["recipes"][0]["mesh_slots"]
        self.assertEqual(slots["BodyShell"]["local_adjustment"]["scale"], [0.25, 0.25, 0.25])
        self.assertEqual(slots["PrimarySilhouette"]["local_adjustment"]["scale"], [0.33, 0.33, 0.33])
        self.assertEqual(slots["Core"]["local_adjustment"]["scale"], [1.1, 1.1, 1.1])
        self.assertEqual(slots["OrbitSet"]["local_adjustment"]["scale"], [0.12, 0.12, 0.12])

    def test_recipe_plan_can_use_level_specific_presentation_transforms(self):
        asset_paths = _complete_family_paths("CrownLily")
        audit = build_asset_audit(asset_paths, families=("CrownLily",))

        with tempfile.TemporaryDirectory() as temp_dir:
            profile_path = Path(temp_dir) / "presentation_profile.json"
            profile_path.write_text(
                json.dumps(
                    {
                        "schema": "SkyIslandPotion.AIGCPlantPresentationProfile.v1",
                        "families": {
                            "CrownLily": {
                                "BodyShell": {
                                    "default": {
                                        "scale": 0.40,
                                        "location": [10.0, 0.0, 2.0],
                                        "rotation": [0.0, 5.0, 0.0],
                                    },
                                    "C2": {
                                        "scale": 0.80,
                                        "location": [25.0, -5.0, 14.0],
                                        "rotation": [0.0, 20.0, 0.0],
                                    },
                                },
                                "OrbitSet": {
                                    "default": 0.12,
                                    "C3": 0.18,
                                },
                            }
                        },
                    }
                ),
                encoding="utf-8",
            )

            plans = build_recipe_plan(audit, presentation_profile_path=profile_path)

        body = plans["recipes"][0]["mesh_slots"]["BodyShell"]
        orbit = plans["recipes"][0]["mesh_slots"]["OrbitSet"]

        self.assertEqual(body["local_adjustment"]["location"], [10.0, 0.0, 2.0])
        self.assertEqual(body["local_adjustment"]["rotation"], [0.0, 5.0, 0.0])
        self.assertEqual(body["local_adjustment"]["scale"], [0.4, 0.4, 0.4])
        self.assertEqual(
            body["variant_adjustments"]["C1"],
            {
                "location": [0.0, 0.0, 0.0],
                "rotation": [0.0, 0.0, 0.0],
                "scale": [1.0, 1.0, 1.0],
            },
        )
        self.assertEqual(
            body["variant_adjustments"]["C2"],
            {
                "location": [15.0, -5.0, 12.0],
                "rotation": [0.0, 15.0, 0.0],
                "scale": [2.0, 2.0, 2.0],
            },
        )
        self.assertEqual(orbit["local_adjustment"]["scale"], [0.12, 0.12, 0.12])
        self.assertEqual(orbit["variant_adjustments"]["C3"]["scale"], [1.5, 1.5, 1.5])

    def test_default_presentation_profile_rejects_extreme_variant_upscales(self):
        profile = load_presentation_scales()

        for family, slots in profile.items():
            for slot, slot_profile in slots.items():
                for collapse, transform in slot_profile.get("levels", {}).items():
                    max_ratio = max(transform["scale"][index] / slot_profile["default"]["scale"][index] for index in range(3))
                    self.assertLessEqual(
                        max_ratio,
                        3.0 + 1e-6,
                        "{} {} {} should stay art-directed instead of auto-normalizing tiny fragments".format(
                            family,
                            slot,
                            collapse,
                        ),
                    )

    def test_default_presentation_profile_keeps_core_as_visual_accent(self):
        profile = load_presentation_scales()

        for family, slots in profile.items():
            core_scale = slots["Core"]["default"]["scale"][0]
            body_scale = slots["BodyShell"]["default"]["scale"][0]

            self.assertLessEqual(
                core_scale,
                0.65,
                "{} Core should read as an energy accent, not a second body shell".format(family),
            )
            self.assertLess(
                core_scale,
                body_scale * 1.35,
                "{} Core should not visually outrank the body shell".format(family),
            )
            self.assertLess(
                core_scale,
                slots["PrimarySilhouette"]["default"]["scale"][0],
                "{} Core should remain smaller than the readable silhouette slot".format(family),
            )

    def test_default_presentation_profile_has_level_specific_fragment_recovery(self):
        profile = load_presentation_scales()

        aether_body = profile["AetherVine"]["BodyShell"]
        aether_primary = profile["AetherVine"]["PrimarySilhouette"]
        crown_primary = profile["CrownLily"]["PrimarySilhouette"]

        self.assertIn("C3", aether_body["levels"])
        self.assertIn("C3", aether_primary["levels"])
        self.assertIn("C3", crown_primary["levels"])
        self.assertLessEqual(
            aether_primary["levels"]["C3"]["scale"][0] / aether_primary["default"]["scale"][0],
            3.0,
        )
        self.assertGreater(
            abs(aether_body["levels"]["C3"]["location"][2]),
            20.0,
            "AetherVine C3 body fragments should be repositioned near the family body, not left at recentered import origin",
        )

    def test_default_presentation_profile_keeps_aether_body_connected_to_fast_collapsing_vine(self):
        profile = load_presentation_scales()
        body = profile["AetherVine"]["BodyShell"]

        self.assertGreaterEqual(
            body["default"]["location"][2],
            15.0,
            "AetherVine C0/C1 body roots need a small upward bridge so the first vine arc does not detach.",
        )
        self.assertIn("C1", body["levels"])
        self.assertGreaterEqual(
            body["levels"]["C1"]["location"][2],
            24.0,
            "AetherVine B1/P3 combinations otherwise leave the root and main vine visibly separated.",
        )
        self.assertGreaterEqual(
            body["levels"]["C2"]["location"][2],
            54.0,
            "AetherVine B2/P3 combinations need the fractured body shell to chase the high primary arc.",
        )
        self.assertGreaterEqual(
            body["levels"]["C3"]["location"][2],
            -26.5,
            "AetherVine C3 body fragments should stay close enough to the C3 primary silhouette to read as one plant.",
        )

    def test_recipe_plan_can_include_incomplete_families_for_live_actor_testing(self):
        asset_paths = _complete_family_paths("CrownLily")
        asset_paths.remove("/Game/AIGC/Plants/CrownLily/C2/PrimarySilhouette")
        audit = build_asset_audit(asset_paths, families=("CrownLily",))

        strict_plan = build_recipe_plan(audit)
        partial_plan = build_recipe_plan(audit, include_incomplete=True)

        self.assertEqual(strict_plan["recipes"], [])
        self.assertEqual(len(partial_plan["recipes"]), 1)
        self.assertEqual(
            partial_plan["recipes"][0]["mesh_slots"]["PrimarySilhouette"]["variants"]["C2"],
            None,
        )
        self.assertEqual(partial_plan["partial_recipe_families"], ["CrownLily"])


if __name__ == "__main__":
    unittest.main()
