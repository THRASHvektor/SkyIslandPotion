import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from plant_all_combinations_layout import build_all_combinations_layout, collect_possible_vectors
from plant_collapse_sampler import BANDS, FAMILIES, SLOTS


class PlantAllCombinationsLayoutTests(unittest.TestCase):
    def test_collect_possible_vectors_deduplicates_sampler_candidates_across_bands(self):
        vectors = collect_possible_vectors("AetherVine", bands=BANDS)

        self.assertEqual(len(vectors), len({entry["slug"] for entry in vectors}))
        self.assertGreater(len(vectors), 120)
        self.assertLess(len(vectors), 256)
        for entry in vectors:
            self.assertEqual(set(entry["vector"].keys()), set(SLOTS))
            self.assertTrue(entry["bands"])
            self.assertIn("severity", entry["metrics"])
            self.assertIn("dispersion", entry["metrics"])

    def test_all_combinations_layout_is_audit_ready(self):
        layout = build_all_combinations_layout(
            families=FAMILIES,
            bands=BANDS,
            origin=(1000.0, 2000.0, 300.0),
            columns=12,
            spacing_x=410.0,
            spacing_y=430.0,
            family_spacing_y=7000.0,
            scale=1.25,
        )

        self.assertEqual(layout["schema"], "SkyIslandPotion.AIGCPlantAllCombinationsLayout.v0")
        self.assertEqual(layout["composition"], "collapse_vector_all_combinations")
        self.assertEqual(layout["families"], list(FAMILIES))
        self.assertEqual(layout["bands"], list(BANDS))
        self.assertEqual(layout["columns"], 12)
        self.assertEqual(len(layout["actors"]), sum(len(collect_possible_vectors(family, BANDS)) for family in FAMILIES))

        first = layout["actors"][0]
        self.assertEqual(first["plant_scale"], 1.25)
        self.assertEqual(set(first["collapse_vector"].keys()), set(SLOTS))
        self.assertTrue(first["vector_slug"].startswith("B"))

        self.assertIn("camera", layout)
        self.assertIn("location", layout["camera"])
        self.assertIn("rotation", layout["camera"])


if __name__ == "__main__":
    unittest.main()
