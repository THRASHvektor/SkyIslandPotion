import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from plant_collapse_sampler import (
    BANDS,
    FAMILIES,
    calculate_metrics,
    passes_hard_constraints,
    sample_collapse_vector,
    summarize_samples,
    vector_slug,
)


class PlantCollapseSamplerTests(unittest.TestCase):
    def test_metrics_and_hard_constraints_match_four_slot_contract(self):
        vector = {
            "BodyShell": 0,
            "PrimarySilhouette": 3,
            "Core": 1,
            "OrbitSet": 2,
        }

        metrics = calculate_metrics(vector)

        self.assertAlmostEqual(metrics["severity"], 1.7)
        self.assertGreater(metrics["dispersion"], 0.5)
        self.assertFalse(passes_hard_constraints(vector))
        self.assertFalse(metrics["passed_hard_constraints"])
        self.assertEqual(vector_slug(vector), "B0_P3_C1_O2")

    def test_sampled_vectors_stay_inside_band_envelopes(self):
        envelopes = {
            "Stable_C0": lambda severity: severity <= 0.8,
            "Weathered_C1": lambda severity: 0.35 <= severity <= 1.65,
            "Fractured_C2": lambda severity: 0.95 <= severity <= 2.55,
            "Unstable_C3": lambda severity: severity >= 1.8,
        }

        for family in FAMILIES:
            for band in BANDS:
                for offset in range(40):
                    sample = sample_collapse_vector(seed=7307 + offset * 17, band=band, family=family)
                    self.assertTrue(sample.metrics["passed_hard_constraints"], sample)
                    self.assertTrue(envelopes[band](sample.metrics["severity"]), sample)
                    self.assertNotEqual(
                        sample.vector,
                        {"BodyShell": 3, "PrimarySilhouette": 3, "Core": 3, "OrbitSet": 3},
                    )

    def test_summary_reports_distribution_by_family_and_band(self):
        summary = summarize_samples(seed=9101, samples_per_band=100)

        self.assertEqual(summary["samples_per_band"], 100)
        self.assertEqual(set(summary["families"]), set(FAMILIES))
        self.assertEqual(set(summary["bands"]), set(BANDS))
        self.assertEqual(len(summary["rows"]), len(FAMILIES) * len(BANDS))

        row = next(
            candidate
            for candidate in summary["rows"]
            if candidate["family"] == "CrownLily" and candidate["band"] == "Stable_C0"
        )
        self.assertEqual(row["count"], 100)
        self.assertLessEqual(row["severity"]["max"], 0.8)
        self.assertGreater(row["unique_vectors"], 1)
        self.assertTrue(row["top_vectors"])
        self.assertLessEqual(row["failed_hard_constraints"], 0)


if __name__ == "__main__":
    unittest.main()
