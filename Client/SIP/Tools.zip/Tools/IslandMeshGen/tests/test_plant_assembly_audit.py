import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from plant_assembly_audit import (
    classify_assembly_row,
    issue_slug,
    summarize_assembly_audit,
)


def _row(family="AetherVine", vector=None, metrics=None, measurements=None):
    return {
        "family": family,
        "label": "Sample",
        "collapse_vector": vector
        or {"BodyShell": 1, "PrimarySilhouette": 3, "Core": 1, "OrbitSet": 0},
        "metrics": metrics or {"severity": 2.0, "dispersion": 0.45},
        "measurements": measurements
        or {
            "body_primary_gap_cm": 28.0,
            "core_to_primary_height_ratio": 0.20,
            "core_to_body_height_ratio": 0.30,
            "core_primary_center_distance_cm": 18.0,
            "plant_height_cm": 165.0,
        },
    }


class PlantAssemblyAuditTests(unittest.TestCase):
    def test_classifies_aether_root_primary_detach_from_measured_gap(self):
        audit = classify_assembly_row(_row())

        self.assertEqual(audit["status"], "critical")
        self.assertIn("RootPrimaryDetach", audit["issues"])
        self.assertEqual(issue_slug(audit["issues"]), "RootPrimaryDetach")

    def test_classifies_core_scale_outliers(self):
        tiny_core = classify_assembly_row(
            _row(
                measurements={
                    "body_primary_gap_cm": 4.0,
                    "core_to_primary_height_ratio": 0.04,
                    "core_to_body_height_ratio": 0.05,
                    "core_primary_center_distance_cm": 16.0,
                    "plant_height_cm": 150.0,
                }
            )
        )
        huge_core = classify_assembly_row(
            _row(
                family="CrownLily",
                measurements={
                    "body_primary_gap_cm": 3.0,
                    "core_to_primary_height_ratio": 0.82,
                    "core_to_body_height_ratio": 1.25,
                    "core_primary_center_distance_cm": 12.0,
                    "plant_height_cm": 180.0,
                },
            )
        )

        self.assertIn("CoreTooSmall", tiny_core["issues"])
        self.assertIn("CoreTooLarge", huge_core["issues"])

    def test_classifies_readability_risk_for_high_dispersion_c3_mix(self):
        audit = classify_assembly_row(
            _row(
                vector={"BodyShell": 0, "PrimarySilhouette": 3, "Core": 3, "OrbitSet": 3},
                metrics={"severity": 2.6, "dispersion": 0.72},
                measurements={
                    "body_primary_gap_cm": 6.0,
                    "core_to_primary_height_ratio": 0.18,
                    "core_to_body_height_ratio": 0.30,
                    "core_primary_center_distance_cm": 38.0,
                    "plant_height_cm": 170.0,
                },
            )
        )

        self.assertEqual(audit["status"], "review")
        self.assertIn("HighDispersionMix", audit["issues"])
        self.assertIn("CoreDrift", audit["issues"])

    def test_summarizes_audit_counts_by_family_status_and_issue(self):
        rows = [
            _row(family="AetherVine"),
            _row(
                family="CrownLily",
                measurements={
                    "body_primary_gap_cm": 2.0,
                    "core_to_primary_height_ratio": 0.18,
                    "core_to_body_height_ratio": 0.28,
                    "core_primary_center_distance_cm": 8.0,
                    "plant_height_cm": 180.0,
                },
            ),
        ]

        summary = summarize_assembly_audit(rows)

        self.assertEqual(summary["total_count"], 2)
        self.assertEqual(summary["status_counts"]["critical"], 1)
        self.assertEqual(summary["status_counts"]["pass"], 1)
        self.assertEqual(summary["family_counts"]["AetherVine"], 1)
        self.assertEqual(summary["issue_counts"]["RootPrimaryDetach"], 1)


if __name__ == "__main__":
    unittest.main()
