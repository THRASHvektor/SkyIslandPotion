import sys
import json
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from plant_aigc_asset_catalog import build_asset_audit, build_recipe_plan
from plant_panorama_layout import build_panorama_layout, load_panorama_preset


def _complete_family_paths(family):
    slots = ("BodyShell", "PrimarySilhouette", "Core", "OrbitSet")
    return [
        "/Game/AIGC/Plants/{}/C{}/{}".format(family, level, slot)
        for level in range(4)
        for slot in slots
    ]


class PlantPanoramaLayoutTests(unittest.TestCase):
    def test_panorama_layout_places_families_across_collapse_bands(self):
        paths = _complete_family_paths("CrownLily") + _complete_family_paths("AetherVine")
        audit = build_asset_audit(paths, families=("CrownLily", "AetherVine"))
        recipe_plan = build_recipe_plan(audit)

        layout = build_panorama_layout(
            recipe_plan,
            samples_per_band=3,
            seed=9103,
            origin=(1000.0, 2000.0, 300.0),
            band_spacing_x=800.0,
            family_spacing_y=950.0,
            sample_spacing_y=220.0,
            scale=1.7,
        )

        self.assertEqual(layout["schema"], "SkyIslandPotion.AIGCPlantPanoramaLayout.v0")
        self.assertEqual(layout["composition"], "collapse_band_panorama")
        self.assertEqual(len(layout["actors"]), 24)
        self.assertEqual([zone["band"] for zone in layout["band_zones"]], ["Stable_C0", "Weathered_C1", "Fractured_C2", "Unstable_C3"])
        self.assertEqual([lane["family"] for lane in layout["family_lanes"]], ["CrownLily", "AetherVine"])

        stable_x = layout["band_zones"][0]["center"][0]
        unstable_x = layout["band_zones"][-1]["center"][0]
        self.assertLess(stable_x, unstable_x)

        crown_y = layout["family_lanes"][0]["center_y"]
        vine_y = layout["family_lanes"][1]["center_y"]
        self.assertLess(crown_y, vine_y)

        for actor in layout["actors"]:
            self.assertEqual(actor["plant_scale"], 1.7)
            self.assertIn(actor["band"], ("Stable_C0", "Weathered_C1", "Fractured_C2", "Unstable_C3"))
            self.assertIn(actor["family"], ("CrownLily", "AetherVine"))
            self.assertTrue(actor["collapse_vector"])
            self.assertTrue(actor["resolved_slot_meshes"])

        self.assertIn("location", layout["camera"])
        self.assertIn("rotation", layout["camera"])

    def test_panorama_preset_can_be_loaded_from_external_file(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            preset_path = Path(temp_dir) / "panorama_preset.json"
            preset_path.write_text(
                json.dumps(
                    {
                        "schema": "SkyIslandPotion.AIGCPlantPanoramaPreset.v0",
                        "origin": [10.0, 20.0, 30.0],
                        "band_spacing_x": 1300.0,
                        "family_spacing_y": 1600.0,
                        "sample_spacing_y": 520.0,
                        "scale": 2.1,
                    }
                ),
                encoding="utf-8",
            )

            preset = load_panorama_preset(preset_path)

        self.assertEqual(preset["origin"], [10.0, 20.0, 30.0])
        self.assertEqual(preset["band_spacing_x"], 1300.0)
        self.assertEqual(preset["family_spacing_y"], 1600.0)
        self.assertEqual(preset["sample_spacing_y"], 520.0)
        self.assertEqual(preset["scale"], 2.1)


if __name__ == "__main__":
    unittest.main()
