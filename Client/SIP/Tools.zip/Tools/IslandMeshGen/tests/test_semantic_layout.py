import json
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from semantic_layout import IslandLayout, default_layout


class SemanticLayoutTests(unittest.TestCase):
    def test_fire_default_layout_contains_volcano_path_and_lava_hazards(self):
        layout = default_layout("fire", seed=2002)

        self.assertEqual(layout.biome, "fire")
        self.assertEqual(layout.radius_m, 100.0)
        self.assertTrue(any(landmark.kind == "volcano" for landmark in layout.landmarks))
        self.assertTrue(any(path.kind == "main_path" for path in layout.paths))
        self.assertTrue(any(zone.kind == "hazard" for zone in layout.zones))
        self.assertTrue(any(mask.slot == "M_ElementCrack" for mask in layout.material_masks))

    def test_ice_default_layout_contains_crystal_clusters_and_resource_zone(self):
        layout = default_layout("ice", seed=3003)

        landmark_kinds = {landmark.kind for landmark in layout.landmarks}
        zone_kinds = {zone.kind for zone in layout.zones}

        self.assertIn("ice_wall", landmark_kinds)
        self.assertIn("ice_crystal_cluster", landmark_kinds)
        self.assertIn("resource", zone_kinds)
        self.assertIn("hazard", zone_kinds)

    def test_forest_default_layout_uses_attachment_landmarks_for_tree_identity(self):
        layout = default_layout("forest", seed=1001)

        attachment_landmarks = [landmark for landmark in layout.landmarks if landmark.bake_mode == "attachment"]

        self.assertTrue(any(landmark.kind == "root_arch" for landmark in attachment_landmarks))
        self.assertTrue(any(landmark.kind == "tree_stump_cave" for landmark in attachment_landmarks))
        self.assertTrue(all(landmark.bake_mode != "terrain_cutout" for landmark in layout.landmarks))

    def test_all_default_layouts_expose_process_controls(self):
        for biome in ("fire", "forest", "ice"):
            with self.subTest(biome=biome):
                layout = default_layout(biome)

                self.assertEqual(
                    set(layout.process),
                    {"detail_energy", "erosion_age", "deposition_weight"},
                )

    def test_layout_roundtrips_through_json(self):
        layout = default_layout("fire", seed=777)
        restored = IslandLayout.from_json(layout.to_json())

        self.assertEqual(restored.to_dict(), layout.to_dict())
        self.assertEqual(json.loads(restored.to_json())["biome"], "fire")

    def test_unknown_biome_is_rejected(self):
        with self.assertRaises(ValueError):
            default_layout("swamp")


if __name__ == "__main__":
    unittest.main()
