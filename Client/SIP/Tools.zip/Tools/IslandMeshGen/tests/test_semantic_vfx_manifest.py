import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from semantic_layout import default_layout
from semantic_manifest import build_unreal_manifest
from semantic_vfx_manifest import build_fire_vfx_manifest


class SemanticVFXManifestTests(unittest.TestCase):
    def test_fire_vfx_manifest_exports_four_testbed_slots(self):
        layout = default_layout("fire", seed=2002)
        island_manifest = build_unreal_manifest(
            layout,
            mesh_path="Tools/IslandMeshGen/output/SM_ProcIsland_Fire_VolcanoLayout_200m.obj",
            layout_path="Tools/IslandMeshGen/layouts/fire_volcano_demo.json",
            bake_metadata={"quality": "hero", "segments": 384, "rings": 56},
        )

        vfx_manifest = build_fire_vfx_manifest(island_manifest)

        self.assertEqual(vfx_manifest["schema"], "SkyIslandPotion.SemanticVFXManifest.v0")
        self.assertEqual(vfx_manifest["biome"], "fire")
        self.assertEqual(vfx_manifest["island"], "SM_ProcIsland_Fire_VolcanoLayout_200m")
        self.assertEqual(len(vfx_manifest["slots"]), 4)

        slot_ids = {slot["id"] for slot in vfx_manifest["slots"]}
        self.assertEqual(
            slot_ids,
            {
                "FIRE_SLOT_01_LAVA_CHANNEL_LEAK",
                "FIRE_SLOT_02_CRATER_RIM_PULSE",
                "FIRE_SLOT_05_CLIFF_COLLAPSE_DISTORTION",
                "FIRE_SLOT_06_REACTION_IMPACT_BURST",
            },
        )

        lava_slot = next(slot for slot in vfx_manifest["slots"] if slot["id"] == "FIRE_SLOT_01_LAVA_CHANNEL_LEAK")
        self.assertEqual(lava_slot["intent"], "AmbientLeak")
        self.assertIn("mask:path", lava_slot["avoid"])
        self.assertIn("NS_BottomSpark_Fire_", lava_slot["niagara_hint"])

        reaction_slot = next(slot for slot in vfx_manifest["slots"] if slot["id"] == "FIRE_SLOT_06_REACTION_IMPACT_BURST")
        self.assertEqual(reaction_slot["activation_policy"], "reaction_triggered")
        self.assertEqual(reaction_slot["spawn_mode"], "reaction_location")


if __name__ == "__main__":
    unittest.main()
