import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from plant_aigc_asset_catalog import build_asset_audit, build_recipe_plan
from plant_actor_spawn_plan import build_actor_spawn_plan


def _complete_family_paths(family):
    slots = ("BodyShell", "PrimarySilhouette", "Core", "OrbitSet")
    return [
        "/Game/AIGC/Plants/{}/C{}/{}".format(family, level, slot)
        for level in range(4)
        for slot in slots
    ]


class PlantActorSpawnPlanTests(unittest.TestCase):
    def test_spawn_plan_resolves_sampled_mesh_paths_for_each_actor_slot(self):
        audit = build_asset_audit(_complete_family_paths("CrownLily"), families=("CrownLily",))
        recipe_plan = build_recipe_plan(audit)

        spawn_plan = build_actor_spawn_plan(
            recipe_plan,
            families=("CrownLily",),
            bands=("Weathered_C1",),
            samples_per_band=2,
            seed=7307,
            origin=(-100.0, 20.0, 30.0),
            band_spacing_x=900.0,
            sample_spacing_y=250.0,
            family_spacing_y=1000.0,
            scale=1.25,
        )

        self.assertEqual(spawn_plan["schema"], "SkyIslandPotion.AIGCPlantActorSpawnPlan.v0")
        self.assertEqual(len(spawn_plan["actors"]), 2)

        first = spawn_plan["actors"][0]
        self.assertEqual(first["family"], "CrownLily")
        self.assertEqual(first["band"], "Weathered_C1")
        self.assertEqual(first["location"], [-100.0, 20.0, 30.0])
        self.assertEqual(first["plant_scale"], 1.25)

        for slot, level in first["collapse_vector"].items():
            expected_path = "/Game/AIGC/Plants/CrownLily/C{}/{}".format(level, slot)
            self.assertEqual(first["resolved_slot_meshes"][slot], expected_path)

        second = spawn_plan["actors"][1]
        self.assertEqual(second["location"], [-100.0, 270.0, 30.0])
        self.assertNotEqual(first["seed"], second["seed"])

    def test_spawn_plan_skips_requested_family_without_complete_recipe(self):
        audit = build_asset_audit(_complete_family_paths("CrownLily"), families=("CrownLily", "AetherVine"))
        recipe_plan = build_recipe_plan(audit)

        spawn_plan = build_actor_spawn_plan(
            recipe_plan,
            families=("CrownLily", "AetherVine"),
            bands=("Stable_C0",),
            samples_per_band=1,
            seed=10,
        )

        self.assertEqual([actor["family"] for actor in spawn_plan["actors"]], ["CrownLily"])
        self.assertEqual(spawn_plan["skipped_missing_recipes"], ["AetherVine"])


if __name__ == "__main__":
    unittest.main()
