import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from plant_aigc_asset_catalog import build_asset_audit, build_recipe_plan
from plant_recipe_asset_plan import build_recipe_asset_plan


def _complete_family_paths(family):
    slots = ("BodyShell", "PrimarySilhouette", "Core", "OrbitSet")
    return [
        "/Game/AIGC/Plants/{}/C{}/{}".format(family, level, slot)
        for level in range(4)
        for slot in slots
    ]


class PlantRecipeAssetPlanTests(unittest.TestCase):
    def test_recipe_asset_plan_maps_recipe_ids_to_data_asset_paths(self):
        audit = build_asset_audit(_complete_family_paths("CrownLily"), families=("CrownLily",))
        recipe_plan = build_recipe_plan(audit)

        asset_plan = build_recipe_asset_plan(recipe_plan)

        self.assertEqual(asset_plan["schema"], "SkyIslandPotion.AIGCPlantRecipeAssetPlan.v0")
        self.assertEqual(len(asset_plan["assets"]), 1)
        self.assertEqual(asset_plan["assets"][0]["asset_name"], "DA_AIGC_CrownLily")
        self.assertEqual(asset_plan["assets"][0]["package_path"], "/Game/AIGC/Plants/Recipes")
        self.assertEqual(asset_plan["assets"][0]["object_path"], "/Game/AIGC/Plants/Recipes/DA_AIGC_CrownLily")
        self.assertEqual(asset_plan["assets"][0]["recipe"]["recipe_id"], "AIGC_CrownLily")

    def test_recipe_asset_plan_rejects_partial_recipes_by_default(self):
        asset_paths = _complete_family_paths("CrownLily")
        asset_paths.remove("/Game/AIGC/Plants/CrownLily/C1/Core")
        audit = build_asset_audit(asset_paths, families=("CrownLily",))
        recipe_plan = build_recipe_plan(audit, include_incomplete=True)

        with self.assertRaises(ValueError):
            build_recipe_asset_plan(recipe_plan)


if __name__ == "__main__":
    unittest.main()
