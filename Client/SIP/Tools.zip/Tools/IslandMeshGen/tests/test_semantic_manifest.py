import sys
import os
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from export_layout import manifest_reference
from semantic_layout import default_layout
from semantic_manifest import build_unreal_manifest


class SemanticManifestTests(unittest.TestCase):
    def test_fire_manifest_exports_unreal_pcg_contract(self):
        layout = default_layout("fire", seed=2002)
        manifest = build_unreal_manifest(
            layout,
            mesh_path="Tools/IslandMeshGen/output/SM_ProcIsland_Fire_VolcanoLayout_200m.obj",
            layout_path="Tools/IslandMeshGen/layouts/fire_volcano_demo.json",
            bake_metadata={"quality": "production", "segments": 192, "rings": 32},
        )

        self.assertEqual(manifest["schema_version"], 1)
        self.assertEqual(manifest["biome"], "fire")
        self.assertEqual(manifest["biome_tag"], "Biome.Fire")
        self.assertEqual(manifest["scale"]["unreal_units"], "centimeters")
        self.assertEqual(manifest["mesh"], "Tools/IslandMeshGen/output/SM_ProcIsland_Fire_VolcanoLayout_200m.obj")
        self.assertEqual(manifest["bake"]["quality"], "production")
        self.assertEqual(manifest["bake"]["segments"], 192)
        self.assertEqual(manifest["bake"]["rings"], 32)
        self.assertIn("M_AshPlateau", manifest["material_slots"])
        self.assertNotIn("M_TopGrass", manifest["material_slots"])
        self.assertIn("M_ElementCrack", manifest["material_slots"])
        self.assertTrue(any(zone["id"] == "crater_arena" for zone in manifest["walkable_zones"]))
        self.assertTrue(any(zone["id"] == "lava_hazard" for zone in manifest["hazard_zones"]))
        self.assertTrue(any(mask["meaning"] == "elemental_reaction_surface" for mask in manifest["material_masks"]))

    def test_forest_manifest_exports_resource_and_connector_anchors(self):
        layout = default_layout("forest", seed=1001)
        manifest = build_unreal_manifest(layout, mesh_path="forest.obj", layout_path="forest.json")

        connector_ids = {anchor["id"] for anchor in manifest["connector_anchors"]}
        resource_ids = {zone["id"] for zone in manifest["resource_zones"]}
        attachment_ids = {landmark["id"] for landmark in manifest["attachment_landmarks"]}

        self.assertIn("vine_bridge_anchor", connector_ids)
        self.assertIn("mushroom_pocket", resource_ids)
        self.assertIn("glowing_root_cave", resource_ids)
        self.assertIn("root_arch", attachment_ids)
        self.assertIn("tree_stump_cave", attachment_ids)

    def test_manifest_reference_prefers_workspace_relative_paths(self):
        original_cwd = Path.cwd()
        with tempfile.TemporaryDirectory() as tmp_dir:
            try:
                os.chdir(tmp_dir)
                mesh_path = Path(tmp_dir) / "Tools" / "IslandMeshGen" / "output" / "mesh.obj"
                self.assertEqual(
                    manifest_reference(mesh_path),
                    "Tools/IslandMeshGen/output/mesh.obj",
                )
            finally:
                os.chdir(original_cwd)


if __name__ == "__main__":
    unittest.main()
