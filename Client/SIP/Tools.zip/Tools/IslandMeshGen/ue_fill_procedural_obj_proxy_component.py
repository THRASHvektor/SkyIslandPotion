import json
from pathlib import Path

import unreal


DEFAULT_ARGS = {
    "source_obj": "C:/Users/12542/Documents/Unreal Projects/SkyIslandPotion/Tools/IslandMeshGen/output/plant_regroup/CrownLily_local-upload-mr9cc1z8-Meshy_AI_Flamebound_Scepter_1783275149_part-segm-Meshy_AI_Fl/07_ue_test/CrownLily_C0_SourceProxy_full.obj",
    "label": "SIP_AIGC_CrownLily_C0_ProceduralProxy",
    "tag": "AIGCPlantC0ProceduralProxy",
    "component_name": "CrownLilyC0ProceduralMesh",
}


def _args():
    if hasattr(unreal, "get_mcp_args"):
        incoming = unreal.get_mcp_args() or {}
        merged = dict(DEFAULT_ARGS)
        merged.update(incoming)
        return merged
    return DEFAULT_ARGS


def _read_obj(path):
    vertices = []
    triangles = []
    with open(path, "r", encoding="utf-8") as handle:
        for line in handle:
            if line.startswith("v "):
                parts = line.strip().split()
                vertices.append(unreal.Vector(float(parts[1]), float(parts[2]), float(parts[3])))
            elif line.startswith("f "):
                raw = line.strip().split()[1:]
                face = []
                for token in raw[:3]:
                    face.append(int(token.split("/")[0]) - 1)
                if len(face) == 3:
                    triangles.extend(face)
    if not vertices or not triangles:
        raise RuntimeError("OBJ has no usable triangle geometry: {}".format(path))
    return vertices, triangles


def _find_actor(label, tag):
    subsystem = unreal.get_editor_subsystem(unreal.EditorActorSubsystem)
    for actor in subsystem.get_all_level_actors():
        if actor.get_actor_label() == label or any(str(actor_tag) == tag for actor_tag in actor.tags):
            return actor
    raise RuntimeError("Actor not found: {}".format(label))


def _find_component(actor, component_name):
    components = actor.get_components_by_class(unreal.ProceduralMeshComponent)
    for component in components:
        if component.get_name() == component_name:
            return component
    if components:
        return components[0]
    raise RuntimeError("ProceduralMeshComponent not found on actor: {}".format(actor.get_actor_label()))


def _compute_vertex_normals(vertices, triangles):
    accum = [[0.0, 0.0, 0.0] for _ in vertices]

    for index in range(0, len(triangles), 3):
        ia = triangles[index]
        ib = triangles[index + 1]
        ic = triangles[index + 2]
        a = vertices[ia]
        b = vertices[ib]
        c = vertices[ic]

        ab = (b.x - a.x, b.y - a.y, b.z - a.z)
        ac = (c.x - a.x, c.y - a.y, c.z - a.z)
        nx = ab[1] * ac[2] - ab[2] * ac[1]
        ny = ab[2] * ac[0] - ab[0] * ac[2]
        nz = ab[0] * ac[1] - ab[1] * ac[0]

        for vertex_index in (ia, ib, ic):
            accum[vertex_index][0] += nx
            accum[vertex_index][1] += ny
            accum[vertex_index][2] += nz

    normals = []
    for nx, ny, nz in accum:
        length = max((nx * nx + ny * ny + nz * nz) ** 0.5, 0.0001)
        normals.append(unreal.Vector(nx / length, ny / length, nz / length))
    return normals


def _create_section(component, vertices, triangles):
    normals = _compute_vertex_normals(vertices, triangles)
    uvs = []
    colors = []
    tangents = []
    if hasattr(component, "clear_all_mesh_sections"):
        component.clear_all_mesh_sections()
    if hasattr(component, "create_mesh_section"):
        component.create_mesh_section(0, vertices, triangles, normals, uvs, colors, tangents, False)
        return "create_mesh_section"
    if hasattr(component, "create_mesh_section_linear_color"):
        component.create_mesh_section_linear_color(0, vertices, triangles, normals, uvs, colors, tangents, False)
        return "create_mesh_section_linear_color"
    raise RuntimeError("ProceduralMeshComponent has no create_mesh_section API")


def main():
    args = _args()
    source = Path(args["source_obj"])
    if not source.exists():
        raise RuntimeError("Missing OBJ: {}".format(source))
    if not hasattr(unreal, "ProceduralMeshComponent"):
        raise RuntimeError("ProceduralMeshComponent is not available")

    actor = _find_actor(args["label"], args["tag"])
    component = _find_component(actor, args["component_name"])
    vertices, triangles = _read_obj(str(source))

    component.set_collision_enabled(unreal.CollisionEnabled.NO_COLLISION)
    component.set_visibility(True, True)
    component.set_hidden_in_game(False)
    if hasattr(component, "activate"):
        component.activate(True)
    material = unreal.EditorAssetLibrary.load_asset("/Engine/BasicShapes/BasicShapeMaterial.BasicShapeMaterial")
    if material:
        dynamic_material = None
        if hasattr(component, "create_dynamic_material_instance"):
            dynamic_material = component.create_dynamic_material_instance(0, material, "CrownLilyC0ProxyMaterial")
        if dynamic_material:
            color = unreal.LinearColor(1.0, 0.45, 0.08, 1.0)
            dynamic_material.set_vector_parameter_value("Color", color)
            dynamic_material.set_vector_parameter_value("BaseColor", color)
        else:
            component.set_material(0, material)
    api = _create_section(component, vertices, triangles)

    unreal.EditorLevelLibrary.set_selected_level_actors([actor])
    actor.modify()
    outermost = actor.get_outermost()
    if hasattr(outermost, "mark_package_dirty"):
        outermost.mark_package_dirty()

    print(
        json.dumps(
            {
                "source_obj": str(source),
                "actor": actor.get_actor_label(),
                "component": component.get_name(),
                "api": api,
                "vertices": len(vertices),
                "triangles": len(triangles) // 3,
                "sections": component.get_num_sections() if hasattr(component, "get_num_sections") else None,
            },
            indent=2,
        )
    )


main()
