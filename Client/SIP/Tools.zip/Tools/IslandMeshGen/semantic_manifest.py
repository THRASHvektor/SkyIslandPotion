from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from semantic_layout import IslandLayout, material_slots_for_biome


BIOME_TAGS = {
    "fire": "Biome.Fire",
    "ice": "Biome.Ice",
    "forest": "Biome.Forest",
}

ZONE_TAGS = {
    "arena": "Zone.Arena",
    "hazard": "Zone.Hazard",
    "resource": "Zone.Resource",
    "pcg": "Zone.PCG",
    "path": "Zone.Path",
    "landmark": "Zone.Landmark",
    "cliff": "Zone.Cliff",
}


def _tag_for_zone_kind(kind: str) -> str:
    return ZONE_TAGS.get(kind, f"Zone.{kind.title().replace('_', '')}")


def _zone_to_manifest(zone) -> dict[str, Any]:
    return {
        "id": zone.id,
        "kind": zone.kind,
        "tag": _tag_for_zone_kind(zone.kind),
        "center": list(zone.center),
        "radius_range": list(zone.radius_range),
        "walkable": zone.walkable,
        "height_role": zone.height_role,
    }


def _landmark_to_manifest(landmark) -> dict[str, Any]:
    return {
        "id": landmark.id,
        "kind": landmark.kind,
        "center": list(landmark.center),
        "radius": landmark.radius,
        "dominance": landmark.dominance,
        "bake_mode": landmark.bake_mode,
        "count": landmark.count,
    }


def _path_to_manifest(path) -> dict[str, Any]:
    return {
        "id": path.id,
        "kind": path.kind,
        "points": [list(point) for point in path.points],
        "width": path.width,
        "max_slope_m": path.max_slope_m,
        "material": path.material,
        "coverage": path.coverage,
    }


def _mask_to_manifest(mask) -> dict[str, str]:
    return {
        "slot": mask.slot,
        "source": mask.source,
        "meaning": mask.meaning,
    }


def _material_slot_contract(layout: IslandLayout) -> dict[str, dict[str, Any]]:
    slots = {
        slot: {
            "slot": slot,
            "sources": [],
            "meanings": [],
        }
        for slot in material_slots_for_biome(layout.biome)
    }
    for mask in layout.material_masks:
        slot = slots.setdefault(mask.slot, {"slot": mask.slot, "sources": [], "meanings": []})
        slot["sources"].append(mask.source)
        slot["meanings"].append(mask.meaning)
    return slots


def build_unreal_manifest(
    layout: IslandLayout,
    mesh_path: str,
    layout_path: str,
    bake_metadata: dict[str, Any] | None = None,
) -> dict[str, Any]:
    zones = [_zone_to_manifest(zone) for zone in layout.zones]
    landmarks = [_landmark_to_manifest(landmark) for landmark in layout.landmarks]
    paths = [_path_to_manifest(path) for path in layout.paths]
    material_masks = [_mask_to_manifest(mask) for mask in layout.material_masks]

    return {
        "schema_version": 1,
        "tool": "IslandMeshGen",
        "biome": layout.biome,
        "biome_tag": BIOME_TAGS.get(layout.biome, f"Biome.{layout.biome.title()}"),
        "seed": layout.seed,
        "layout": layout_path,
        "mesh": mesh_path,
        "bake": bake_metadata or {},
        "scale": {
            "radius_m": layout.radius_m,
            "diameter_m": layout.radius_m * 2.0,
            "unreal_units": "centimeters",
        },
        "material_slots": _material_slot_contract(layout),
        "zones": zones,
        "landmarks": landmarks,
        "paths": paths,
        "material_masks": material_masks,
        "walkable_zones": [zone for zone in zones if zone["walkable"]],
        "hazard_zones": [zone for zone in zones if zone["kind"] == "hazard" or not zone["walkable"]],
        "resource_zones": [zone for zone in zones if zone["kind"] in {"resource", "pcg"}],
        "connector_anchors": [
            landmark for landmark in landmarks
            if "bridge" in landmark["kind"] or "anchor" in landmark["kind"]
        ] + [
            path for path in paths
            if "bridge" in path["kind"] or "anchor" in path["kind"]
        ],
        "attachment_landmarks": [
            landmark for landmark in landmarks
            if landmark["bake_mode"] == "attachment"
        ],
    }


def write_manifest(manifest: dict[str, Any], output_path: Path) -> None:
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8")
