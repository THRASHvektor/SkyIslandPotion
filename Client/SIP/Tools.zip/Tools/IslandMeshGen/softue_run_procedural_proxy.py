from __future__ import annotations

import json

from soft_ue_cli.client import call_tool


PREPARE_SCRIPT_PATH = r"C:\Users\12542\Documents\Unreal Projects\SkyIslandPotion\Tools\IslandMeshGen\ue_prepare_procedural_obj_proxy_host.py"
FILL_SCRIPT_PATH = r"C:\Users\12542\Documents\Unreal Projects\SkyIslandPotion\Tools\IslandMeshGen\ue_fill_procedural_obj_proxy_component.py"
ACTOR_LABEL = "SIP_AIGC_CrownLily_C0_ProceduralProxy"
COMPONENT_NAME = "CrownLilyC0ProceduralMesh"


def main() -> int:
    prepare = call_tool("run-python-script", {"script_path": PREPARE_SCRIPT_PATH}, timeout=120)
    add_component = call_tool(
        "add-component",
        {
            "actor_name": ACTOR_LABEL,
            "component_class": "ProceduralMeshComponent",
            "component_name": COMPONENT_NAME,
        },
        timeout=120,
    )
    fill = call_tool("run-python-script", {"script_path": FILL_SCRIPT_PATH}, timeout=180)
    print(
        json.dumps(
            {
                "prepare": prepare,
                "add_component": add_component,
                "fill": fill,
            },
            indent=2,
            ensure_ascii=False,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
