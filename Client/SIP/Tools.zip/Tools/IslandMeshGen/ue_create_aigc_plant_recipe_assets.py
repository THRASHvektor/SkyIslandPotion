import json
import sys
from pathlib import Path

import unreal


def _tool_script_dir():
    script_path = globals().get("__file__")
    if script_path:
        return Path(script_path).resolve().parent

    project_dir = Path(unreal.Paths.project_dir()).resolve()
    candidates = [
        project_dir.parents[1] / "Tools" / "IslandMeshGen",
        project_dir.parent / "Tools" / "IslandMeshGen",
        Path.cwd(),
    ]
    for candidate in candidates:
        if (candidate / "plant_recipe_asset_plan.py").exists():
            return candidate
    return candidates[0]


TOOL_DIR = _tool_script_dir()
sys.path.insert(0, str(TOOL_DIR))

for module_name in ("plant_collapse_sampler", "plant_aigc_asset_catalog", "plant_recipe_asset_plan"):
    sys.modules.pop(module_name, None)

from plant_aigc_asset_catalog import AIGC_PLANT_ROOT, build_asset_audit, build_recipe_plan
from plant_collapse_sampler import SLOTS
from plant_recipe_asset_plan import RECIPE_ASSET_ROOT, build_recipe_asset_plan


DEFAULT_ARGS = {
    "package_path": RECIPE_ASSET_ROOT,
    "allow_partial": False,
    "save_assets": True,
}


def _get_args():
    args = dict(DEFAULT_ARGS)
    if hasattr(unreal, "get_mcp_args"):
        supplied = unreal.get_mcp_args()
        if isinstance(supplied, dict):
            args.update(supplied)
    args["package_path"] = str(args["package_path"])
    args["allow_partial"] = bool(args["allow_partial"])
    args["save_assets"] = bool(args["save_assets"])
    return args


def _class_name(asset_data):
    if hasattr(asset_data, "asset_class_path"):
        return str(asset_data.asset_class_path.asset_name)
    return str(asset_data.asset_class)


def _collect_static_mesh_paths():
    registry = unreal.AssetRegistryHelpers.get_asset_registry()
    registry.scan_paths_synchronous([AIGC_PLANT_ROOT], True)
    return sorted(
        {
            str(asset.package_name)
            for asset in registry.get_assets_by_path(AIGC_PLANT_ROOT, True)
            if _class_name(asset) == "StaticMesh"
        }
    )


def _normalize_name(value):
    return "".join(ch for ch in str(value).lower() if ch.isalnum())


def _get_unreal_type(*names):
    for name in names:
        value = getattr(unreal, name, None)
        if value is not None:
            return value
    return None


def _enum_value(type_name, value):
    enum_type = _get_unreal_type(type_name, type_name[1:] if type_name.startswith("E") else type_name)
    if enum_type is None:
        raise RuntimeError("Missing reflected enum type {}".format(type_name))

    wanted = _normalize_name(value)
    for attr in dir(enum_type):
        if attr.startswith("_"):
            continue
        if _normalize_name(attr) == wanted:
            return getattr(enum_type, attr)

    for attr in dir(enum_type):
        if attr.startswith("_"):
            continue
        normalized = _normalize_name(attr)
        if wanted in normalized or normalized in wanted:
            return getattr(enum_type, attr)

    raise RuntimeError("Cannot resolve enum {}.{}".format(type_name, value))


def _set_editor_property(obj, names, value):
    errors = []
    for name in names:
        try:
            obj.set_editor_property(name, value)
            return name
        except Exception as exc:
            errors.append("{}: {}".format(name, exc))
    raise RuntimeError("Could not set property on {}. Tried {}. Errors: {}".format(obj, names, errors))


def _load_static_mesh(asset_path):
    asset = unreal.EditorAssetLibrary.load_asset(asset_path)
    if isinstance(asset, unreal.StaticMesh):
        return asset
    raise RuntimeError("Expected StaticMesh at {}, got {}".format(asset_path, asset))


def _make_transform(payload):
    location = payload.get("location", [0.0, 0.0, 0.0])
    rotation = payload.get("rotation", [0.0, 0.0, 0.0])
    scale = payload.get("scale", [1.0, 1.0, 1.0])
    return unreal.Transform(
        unreal.Vector(float(location[0]), float(location[1]), float(location[2])),
        unreal.Rotator(float(rotation[0]), float(rotation[1]), float(rotation[2])),
        unreal.Vector(float(scale[0]), float(scale[1]), float(scale[2])),
    )


def _make_assembly_hint(recipe):
    hint_type = _get_unreal_type("SIPResourcePlantAssemblyHint")
    slot_hint_type = _get_unreal_type("SIPResourcePlantSlotAssemblyHint")
    if hint_type is None or slot_hint_type is None:
        raise RuntimeError("Missing reflected assembly hint structs. Rebuild the SIP editor module first.")

    hint_payload = recipe["assembly_hint"]
    hint = hint_type()
    _set_editor_property(hint, ("axis_mapping", "AxisMapping"), _enum_value("SIPResourcePlantAssemblyAxisMapping", hint_payload["axis_mapping"]))
    _set_editor_property(hint, ("source_to_unreal_scale", "SourceToUnrealScale"), float(hint_payload["source_to_unreal_scale"]))
    anchor = hint_payload.get("source_anchor", [0.0, 0.0, 0.0])
    _set_editor_property(hint, ("source_anchor", "SourceAnchor"), unreal.Vector(float(anchor[0]), float(anchor[1]), float(anchor[2])))

    slot_hints = []
    for slot in SLOTS:
        slot_hint = slot_hint_type()
        _set_editor_property(slot_hint, ("slot", "Slot"), _enum_value("SIPResourcePlantSlot", slot))
        _set_editor_property(slot_hint, ("source_placement_center", "SourcePlacementCenter"), unreal.Vector(0.0, 0.0, 0.0))
        _set_editor_property(slot_hint, ("local_rotation", "LocalRotation"), unreal.Rotator(0.0, 0.0, 0.0))
        _set_editor_property(slot_hint, ("local_scale", "LocalScale"), unreal.Vector(1.0, 1.0, 1.0))
        slot_hints.append(slot_hint)

    _set_editor_property(hint, ("slots", "Slots"), slot_hints)
    return hint


def _make_mesh_slot_recipe(slot, slot_plan):
    slot_type = _get_unreal_type("SIPResourcePlantMeshSlotRecipe")
    variant_type = _get_unreal_type("SIPResourcePlantMeshCollapseVariant")
    if slot_type is None or variant_type is None:
        raise RuntimeError("Missing reflected recipe structs. Rebuild the SIP editor module first.")

    slot_recipe = slot_type()
    _set_editor_property(slot_recipe, ("slot", "Slot"), _enum_value("SIPResourcePlantSlot", slot))
    _set_editor_property(slot_recipe, ("mesh", "Mesh"), _load_static_mesh(slot_plan["default_mesh"]))
    _set_editor_property(slot_recipe, ("local_adjustment", "LocalAdjustment"), _make_transform(slot_plan.get("local_adjustment", {})))
    _set_editor_property(slot_recipe, ("runtime_slot_tag", "RuntimeSlotTag"), unreal.Name(slot_plan["runtime_slot_tag"]))
    _set_editor_property(slot_recipe, ("visible", "b_visible", "bVisible"), True)

    variants = []
    variant_adjustments = slot_plan.get("variant_adjustments", {})
    for level in range(4):
        collapse_key = "C{}".format(level)
        variant = variant_type()
        _set_editor_property(variant, ("collapse_level", "CollapseLevel"), level)
        _set_editor_property(variant, ("mesh", "Mesh"), _load_static_mesh(slot_plan["variants"][collapse_key]))
        _set_editor_property(
            variant,
            ("local_adjustment", "LocalAdjustment"),
            _make_transform(variant_adjustments.get(collapse_key, {"scale": [1.0, 1.0, 1.0]})),
        )
        _set_editor_property(variant, ("runtime_slot_tag", "RuntimeSlotTag"), unreal.Name("{}.C{}".format(slot_plan["runtime_slot_tag"], level)))
        _set_editor_property(variant, ("visible", "b_visible", "bVisible"), True)
        variants.append(variant)

    _set_editor_property(slot_recipe, ("collapse_variants", "CollapseVariants"), variants)
    return slot_recipe


def _load_or_create_recipe_asset(asset_spec):
    recipe_type = _get_unreal_type("SIPResourcePlantRecipe")
    if recipe_type is None:
        raise RuntimeError("Missing reflected USIPResourcePlantRecipe class. Rebuild the SIP editor module first.")

    object_path = asset_spec["object_path"]
    existing = unreal.EditorAssetLibrary.load_asset(object_path)
    if existing:
        if not isinstance(existing, recipe_type):
            raise RuntimeError("{} exists but is not SIPResourcePlantRecipe: {}".format(object_path, existing))
        return existing, False

    if not unreal.EditorAssetLibrary.does_directory_exist(asset_spec["package_path"]):
        unreal.EditorAssetLibrary.make_directory(asset_spec["package_path"])

    factory = unreal.DataAssetFactory()
    _set_editor_property(factory, ("data_asset_class", "DataAssetClass"), recipe_type)
    asset = unreal.AssetToolsHelpers.get_asset_tools().create_asset(
        asset_spec["asset_name"],
        asset_spec["package_path"],
        recipe_type,
        factory,
    )
    if not asset:
        raise RuntimeError("Failed to create {}".format(object_path))
    return asset, True


def _write_recipe_asset(asset, recipe):
    _set_editor_property(asset, ("recipe_id", "RecipeId"), unreal.Name(recipe["recipe_id"]))
    _set_editor_property(asset, ("family", "Family"), _enum_value("SIPResourcePlantPreviewFamily", recipe["family"]))
    _set_editor_property(asset, ("default_collapse_band", "DefaultCollapseBand"), _enum_value("SIPResourcePlantCollapseBand", recipe["default_collapse_band"]))
    _set_editor_property(asset, ("assembly_hint", "AssemblyHint"), _make_assembly_hint(recipe))
    _set_editor_property(
        asset,
        ("mesh_slots", "MeshSlots"),
        [_make_mesh_slot_recipe(slot, recipe["mesh_slots"][slot]) for slot in SLOTS],
    )
    _set_editor_property(asset, ("fx_slots", "FXSlots"), [])


def _validate_recipe_asset(asset):
    options_type = _get_unreal_type("SIPResourcePlantRecipeValidationOptions")
    if options_type is None:
        return {"ready": None, "reason": "Validation options struct not reflected"}

    options = options_type()
    _set_editor_property(options, ("require_all_semantic_slots", "b_require_all_semantic_slots", "bRequireAllSemanticSlots"), True)
    _set_editor_property(options, ("require_assembly_hints", "b_require_assembly_hints", "bRequireAssemblyHints"), True)
    _set_editor_property(options, ("require_collapse_variants", "b_require_collapse_variants", "bRequireCollapseVariants"), True)
    _set_editor_property(options, ("require_meshes", "b_require_meshes", "bRequireMeshes"), True)

    ready = bool(asset.is_ready_for_assembly(options)) if hasattr(asset, "is_ready_for_assembly") else None
    return {"ready": ready, "reason": "ok" if ready else "recipe validation reported errors"}


def main():
    args = _get_args()
    static_mesh_paths = _collect_static_mesh_paths()
    audit = build_asset_audit(static_mesh_paths)
    recipe_plan = build_recipe_plan(audit, include_incomplete=args["allow_partial"])
    asset_plan = build_recipe_asset_plan(recipe_plan, package_path=args["package_path"], allow_partial=args["allow_partial"])

    results = []
    for asset_spec in asset_plan["assets"]:
        asset, created = _load_or_create_recipe_asset(asset_spec)
        _write_recipe_asset(asset, asset_spec["recipe"])
        validation = _validate_recipe_asset(asset)
        saved = bool(unreal.EditorAssetLibrary.save_loaded_asset(asset)) if args["save_assets"] else False
        results.append(
            {
                "recipe_id": asset_spec["recipe"]["recipe_id"],
                "object_path": asset_spec["object_path"],
                "created": created,
                "saved": saved,
                "validation": validation,
                "slot_count": len(asset_spec["recipe"]["mesh_slots"]),
            }
        )

    print(
        json.dumps(
            {
                "asset_root": AIGC_PLANT_ROOT,
                "static_mesh_count": len(static_mesh_paths),
                "complete_families": audit["summary"]["complete_families"],
                "incomplete_families": audit["summary"]["incomplete_families"],
                "recipe_asset_package_path": args["package_path"],
                "recipe_asset_count": len(results),
                "results": results,
            },
            indent=2,
            ensure_ascii=False,
        )
    )


main()
