import math

from plant_collapse_sampler import BANDS, FAMILIES, iter_candidates, vector_slug


DEFAULT_ALL_COMBINATIONS_PRESET = {
    "origin": [42000.0, 42000.0, 10000.0],
    "columns": 16,
    "spacing_x": 420.0,
    "spacing_y": 420.0,
    "family_spacing_y": 6200.0,
    "scale": 1.15,
}


def collect_possible_vectors(family, bands=BANDS):
    by_slug = {}

    for band in bands:
        for vector, metrics, energy in iter_candidates(band, family):
            slug = vector_slug(vector)
            if slug not in by_slug:
                by_slug[slug] = {
                    "vector": dict(vector),
                    "bands": [],
                    "metrics": dict(metrics),
                    "min_energy": float(energy),
                    "slug": slug,
                }
            by_slug[slug]["bands"].append(band)
            by_slug[slug]["min_energy"] = min(by_slug[slug]["min_energy"], float(energy))

    rows = list(by_slug.values())
    rows.sort(
        key=lambda item: (
            item["metrics"]["severity"],
            item["metrics"]["dispersion"],
            item["vector"]["BodyShell"],
            item["vector"]["PrimarySilhouette"],
            item["vector"]["Core"],
            item["vector"]["OrbitSet"],
        )
    )
    return rows


def _bounds(points):
    if not points:
        return {"min": [0.0, 0.0, 0.0], "max": [0.0, 0.0, 0.0], "center": [0.0, 0.0, 0.0]}

    mins = [min(point[index] for point in points) for index in range(3)]
    maxs = [max(point[index] for point in points) for index in range(3)]
    center = [(mins[index] + maxs[index]) * 0.5 for index in range(3)]
    return {"min": mins, "max": maxs, "center": center}


def _look_at_rotation(location, target):
    direction = [
        float(target[0]) - float(location[0]),
        float(target[1]) - float(location[1]),
        float(target[2]) - float(location[2]),
    ]
    horizontal = math.sqrt(direction[0] * direction[0] + direction[1] * direction[1])
    pitch = math.degrees(math.atan2(direction[2], horizontal))
    yaw = math.degrees(math.atan2(direction[1], direction[0]))
    return [pitch, yaw, 0.0]


def _camera_for_bounds(bounds):
    center = list(bounds["center"])
    width = max(1.0, bounds["max"][0] - bounds["min"][0])
    depth = max(1.0, bounds["max"][1] - bounds["min"][1])
    location = [
        center[0] - width * 0.25,
        center[1] - max(width * 0.92, depth * 1.24),
        center[2] + 2700.0,
    ]
    target = [center[0], center[1], center[2] + 520.0]
    return {
        "location": location,
        "rotation": _look_at_rotation(location, target),
        "target": target,
    }


def build_all_combinations_layout(
    families=FAMILIES,
    bands=BANDS,
    origin=tuple(DEFAULT_ALL_COMBINATIONS_PRESET["origin"]),
    columns=DEFAULT_ALL_COMBINATIONS_PRESET["columns"],
    spacing_x=DEFAULT_ALL_COMBINATIONS_PRESET["spacing_x"],
    spacing_y=DEFAULT_ALL_COMBINATIONS_PRESET["spacing_y"],
    family_spacing_y=DEFAULT_ALL_COMBINATIONS_PRESET["family_spacing_y"],
    scale=DEFAULT_ALL_COMBINATIONS_PRESET["scale"],
):
    columns = max(1, int(columns))
    actors = []
    family_lanes = []

    for family_index, family in enumerate(families):
        vectors = collect_possible_vectors(family, bands=bands)
        lane_y = float(origin[1]) + family_index * float(family_spacing_y)
        family_lanes.append(
            {
                "family": family,
                "center_y": lane_y,
                "vector_count": len(vectors),
            }
        )

        for vector_index, entry in enumerate(vectors):
            row = vector_index // columns
            column = vector_index % columns
            location = [
                float(origin[0]) + column * float(spacing_x),
                lane_y + row * float(spacing_y),
                float(origin[2]),
            ]
            actors.append(
                {
                    "family": family,
                    "vector_index": vector_index,
                    "location": location,
                    "plant_scale": float(scale),
                    "collapse_vector": dict(entry["vector"]),
                    "vector_slug": entry["slug"],
                    "bands": list(entry["bands"]),
                    "metrics": dict(entry["metrics"]),
                    "min_energy": float(entry["min_energy"]),
                }
            )

    layout_bounds = _bounds([actor["location"] for actor in actors])
    return {
        "schema": "SkyIslandPotion.AIGCPlantAllCombinationsLayout.v0",
        "composition": "collapse_vector_all_combinations",
        "families": list(families),
        "bands": list(bands),
        "columns": columns,
        "origin": [float(value) for value in origin],
        "spacing_x": float(spacing_x),
        "spacing_y": float(spacing_y),
        "family_spacing_y": float(family_spacing_y),
        "scale": float(scale),
        "family_lanes": family_lanes,
        "actors": actors,
        "bounds": layout_bounds,
        "camera": _camera_for_bounds(layout_bounds),
    }
