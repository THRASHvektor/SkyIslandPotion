from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

from PIL import Image, ImageDraw


PANEL_SIZE = 360
PANEL_GAP = 18
HEADER_HEIGHT = 28
BACKGROUND = (22, 24, 26)


def _lerp(a: int, b: int, t: float) -> int:
    return round(a + (b - a) * max(0.0, min(1.0, t)))


def _mix(a: tuple[int, int, int], b: tuple[int, int, int], t: float) -> tuple[int, int, int]:
    return (_lerp(a[0], b[0], t), _lerp(a[1], b[1], t), _lerp(a[2], b[2], t))


def _heat(value: float) -> tuple[int, int, int]:
    value = max(0.0, min(1.0, value))
    if value < 0.5:
        return _mix((35, 45, 72), (188, 83, 50), value * 2.0)
    return _mix((188, 83, 50), (244, 221, 146), (value - 0.5) * 2.0)


def _mask_color(value: float, color: tuple[int, int, int]) -> tuple[int, int, int]:
    base = (34, 36, 38)
    return _mix(base, color, max(0.0, min(1.0, value)))


def _sample(field: dict, layer: str, x: int, y: int, size: int) -> float | None:
    nx = (x + 0.5) / size * 2.0 - 1.0
    ny = (y + 0.5) / size * 2.0 - 1.0
    radius = math.hypot(nx, ny)
    if radius > 1.0:
        return None

    rings = int(field["rings"])
    segments = int(field["radial_segments"])
    ring = max(0, min(rings, round(radius * rings)))
    angle = (math.atan2(ny, nx) + math.tau) % math.tau
    index = int((angle / math.tau) * segments) % segments
    if layer == "heights":
        return float(field["heights"][ring][index])
    return float(field["masks"][layer][ring][index])


def _render_panel(field: dict, title: str, layer: str, color: tuple[int, int, int] | None = None) -> Image.Image:
    image = Image.new("RGB", (PANEL_SIZE, PANEL_SIZE + HEADER_HEIGHT), BACKGROUND)
    pixels = image.load()
    draw = ImageDraw.Draw(image)
    draw.text((8, 7), title, fill=(226, 228, 224))

    min_height = 0.0
    max_height = 1.0
    if layer == "heights":
        height_values = [float(value) for row in field["heights"] for value in row]
        min_height = min(height_values)
        max_height = max(height_values)

    for y in range(PANEL_SIZE):
        for x in range(PANEL_SIZE):
            value = _sample(field, layer, x, y, PANEL_SIZE)
            if value is None:
                pixels[x, y + HEADER_HEIGHT] = BACKGROUND
                continue
            if layer == "heights":
                normalized = (value - min_height) / max(1.0, max_height - min_height)
                pixels[x, y + HEADER_HEIGHT] = _heat(normalized)
            else:
                pixels[x, y + HEADER_HEIGHT] = _mask_color(value, color or (220, 220, 220))
    return image


def _render_semantic_panel(field: dict) -> Image.Image:
    image = Image.new("RGB", (PANEL_SIZE, PANEL_SIZE + HEADER_HEIGHT), BACKGROUND)
    pixels = image.load()
    draw = ImageDraw.Draw(image)
    draw.text((8, 7), "Semantic Material Masks", fill=(226, 228, 224))

    for y in range(PANEL_SIZE):
        for x in range(PANEL_SIZE):
            path = _sample(field, "path", x, y, PANEL_SIZE)
            if path is None:
                pixels[x, y + HEADER_HEIGHT] = BACKGROUND
                continue
            lava = _sample(field, "lava", x, y, PANEL_SIZE) or 0.0
            cliff = _sample(field, "cliff", x, y, PANEL_SIZE) or 0.0
            strata = _sample(field, "strata", x, y, PANEL_SIZE) or 0.0
            slope = _sample(field, "slope", x, y, PANEL_SIZE) or 0.0

            color = (76, 93, 77)
            color = _mix(color, (112, 110, 104), max(cliff, strata * 0.72, slope * 0.42))
            color = _mix(color, (187, 139, 86), path)
            color = _mix(color, (240, 88, 41), lava)
            pixels[x, y + HEADER_HEIGHT] = color
    return image


def render_diagnostics(field_path: Path, output_path: Path) -> None:
    field = json.loads(field_path.read_text(encoding="utf-8"))
    panels = [
        _render_panel(field, "Height Field", "heights"),
        _render_semantic_panel(field),
        _render_panel(field, "Slope Risk", "slope", (230, 98, 82)),
        _render_panel(field, "Talus Deposition", "talus", (198, 168, 104)),
        _render_panel(field, "Flow Accumulation", "flow_accumulation", (89, 165, 220)),
        _render_panel(field, "Strata Exposure", "strata", (186, 184, 171)),
    ]

    width = PANEL_SIZE * 3 + PANEL_GAP * 4
    height = (PANEL_SIZE + HEADER_HEIGHT) * 2 + PANEL_GAP * 3
    atlas = Image.new("RGB", (width, height), BACKGROUND)
    for panel_index, panel in enumerate(panels):
        column = panel_index % 3
        row = panel_index // 3
        x = PANEL_GAP + column * (PANEL_SIZE + PANEL_GAP)
        y = PANEL_GAP + row * (PANEL_SIZE + HEADER_HEIGHT + PANEL_GAP)
        atlas.paste(panel, (x, y))

    output_path.parent.mkdir(parents=True, exist_ok=True)
    atlas.save(output_path)


def main() -> None:
    parser = argparse.ArgumentParser(description="Render IslandMeshGen field masks into a diagnostic PNG atlas.")
    parser.add_argument("--field", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    render_diagnostics(args.field, args.output)
    print(f"Wrote {args.output}")


if __name__ == "__main__":
    main()
