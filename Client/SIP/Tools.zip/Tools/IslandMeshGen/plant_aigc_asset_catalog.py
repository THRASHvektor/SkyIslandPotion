import json
from pathlib import Path

from plant_collapse_sampler import BANDS, FAMILIES, SLOTS


AIGC_PLANT_ROOT = "/Game/AIGC/Plants"
COLLAPSE_LEVELS = (0, 1, 2, 3)
DEFAULT_COLLAPSE_BAND = "Weathered_C1"
DEFAULT_PRESENTATION_PROFILE_PATH = Path(__file__).resolve().parent / "config" / "aigc_plant_presentation_profile.json"

SLOT_PRESENTATION_SCALES = {
    "CrownLily": {
        "BodyShell": 0.52,
        "PrimarySilhouette": 0.58,
        "Core": 0.36,
        "OrbitSet": 0.13,
    },
    "AetherVine": {
        "BodyShell": 1.05,
        "PrimarySilhouette": 0.62,
        "Core": 0.40,
        "OrbitSet": 0.18,
    },
}


TRANSFORM_KEYS = ("location", "rotation", "scale")


def _expected_path(family, level, slot):
    return "{}/{}/C{}/{}".format(AIGC_PLANT_ROOT, family, level, slot)


def parse_aigc_static_mesh_path(path):
    normalized = str(path).strip()
    parts = normalized.split("/")

    if len(parts) != 7:
        return None
    if "/".join(parts[:4]) != "/Game/AIGC/Plants":
        return None

    family = parts[4]
    collapse = parts[5]
    slot = parts[6]

    if slot not in SLOTS:
        return None
    if not collapse.startswith("C") or not collapse[1:].isdigit():
        return None

    level = int(collapse[1:])
    if level not in COLLAPSE_LEVELS:
        return None

    return {
        "family": family,
        "collapse": collapse,
        "level": level,
        "slot": slot,
        "path": normalized,
    }


def build_asset_audit(asset_paths, families=FAMILIES):
    parsed_assets = []
    path_set = set()

    for path in asset_paths:
        parsed = parse_aigc_static_mesh_path(path)
        if parsed is None:
            continue
        parsed_assets.append(parsed)
        path_set.add(parsed["path"])

    discovered_families = sorted({asset["family"] for asset in parsed_assets})
    requested_families = list(families)
    family_order = list(dict.fromkeys(requested_families + discovered_families))

    family_reports = {}
    for family in family_order:
        found = []
        missing = []
        levels = {}

        for level in COLLAPSE_LEVELS:
            collapse_key = "C{}".format(level)
            levels[collapse_key] = {}
            for slot in SLOTS:
                expected = _expected_path(family, level, slot)
                if expected in path_set:
                    found.append(expected)
                    levels[collapse_key][slot] = expected
                else:
                    missing.append(expected)
                    levels[collapse_key][slot] = None

        family_reports[family] = {
            "family": family,
            "is_complete": len(missing) == 0,
            "found_count": len(found),
            "expected_count": len(COLLAPSE_LEVELS) * len(SLOTS),
            "found": found,
            "missing": missing,
            "levels": levels,
        }

    complete_families = [family for family in family_order if family_reports[family]["is_complete"]]
    incomplete_families = [family for family in family_order if not family_reports[family]["is_complete"]]

    return {
        "schema": "SkyIslandPotion.AIGCPlantAssetAudit.v0",
        "asset_root": AIGC_PLANT_ROOT,
        "slots": list(SLOTS),
        "collapse_levels": ["C{}".format(level) for level in COLLAPSE_LEVELS],
        "families": family_reports,
        "summary": {
            "family_count": len(family_order),
            "complete_families": complete_families,
            "incomplete_families": incomplete_families,
            "static_mesh_count": len(path_set),
        },
    }


def _float_list(values):
    return [float(value) for value in values]


def _identity_transform():
    return {
        "location": [0.0, 0.0, 0.0],
        "rotation": [0.0, 0.0, 0.0],
        "scale": [1.0, 1.0, 1.0],
    }


def _clone_transform(transform):
    return {
        "location": list(transform["location"]),
        "rotation": list(transform["rotation"]),
        "scale": list(transform["scale"]),
    }


def _coerce_vector3(value, fallback, clamp_min=None):
    if value is None:
        values = list(fallback)
    elif isinstance(value, (int, float, str)):
        values = [float(value), float(value), float(value)]
    else:
        values = list(value)
        if len(values) != 3:
            raise ValueError("Expected a 3-value vector, got {}".format(value))
        values = _float_list(values)

    if clamp_min is not None:
        values = [max(float(clamp_min), value) for value in values]
    return values


def _coerce_transform(value, fallback=None):
    transform = _clone_transform(fallback or _identity_transform())

    if isinstance(value, (int, float, str)):
        transform["scale"] = _coerce_vector3(value, transform["scale"], clamp_min=0.001)
        return transform

    if not isinstance(value, dict):
        raise ValueError("Expected a transform object or scalar scale, got {}".format(value))

    if "location" in value:
        transform["location"] = _coerce_vector3(value.get("location"), transform["location"])
    if "rotation" in value:
        transform["rotation"] = _coerce_vector3(value.get("rotation"), transform["rotation"])
    if "scale" in value:
        transform["scale"] = _coerce_vector3(value.get("scale"), transform["scale"], clamp_min=0.001)

    return transform


def _make_slot_presentation(default_transform):
    return {
        "default": _clone_transform(default_transform),
        "levels": {},
    }


def _clone_slot_presentation(slot_presentation):
    return {
        "default": _clone_transform(slot_presentation["default"]),
        "levels": {
            collapse: _clone_transform(transform)
            for collapse, transform in slot_presentation.get("levels", {}).items()
        },
    }


def _clone_default_presentation_profile():
    profile = {}
    for family, slot_scales in SLOT_PRESENTATION_SCALES.items():
        profile[family] = {}
        for slot, scale in slot_scales.items():
            profile[family][slot] = _make_slot_presentation(_coerce_transform(scale))
    return profile


def _has_transform_keys(payload):
    return isinstance(payload, dict) and any(key in payload for key in TRANSFORM_KEYS)


def _merge_presentation_profile(base_profile, profile):
    for family, slot_payloads in profile.get("families", {}).items():
        family_profile = base_profile.setdefault(str(family), {})
        for slot, payload in slot_payloads.items():
            if slot not in SLOTS:
                continue
            slot = str(slot)
            slot_profile = family_profile.setdefault(slot, _make_slot_presentation(_identity_transform()))

            if isinstance(payload, dict):
                default_payload = payload.get("default", payload if _has_transform_keys(payload) else None)
                if default_payload is not None:
                    slot_profile["default"] = _coerce_transform(default_payload, slot_profile["default"])

                for level in COLLAPSE_LEVELS:
                    collapse = "C{}".format(level)
                    if collapse in payload:
                        slot_profile["levels"][collapse] = _coerce_transform(payload[collapse], slot_profile["default"])
            else:
                slot_profile["default"] = _coerce_transform(payload, slot_profile["default"])

    return base_profile


def load_presentation_scales(profile_path=None):
    profile = _clone_default_presentation_profile()
    resolved_path = Path(profile_path) if profile_path else DEFAULT_PRESENTATION_PROFILE_PATH

    if not resolved_path.exists():
        if profile_path:
            raise FileNotFoundError(str(resolved_path))
        return profile

    with resolved_path.open("r", encoding="utf-8") as handle:
        return _merge_presentation_profile(profile, json.load(handle))


def _slot_presentation(family, slot, presentation_profile):
    family_profile = presentation_profile.get(family, {})
    slot_profile = family_profile.get(slot)
    if not slot_profile:
        return _make_slot_presentation(_identity_transform())
    return _clone_slot_presentation(slot_profile)


def _delta_transform(base, target):
    return {
        "location": [
            float(target["location"][index]) - float(base["location"][index])
            for index in range(3)
        ],
        "rotation": [
            float(target["rotation"][index]) - float(base["rotation"][index])
            for index in range(3)
        ],
        "scale": [
            float(target["scale"][index]) / float(base["scale"][index])
            if abs(float(base["scale"][index])) > 1e-8
            else float(target["scale"][index])
            for index in range(3)
        ],
    }


def _slot_recipe(slot, family_report, presentation_profile):
    presentation = _slot_presentation(family_report["family"], slot, presentation_profile)
    default_transform = presentation["default"]
    level_targets = {
        "C{}".format(level): presentation["levels"].get("C{}".format(level), default_transform)
        for level in COLLAPSE_LEVELS
    }

    return {
        "slot": slot,
        "default_mesh": family_report["levels"]["C0"][slot],
        "runtime_slot_tag": "Runtime.{}.AIGC".format(slot),
        "local_adjustment": _clone_transform(default_transform),
        "variants": {
            "C{}".format(level): family_report["levels"]["C{}".format(level)][slot]
            for level in COLLAPSE_LEVELS
        },
        "variant_adjustments": {
            collapse: _delta_transform(default_transform, target)
            for collapse, target in level_targets.items()
        },
    }


def build_recipe_plan(audit, include_incomplete=False, presentation_profile_path=None):
    presentation_profile = load_presentation_scales(presentation_profile_path)
    recipes = []
    partial_recipe_families = []

    for family, family_report in audit["families"].items():
        if not family_report["is_complete"] and not include_incomplete:
            continue
        if not family_report["is_complete"]:
            partial_recipe_families.append(family)

        recipes.append(
            {
                "recipe_id": "AIGC_{}".format(family),
                "family": family,
                "default_collapse_band": DEFAULT_COLLAPSE_BAND,
                "supported_bands": list(BANDS),
                "assembly_hint": {
                    "mode": "shared_origin_identity",
                    "axis_mapping": "Identity",
                    "source_to_unreal_scale": 1.0,
                    "source_anchor": [0.0, 0.0, 0.0],
                },
                "mesh_slots": {
                    slot: _slot_recipe(slot, family_report, presentation_profile)
                    for slot in SLOTS
                },
            }
        )

    return {
        "schema": "SkyIslandPotion.AIGCPlantRecipePlan.v0",
        "source_audit_schema": audit["schema"],
        "asset_root": audit["asset_root"],
        "recipes": recipes,
        "skipped_incomplete_families": audit["summary"]["incomplete_families"],
        "partial_recipe_families": partial_recipe_families,
    }
