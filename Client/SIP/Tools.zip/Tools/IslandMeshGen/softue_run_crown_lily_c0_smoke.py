from __future__ import annotations

import json

from soft_ue_cli.client import call_tool


SCRIPT_PATH = r"C:\Users\12542\Documents\Unreal Projects\SkyIslandPotion\Tools\IslandMeshGen\ue_place_crown_lily_c0_smoke.py"


def main() -> int:
    result = call_tool("run-python-script", {"script_path": SCRIPT_PATH}, timeout=180)
    print(json.dumps(result, indent=2, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
