from plant_collapse_sampler import BANDS, FAMILIES, SLOTS, sample_collapse_vector, vector_slug


DEFAULT_ORIGIN = (-2100.0, -1200.0, 120.0)
DEFAULT_FAMILY_SPACING_Y = 1450.0
DEFAULT_BAND_SPACING_X = 920.0
DEFAULT_SAMPLE_SPACING_Y = 470.0


def _recipe_by_family(recipe_plan):
    return {recipe["family"]: recipe for recipe in recipe_plan.get("recipes", [])}


def _resolve_slot_meshes(recipe, vector):
    resolved = {}
    for slot in SLOTS:
        level = int(vector[slot])
        slot_recipe = recipe["mesh_slots"][slot]
        resolved[slot] = slot_recipe["variants"]["C{}".format(level)]
    return resolved


def _actor_label(family, band, sample_index, vector):
    return "SIP_AIGC_ResourcePlant_{}_{}_S{}_{}".format(
        family,
        band,
        sample_index,
        vector_slug(vector),
    )


def _location(origin, family_index, band_index, sample_index, family_spacing_y, band_spacing_x, sample_spacing_y):
    return [
        float(origin[0]) + band_index * float(band_spacing_x),
        float(origin[1]) + family_index * float(family_spacing_y) + sample_index * float(sample_spacing_y),
        float(origin[2]),
    ]


def build_actor_spawn_plan(
    recipe_plan,
    families=FAMILIES,
    bands=BANDS,
    samples_per_band=2,
    seed=7307,
    origin=DEFAULT_ORIGIN,
    family_spacing_y=DEFAULT_FAMILY_SPACING_Y,
    band_spacing_x=DEFAULT_BAND_SPACING_X,
    sample_spacing_y=DEFAULT_SAMPLE_SPACING_Y,
    scale=1.0,
    temperature_scale=1.0,
):
    recipes = _recipe_by_family(recipe_plan)
    actors = []
    skipped = []

    samples_per_band = max(1, int(samples_per_band))
    seed = int(seed)
    scale = max(0.01, float(scale))

    for family_index, family in enumerate(families):
        recipe = recipes.get(family)
        if not recipe:
            skipped.append(family)
            continue

        for band_index, band in enumerate(bands):
            for sample_index in range(samples_per_band):
                sample_seed = seed + family_index * 1000 + band_index * 100 + sample_index * 17
                sample = sample_collapse_vector(
                    seed=sample_seed,
                    band=band,
                    family=family,
                    temperature_scale=temperature_scale,
                )
                vector = sample.vector

                actors.append(
                    {
                        "label": _actor_label(family, band, sample_index, vector),
                        "recipe_id": recipe["recipe_id"],
                        "family": family,
                        "band": band,
                        "sample_index": sample_index,
                        "seed": sample_seed,
                        "location": _location(
                            origin,
                            family_index,
                            band_index,
                            sample_index,
                            family_spacing_y,
                            band_spacing_x,
                            sample_spacing_y,
                        ),
                        "plant_scale": scale,
                        "temperature_scale": float(temperature_scale),
                        "collapse_vector": dict(vector),
                        "vector_slug": vector_slug(vector),
                        "metrics": dict(sample.metrics),
                        "energy": sample.energy,
                        "resolved_slot_meshes": _resolve_slot_meshes(recipe, vector),
                        "recipe": recipe,
                    }
                )

    return {
        "schema": "SkyIslandPotion.AIGCPlantActorSpawnPlan.v0",
        "placement_mode": "ASIPResourcePlantActor_transient_recipe_readonly_aigc_assets",
        "families": list(families),
        "bands": list(bands),
        "samples_per_band": samples_per_band,
        "seed": seed,
        "origin": [float(origin[0]), float(origin[1]), float(origin[2])],
        "plant_scale": scale,
        "temperature_scale": float(temperature_scale),
        "actors": actors,
        "skipped_missing_recipes": skipped,
    }
