# IslandMeshGen

Small CLI prototype for generating Unreal-friendly floating island OBJ meshes.

This is not an art-quality sculpting tool. It generates controllable gameplay bones: walkable top surface, broken outline, heightfield terrain variation, ravine material bands, cliff sides, underside cone, and material slots for UE replacement materials.

## Generate

```powershell
py -3 Tools\IslandMeshGen\island_mesh_generator.py --biome forest --radius-m 100 --seed 1001 --segments 96 --output Tools\IslandMeshGen\output\SM_ProcIsland_Forest_Main_200m.obj
```

## Semantic Layout

`semantic_layout.py` is the first concrete step toward the semantic whitebox pipeline. It defines JSON-friendly layouts for fire, ice, and forest islands before mesh baking.

```python
from semantic_layout import default_layout

layout = default_layout("fire", seed=2002)
print(layout.to_json())
```

The current mesh generator still uses its original heightfield path. The layout model is intentionally separate so the next iteration can move from `biome + noise` to `layout zones + landmarks + paths` without breaking OBJ export.

`generate_island_mesh_from_layout(layout)` now bridges the first fire controls into mesh baking:

- `central_volcano.dominance` changes crater rim height.
- `main_approach.width` changes path material coverage and approach flattening.
- `central_volcano.radius` changes the crater footprint.
- `lava_channels.count` changes lava crack coverage.
- `partial_crater_loop.coverage` changes the amount of ring-path material around the crater.

Generate the current fire semantic demo with:

```powershell
py -3 Tools\IslandMeshGen\export_fire_demo.py
```

This writes:

- `Tools\IslandMeshGen\layouts\fire_volcano_demo.json`
- `Tools\IslandMeshGen\output\SM_ProcIsland_Fire_VolcanoLayout_200m.obj`

## Web Editor

Run the local semantic editor with:

```powershell
node Tools\IslandMeshGen\web\server.mjs
```

Then open:

```text
http://127.0.0.1:4177
```

The editor currently focuses on the fire volcano sample. It includes:

- Editable controls for volcano dominance, volcano radius, path width, lava channel count, and crater loop coverage.
- Auto-link mode that derives a coherent volcanic layout from the main dominance control.
- Design health warnings for unnatural parameter combinations.
- 2D semantic layout preview for landmarks, paths, hazards, and arenas.
- Lightweight realtime OBJ preview for authoring, decoupled from high-density output quality.
- Explicit high-res inspect snapshots for checking the selected final bake quality without writing final artifacts.
- A generate button that writes the current JSON and exports the OBJ.

The editor has three separate graphics data flows: realtime preview, high-res inspect, and final generate. See `docs/GRAPHICS_DATAFLOW_MINDSET.md` for the platform mental model and renderer roadmap. See `docs/PLATFORM_BASELINE_2026-07-04.md` for the current landed platform baseline and state boundaries.

### 中文速读

本地 Web 编辑器现在已经不是单纯的 OBJ 预览页，而是一个语义地形 authoring 工作台。当前主要围绕 Fire Volcano 样例，支持拖动火山强度、火山半径、路线宽度、岩浆分支、环形路径覆盖度、地表 detail / erosion / deposition 等参数。

当前平台基座的核心心智是三条数据流分离：

- `Realtime Preview`：拖参数时自动跑轻量 preview，优先保证反馈速度。
- `High-res Inspect`：用户显式点击 `Inspect <QUALITY>`，按当前 final bake 档位看高精度快照，但不写正式导出产物。
- `Final Generate`：用户点击 `Generate Biome`，才写给 UE / PCG 管线使用的正式 OBJ、manifest、field 和 quality report。

右侧 3D 视口默认使用 WebGL，Canvas 仍保留为 fallback / debug；左侧 2D footprint / minimap 继续使用 Canvas。Inspect 只是快照，一旦继续编辑参数，快照会变成 stale，界面回到 realtime preview。

中文版平台基线见 `docs/PLATFORM_BASELINE_2026-07-04.md` 的“中文版：IslandMeshGen 平台基座现状”一节。

## Output Scale

- Units are Unreal centimeters.
- `--radius-m 100` produces an island around 200 m wide. This is the current target scale for playable island layouts.
- Smaller values such as `--radius-m 20` or `--radius-m 30` are useful only for quick mesh previews; they are too cramped for volcano paths, ice arenas, and forest pockets.

## Terrain Model

- Broad fractal noise creates large terrain forms.
- Ridged noise creates raised ridges and rougher ground.
- Three radial ravine bands carve visible cracks from the center toward the edge.
- A central plateau and one path band are partially flattened to preserve gameplay traversal.
- Edge falloff lowers the perimeter so the island reads as a broken floating landmass instead of a flat disk.
- Forest adds a lightly quantized outer shelf band so the side profile reads as layered terrain instead of random folds.
- Fire narrows crack material bands while deepening the actual cuts, so the silhouette reads as main ravines instead of dense spikes.
- Ice aggressively flattens the inner cap while keeping sharper outer cuts, so it reads as a playable ice shelf.
- Fire adds an explicit central volcano crater and radial lava channels. This is a landmark silhouette, not just noise.
- Fire also reserves a flattened approach path to the volcano so the crater is a playable destination instead of only a background prop.
- Ice adds primary crystal spires around the playable center so the biome reads from a distance.
- Forest removes several cliff-side panels to create actual cave-mouth openings for tree-hole / root-hole dressing.

## Biome Presets

- `forest`: wider playable plateau, moderate natural ravines, layered outer terraces, softer edge drop.
- `fire`: fewer but deeper radial cracks, stronger macro relief, smaller safe plateau.
- `ice`: broad flattened ice cap, fewer cracks, clean outer cuts, smoother core relief.

## Iteration Log

- Round 0: The first generator proved the pipeline: deterministic OBJ output, UE centimeter scale, five material slots, and enough roughness to avoid a flat disk. The mental model was "gameplay bones first, art polish later."
- Round 1: The islands looked too flat and read mostly as wide plates. The key insight was to shrink sculpting scale and increase vertical exaggeration instead of only scaling the mesh up. Aerialod was useful here: small heightfield differences become dramatic when vertical range, light, and shadow are allowed to speak.
- Round 2: The screenshots showed verticality was better, but biome identity was still weak. Fire became too spiky, forest still looked like folded gray terrain, and ice was only a flatter forest. The mental model changed from "more relief" to "readable terrain grammar."
- Round 3: The current target is biome-specific grammar. Fire should be 3-5 dominant ravines and deep cuts, not noisy spikes. Forest should expose layered shelves that can carry PCG vegetation. Ice should keep a broad playable cap with sharper broken ice edges. Tests now track these proxies: crack count, top height range, inner cap flatness, and terrace alignment.
- Round 4: The screenshots still changed too little because all changes were terrain grammar, not concept-art landmarks. The target shifted to big readable props baked into the mesh silhouette: a fire volcano crater, tall ice crystal spires, and forest cliff cave mouths. The tool should now steal more directly from the pitch images: each biome needs one dominant symbol visible before materials, VFX, or PCG dressing are added.
- Round 5: The 40-60 m previews were too cramped. They made every biome read as a tabletop prop, not a playable island. The target scale is now 200 m diameter so the generator has room for layout: fire needs a walkable approach path to the crater, ice needs space between the crystal spires, and forest needs pockets for tree holes, PCG vegetation, and traversal beats.
- Round 6: The generator now has a semantic layout layer in `semantic_layout.py`. Fire, ice, and forest each expose zones, landmarks, paths, and material masks as JSON-friendly dataclasses. The first mesh bridge is active: fire `central_volcano.dominance`, `central_volcano.radius`, `main_approach.width`, `lava_channels.count`, and `partial_crater_loop.coverage` now drive generated OBJ geometry/material coverage through `generate_island_mesh_from_layout()`.
- Round 7: The tool gained a local Web editor for recording and review. The important shift was from "show the Python output" to "show the semantic design workflow": fire layout JSON, controls, 2D semantic map, and one-click OBJ export in the same screen.
- Round 8: Independent sliders could create unnatural layouts, so the editor gained an auto-link coherence layer. `central_volcano.dominance` now acts as a macro control that can derive radius, route width, lava count, and loop coverage. The editor also gained a 3D OBJ canvas preview so the 2D intent and generated mesh can be reviewed side by side.

## AIGC Shader Direction

- Use AIGC for material ideation and texture generation, not for replacing the UE material graph. Generate tileable albedo/roughness/normal/emissive references, then assemble them as controlled Unreal materials.
- Keep the mesh material slots semantic: top/path/cliff/underside/crack. They are the stable bridge from generated whitebox mesh to AI-assisted material dressing.
- For fast iteration, feed screenshots or clay renders into image tools to create style targets, then convert the useful parts into tileable textures or masks. Do not rely on a single baked image projected onto the mesh; it will break as soon as the island shape changes.

## Material Slots

- `M_TopGrass`
- `M_PathDirt`
- `M_CliffRock`
- `M_UndersideRock`
- `M_ElementCrack`

## UE Import Notes

- Import as Static Mesh.
- Use simple collision or `Use Complex Collision As Simple` for the first prototype check.
- Replace material slots with project materials after import.
- Put the mesh into an `ASIPIslandActor` / BP island and adjust `IslandBounds` to cover the top surface.
