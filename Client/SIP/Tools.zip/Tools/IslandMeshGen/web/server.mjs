import { createServer } from 'node:http';
import { existsSync } from 'node:fs';
import { copyFile, mkdir, readFile, readdir, rm, stat, writeFile } from 'node:fs/promises';
import { spawn } from 'node:child_process';
import { basename, dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';
import {
  BIOME_META,
  DEFAULT_PLANT_SAMPLE_ID,
  SUPPORTED_BIOMES,
  bakeQualityOptions,
  contentTypeForPath,
  exportArgsForQuality,
  inspectPathsForBiome,
  normalizeBiome,
  plantExportPreviewGroups,
  plantExportPreviewRoots,
  plantExportWorkspacePriority,
  plantPreviewFileUrl,
  plantPreviewProjectPath,
  pathsForBiome,
  previewExportArgs,
  previewPathsForBiome,
  localPlantUploadRoot,
  resolveDefaultPlantSampleFiles,
  resolveInboxPlantSampleFiles,
  resolveLocalPlantUploadSampleFiles,
  resolvePlantPreviewFilePath,
  isInboxPlantSampleId,
  isLocalPlantUploadSampleId,
  normalizePlantSampleId,
  resolvePythonCommand,
  safePlantUploadFileName,
  safePlantUploadId,
  staticHeadersForPath,
} from './server_utils.mjs';
import { packGltfToGlb } from './plant_glb_pack.mjs';
import {
  MESHY_BASE_URL,
  MESHY_TEXT_STYLE_PROMPT_MAX_LENGTH,
  buildMeshyRoundtripCreateRequest,
  meshyResultGlbUrl,
  normalizeRoundtripOperation,
  sanitizeMeshyRoundtripRequest,
  sanitizeMeshyRoundtripTask,
} from './meshy_roundtrip.mjs';
import { qualityReportForMesh } from './view_model.mjs';

const __dirname = fileURLToPath(new URL('.', import.meta.url));
const toolRoot = resolve(__dirname, '..');
const staticRoot = __dirname;
const port = Number(process.env.PORT || 4177);
const localPythonFallback = 'C:\\Users\\12542\\AppData\\Local\\Programs\\Python\\Python312\\python.exe';

function sendJson(response, statusCode, payload) {
  response.writeHead(statusCode, { 'Content-Type': 'application/json; charset=utf-8' });
  response.end(JSON.stringify(payload, null, 2));
}

function plantAssetHeaders(assetKey, byteLength) {
  const extension = assetKey.split('-').at(-1);
  const contentTypes = {
    obj: 'text/plain; charset=utf-8',
    mtl: 'text/plain; charset=utf-8',
    glb: 'model/gltf-binary',
    png: 'image/png',
  };
  return {
    'Content-Type': contentTypes[extension] || 'application/octet-stream',
    'Content-Length': byteLength,
    'Cache-Control': 'no-store',
  };
}

async function plantSampleFilesForId(rawSampleId) {
  const sampleId = normalizePlantSampleId(rawSampleId);
  if (sampleId === DEFAULT_PLANT_SAMPLE_ID) return resolveDefaultPlantSampleFiles(toolRoot);
  if (isLocalPlantUploadSampleId(sampleId)) {
    const manifestPath = resolve(localPlantUploadRoot(toolRoot), sampleId, 'upload_manifest.json');
    const uploadManifest = await maybeReadJson(manifestPath);
    if (!uploadManifest) {
      throw new Error(`Local plant upload "${sampleId}" has no upload manifest.`);
    }
    return resolveLocalPlantUploadSampleFiles(toolRoot, sampleId, uploadManifest);
  }
  if (!isInboxPlantSampleId(sampleId)) {
    throw new Error(`Unknown plant sample "${rawSampleId}".`);
  }
  const sampleDir = resolve(toolRoot, 'mesh_inbox', sampleId);
  const entries = await readdir(sampleDir, { withFileTypes: true });
  return resolveInboxPlantSampleFiles(
    toolRoot,
    sampleId,
    entries.filter((entry) => entry.isFile()).map((entry) => entry.name),
  );
}

async function plantSampleAssetInfo(sampleFiles, assetKey) {
  const filePath = sampleFiles.files[assetKey];
  const fileStat = await stat(filePath);
  return {
    key: assetKey,
    fileName: basename(filePath),
    bytes: fileStat.size,
    url: `/api/plant/sample-assets/${assetKey}?id=${encodeURIComponent(sampleFiles.sampleId)}`,
  };
}

async function plantSampleManifest(rawSampleId) {
  const sampleFiles = await plantSampleFilesForId(rawSampleId);
  const assetKeys = ['split-obj', 'split-mtl', 'split-glb', 'pbr-glb', 'pbr-obj', 'pbr-png']
    .filter((key) => sampleFiles.files[key]);
  const assets = Object.fromEntries(
    await Promise.all(assetKeys.map(async (key) => [key, await plantSampleAssetInfo(sampleFiles, key)])),
  );
  return {
    ok: true,
    sampleId: sampleFiles.sampleId,
    label: sampleFiles.label,
    plantProfile: sampleFiles.plantProfile,
    assetRoot: sampleFiles.assetRoot,
    assets,
    mapping: sampleFiles.mapping,
    defaultGroups: ['Core', 'PrimarySilhouette', 'OrbitSet', 'BodyShell'],
  };
}

async function saveLocalPlantUpload(request, requestUrl) {
  const rawUploadId = requestUrl.searchParams.get('uploadId') || `local-upload-${Date.now().toString(36)}`;
  let uploadId = safePlantUploadId(rawUploadId);
  if (!uploadId.startsWith('local-upload-')) uploadId = `local-upload-${uploadId}`;
  const assetKey = requestUrl.searchParams.get('assetKey');
  if (!['split-glb', 'pbr-glb'].includes(assetKey)) {
    throw new Error('Local plant upload assetKey must be split-glb or pbr-glb.');
  }
  const fallbackName = assetKey === 'split-glb' ? 'split.glb' : 'pbr.glb';
  const fileName = safePlantUploadFileName(requestUrl.searchParams.get('fileName') || fallbackName, fallbackName);
  if (!/\.glb$/i.test(fileName)) {
    throw new Error('Local plant upload currently accepts GLB files only.');
  }
  const uploadRoot = localPlantUploadRoot(toolRoot);
  const uploadDir = resolve(uploadRoot, uploadId);
  if (!uploadDir.startsWith(uploadRoot)) {
    throw new Error('Resolved local upload path escapes upload workspace.');
  }
  await mkdir(uploadDir, { recursive: true });
  const filePath = resolve(uploadDir, fileName);
  if (!filePath.startsWith(uploadDir)) {
    throw new Error('Resolved local upload file path escapes upload workspace.');
  }
  const body = await readRequestBuffer(request, 512 * 1024 * 1024);
  await writeFile(filePath, body);

  const manifestPath = resolve(uploadDir, 'upload_manifest.json');
  const previous = await maybeReadJson(manifestPath);
  const plantProfile = requestUrl.searchParams.get('plantProfile') || previous?.plantProfile || 'CrownLily';
  const manifest = {
    schema: 'SkyIslandPotion.PlantLocalUpload.v1',
    sampleId: uploadId,
    label: `${plantProfile} Local GLB Upload`,
    plantProfile,
    updated_at: new Date().toISOString(),
    assets: {
      ...(previous?.assets || {}),
      [assetKey]: {
        fileName,
        bytes: body.byteLength,
        uploaded_at: new Date().toISOString(),
      },
    },
  };
  await writeFile(manifestPath, JSON.stringify(manifest, null, 2) + '\n', 'utf8');
  const complete = Boolean(manifest.assets['split-glb'] && manifest.assets['pbr-glb']);
  return {
    uploadId,
    complete,
    asset: {
      key: assetKey,
      fileName,
      bytes: body.byteLength,
      projectPath: plantPreviewProjectPath(toolRoot, filePath),
    },
    sample: complete ? await plantSampleManifest(uploadId) : null,
  };
}

function safeJsonFileName(input, fallback = 'plant_regroup_manifest') {
  const rawName = String(input || fallback).replace(/\.json$/i, '');
  const safeName = rawName
    .replace(/[^a-zA-Z0-9._-]+/g, '_')
    .replace(/^_+|_+$/g, '')
    .slice(0, 96);
  return `${safeName || fallback}.json`;
}

function safePathSegment(input, fallback = 'plant_asset') {
  const safeName = String(input || fallback)
    .replace(/\.[a-z0-9]+$/i, '')
    .replace(/[^a-zA-Z0-9._-]+/g, '_')
    .replace(/^_+|_+$/g, '')
    .slice(0, 92);
  return safeName || fallback;
}

function plantOutputWorkspace(payload) {
  const outputRoot = resolve(toolRoot, 'output', 'plant_regroup');
  const profile = safePathSegment(payload?.plant_profile || 'Plant');
  const sourceId = safePathSegment(
    payload?.source?.sample_id
      || payload?.source?.split_obj
      || payload?.file_name
      || 'local',
  );
  const workspaceName = safePathSegment(`${profile}_${sourceId}`);
  const workspaceDir = resolve(outputRoot, workspaceName);
  if (!workspaceDir.startsWith(outputRoot)) {
    throw new Error('Resolved plant output path escapes plant_regroup directory.');
  }
  return {
    outputRoot,
    workspaceName,
    workspaceDir,
    sourceDir: resolve(workspaceDir, '00_source'),
    manifestDir: resolve(workspaceDir, '01_manifest'),
    previewDir: resolve(workspaceDir, '02_preview'),
    partsDir: resolve(workspaceDir, '03_pbr_parts'),
    reportsDir: resolve(workspaceDir, '04_reports'),
    projectRoot: `Tools/IslandMeshGen/output/plant_regroup/${workspaceName}`,
  };
}

async function ensurePlantWorkspace(payload) {
  const workspace = plantOutputWorkspace(payload);
  await Promise.all([
    mkdir(workspace.sourceDir, { recursive: true }),
    mkdir(workspace.manifestDir, { recursive: true }),
    mkdir(workspace.previewDir, { recursive: true }),
    mkdir(workspace.partsDir, { recursive: true }),
    mkdir(workspace.reportsDir, { recursive: true }),
  ]);
  await writeFile(
    resolve(workspace.sourceDir, 'source_manifest.json'),
    JSON.stringify({
      schema: 'SkyIslandPotion.PlantSourceManifest.v1',
      written_at: new Date().toISOString(),
      plant_profile: payload?.plant_profile || null,
      source: payload?.source || {},
      mapping: payload?.mapping || {},
    }, null, 2) + '\n',
    'utf8',
  );
  return workspace;
}

async function savePlantRegroupManifest(payload) {
  const workspace = await ensurePlantWorkspace(payload);
  const fileName = 'regroup_manifest.json';
  const outputPath = resolve(workspace.manifestDir, fileName);
  const savedPayload = {
    ...payload,
    saved_at: new Date().toISOString(),
  };
  const body = JSON.stringify(savedPayload, null, 2) + '\n';
  await writeFile(outputPath, body, 'utf8');
  return {
    fileName,
    bytes: Buffer.byteLength(body),
    absolutePath: outputPath,
    projectPath: `${workspace.projectRoot}/01_manifest/${fileName}`,
    workspace: workspace.projectRoot,
  };
}

async function pathExists(filePath) {
  try {
    await stat(filePath);
    return true;
  } catch {
    return false;
  }
}

async function maybeReadJson(filePath) {
  try {
    return JSON.parse(await readFile(filePath, 'utf8'));
  } catch {
    return null;
  }
}

async function latestPlantExportPartsDir() {
  const candidates = [];
  for (const root of plantExportPreviewRoots(toolRoot)) {
    if (!existsSync(root)) continue;
    const entries = await readdir(root, { withFileTypes: true });
    for (const entry of entries) {
      if (!entry.isDirectory()) continue;
      const partsDir = resolve(root, entry.name, '03_pbr_parts');
      if (!(await pathExists(partsDir))) continue;
      const partsStat = await stat(partsDir);
      candidates.push({
        partsDir,
        mtimeMs: partsStat.mtimeMs,
        workspacePriority: plantExportWorkspacePriority(entry.name),
        completeGroups: await plantExportCompleteGroupCount(partsDir),
        textureCount: await plantExportTextureCount(partsDir),
        hasReport: await pathExists(resolve(root, entry.name, '04_reports', 'export_report.json')),
      });
    }
  }
  candidates.sort((a, b) => (
    b.completeGroups - a.completeGroups
    || b.textureCount - a.textureCount
    || Number(b.hasReport) - Number(a.hasReport)
    || b.workspacePriority - a.workspacePriority
    || b.mtimeMs - a.mtimeMs
  ));
  if (!candidates.length) {
    throw new Error('No exported plant PBR parts found under output/plant_regroup or mesh_inbox/_analysis_runs.');
  }
  return candidates[0].partsDir;
}

async function plantExportCompleteGroupCount(partsDir) {
  let complete = 0;
  for (const groupId of plantExportPreviewGroups()) {
    const groupDir = resolve(partsDir, groupId);
    const gltfPath = resolve(groupDir, `${groupId}.gltf`);
    const binPath = resolve(groupDir, `${groupId}.bin`);
    if ((await pathExists(gltfPath)) && (await pathExists(binPath))) complete += 1;
  }
  return complete;
}

async function plantExportTextureCount(partsDir) {
  const texturesDir = resolve(partsDir, 'textures');
  if (!(await pathExists(texturesDir))) return 0;
  return (await readdir(texturesDir, { withFileTypes: true }))
    .filter((entry) => entry.isFile())
    .length;
}

async function resolvePlantExportPartsDir(rawPath) {
  if (!rawPath) return latestPlantExportPartsDir();
  let targetPath = resolvePlantPreviewFilePath(toolRoot, rawPath);
  const targetStat = await stat(targetPath);
  if (targetStat.isFile()) targetPath = dirname(targetPath);
  if (basename(targetPath) !== '03_pbr_parts') {
    const nestedPartsDir = resolve(targetPath, '03_pbr_parts');
    if (await pathExists(nestedPartsDir)) targetPath = nestedPartsDir;
  }
  if (basename(targetPath) !== '03_pbr_parts') {
    throw new Error('Plant export preview path must point to a 03_pbr_parts folder or its workspace.');
  }
  return targetPath;
}

async function plantExportPreviewPayload(rawPath) {
  const partsDir = await resolvePlantExportPartsDir(rawPath);
  const workspaceDir = resolve(partsDir, '..');
  const reportPath = resolve(workspaceDir, '04_reports', 'export_report.json');
  const report = await maybeReadJson(reportPath);
  const reportExports = new Map((report?.exports || []).map((item) => [item.group, item]));
  const groups = [];
  for (const groupId of plantExportPreviewGroups()) {
    const groupDir = resolve(partsDir, groupId);
    const gltfPath = resolve(groupDir, `${groupId}.gltf`);
    const binPath = resolve(groupDir, `${groupId}.bin`);
    const gltfExists = await pathExists(gltfPath);
    const binExists = await pathExists(binPath);
    const reportItem = reportExports.get(groupId) || {};
    groups.push({
      id: groupId,
      folderPath: plantPreviewProjectPath(toolRoot, groupDir),
      gltfPath: plantPreviewProjectPath(toolRoot, gltfPath),
      binPath: plantPreviewProjectPath(toolRoot, binPath),
      gltfUrl: gltfExists ? plantPreviewFileUrl(toolRoot, gltfPath) : null,
      binUrl: binExists ? plantPreviewFileUrl(toolRoot, binPath) : null,
      hasGltf: gltfExists,
      hasBin: binExists,
      faces: Number(reportItem.faces || 0),
      vertices: Number(reportItem.vertices || 0),
    });
  }
  const texturesDir = resolve(partsDir, 'textures');
  const textureFiles = (await pathExists(texturesDir))
    ? (await readdir(texturesDir, { withFileTypes: true }))
      .filter((entry) => entry.isFile())
      .map((entry) => {
        const filePath = resolve(texturesDir, entry.name);
        return {
          fileName: entry.name,
          path: plantPreviewProjectPath(toolRoot, filePath),
          url: plantPreviewFileUrl(toolRoot, filePath),
        };
      })
    : [];
  return {
    workspaceName: basename(workspaceDir),
    workspacePath: plantPreviewProjectPath(toolRoot, workspaceDir),
    partsDir: plantPreviewProjectPath(toolRoot, partsDir),
    reportPath: (await pathExists(reportPath)) ? plantPreviewProjectPath(toolRoot, reportPath) : null,
    report,
    groups,
    textures: textureFiles,
  };
}

async function servePlantPreviewFile(requestUrl, response) {
  const rawPath = requestUrl.searchParams.get('path');
  const filePath = resolvePlantPreviewFilePath(toolRoot, rawPath);
  const body = await readFile(filePath);
  response.writeHead(200, {
    'Content-Type': contentTypeForPath(filePath),
    'Content-Length': body.byteLength,
    'Cache-Control': 'no-store',
  });
  response.end(body);
}

function projectionPythonCommand() {
  if (process.env.PYTHON) return { command: process.env.PYTHON, args: [], label: 'PYTHON' };
  if (existsSync(localPythonFallback)) return { command: localPythonFallback, args: [], label: 'local Python 3.12' };
  return resolvePythonCommand();
}

function runPlantProjectionDiagnostics(manifestPath, reportPath, sampleFiles) {
  return new Promise((resolvePromise, reject) => {
    const python = projectionPythonCommand();
    const splitPath = sampleFiles.files['split-glb'] || sampleFiles.files['split-obj'];
    const splitArg = sampleFiles.files['split-glb'] ? '--split-glb' : '--split-obj';
    const args = [
      ...python.args,
      resolve(toolRoot, 'plant_projection_diagnostics.py'),
      '--manifest',
      manifestPath,
      splitArg,
      splitPath,
      '--pbr-glb',
      sampleFiles.files['pbr-glb'],
      '--output',
      reportPath,
      '--sample-faces',
      '20000',
      '--split-sample-faces',
      '50000',
    ];
    const child = spawn(python.command, args, {
      cwd: toolRoot,
      shell: false,
    });
    let stdout = '';
    let stderr = '';
    child.stdout.on('data', (chunk) => {
      stdout += chunk.toString();
    });
    child.stderr.on('data', (chunk) => {
      stderr += chunk.toString();
    });
    child.on('error', reject);
    child.on('close', (code) => {
      if (code === 0) {
        resolvePromise({ stdout: stdout.trim(), stderr: stderr.trim(), python: python.label });
      } else {
        reject(new Error(stderr.trim() || `plant_projection_diagnostics.py exited with ${code}`));
      }
    });
  });
}

async function writePlantProjectionDiagnostics(payload) {
  if (payload?.source?.source_mode && payload.source.source_mode !== 'sample') {
    throw new Error('Projection diagnostics currently require server-visible sample assets. Local browser files need an upload/path bridge first.');
  }
  const sampleFiles = await plantSampleFilesForId(payload?.source?.sample_id);
  const workspace = await ensurePlantWorkspace(payload);
  const manifestPath = resolve(workspace.manifestDir, 'regroup_manifest.json');
  const reportPath = resolve(workspace.manifestDir, 'projection_report.json');
  await writeFile(manifestPath, JSON.stringify(payload, null, 2) + '\n', 'utf8');
  const result = await runPlantProjectionDiagnostics(manifestPath, reportPath, sampleFiles);
  const report = JSON.parse(await readFile(reportPath, 'utf8'));
  return {
    report,
    python: result.python,
    reportPath,
    projectPath: `${workspace.projectRoot}/01_manifest/projection_report.json`,
    workspace: workspace.projectRoot,
  };
}

function runPlantPbrPartExport(manifestPath, outputDir, reportPath, sampleFiles) {
  return new Promise((resolvePromise, reject) => {
    const python = projectionPythonCommand();
    const splitPath = sampleFiles.files['split-glb'] || sampleFiles.files['split-obj'];
    const splitArg = sampleFiles.files['split-glb'] ? '--split-glb' : '--split-obj';
    const args = [
      ...python.args,
      resolve(toolRoot, 'plant_export_pbr_parts.py'),
      '--manifest',
      manifestPath,
      splitArg,
      splitPath,
      '--pbr-glb',
      sampleFiles.files['pbr-glb'],
      '--output-dir',
      outputDir,
      '--report-output',
      reportPath,
    ];
    const child = spawn(python.command, args, {
      cwd: toolRoot,
      shell: false,
    });
    let stdout = '';
    let stderr = '';
    child.stdout.on('data', (chunk) => {
      stdout += chunk.toString();
    });
    child.stderr.on('data', (chunk) => {
      stderr += chunk.toString();
    });
    child.on('error', reject);
    child.on('close', (code) => {
      if (code === 0) {
        resolvePromise({ stdout: stdout.trim(), stderr: stderr.trim(), python: python.label });
      } else {
        reject(new Error(stderr.trim() || `plant_export_pbr_parts.py exited with ${code}`));
      }
    });
  });
}

async function writePlantPbrPartExport(payload) {
  if (payload?.source?.source_mode && payload.source.source_mode !== 'sample') {
    throw new Error('PBR part export currently requires server-visible sample assets. Local browser files need an upload/path bridge first.');
  }
  const sampleFiles = await plantSampleFilesForId(payload?.source?.sample_id);
  const workspace = await ensurePlantWorkspace(payload);
  const partOutputDir = workspace.partsDir;
  await rm(partOutputDir, { recursive: true, force: true });
  await mkdir(partOutputDir, { recursive: true });
  await mkdir(workspace.reportsDir, { recursive: true });
  const manifestPath = resolve(workspace.manifestDir, 'regroup_manifest.json');
  const reportPath = resolve(workspace.reportsDir, 'export_report.json');
  await writeFile(manifestPath, JSON.stringify(payload, null, 2) + '\n', 'utf8');
  const result = await runPlantPbrPartExport(manifestPath, partOutputDir, reportPath, sampleFiles);
  const report = JSON.parse(await readFile(reportPath, 'utf8'));
  return {
    report,
    python: result.python,
    outputDir: partOutputDir,
    projectPath: `${workspace.projectRoot}/03_pbr_parts`,
    reportPath: `${workspace.projectRoot}/04_reports/export_report.json`,
    workspace: workspace.projectRoot,
  };
}

async function packPlantPbrGlbs(rawPartsPath) {
  const startedAt = performance.now();
  const partsDir = await resolvePlantExportPartsDir(rawPartsPath);
  const workspaceDir = resolve(partsDir, '..');
  const outputDir = resolve(workspaceDir, '05_glb_parts');
  await mkdir(outputDir, { recursive: true });

  const exports = [];
  for (const groupId of plantExportPreviewGroups()) {
    const gltfPath = resolve(partsDir, groupId, `${groupId}.gltf`);
    if (!(await pathExists(gltfPath))) {
      throw new Error(`Missing exported glTF for ${groupId}: ${plantPreviewProjectPath(toolRoot, gltfPath)}`);
    }
    const outputPath = resolve(outputDir, `${groupId}.glb`);
    const packed = await packGltfToGlb({ gltfPath, outputPath });
    exports.push({
      group: groupId,
      fileName: packed.fileName,
      bytes: packed.bytes,
      path: plantPreviewProjectPath(toolRoot, outputPath),
      url: plantPreviewFileUrl(toolRoot, outputPath),
    });
  }

  const report = {
    schema: 'SkyIslandPotion.PlantGlbPartsPack.v1',
    written_at: new Date().toISOString(),
    source_parts_dir: plantPreviewProjectPath(toolRoot, partsDir),
    output_dir: plantPreviewProjectPath(toolRoot, outputDir),
    exports,
    elapsed_ms: Math.round(performance.now() - startedAt),
  };
  const reportPath = resolve(outputDir, 'pack_report.json');
  await writeFile(reportPath, JSON.stringify(report, null, 2) + '\n', 'utf8');

  return {
    workspaceName: basename(workspaceDir),
    workspacePath: plantPreviewProjectPath(toolRoot, workspaceDir),
    sourcePartsDir: plantPreviewProjectPath(toolRoot, partsDir),
    outputDir: report.output_dir,
    reportPath: plantPreviewProjectPath(toolRoot, reportPath),
    reportUrl: plantPreviewFileUrl(toolRoot, reportPath),
    exports,
    elapsed_ms: report.elapsed_ms,
  };
}

function meshyApiKey() {
  const key = process.env.MESHY_API_KEY || '';
  if (!key) throw new Error('MESHY_API_KEY is missing. Configure it on the server before sending to Meshy.');
  return key;
}

function meshyHeaders() {
  return {
    Authorization: `Bearer ${meshyApiKey()}`,
    'Content-Type': 'application/json',
  };
}

async function ensurePlantGlbParts(rawPartsPath) {
  const partsDir = await resolvePlantExportPartsDir(rawPartsPath);
  const workspaceDir = resolve(partsDir, '..');
  const glbDir = resolve(workspaceDir, '05_glb_parts');
  const missing = [];
  for (const groupId of plantExportPreviewGroups()) {
    if (!(await pathExists(resolve(glbDir, `${groupId}.glb`)))) missing.push(groupId);
  }
  if (missing.length) await packPlantPbrGlbs(plantPreviewProjectPath(toolRoot, partsDir));
  return { partsDir, workspaceDir, glbDir };
}

function roundtripRunName(groupId, operation) {
  const stamp = new Date().toISOString()
    .replace(/[-:]/g, '')
    .replace(/\.\d+Z$/, '')
    .replace('T', '_');
  return `${stamp}_${groupId}_${operation}`;
}

async function startPlantMeshyRoundtrip(payload) {
  const operation = normalizeRoundtripOperation(payload?.operation);
  const groupId = String(payload?.group || 'Core');
  if (!plantExportPreviewGroups().includes(groupId)) {
    throw new Error(`Unsupported plant group "${groupId}".`);
  }
  const prompt = String(payload?.prompt || '').trim();
  if (!prompt) throw new Error('Meshy prompt is empty.');
  if (!payload?.partsDir) {
    throw new Error('Meshy roundtrip requires a loaded PBR export partsDir. Export or load the matching PBR Parts Preview first.');
  }
  if (operation === 'retexture' && prompt.length > MESHY_TEXT_STYLE_PROMPT_MAX_LENGTH) {
    throw new Error(`Meshy retexture prompt is ${prompt.length} characters; maximum is ${MESHY_TEXT_STYLE_PROMPT_MAX_LENGTH}.`);
  }
  const { workspaceDir, glbDir } = await ensurePlantGlbParts(payload.partsDir);
  const sourceGlbPath = resolve(glbDir, `${groupId}.glb`);
  if (!(await pathExists(sourceGlbPath))) {
    throw new Error(`Packed GLB is missing for ${groupId}.`);
  }

  const sourceBytes = await readFile(sourceGlbPath);
  const sourceSha256 = createHash('sha256').update(sourceBytes).digest('hex');
  const modelDataUri = `data:model/gltf-binary;base64,${sourceBytes.toString('base64')}`;
  const createRequest = buildMeshyRoundtripCreateRequest({
    operation,
    modelDataUri,
    prompt,
    options: payload?.options || {},
  });

  const runDir = resolve(workspaceDir, '06_meshy_roundtrip', roundtripRunName(groupId, operation));
  await mkdir(runDir, { recursive: true });
  await copyFile(sourceGlbPath, resolve(runDir, 'source.glb'));
  await writeFile(resolve(runDir, 'prompt.txt'), `${prompt}\n`, 'utf8');
  await writeFile(
    resolve(runDir, 'request.sanitized.json'),
    JSON.stringify(sanitizeMeshyRoundtripRequest(createRequest, sourceBytes.byteLength, sourceSha256), null, 2) + '\n',
    'utf8',
  );

  const response = await fetch(`${MESHY_BASE_URL}${createRequest.endpointPath}`, {
    method: 'POST',
    headers: meshyHeaders(),
    body: JSON.stringify(createRequest.payload),
  });
  const responseText = await response.text();
  let createResponse = {};
  try {
    createResponse = responseText ? JSON.parse(responseText) : {};
  } catch {
    createResponse = { raw: responseText };
  }
  if (!response.ok) {
    await writeFile(resolve(runDir, 'create_error.json'), JSON.stringify({
      status: response.status,
      body: createResponse,
    }, null, 2) + '\n', 'utf8');
    const detail = createResponse?.message || createResponse?.error || createResponse?.raw || '';
    throw new Error(`Meshy ${operation} request failed with ${response.status}${detail ? `: ${detail}` : ''}.`);
  }
  await writeFile(resolve(runDir, 'create_response.json'), JSON.stringify(createResponse, null, 2) + '\n', 'utf8');

  const taskId = createResponse.result || createResponse.id;
  if (!taskId) throw new Error('Meshy response did not include a task id.');

  const state = {
    schema: 'SkyIslandPotion.PlantMeshyRoundtrip.v1',
    created_at: new Date().toISOString(),
    workspace: plantPreviewProjectPath(toolRoot, workspaceDir),
    runDir: plantPreviewProjectPath(toolRoot, runDir),
    group: groupId,
    operation,
    endpointPath: createRequest.endpointPath,
    taskId,
    status: 'SUBMITTED',
    progress: 0,
    source: {
      path: plantPreviewProjectPath(toolRoot, sourceGlbPath),
      bytes: sourceBytes.byteLength,
      sha256: sourceSha256,
    },
  };
  await writeFile(resolve(runDir, 'state.json'), JSON.stringify(state, null, 2) + '\n', 'utf8');
  return state;
}

async function pollPlantMeshyRoundtrip(rawRunPath) {
  const runDir = resolvePlantPreviewFilePath(toolRoot, rawRunPath);
  const statePath = resolve(runDir, 'state.json');
  const state = JSON.parse(await readFile(statePath, 'utf8'));
  const response = await fetch(`${MESHY_BASE_URL}${state.endpointPath}/${state.taskId}`, {
    headers: meshyHeaders(),
  });
  const responseText = await response.text();
  let task = {};
  try {
    task = responseText ? JSON.parse(responseText) : {};
  } catch {
    task = { raw: responseText };
  }
  if (!response.ok) {
    throw new Error(`Meshy task poll failed with ${response.status}.`);
  }

  const sanitizedTask = sanitizeMeshyRoundtripTask(task);
  await writeFile(resolve(runDir, 'task.latest.sanitized.json'), JSON.stringify(sanitizedTask, null, 2) + '\n', 'utf8');
  const nextState = {
    ...state,
    status: sanitizedTask.status || state.status,
    progress: sanitizedTask.progress ?? state.progress,
    task_error: sanitizedTask.task_error || null,
    consumed_credits: sanitizedTask.consumed_credits,
    updated_at: new Date().toISOString(),
  };

  if (nextState.status === 'SUCCEEDED') {
    const resultPath = resolve(runDir, 'result.glb');
    if (!(await pathExists(resultPath))) {
      const resultUrl = meshyResultGlbUrl(task);
      if (!resultUrl) throw new Error('Meshy task succeeded but did not return a GLB URL.');
      const resultResponse = await fetch(resultUrl);
      if (!resultResponse.ok) throw new Error(`Could not download Meshy result GLB (${resultResponse.status}).`);
      const resultBuffer = Buffer.from(await resultResponse.arrayBuffer());
      await writeFile(resultPath, resultBuffer);
      nextState.result = {
        path: plantPreviewProjectPath(toolRoot, resultPath),
        url: plantPreviewFileUrl(toolRoot, resultPath),
        bytes: resultBuffer.byteLength,
      };
    } else if (!nextState.result) {
      const resultStat = await stat(resultPath);
      nextState.result = {
        path: plantPreviewProjectPath(toolRoot, resultPath),
        url: plantPreviewFileUrl(toolRoot, resultPath),
        bytes: resultStat.size,
      };
    }
  }

  await writeFile(statePath, JSON.stringify(nextState, null, 2) + '\n', 'utf8');
  return { ...nextState, task: sanitizedTask };
}

async function listPlantMeshyRoundtrips(rawPartsPath) {
  const partsDir = rawPartsPath ? await resolvePlantExportPartsDir(rawPartsPath) : await latestPlantExportPartsDir();
  const workspaceDir = resolve(partsDir, '..');
  const roundtripDir = resolve(workspaceDir, '06_meshy_roundtrip');
  if (!(await pathExists(roundtripDir))) {
    return {
      workspaceName: basename(workspaceDir),
      roundtripDir: plantPreviewProjectPath(toolRoot, roundtripDir),
      runs: [],
    };
  }
  const entries = await readdir(roundtripDir, { withFileTypes: true });
  const runs = [];
  for (const entry of entries) {
    if (!entry.isDirectory()) continue;
    const state = await maybeReadJson(resolve(roundtripDir, entry.name, 'state.json'));
    if (!state) continue;
    const runStat = await stat(resolve(roundtripDir, entry.name));
    runs.push({
      ...state,
      mtimeMs: runStat.mtimeMs,
    });
  }
  runs.sort((a, b) => b.mtimeMs - a.mtimeMs);
  return {
    workspaceName: basename(workspaceDir),
    roundtripDir: plantPreviewProjectPath(toolRoot, roundtripDir),
    runs,
  };
}

async function readLayout(biome) {
  const { layoutPath } = pathsForBiome(toolRoot, biome);
  const text = await readFile(layoutPath, 'utf8');
  return JSON.parse(text);
}

function readRequestBody(request) {
  return new Promise((resolvePromise, reject) => {
    let body = '';
    request.on('data', (chunk) => {
      body += chunk.toString();
      if (body.length > 1024 * 1024) {
        request.destroy();
        reject(new Error('Request body too large'));
      }
    });
    request.on('end', () => resolvePromise(body));
    request.on('error', reject);
  });
}

function readRequestBuffer(request, maxBytes) {
  return new Promise((resolvePromise, reject) => {
    const chunks = [];
    let total = 0;
    request.on('data', (chunk) => {
      total += chunk.byteLength;
      if (total > maxBytes) {
        request.destroy();
        reject(new Error('Upload body too large'));
        return;
      }
      chunks.push(chunk);
    });
    request.on('end', () => resolvePromise(Buffer.concat(chunks, total)));
    request.on('error', reject);
  });
}

function parseObj(text) {
  const vertices = [];
  const faces = [];
  let material = 'M_TopGrass';
  let order = 0;
  for (const line of String(text).split(/\r?\n/)) {
    const parts = line.trim().split(/\s+/);
    if (parts[0] === 'usemtl') material = parts[1] || material;
    if (parts[0] === 'v') vertices.push(parts.slice(1, 4).map(Number));
    if (parts[0] === 'f') {
      faces.push({
        material,
        order: order++,
        indices: parts.slice(1).map((part) => Number(part.split('/')[0]) - 1),
      });
    }
  }
  return { vertices, faces };
}

async function writeQualityReport(reportPath, {
  meshText,
  field,
  biome,
  quality,
  topology,
  meshPath,
  layoutPath,
  fieldPath,
}) {
  const report = qualityReportForMesh(parseObj(meshText), field, {
    biome,
    quality,
    topology,
    meshPath,
    layoutPath,
    fieldPath,
    generatedAt: new Date().toISOString(),
  });
  await writeFile(reportPath, JSON.stringify(report, null, 2) + '\n', 'utf8');
  return report;
}

function runExportLayout(layoutPath, outputPath, manifestPath, exportOptions = {}) {
  return new Promise((resolvePromise, reject) => {
    const python = resolvePythonCommand();
    const args = [
      ...python.args,
      join(toolRoot, 'export_layout.py'),
      '--layout',
      layoutPath,
      '--output',
      outputPath,
    ];
    if (manifestPath) args.push('--manifest', manifestPath);
    if (exportOptions.fieldJsonPath) args.push('--field-json', String(exportOptions.fieldJsonPath));
    if (exportOptions.segments) args.push('--segments', String(exportOptions.segments));
    if (exportOptions.rings) args.push('--rings', String(exportOptions.rings));
    if (exportOptions.quality) args.push('--quality', String(exportOptions.quality));
    const child = spawn(python.command, [
      ...args,
    ], {
      cwd: resolve(toolRoot, '..', '..'),
      shell: false,
    });
    let stdout = '';
    let stderr = '';
    child.stdout.on('data', (chunk) => {
      stdout += chunk.toString();
    });
    child.stderr.on('data', (chunk) => {
      stderr += chunk.toString();
    });
    child.on('error', reject);
    child.on('close', (code) => {
      if (code === 0) {
        resolvePromise({ stdout: stdout.trim(), stderr: stderr.trim(), python: python.label });
      } else {
        reject(new Error(stderr.trim() || `export_layout.py exited with ${code}`));
      }
    });
  });
}

async function clearPreviewArtifacts(biome) {
  const preview = previewPathsForBiome(toolRoot, biome);
  await Promise.allSettled([
    rm(preview.layoutPath, { force: true }),
    rm(preview.meshPath, { force: true }),
    rm(preview.manifestPath, { force: true }),
    rm(preview.fieldPath, { force: true }),
    rm(preview.qualityReportPath, { force: true }),
  ]);
}

async function serveStatic(request, response) {
  const url = new URL(request.url, `http://${request.headers.host}`);
  const pathname = url.pathname === '/' ? '/index.html' : url.pathname;
  const filePath = resolve(staticRoot, `.${pathname}`);
  if (!filePath.startsWith(staticRoot)) {
    response.writeHead(403);
    response.end('Forbidden');
    return;
  }

  try {
    const body = await readFile(filePath);
    response.writeHead(200, staticHeadersForPath(filePath));
    response.end(body);
  } catch {
    response.writeHead(404);
    response.end('Not found');
  }
}

const server = createServer(async (request, response) => {
  try {
    const requestUrl = new URL(request.url, `http://${request.headers.host}`);
    const requestPath = requestUrl.pathname;

    if (request.method === 'GET' && requestPath === '/api/plant/sample') {
      sendJson(response, 200, await plantSampleManifest(requestUrl.searchParams.get('id')));
      return;
    }

    if (request.method === 'GET' && requestPath === '/api/plant/export-preview') {
      const preview = await plantExportPreviewPayload(requestUrl.searchParams.get('path'));
      sendJson(response, 200, { ok: true, ...preview });
      return;
    }

    if (request.method === 'GET' && requestPath === '/api/plant/export-preview/file') {
      await servePlantPreviewFile(requestUrl, response);
      return;
    }

    if (request.method === 'POST' && requestPath === '/api/plant/local-upload') {
      const uploaded = await saveLocalPlantUpload(request, requestUrl);
      sendJson(response, 200, { ok: true, ...uploaded });
      return;
    }

    if (request.method === 'POST' && requestPath === '/api/plant/pack-pbr-glbs') {
      const body = await readRequestBody(request);
      const payload = body.trim() ? JSON.parse(body) : {};
      const packed = await packPlantPbrGlbs(payload.partsDir || payload.path || null);
      sendJson(response, 200, { ok: true, ...packed });
      return;
    }

    if (request.method === 'GET' && requestPath === '/api/plant/meshy-status') {
      sendJson(response, 200, {
        ok: true,
        configured: Boolean(process.env.MESHY_API_KEY),
        baseUrl: MESHY_BASE_URL,
      });
      return;
    }

    if (request.method === 'GET' && requestPath === '/api/plant/meshy-roundtrip/list') {
      const listing = await listPlantMeshyRoundtrips(requestUrl.searchParams.get('path'));
      sendJson(response, 200, { ok: true, ...listing });
      return;
    }

    if (request.method === 'POST' && requestPath === '/api/plant/meshy-roundtrip/start') {
      const body = await readRequestBody(request);
      const payload = body.trim() ? JSON.parse(body) : {};
      const run = await startPlantMeshyRoundtrip(payload);
      sendJson(response, 200, { ok: true, run });
      return;
    }

    if (request.method === 'POST' && requestPath === '/api/plant/meshy-roundtrip/poll') {
      const body = await readRequestBody(request);
      const payload = body.trim() ? JSON.parse(body) : {};
      if (!payload.runDir) {
        sendJson(response, 400, { ok: false, error: 'runDir is required.' });
        return;
      }
      const run = await pollPlantMeshyRoundtrip(payload.runDir);
      sendJson(response, 200, { ok: true, run });
      return;
    }

    if (request.method === 'POST' && requestPath === '/api/plant/save-regroup-manifest') {
      const body = await readRequestBody(request);
      const manifest = body.trim() ? JSON.parse(body) : {};
      if (manifest.schema !== 'SkyIslandPotion.PlantRegroupManifest.v1') {
        sendJson(response, 400, { ok: false, error: 'Expected SkyIslandPotion.PlantRegroupManifest.v1 manifest.' });
        return;
      }
      const saved = await savePlantRegroupManifest(manifest);
      sendJson(response, 200, { ok: true, saved });
      return;
    }

    if (request.method === 'POST' && requestPath === '/api/plant/projection-diagnostics') {
      const body = await readRequestBody(request);
      const manifest = body.trim() ? JSON.parse(body) : {};
      if (manifest.schema !== 'SkyIslandPotion.PlantRegroupManifest.v1') {
        sendJson(response, 400, { ok: false, error: 'Expected SkyIslandPotion.PlantRegroupManifest.v1 manifest.' });
        return;
      }
      const diagnostics = await writePlantProjectionDiagnostics(manifest);
      sendJson(response, 200, { ok: true, ...diagnostics });
      return;
    }

    if (request.method === 'POST' && requestPath === '/api/plant/export-pbr-parts') {
      const body = await readRequestBody(request);
      const manifest = body.trim() ? JSON.parse(body) : {};
      if (manifest.schema !== 'SkyIslandPotion.PlantRegroupManifest.v1') {
        sendJson(response, 400, { ok: false, error: 'Expected SkyIslandPotion.PlantRegroupManifest.v1 manifest.' });
        return;
      }
      const exported = await writePlantPbrPartExport(manifest);
      sendJson(response, 200, { ok: true, ...exported });
      return;
    }

    const plantAssetMatch = requestPath.match(/^\/api\/plant\/sample-assets\/([a-z0-9-]+)$/);
    if (request.method === 'GET' && plantAssetMatch) {
      const assetKey = plantAssetMatch[1];
      const sampleFiles = await plantSampleFilesForId(requestUrl.searchParams.get('id'));
      const filePath = sampleFiles.files[assetKey];
      if (!filePath) {
        sendJson(response, 404, { ok: false, error: `Unknown plant sample asset "${assetKey}".` });
        return;
      }
      const body = await readFile(filePath);
      response.writeHead(200, plantAssetHeaders(assetKey, body.byteLength));
      response.end(body);
      return;
    }

    if (request.method === 'GET' && requestPath === '/api/biomes') {
      sendJson(response, 200, SUPPORTED_BIOMES.map((biome) => ({ biome, label: BIOME_META[biome].label })));
      return;
    }

    if (request.method === 'GET' && requestPath === '/api/bake-profiles') {
      sendJson(response, 200, bakeQualityOptions());
      return;
    }

    const layoutMatch = requestPath.match(/^\/api\/layout\/([^/]+)$/);
    if (request.method === 'GET' && layoutMatch) {
      sendJson(response, 200, await readLayout(normalizeBiome(layoutMatch[1])));
      return;
    }

    const meshMatch = requestPath.match(/^\/api\/mesh\/([^/]+)$/);
    if (request.method === 'GET' && meshMatch) {
      const { meshPath } = pathsForBiome(toolRoot, meshMatch[1]);
      const text = await readFile(meshPath, 'utf8');
      response.writeHead(200, { 'Content-Type': 'text/plain; charset=utf-8' });
      response.end(text);
      return;
    }

    const manifestMatch = requestPath.match(/^\/api\/manifest\/([^/]+)$/);
    if (request.method === 'GET' && manifestMatch) {
      const { manifestPath } = pathsForBiome(toolRoot, manifestMatch[1]);
      const text = await readFile(manifestPath, 'utf8');
      response.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
      response.end(text);
      return;
    }

    const qualityReportMatch = requestPath.match(/^\/api\/quality-report\/([^/]+)$/);
    if (request.method === 'GET' && qualityReportMatch) {
      const { qualityReportPath } = pathsForBiome(toolRoot, qualityReportMatch[1]);
      const text = await readFile(qualityReportPath, 'utf8');
      response.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
      response.end(text);
      return;
    }

    const generateMatch = requestPath.match(/^\/api\/generate\/([^/]+)$/);
    if (request.method === 'POST' && generateMatch) {
      const biome = normalizeBiome(generateMatch[1]);
      const body = await readRequestBody(request);
      const layout = body.trim() ? JSON.parse(body) : await readLayout(biome);
      if (layout.biome !== biome) {
        sendJson(response, 400, { ok: false, error: `Posted layout biome "${layout.biome}" does not match route biome "${biome}".` });
        return;
      }
      const { layoutPath, meshPath, manifestPath, fieldPath, qualityReportPath, meta } = pathsForBiome(toolRoot, biome);
      await writeFile(layoutPath, JSON.stringify(layout, null, 2) + '\n', 'utf8');
      const exportOptions = exportArgsForQuality(requestUrl.searchParams.get('quality'));
      const result = await runExportLayout(layoutPath, meshPath, manifestPath, {
        ...exportOptions,
        fieldJsonPath: fieldPath,
      });
      const meshText = await readFile(meshPath, 'utf8');
      const field = JSON.parse(await readFile(fieldPath, 'utf8'));
      const qualityReport = await writeQualityReport(qualityReportPath, {
        meshText,
        field,
        biome,
        quality: exportOptions.quality,
        topology: {
          segments: exportOptions.segments,
          rings: exportOptions.rings,
        },
        meshPath: `Tools/IslandMeshGen/output/${meta.meshFile}`,
        layoutPath: `Tools/IslandMeshGen/layouts/${meta.layoutFile}`,
        fieldPath: `Tools/IslandMeshGen/output/${meta.fieldFile}`,
      });
      await clearPreviewArtifacts(biome);
      sendJson(response, 200, {
        ok: true,
        stdout: result.stdout,
        python: result.python,
        quality: exportOptions.quality,
        topology: {
          segments: exportOptions.segments,
          rings: exportOptions.rings,
        },
        output: `Tools/IslandMeshGen/output/${meta.meshFile}`,
        manifest: `Tools/IslandMeshGen/output/${meta.manifestFile}`,
        field: `Tools/IslandMeshGen/output/${meta.fieldFile}`,
        qualityReport: `Tools/IslandMeshGen/output/${meta.qualityReportFile}`,
        fieldData: field,
        qualityReportData: qualityReport,
        qualitySummary: qualityReport.summary,
        layout: `Tools/IslandMeshGen/layouts/${meta.layoutFile}`,
      });
      return;
    }

    const inspectMatch = requestPath.match(/^\/api\/inspect\/([^/]+)$/);
    if (request.method === 'POST' && inspectMatch) {
      const biome = normalizeBiome(inspectMatch[1]);
      const body = await readRequestBody(request);
      const layout = body.trim() ? JSON.parse(body) : await readLayout(biome);
      if (layout.biome !== biome) {
        sendJson(response, 400, { ok: false, error: `Posted layout biome "${layout.biome}" does not match route biome "${biome}".` });
        return;
      }
      const inspect = inspectPathsForBiome(toolRoot, biome);
      await mkdir(inspect.inspectDir, { recursive: true });
      await writeFile(inspect.layoutPath, JSON.stringify(layout, null, 2) + '\n', 'utf8');
      const startedAt = performance.now();
      const exportOptions = exportArgsForQuality(requestUrl.searchParams.get('quality'));
      const result = await runExportLayout(inspect.layoutPath, inspect.meshPath, inspect.manifestPath, {
        ...exportOptions,
        fieldJsonPath: inspect.fieldPath,
      });
      const mesh = await readFile(inspect.meshPath, 'utf8');
      const field = JSON.parse(await readFile(inspect.fieldPath, 'utf8'));
      const qualityReport = await writeQualityReport(inspect.qualityReportPath, {
        meshText: mesh,
        field,
        biome,
        quality: exportOptions.quality,
        topology: {
          segments: exportOptions.segments,
          rings: exportOptions.rings,
        },
        meshPath: `Tools/IslandMeshGen/output/.inspect/${biome}_inspect.obj`,
        layoutPath: `Tools/IslandMeshGen/output/.inspect/${biome}_inspect_layout.json`,
        fieldPath: `Tools/IslandMeshGen/output/.inspect/${biome}_inspect.field.json`,
      });
      sendJson(response, 200, {
        ok: true,
        inspect: true,
        stdout: result.stdout,
        python: result.python,
        quality: exportOptions.quality,
        topology: {
          segments: exportOptions.segments,
          rings: exportOptions.rings,
        },
        elapsed_ms: Math.round(performance.now() - startedAt),
        output: `Tools/IslandMeshGen/output/.inspect/${biome}_inspect.obj`,
        qualityReportPath: `Tools/IslandMeshGen/output/.inspect/${biome}_inspect.quality_report.json`,
        qualityReport,
        field,
        mesh,
      });
      return;
    }

    const previewMatch = requestPath.match(/^\/api\/preview\/([^/]+)$/);
    if (request.method === 'POST' && previewMatch) {
      const biome = normalizeBiome(previewMatch[1]);
      const body = await readRequestBody(request);
      const layout = body.trim() ? JSON.parse(body) : await readLayout(biome);
      if (layout.biome !== biome) {
        sendJson(response, 400, { ok: false, error: `Posted layout biome "${layout.biome}" does not match route biome "${biome}".` });
        return;
      }
      const preview = previewPathsForBiome(toolRoot, biome);
      await mkdir(preview.previewDir, { recursive: true });
      await writeFile(preview.layoutPath, JSON.stringify(layout, null, 2) + '\n', 'utf8');
      const startedAt = performance.now();
      const exportOptions = previewExportArgs(requestUrl.searchParams.get('quality') || 'draft');
      const result = await runExportLayout(preview.layoutPath, preview.meshPath, preview.manifestPath, {
        ...exportOptions,
        fieldJsonPath: preview.fieldPath,
      });
      const mesh = await readFile(preview.meshPath, 'utf8');
      const field = JSON.parse(await readFile(preview.fieldPath, 'utf8'));
      const qualityReport = await writeQualityReport(preview.qualityReportPath, {
        meshText: mesh,
        field,
        biome,
        quality: exportOptions.quality,
        topology: {
          segments: exportOptions.segments,
          rings: exportOptions.rings,
        },
        meshPath: `Tools/IslandMeshGen/output/.preview/${biome}_preview.obj`,
        layoutPath: `Tools/IslandMeshGen/output/.preview/${biome}_preview_layout.json`,
        fieldPath: `Tools/IslandMeshGen/output/.preview/${biome}_preview.field.json`,
      });
      sendJson(response, 200, {
        ok: true,
        preview: true,
        stdout: result.stdout,
        python: result.python,
        quality: exportOptions.quality,
        topology: {
          segments: exportOptions.segments,
          rings: exportOptions.rings,
        },
        elapsed_ms: Math.round(performance.now() - startedAt),
        output: `Tools/IslandMeshGen/output/.preview/${biome}_preview.obj`,
        qualityReportPath: `Tools/IslandMeshGen/output/.preview/${biome}_preview.quality_report.json`,
        qualityReport,
        field,
        mesh,
      });
      return;
    }

    await serveStatic(request, response);
  } catch (error) {
    sendJson(response, 500, { ok: false, error: error.message });
  }
});

server.listen(port, '127.0.0.1', () => {
  console.log(`IslandMeshGen web demo running at http://127.0.0.1:${port}`);
});
