import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, mkdir, readFile, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { tmpdir } from 'node:os';

import { packGltfToGlb } from './plant_glb_pack.mjs';

test('packGltfToGlb embeds external bin and texture into one GLB', async () => {
  const root = await mkdtemp(join(tmpdir(), 'plant-glb-pack-'));
  const partDir = join(root, 'Core');
  const textureDir = join(root, 'textures');
  await mkdir(partDir);
  await mkdir(textureDir);

  const bin = Buffer.alloc(36);
  new Float32Array(bin.buffer, bin.byteOffset, 9).set([
    0, 0, 0,
    1, 0, 0,
    0, 1, 0,
  ]);
  await writeFile(join(partDir, 'Core.bin'), bin);
  await writeFile(join(textureDir, 'texture_0.jpg'), Buffer.from([0xff, 0xd8, 0xff, 0xd9]));
  await writeFile(join(partDir, 'Core.gltf'), JSON.stringify({
    asset: { version: '2.0' },
    scene: 0,
    scenes: [{ nodes: [0] }],
    nodes: [{ mesh: 0 }],
    meshes: [{
      primitives: [{
        attributes: { POSITION: 0 },
        mode: 4,
        material: 0,
      }],
    }],
    buffers: [{ uri: 'Core.bin', byteLength: bin.byteLength }],
    bufferViews: [{ buffer: 0, byteOffset: 0, byteLength: bin.byteLength }],
    accessors: [{
      bufferView: 0,
      componentType: 5126,
      count: 3,
      type: 'VEC3',
      min: [0, 0, 0],
      max: [1, 1, 0],
    }],
    materials: [{
      pbrMetallicRoughness: {
        baseColorTexture: { index: 0 },
      },
    }],
    textures: [{ source: 0 }],
    images: [{ uri: '../textures/texture_0.jpg', mimeType: 'image/jpeg' }],
  }, null, 2));

  const outputPath = join(root, 'Core.glb');
  const result = await packGltfToGlb({
    gltfPath: join(partDir, 'Core.gltf'),
    outputPath,
  });
  const glb = await readFile(outputPath);
  const jsonLength = glb.readUInt32LE(12);
  const json = JSON.parse(glb.subarray(20, 20 + jsonLength).toString('utf8').trim());

  assert.equal(result.fileName, 'Core.glb');
  assert.equal(glb.readUInt32LE(0), 0x46546c67);
  assert.equal(json.buffers.length, 1);
  assert.equal(json.buffers[0].uri, undefined);
  assert.equal(json.images[0].uri, undefined);
  assert.equal(typeof json.images[0].bufferView, 'number');
  assert.equal(json.images[0].mimeType, 'image/jpeg');
  assert.ok(result.bytes > bin.byteLength);
});
