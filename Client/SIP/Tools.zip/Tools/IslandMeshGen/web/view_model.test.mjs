import test from 'node:test';
import assert from 'node:assert/strict';

import {
  clampOrbitCamera,
  controlGroupTabs,
  controlsForActiveGroup,
  dragOrbitCamera,
  materialColorForBiome,
  faceHitAtPoint,
  fieldFaceSampleForOrder,
  maskColorForValue,
  meshDeltaColorForFace,
  meshDeltaForFace,
  processHighlightSpecForControl,
  processLayerStack,
  processMovementHighlightForFace,
  processMovementHighlightStyle,
  processTraceColorForFace,
  processTraceForFace,
  processTracePulseAlpha,
  processMaskCoverageMetrics,
  qualityMetricsForMesh,
  qualityAdvisorForFace,
  qualityNudgePlanForIssue,
  qualityNudgePlanSummaryForIssue,
  qualityNudgeResultForIssue,
  qualityReportForMesh,
  qualityRiskColorForFace,
  qualityRiskForFace,
  maskValueForFaceOrder,
  maskViewOptions,
  meshWireAlphaForFaceCount,
  bakeButtonLabel,
  biomeControlLabels,
  biomeControlRanges,
  biomeMovementHighlightForFace,
  biomeMovementHighlightThreshold,
  biomeMovementInfluenceForVertex,
  biomeLiveOverlaySpec,
  fireLiveOverlaySpec,
  forestLiveOverlaySpec,
  fireMovementHighlightForFace,
  fireMovementHighlightThreshold,
  fireMovementInfluenceForVertex,
  footprintRadiusForMesh,
  iceLiveOverlaySpec,
  layoutPointToTopDown,
  meshAtTransitionFrame,
  meshForPreviewRender,
  morphMeshes,
  inspectBakeSignature,
  previewBakeSignature,
  previewQualityStatusForBakeQuality,
  previewQualityForBakeQuality,
  semanticBadgesForLayout,
  semanticLegendForLayout,
  projectTopDownVertex,
  stableTopDownFrameForMesh,
  volcanoControlRanges,
  yawLabel,
  topDownFrameForMesh,
  volcanoControlLabels,
  wheelOrbitCamera,
} from './view_model.mjs';

test('fire controls can be split into compact group tabs in authoring order', () => {
  const controls = [
    { id: 'detailEnergy', group: 'Process' },
    { id: 'mainPathWidth', group: 'Routes' },
    { id: 'volcanoDominance', group: 'Form' },
    { id: 'lavaCount', group: 'Hazards' },
    { id: 'erosionAge', group: 'Process' },
  ];

  const tabs = controlGroupTabs(controls);

  assert.deepEqual(tabs.map((tab) => tab.id), ['Form', 'Routes', 'Hazards', 'Process']);
  assert.deepEqual(tabs.map((tab) => tab.count), [1, 1, 1, 2]);
});

test('active control group falls back to a visible compact page', () => {
  const controls = [
    { id: 'volcanoDominance', group: 'Form' },
    { id: 'volcanoRadius', group: 'Form' },
    { id: 'detailEnergy', group: 'Process' },
    { id: 'erosionAge', group: 'Process' },
    { id: 'depositionWeight', group: 'Process' },
  ];

  const processPage = controlsForActiveGroup(controls, 'Process');
  const fallbackPage = controlsForActiveGroup(controls, 'Missing');

  assert.equal(processPage.activeGroup, 'Process');
  assert.deepEqual(processPage.controls.map((control) => control.id), ['detailEnergy', 'erosionAge', 'depositionWeight']);
  assert.equal(fallbackPage.activeGroup, 'Form');
  assert.deepEqual(fallbackPage.controls.map((control) => control.id), ['volcanoDominance', 'volcanoRadius']);
});

test('volcano controls expose artist-facing names instead of raw JSON field paths', () => {
  const labels = volcanoControlLabels();
  const ranges = volcanoControlRanges();

  assert.equal(labels.volcanoDominance.title, 'Volcano height');
  assert.equal(labels.volcanoDominance.metric, 'rim lift');
  assert.equal(labels.volcanoRadius.title, 'Crater footprint');
  assert.ok(!labels.volcanoDominance.title.includes('central_volcano'));
  assert.equal(ranges.mainPathWidth.max, 0.55);
});

test('process detail controls expose Houdini-lite artist language', () => {
  const labels = volcanoControlLabels();
  const ranges = volcanoControlRanges();

  assert.equal(labels.detailEnergy.title, 'Detail energy');
  assert.equal(labels.erosionAge.metric, 'weathering');
  assert.equal(labels.depositionWeight.title, 'Deposition weight');
  assert.equal(ranges.detailEnergy.max, 1.4);
  assert.equal(ranges.erosionAge.step, 0.01);
  assert.equal(ranges.depositionWeight.min, 0);
});

test('biome controls expose forest and ice artist-facing terrain knobs', () => {
  const forestLabels = biomeControlLabels('forest');
  const forestRanges = biomeControlRanges('forest');
  const iceLabels = biomeControlLabels('ice');
  const iceRanges = biomeControlRanges('ice');

  assert.equal(forestLabels.mushroomPocketOuter.title, 'Mushroom pocket');
  assert.equal(forestLabels.vineBridgeWidth.metric, 'route width');
  assert.equal(forestRanges.vineBridgeWidth.max, 0.18);
  assert.equal(iceLabels.crystalWallRadius.title, 'Crystal wall ring');
  assert.equal(iceLabels.resourceClusterCount.metric, 'landmark count');
  assert.equal(iceRanges.resourceClusterCount.step, 1);
});

test('semantic legend explains what each overlay color means in the current layout', () => {
  const legend = semanticLegendForLayout({
    zones: [
      { kind: 'arena' },
      { kind: 'hazard' },
      { kind: 'pcg' },
    ],
    paths: [{ kind: 'main_path' }],
    landmarks: [{ kind: 'volcano', bake_mode: 'terrain' }],
  });

  assert.deepEqual(
    legend.map((entry) => entry.label),
    ['Walkable arena', 'Hazard mask', 'PCG scatter area', 'Route', 'Terrain landmark'],
  );
  assert.equal(legend.find((entry) => entry.id === 'hazard')?.description, 'blocks traversal and exports as a hazard zone');
});

test('semantic map badges stay compact so the 2D viewport does not become a label explosion', () => {
  const badges = semanticBadgesForLayout({
    biome: 'fire',
    zones: [
      { id: 'crater_arena', kind: 'arena', walkable: true },
      { id: 'lava_hazard', kind: 'hazard', walkable: false },
      { id: 'outer_blackrock_shelves', kind: 'arena', walkable: true },
    ],
    paths: [
      { id: 'main_approach', kind: 'main_path' },
      { id: 'partial_crater_loop', kind: 'loop_path' },
    ],
    landmarks: [
      { id: 'central_volcano', kind: 'volcano', bake_mode: 'terrain' },
      { id: 'lava_channels', kind: 'lava_channel', bake_mode: 'terrain' },
    ],
  });

  assert.equal(badges.length, 4);
  assert.deepEqual(badges.map((badge) => badge.code), ['CV', 'AP', 'CL', 'LC']);
  assert.deepEqual(
    badges.map((badge) => badge.id),
    ['central_volcano', 'main_approach', 'partial_crater_loop', 'lava_channels'],
  );
  assert.ok(badges.every((badge) => badge.code.length <= 2));
  assert.ok(badges.every((badge) => !badge.label.includes('central_volcano')));
});

test('fire legend labels badges by editable layout sources instead of generic mask classes', () => {
  const legend = semanticLegendForLayout({
    biome: 'fire',
    landmarks: [
      { id: 'central_volcano', kind: 'volcano', bake_mode: 'terrain' },
      { id: 'lava_channels', kind: 'lava_channel', bake_mode: 'terrain' },
    ],
    paths: [
      { id: 'main_approach', kind: 'main_path' },
      { id: 'partial_crater_loop', kind: 'loop_path' },
    ],
    zones: [
      { id: 'crater_arena', kind: 'arena', walkable: true },
      { id: 'lava_hazard', kind: 'hazard', walkable: false },
    ],
  });

  assert.deepEqual(
    legend.map((entry) => [entry.code, entry.label]),
    [
      ['CV', 'Central volcano'],
      ['AP', 'Approach route'],
      ['CL', 'Crater loop'],
      ['LC', 'Lava channels'],
    ],
  );
});

test('ice legend and badges expose biome-specific semantic map language', () => {
  const layout = {
    biome: 'ice',
    landmarks: [
      { id: 'primary_crystal_wall', kind: 'ice_wall', radius: 0.54, count: 4 },
      { id: 'secondary_spire_clusters', kind: 'ice_crystal_cluster', radius: 0.48, count: 4 },
    ],
    paths: [
      { id: 'central_shelf', kind: 'open_area', points: [[0, 0]], width: 0.34 },
      { id: 'broken_ice_ring', kind: 'loop_path', points: [[0.62, 0]], width: 0.1 },
    ],
    zones: [
      { id: 'resource_crystals', kind: 'resource', radius_range: [0.38, 0.76] },
      { id: 'deep_cracks', kind: 'hazard', radius_range: [0.42, 0.92], walkable: false },
      { id: 'central_ice_shelf', kind: 'arena', radius_range: [0, 0.34] },
    ],
  };

  assert.deepEqual(
    semanticLegendForLayout(layout).map((entry) => [entry.code, entry.label]),
    [
      ['IW', 'Crystal wall'],
      ['CS', 'Central shelf'],
      ['BP', 'Broken plate ring'],
      ['CR', 'Deep cracks'],
      ['RC', 'Resource crystals'],
    ],
  );
  assert.deepEqual(semanticBadgesForLayout(layout).map((badge) => badge.code), ['IW', 'CS', 'BP', 'CR', 'RC']);
});

test('forest legend and badges expose canopy roots cave mushrooms and vine bridge', () => {
  const layout = {
    biome: 'forest',
    landmarks: [
      { id: 'root_arch', kind: 'root_arch', center: [0.35, -0.1], radius: 0.22 },
      { id: 'tree_stump_cave', kind: 'tree_stump_cave', center: [-0.25, 0.25], radius: 0.2 },
      { id: 'vine_bridge_anchor', kind: 'vine_bridge_anchor', center: [0.62, 0.18], radius: 0.12 },
    ],
    paths: [
      { id: 'forest_main_path', kind: 'main_path', points: [[0.9, 0], [0.35, -0.1], [-0.25, 0.25]], width: 0.14 },
      { id: 'vine_bridge', kind: 'bridge_anchor', points: [[0.62, 0.18], [0.2, 0.42]], width: 0.08 },
    ],
    zones: [
      { id: 'mushroom_pocket', kind: 'pcg', center: [0.28, 0.34], radius_range: [0.18, 0.42] },
      { id: 'glowing_root_cave', kind: 'pcg', center: [-0.25, 0.25], radius_range: [0.14, 0.34] },
      { id: 'canopy_platform', kind: 'arena', center: [0, 0], radius_range: [0, 0.44] },
    ],
  };

  assert.deepEqual(
    semanticLegendForLayout(layout).map((entry) => [entry.code, entry.label]),
    [
      ['CP', 'Canopy platform'],
      ['RA', 'Root arch'],
      ['SC', 'Stump cave'],
      ['MP', 'Mushroom pocket'],
      ['VB', 'Vine bridge'],
    ],
  );
  assert.deepEqual(semanticBadgesForLayout(layout).map((badge) => badge.code), ['CP', 'RA', 'SC', 'MP', 'VB']);
});

test('ice and forest live overlay specs map diagram ranges to biome features', () => {
  const iceLayout = {
    biome: 'ice',
    landmarks: [
      { id: 'primary_crystal_wall', radius: 0.54, count: 4, dominance: 0.86 },
      { id: 'secondary_spire_clusters', radius: 0.48, count: 5, dominance: 0.62 },
    ],
    paths: [
      { id: 'central_shelf', width: 0.34 },
      { id: 'broken_ice_ring', width: 0.1, points: [[0.62, 0]] },
    ],
    zones: [
      { id: 'central_ice_shelf', radius_range: [0, 0.34] },
      { id: 'resource_crystals', radius_range: [0.38, 0.76] },
      { id: 'deep_cracks', radius_range: [0.42, 0.92] },
    ],
  };
  const forestLayout = {
    biome: 'forest',
    landmarks: [
      { id: 'root_arch', center: [0.35, -0.1], radius: 0.22 },
      { id: 'tree_stump_cave', center: [-0.25, 0.25], radius: 0.2 },
    ],
    paths: [
      { id: 'forest_main_path', points: [[0.9, 0], [0.35, -0.1], [-0.25, 0.25]], width: 0.14 },
      { id: 'vine_bridge', points: [[0.62, 0.18], [0.2, 0.42]], width: 0.08 },
    ],
    zones: [
      { id: 'canopy_platform', center: [0, 0], radius_range: [0, 0.44] },
      { id: 'mushroom_pocket', center: [0.28, 0.34], radius_range: [0.18, 0.42] },
    ],
  };

  assert.deepEqual(iceLiveOverlaySpec(iceLayout).wallAngles, [1.18, 4.18, 0.28, 5.25]);
  assert.equal(iceLiveOverlaySpec(iceLayout).resourceAngles.length, 5);
  assert.deepEqual(iceLiveOverlaySpec(iceLayout).crackAngles, [0.78, 2.55, 4.75]);
  assert.equal(biomeLiveOverlaySpec(iceLayout).biome, 'ice');
  assert.deepEqual(forestLiveOverlaySpec(forestLayout).vineBridgePoints, [[0.62, 0.18], [0.2, 0.42]]);
  assert.equal(forestLiveOverlaySpec(forestLayout).canopyRadius, 0.44);
  assert.equal(biomeLiveOverlaySpec(forestLayout).biome, 'forest');
});

test('orbit camera drag and wheel input support free inspection with clamps', () => {
  const camera = clampOrbitCamera({ yaw: 0, pitch: -0.72, zoom: 1, panX: 0, panY: 0 });
  const dragged = dragOrbitCamera(camera, 200, -120);
  const zoomed = wheelOrbitCamera(dragged, -800);

  assert.equal(Number(dragged.yaw.toFixed(2)), 1.2);
  assert.equal(Number(dragged.pitch.toFixed(2)), -1.2);
  assert.equal(Number(zoomed.zoom.toFixed(2)), 1.8);
  assert.equal(wheelOrbitCamera(zoomed, -9000).zoom, 2.4);
  assert.equal(wheelOrbitCamera(zoomed, 9000).zoom, 0.55);
});

test('preview signatures cap high-density export quality to interactive topology', () => {
  const layout = {
    biome: 'fire',
    landmarks: [{ id: 'central_volcano', dominance: 0.9 }],
    paths: [],
    zones: [],
  };

  assert.equal(previewQualityForBakeQuality('draft'), 'draft');
  assert.equal(previewQualityForBakeQuality('preview'), 'preview');
  assert.equal(previewQualityForBakeQuality('production'), 'preview');
  assert.equal(previewQualityForBakeQuality('hero'), 'preview');

  assert.equal(
    previewBakeSignature(layout, { quality: previewQualityForBakeQuality('production') }),
    previewBakeSignature(layout, { quality: previewQualityForBakeQuality('hero') }),
  );
  assert.notEqual(
    previewBakeSignature(layout, { quality: previewQualityForBakeQuality('draft') }),
    previewBakeSignature(layout, { quality: previewQualityForBakeQuality('hero') }),
  );
});

test('preview quality status separates realtime preview from final inspect topology', () => {
  assert.deepEqual(previewQualityStatusForBakeQuality('hero'), {
    finalQuality: 'hero',
    finalLabel: 'HERO',
    realtimeQuality: 'preview',
    realtimeLabel: 'PREVIEW',
    inspectLabel: 'Inspect HERO',
    isRealtimeCapped: true,
    idleStatus: 'Realtime PREVIEW; inspect HERO for final topology',
    currentStatus: 'HERO snapshot current',
    staleStatus: 'HERO snapshot stale',
  });
  assert.deepEqual(previewQualityStatusForBakeQuality('draft'), {
    finalQuality: 'draft',
    finalLabel: 'DRAFT',
    realtimeQuality: 'draft',
    realtimeLabel: 'DRAFT',
    inspectLabel: 'Inspect DRAFT',
    isRealtimeCapped: false,
    idleStatus: 'Realtime DRAFT matches final topology',
    currentStatus: 'DRAFT snapshot current',
    staleStatus: 'DRAFT snapshot stale',
  });
  assert.equal(previewQualityStatusForBakeQuality('unknown').finalQuality, 'production');
});

test('high-res inspect signatures preserve final bake quality for snapshot staleness', () => {
  const layout = {
    biome: 'fire',
    landmarks: [{ id: 'central_volcano', dominance: 0.9 }],
    paths: [],
    zones: [],
  };
  const editedLayout = structuredClone(layout);
  editedLayout.landmarks[0].dominance = 0.94;

  assert.notEqual(
    inspectBakeSignature(layout, { quality: 'production' }),
    inspectBakeSignature(layout, { quality: 'hero' }),
  );
  assert.notEqual(
    inspectBakeSignature(layout, { quality: 'hero' }),
    inspectBakeSignature(editedLayout, { quality: 'hero' }),
  );
  assert.equal(
    inspectBakeSignature(layout, { quality: 'unknown' }),
    inspectBakeSignature(layout, { quality: 'production' }),
  );
});

test('top-down mesh projection fits an OBJ footprint into the minimap frame', () => {
  const frame = topDownFrameForMesh(
    [
      [-1, -2, 0.1],
      [3, 2, 0.2],
    ],
    400,
    300,
    20,
  );

  assert.deepEqual(frame, {
    centerX: 1,
    centerY: 0,
    scale: 65,
    width: 400,
    height: 300,
    rotation: 0,
  });
  assert.deepEqual(projectTopDownVertex([-1, -2, 0.1], frame), { x: 70, y: 280 });
  assert.deepEqual(projectTopDownVertex([3, 2, 0.2], frame), { x: 330, y: 20 });
});

test('top-down mesh projection can share the 3D orbit yaw for visual comparison', () => {
  const frame = topDownFrameForMesh(
    [
      [-1, -2, 0.1],
      [3, 2, 0.2],
    ],
    400,
    300,
    20,
    Math.PI / 2,
  );

  assert.equal(Number(frame.rotation.toFixed(2)), 1.57);
  assert.deepEqual(projectTopDownVertex([-1, -2, 0.1], frame), { x: 330, y: 280 });
  assert.deepEqual(projectTopDownVertex([3, 2, 0.2], frame), { x: 70, y: 20 });
});

test('live layout overlay uses the generated footprint range instead of a fixed canvas scale', () => {
  const vertices = [
    [-0.42, -0.28, -1.4],
    [0.48, 0.3, 1.2],
    [0, 0, 0],
  ];
  const frame = topDownFrameForMesh(vertices, 400, 300, 20, 0);
  const footprintRadius = footprintRadiusForMesh(vertices);
  const center = layoutPointToTopDown([0, 0], frame, footprintRadius);
  const eastEdge = layoutPointToTopDown([1, 0], frame, footprintRadius);
  const meshEastEdge = projectTopDownVertex([footprintRadius, 0, 0], frame);

  assert.equal(Number(footprintRadius.toFixed(2)), 0.57);
  assert.deepEqual(center, projectTopDownVertex([0, 0, 0], frame));
  assert.deepEqual(eastEdge, meshEastEdge);
  assert.ok(eastEdge.x > center.x);
});

test('stable top-down frame keeps the minimap range constant while yaw rotates', () => {
  const vertices = [
    [-1, -0.2, 0],
    [1, 0.2, 0],
  ];
  const frameA = stableTopDownFrameForMesh(vertices, 400, 300, 20, 0);
  const frameB = stableTopDownFrameForMesh(vertices, 400, 300, 20, Math.PI / 2);

  assert.equal(frameA.scale, frameB.scale);
  assert.equal(frameA.centerX, 0);
  assert.equal(frameA.centerY, 0);
  assert.equal(Number(frameA.scale.toFixed(2)), 127.48);
});

test('bake button labels expose dirty preview and formal bake states', () => {
  assert.equal(bakeButtonLabel('fire', { dirty: false }), 'Bake Fire Mesh');
  assert.equal(bakeButtonLabel('fire', { dirty: true }), 'Bake Fire Changes');
  assert.equal(bakeButtonLabel('fire', { previewing: true }), 'Preview baking...');
  assert.equal(bakeButtonLabel('fire', { generating: true }), 'Baking Fire...');
});

test('preview bake signature only changes after a 0.01 parameter step', () => {
  const baseLayout = {
    biome: 'fire',
    landmarks: [
      { id: 'central_volcano', radius: 0.45, dominance: 1.16 },
      { id: 'lava_channels', count: 4 },
    ],
    paths: [
      { id: 'main_approach', width: 0.12 },
      { id: 'partial_crater_loop', coverage: 0.68 },
    ],
  };
  const sameBucket = structuredClone(baseLayout);
  sameBucket.landmarks[0].dominance = 1.164;
  const nextBucket = structuredClone(baseLayout);
  nextBucket.landmarks[0].dominance = 1.17;

  assert.equal(previewBakeSignature(baseLayout), previewBakeSignature(sameBucket));
  assert.notEqual(previewBakeSignature(baseLayout), previewBakeSignature(nextBucket));
});

test('preview bake signature changes when mesh quality changes', () => {
  const layout = {
    biome: 'fire',
    landmarks: [
      { id: 'central_volcano', radius: 0.45, dominance: 1.16 },
    ],
    paths: [
      { id: 'main_approach', width: 0.12 },
    ],
  };

  assert.notEqual(
    previewBakeSignature(layout, { quality: 'draft' }),
    previewBakeSignature(layout, { quality: 'production' }),
  );
});

test('mask view options expose material and process fields in a compact order', () => {
  assert.deepEqual(maskViewOptions().map((option) => option.id), ['material', 'slope', 'talus', 'lavaFlow']);
  assert.equal(maskViewOptions()[1].label, 'Slope');
});

test('maskValueForFaceOrder maps top mesh face order back to terrain field samples', () => {
  const field = {
    radial_segments: 4,
    rings: 2,
    masks: {
      slope: [
        [0, 0, 0, 0],
        [0.1, 0.2, 0.3, 0.4],
        [0.5, 0.6, 0.7, 0.8],
      ],
      lava_flow: [
        [0, 0, 0, 0],
        [0.2, 0.2, 0.2, 0.2],
        [1, 0.8, 0.1, 0.1],
      ],
    },
  };

  assert.equal(maskValueForFaceOrder(field, 4, 'slope'), 0.35);
  assert.equal(maskValueForFaceOrder(field, 4, 'lavaFlow'), 0.55);
  assert.equal(maskValueForFaceOrder(field, 8, 'slope'), null);
  assert.equal(maskValueForFaceOrder(field, 0, 'material'), null);
});

test('maskColorForValue uses distinct terrain-process palettes', () => {
  assert.equal(maskColorForValue('slope', 1), 'rgba(172, 224, 218, 0.94)');
  assert.equal(maskColorForValue('talus', 1), 'rgba(218, 174, 96, 0.94)');
  assert.equal(maskColorForValue('lavaFlow', 1), 'rgba(242, 93, 38, 0.95)');
  assert.notEqual(maskColorForValue('slope', 0.8), maskColorForValue('lavaFlow', 0.8));
});

test('processTraceForFace turns terrain fields into a compact 3D trace signal', () => {
  const field = {
    radial_segments: 4,
    rings: 1,
    heights: [
      [0, 0, 0, 0],
      [100, 100, 100, 100],
    ],
    masks: {
      slope: [
        [0.1, 0.1, 0.1, 0.1],
        [0.8, 0.8, 0.1, 0.1],
      ],
      talus: [
        [0.1, 0.1, 0.1, 0.1],
        [0.7, 0.7, 0.1, 0.1],
      ],
      lava_flow: [
        [0.1, 0.1, 0.1, 0.1],
        [0.9, 0.9, 0.1, 0.1],
      ],
    },
  };

  const trace = processTraceForFace(field, 0);

  assert.equal(trace.dominant, 'lavaFlow');
  assert.equal(trace.lavaFlow, 0.5);
  assert.equal(trace.talus, 0.4);
  assert.equal(trace.slope, 0.45);
  assert.ok(trace.intensity > 0.45);
  assert.equal(processTraceForFace(field, 4), null);
});

test('processTraceColorForFace adds readable but restrained process tint to 3D material colors', () => {
  const base = 'rgb(82,74,65)';
  const lavaColor = processTraceColorForFace(base, null, 0, {
    trace: { slope: 0.2, talus: 0.1, lavaFlow: 0.9, intensity: 0.9 },
  });
  const talusColor = processTraceColorForFace(base, null, 0, {
    trace: { slope: 0.2, talus: 0.9, lavaFlow: 0.1, intensity: 0.9 },
  });
  const disabledColor = processTraceColorForFace(base, null, 0, {
    enabled: false,
    trace: { slope: 1, talus: 1, lavaFlow: 1, intensity: 1 },
  });

  assert.equal(lavaColor, 'rgb(116,53,42)');
  assert.equal(talusColor, 'rgb(113,96,74)');
  assert.equal(disabledColor, base);
});

test('processTraceColorForFace pulse briefly strengthens trace readability after preview bake', () => {
  const base = 'rgb(82,74,65)';
  const trace = { slope: 0.2, talus: 0.1, lavaFlow: 0.9, intensity: 0.9 };

  assert.equal(processTracePulseAlpha(100, 100, 800), 0);
  assert.equal(processTracePulseAlpha(100, 500, 800), 1);
  assert.equal(processTracePulseAlpha(100, 900, 800), 0);
  assert.equal(processTraceColorForFace(base, null, 0, { trace }), 'rgb(116,53,42)');
  assert.equal(processTraceColorForFace(base, null, 0, { trace, pulse: 1 }), 'rgb(129,48,37)');
  assert.equal(
    processTraceColorForFace(base, null, 0, { trace: { slope: 0.1, talus: 0.9, lavaFlow: 0.1, intensity: 0.9 }, pulse: 1 }),
    'rgb(118,99,76)',
  );
});

test('process slider highlight specs distinguish detail, erosion, and deposition semantics', () => {
  const detail = processHighlightSpecForControl('detailEnergy');
  const erosion = processHighlightSpecForControl('erosionAge');
  const deposition = processHighlightSpecForControl('depositionWeight');

  assert.equal(detail.traceKind, 'slope');
  assert.equal(erosion.traceKind, 'lavaFlow');
  assert.equal(deposition.traceKind, 'talus');
  assert.equal(detail.label, 'Surface detail highlighted');
  assert.equal(erosion.label, 'Erosion flow highlighted');
  assert.equal(deposition.label, 'Talus deposition highlighted');
  assert.notEqual(processMovementHighlightStyle('detailEnergy', 0.8).fill, processMovementHighlightStyle('erosionAge', 0.8).fill);
  assert.notEqual(processMovementHighlightStyle('erosionAge', 0.8).fill, processMovementHighlightStyle('depositionWeight', 0.8).fill);
  assert.equal(processMovementHighlightStyle('detailEnergy', 0.8).drawVertices, false);
});

test('process slider highlights are scoped to the matching baked terrain mask', () => {
  const field = {
    radial_segments: 6,
    rings: 1,
    heights: [
      [0, 0, 0, 0, 0, 0],
      [100, 100, 100, 100, 100, 100],
    ],
    masks: {
      slope: [
        [0.95, 0.95, 0.05, 0.05, 0.05, 0.05],
        [0.95, 0.95, 0.05, 0.05, 0.05, 0.05],
      ],
      talus: [
        [0.05, 0.05, 0.05, 0.05, 0.9, 0.9],
        [0.05, 0.05, 0.05, 0.05, 0.9, 0.9],
      ],
      lava_flow: [
        [0.05, 0.05, 0.92, 0.92, 0.05, 0.05],
        [0.05, 0.05, 0.92, 0.92, 0.05, 0.05],
      ],
    },
  };

  assert.ok(processMovementHighlightForFace(field, 0, 'detailEnergy') > 0.8);
  assert.ok(processMovementHighlightForFace(field, 0, 'erosionAge') < 0.2);
  assert.ok(processMovementHighlightForFace(field, 2, 'erosionAge') > 0.8);
  assert.ok(processMovementHighlightForFace(field, 2, 'depositionWeight') < 0.2);
  assert.ok(processMovementHighlightForFace(field, 4, 'depositionWeight') > 0.8);
  assert.equal(processMovementHighlightForFace(field, 4, 'volcanoRadius'), 0);
});

test('processMaskCoverageMetrics summarizes process masks over top field samples', () => {
  const field = {
    radial_segments: 4,
    rings: 1,
    masks: {
      slope: [
        [0.1, 0.1, 0.1, 0.1],
        [0.8, 0.8, 0.1, 0.1],
      ],
      talus: [
        [0, 0, 0, 0],
        [0.7, 0.1, 0.7, 0.1],
      ],
      lava_flow: [
        [0.9, 0.9, 0.1, 0.1],
        [0.9, 0.9, 0.1, 0.1],
      ],
    },
  };

  const metrics = processMaskCoverageMetrics(field);

  assert.deepEqual(metrics.map((metric) => metric.id), ['slope', 'talus', 'lavaFlow']);
  assert.equal(metrics[0].coverage, 0.5);
  assert.equal(metrics[0].coverageLabel, '50%');
  assert.equal(metrics[0].average, 0.45);
  assert.equal(metrics[2].coverage, 0.5);
});

test('processLayerStack exposes a Houdini-style ordered layer list with mask bindings', () => {
  const layers = processLayerStack(null, 'erosionAge');

  assert.deepEqual(layers.map((layer) => layer.id), [
    'baseForm',
    'craterCone',
    'routeCarve',
    'lavaFlow',
    'erosionAge',
    'talusDeposition',
    'surfaceDetail',
    'qualityDiagnostics',
    'finalMesh',
  ]);
  assert.equal(layers.find((layer) => layer.id === 'surfaceDetail').maskView, 'slope');
  assert.equal(layers.find((layer) => layer.id === 'erosionAge').traceKind, 'lavaFlow');
  assert.equal(layers.find((layer) => layer.id === 'talusDeposition').maskView, 'talus');
  assert.equal(layers.find((layer) => layer.id === 'qualityDiagnostics').maskView, 'quality');
  assert.equal(layers.find((layer) => layer.id === 'qualityDiagnostics').disabled, true);
  assert.equal(layers.find((layer) => layer.id === 'erosionAge').active, true);
  assert.equal(layers.find((layer) => layer.id === 'surfaceDetail').disabled, true);
  assert.equal(layers.find((layer) => layer.id === 'baseForm').disabled, false);
});

test('processLayerStack renames landmark and flow layers for non-fire biomes', () => {
  const forestLayers = processLayerStack({ biome: 'forest' });
  const iceLayers = processLayerStack({ biome: 'ice' });

  assert.equal(forestLayers.find((layer) => layer.id === 'craterCone').label, 'Canopy / roots');
  assert.equal(forestLayers.find((layer) => layer.id === 'lavaFlow').label, 'Root flow');
  assert.equal(iceLayers.find((layer) => layer.id === 'craterCone').label, 'Wall / shelf');
  assert.equal(iceLayers.find((layer) => layer.id === 'lavaFlow').label, 'Crack flow');
});

test('processLayerStack annotates process layers with field coverage when masks are available', () => {
  const field = {
    radial_segments: 4,
    rings: 1,
    masks: {
      slope: [
        [0.9, 0.9, 0.1, 0.1],
        [0.9, 0.9, 0.1, 0.1],
      ],
      talus: [
        [0.1, 0.1, 0.8, 0.8],
        [0.1, 0.1, 0.8, 0.8],
      ],
      lava_flow: [
        [0.1, 0.7, 0.7, 0.1],
        [0.1, 0.7, 0.7, 0.1],
      ],
    },
  };
  const quality = { overallHealth: 0.82, overallLabel: '82%', routeHealthLabel: '90%', overDetailLabel: '8%', thinEdgeLabel: '14%' };
  const layers = processLayerStack(field, 'surfaceDetail', quality);

  assert.equal(layers.find((layer) => layer.id === 'surfaceDetail').coverageLabel, '50%');
  assert.equal(layers.find((layer) => layer.id === 'erosionAge').averageLabel, '0.40');
  assert.equal(layers.find((layer) => layer.id === 'qualityDiagnostics').coverageLabel, '82%');
  assert.equal(layers.find((layer) => layer.id === 'qualityDiagnostics').averageLabel, '90% route');
  assert.equal(layers.find((layer) => layer.id === 'surfaceDetail').active, true);
  assert.equal(layers.find((layer) => layer.id === 'talusDeposition').disabled, false);
});

test('qualityRiskForFace separates route damage, over-detail, and thin edge risk', () => {
  const mesh = {
    vertices: [
      [0.1, 0, 0.05],
      [0.2, 0.02, 0.35],
      [0.25, -0.02, 0.62],
      [0.35, 0.35, 0.02],
      [0.4, 0.36, 0.04],
      [0.36, 0.42, 0.03],
      [0.98, 0.04, -0.06],
      [0.92, 0.12, -0.08],
      [0.94, -0.1, -0.05],
    ],
    faces: [
      { material: 'M_PathDirt', indices: [0, 1, 2], order: 0 },
      { material: 'M_TopGrass', indices: [3, 4, 5], order: 1 },
      { material: 'M_CliffRock', indices: [6, 7, 8], order: 2 },
    ],
  };
  const field = {
    radial_segments: 3,
    rings: 1,
    heights: [
      [0, 0, 0],
      [100, 100, 100],
    ],
    masks: {
      slope: [
        [0.95, 0.95, 0.95],
        [0.95, 0.95, 0.95],
      ],
      talus: [
        [0.05, 0.05, 0.05],
        [0.05, 0.05, 0.05],
      ],
      lava_flow: [
        [0.7, 0.1, 0.1],
        [0.7, 0.1, 0.1],
      ],
    },
  };

  const routeRisk = qualityRiskForFace(mesh, field, mesh.faces[0]);
  const detailRisk = qualityRiskForFace(mesh, field, mesh.faces[1]);
  const edgeRisk = qualityRiskForFace(mesh, field, mesh.faces[2]);

  assert.equal(routeRisk.dominant, 'routeDamage');
  assert.ok(routeRisk.routeDamage > 0.7);
  assert.equal(detailRisk.dominant, 'overDetail');
  assert.ok(detailRisk.overDetail > 0.6);
  assert.equal(edgeRisk.dominant, 'thinEdge');
  assert.ok(edgeRisk.thinEdge > 0.4);
  assert.equal(qualityRiskColorForFace(routeRisk), 'rgba(255, 90, 62, 0.6)');
});

test('qualityRiskForFace treats fire ash plateau as top-surface detail risk', () => {
  const mesh = {
    vertices: [
      [0.35, 0.35, 0.02],
      [0.4, 0.36, 0.04],
      [0.36, 0.42, 0.03],
    ],
    faces: [
      { material: 'M_AshPlateau', indices: [0, 1, 2], order: 0 },
    ],
  };
  const field = {
    radial_segments: 1,
    rings: 1,
    heights: [
      [0],
      [100],
    ],
    masks: {
      slope: [
        [0.95],
        [0.95],
      ],
      talus: [
        [0.05],
        [0.05],
      ],
    },
  };

  const risk = qualityRiskForFace(mesh, field, mesh.faces[0]);
  const metrics = qualityMetricsForMesh(mesh, field);

  assert.equal(risk.dominant, 'overDetail');
  assert.ok(risk.overDetail > 0.6);
  assert.ok(metrics.overDetail > 0.6);
});

test('qualityAdvisorForFace translates risks into causes and parameter guidance', () => {
  const mesh = {
    vertices: [
      [0.1, 0, 0.05],
      [0.2, 0.02, 0.35],
      [0.25, -0.02, 0.62],
      [0.35, 0.35, 0.02],
      [0.4, 0.36, 0.04],
      [0.36, 0.42, 0.03],
      [0.98, 0.04, -0.06],
      [0.92, 0.12, -0.08],
      [0.94, -0.1, -0.05],
    ],
    faces: [
      { material: 'M_PathDirt', indices: [0, 1, 2], order: 0 },
      { material: 'M_TopGrass', indices: [3, 4, 5], order: 1 },
      { material: 'M_CliffRock', indices: [6, 7, 8], order: 2 },
    ],
  };
  const field = {
    radial_segments: 3,
    rings: 1,
    heights: [
      [0, 0, 0],
      [100, 100, 100],
    ],
    masks: {
      slope: [
        [0.95, 0.95, 0.95],
        [0.95, 0.95, 0.95],
      ],
      talus: [
        [0.05, 0.05, 0.05],
        [0.05, 0.05, 0.05],
      ],
      lava_flow: [
        [0.7, 0.1, 0.1],
        [0.7, 0.1, 0.1],
      ],
    },
  };

  const routeAdvisor = qualityAdvisorForFace(mesh, field, mesh.faces[0]);
  const detailAdvisor = qualityAdvisorForFace(mesh, field, mesh.faces[1]);
  const edgeAdvisor = qualityAdvisorForFace(mesh, field, mesh.faces[2]);

  assert.equal(routeAdvisor.title, 'Route damage risk');
  assert.equal(routeAdvisor.severityLabel, 'High');
  assert.deepEqual(routeAdvisor.controls.map((control) => control.id), ['mainPathWidth', 'erosionAge', 'lavaCount']);
  assert.match(routeAdvisor.reasons.join(' '), /walkable route/i);
  assert.match(routeAdvisor.suggestion, /Approach width/);
  assert.deepEqual(routeAdvisor.layers, ['Route carve', 'Erosion age', 'Lava flow']);

  assert.equal(detailAdvisor.title, 'Over-detail risk');
  assert.deepEqual(detailAdvisor.controls.map((control) => control.id), ['detailEnergy', 'depositionWeight']);
  assert.match(detailAdvisor.reasons.join(' '), /surface noise/i);
  assert.match(detailAdvisor.suggestion, /Detail energy/);

  assert.equal(edgeAdvisor.title, 'Thin edge risk');
  assert.deepEqual(edgeAdvisor.controls.map((control) => control.id), ['volcanoRadius', 'volcanoDominance']);
  assert.match(edgeAdvisor.suggestion, /Crater footprint/);
});

test('qualityReportForMesh exports advisor issues for downstream tools', () => {
  const mesh = {
    vertices: [
      [0.1, 0, 0.05],
      [0.2, 0.02, 0.35],
      [0.25, -0.02, 0.62],
      [0.35, 0.35, 0.02],
      [0.4, 0.36, 0.04],
      [0.36, 0.42, 0.03],
      [0.98, 0.04, -0.06],
      [0.92, 0.12, -0.08],
      [0.94, -0.1, -0.05],
    ],
    faces: [
      { material: 'M_PathDirt', indices: [0, 1, 2], order: 0 },
      { material: 'M_TopGrass', indices: [3, 4, 5], order: 1 },
      { material: 'M_CliffRock', indices: [6, 7, 8], order: 2 },
    ],
  };
  const field = {
    biome: 'fire',
    radial_segments: 3,
    rings: 1,
    heights: [
      [0, 0, 0],
      [100, 100, 100],
    ],
    masks: {
      slope: [
        [0.95, 0.95, 0.95],
        [0.95, 0.95, 0.95],
      ],
      talus: [
        [0.05, 0.05, 0.05],
        [0.05, 0.05, 0.05],
      ],
      lava_flow: [
        [0.7, 0.1, 0.1],
        [0.7, 0.1, 0.1],
      ],
    },
  };

  const report = qualityReportForMesh(mesh, field, {
    quality: 'production',
    topology: { segments: 192, rings: 32 },
    meshPath: 'Tools/IslandMeshGen/output/fire.obj',
    layoutPath: 'Tools/IslandMeshGen/layouts/fire.json',
    generatedAt: '2026-07-03T00:00:00.000Z',
    maxIssues: 2,
  });

  assert.equal(report.schemaVersion, 1);
  assert.equal(report.biome, 'fire');
  assert.equal(report.quality, 'production');
  assert.deepEqual(report.topology, { segments: 192, rings: 32 });
  assert.deepEqual(report.mesh, { vertices: 9, faces: 3 });
  assert.match(report.summary, /Route/);
  assert.equal(report.topIssues.length, 2);
  assert.deepEqual(report.topIssues[0].suggestedControls.map((control) => control.id), ['mainPathWidth', 'erosionAge', 'lavaCount']);
  assert.deepEqual(report.topIssues[0].layers, ['Route carve', 'Erosion age', 'Lava flow']);
  assert.equal(report.topIssues[0].region, 'R01/S000');
  assert.equal(report.topIssues[0].material, 'M_PathDirt');
  assert.equal(report.controlIndex.mainPathWidth.issueCount, 1);
});

test('qualityNudgePlanForIssue returns conservative control nudges by issue type', () => {
  assert.deepEqual(qualityNudgePlanForIssue({ type: 'overDetail' }), [
    { controlId: 'detailEnergy', delta: -0.08 },
    { controlId: 'depositionWeight', delta: 0.06 },
  ]);
  assert.deepEqual(qualityNudgePlanForIssue({ type: 'routeDamage' }), [
    { controlId: 'mainPathWidth', delta: 0.02 },
    { controlId: 'erosionAge', delta: -0.04 },
  ]);
  assert.deepEqual(qualityNudgePlanForIssue({ type: 'thinEdge' }), [
    { controlId: 'volcanoRadius', delta: 0.02 },
    { controlId: 'volcanoDominance', delta: -0.04 },
  ]);
  assert.deepEqual(qualityNudgePlanForIssue(null), []);
});

test('qualityNudgePlanSummaryForIssue exposes artist-readable planned deltas', () => {
  assert.deepEqual(qualityNudgePlanSummaryForIssue({ type: 'routeDamage' }), [
    { controlId: 'mainPathWidth', label: 'Approach width', delta: 0.02, deltaLabel: '+2%', direction: 'raise' },
    { controlId: 'erosionAge', label: 'Erosion age', delta: -0.04, deltaLabel: '-4%', direction: 'lower' },
  ]);
  assert.deepEqual(qualityNudgePlanSummaryForIssue({ type: 'unknown' }), []);
});

test('qualityNudgeResultForIssue summarizes before and after risk movement', () => {
  const beforeIssue = {
    type: 'overDetail',
    label: 'Over-detail risk',
    faceOrder: 12,
    score: 0.52,
    scoreLabel: '52%',
  };

  assert.deepEqual(qualityNudgeResultForIssue(beforeIssue, null), {
    status: 'pending',
    statusLabel: 'Waiting',
    label: 'Waiting for preview bake',
    summary: 'Over-detail risk was 52%.',
    beforeScore: 0.52,
    afterScore: null,
    delta: null,
    deltaLabel: '',
    faceOrder: 12,
    beforeIssue,
  });

  const improved = qualityNudgeResultForIssue(beforeIssue, {
    topIssues: [{ type: 'overDetail', faceOrder: 12, score: 0.38, scoreLabel: '38%' }],
  });
  assert.equal(improved.status, 'improved');
  assert.equal(improved.deltaLabel, '-14%');
  assert.equal(improved.summary, 'Over-detail risk moved from 52% to 38%.');

  const worse = qualityNudgeResultForIssue(beforeIssue, {
    topIssues: [{ type: 'overDetail', faceOrder: 12, score: 0.57, scoreLabel: '57%' }],
  });
  assert.equal(worse.status, 'worse');
  assert.equal(worse.deltaLabel, '+5%');

  const cleared = qualityNudgeResultForIssue(beforeIssue, { topIssues: [] });
  assert.equal(cleared.status, 'cleared');
  assert.equal(cleared.afterScore, 0);
  assert.equal(cleared.deltaLabel, '-52%');
});

test('quality diagnostics keep top grass outer shelves out of thin-edge alerts', () => {
  const mesh = {
    vertices: [
      [0, 0, 1200],
      [0.3, 0, 620],
      [0.8, 0, -120],
      [0.91, 0.05, -1192],
      [0.88, 0.12, -867],
      [0.93, -0.04, -622],
      [1, 0, -1500],
    ],
    faces: [
      { material: 'M_TopGrass', indices: [3, 4, 5], order: 0 },
    ],
  };
  const field = {
    radial_segments: 1,
    rings: 1,
    heights: [[0], [100]],
    masks: {
      slope: [[0.35], [0.35]],
      talus: [[0.1], [0.1]],
      lava_flow: [[0.05], [0.05]],
    },
  };

  const risk = qualityRiskForFace(mesh, field, mesh.faces[0]);

  assert.equal(risk.dominant, 'overDetail');
  assert.equal(risk.thinEdge, 0);
  assert.ok(risk.score < 0.45);
});

test('quality diagnostics are stable when mesh height units are scaled up', () => {
  const makeMesh = (scale) => ({
    vertices: [
      [0, 0, 1.2 * scale],
      [0.32, 0.02, 0.48 * scale],
      [0.52, -0.04, 0.38 * scale],
      [0.82, 0.06, -0.42 * scale],
      [0.88, 0.12, -0.58 * scale],
      [0.92, -0.08, -0.66 * scale],
      [1, 0, -1.1 * scale],
    ],
    faces: [
      { material: 'M_PathDirt', indices: [1, 2, 3], order: 0 },
      { material: 'M_CliffRock', indices: [3, 4, 5], order: 1 },
    ],
  });
  const field = {
    radial_segments: 2,
    rings: 1,
    heights: [[0, 0], [100, 100]],
    masks: {
      slope: [[0.62, 0.48], [0.62, 0.48]],
      talus: [[0.18, 0.22], [0.18, 0.22]],
      lava_flow: [[0.24, 0.12], [0.24, 0.12]],
    },
  };

  const smallRouteRisk = qualityRiskForFace(makeMesh(1), field, makeMesh(1).faces[0]);
  const largeRouteRisk = qualityRiskForFace(makeMesh(1000), field, makeMesh(1000).faces[0]);
  const smallEdgeRisk = qualityRiskForFace(makeMesh(1), field, makeMesh(1).faces[1]);
  const largeEdgeRisk = qualityRiskForFace(makeMesh(1000), field, makeMesh(1000).faces[1]);

  assert.ok(Math.abs(smallRouteRisk.routeDamage - largeRouteRisk.routeDamage) <= 0.02);
  assert.ok(Math.abs(smallEdgeRisk.thinEdge - largeEdgeRisk.thinEdge) <= 0.02);
  assert.ok(largeEdgeRisk.thinEdge < 0.7);
});

test('qualityMetricsForMesh avoids per-face full-mesh radius scans', () => {
  const vertexCount = 1200;
  const faceCount = 2400;
  const vertices = Array.from({ length: vertexCount }, (_, index) => {
    const angle = index * 0.17;
    const radius = (index % 100) / 100;
    return [
      Math.cos(angle) * radius,
      Math.sin(angle) * radius,
      Math.sin(index * 0.07) * 1200,
    ];
  });
  const materials = ['M_TopGrass', 'M_PathDirt', 'M_CliffRock', 'M_ElementCrack'];
  const mesh = {
    vertices,
    faces: Array.from({ length: faceCount }, (_, index) => ({
      material: materials[index % materials.length],
      order: index % 512,
      indices: [index % vertexCount, (index * 7 + 1) % vertexCount, (index * 13 + 2) % vertexCount],
    })),
  };
  const segments = 64;
  const rings = 8;
  const grid = (mapper) => Array.from(
    { length: rings + 1 },
    (_, ring) => Array.from({ length: segments }, (_, segment) => mapper(ring, segment)),
  );
  const field = {
    radial_segments: segments,
    rings,
    heights: grid((ring, segment) => 100 + ring + segment),
    masks: {
      slope: grid((ring, segment) => ((ring + segment) % 10) / 10),
      talus: grid((ring, segment) => ((ring * 2 + segment) % 10) / 10),
      lava_flow: grid((ring, segment) => ((ring + segment * 3) % 10) / 10),
    },
  };

  const start = performance.now();
  const metrics = qualityMetricsForMesh(mesh, field);
  const elapsed = performance.now() - start;
  const repeatStart = performance.now();
  const repeatMetrics = qualityMetricsForMesh(mesh, field);
  const repeatElapsed = performance.now() - repeatStart;
  const riskStart = performance.now();
  for (const face of mesh.faces) qualityRiskForFace(mesh, field, face);
  const riskElapsed = performance.now() - riskStart;

  assert.match(metrics.summary, /Route/);
  assert.equal(repeatMetrics.summary, metrics.summary);
  assert.ok(elapsed < 60, `quality diagnostics took ${elapsed.toFixed(1)}ms`);
  assert.ok(repeatElapsed < 3, `cached quality metrics took ${repeatElapsed.toFixed(1)}ms`);
  assert.ok(riskElapsed < 4, `cached per-face risks took ${riskElapsed.toFixed(1)}ms`);
});

test('qualityMetricsForMesh summarizes route health and diagnostic risk labels', () => {
  const mesh = {
    vertices: [
      [0.1, 0, 0.05],
      [0.2, 0.02, 0.35],
      [0.25, -0.02, 0.62],
      [0.35, 0.35, 0.02],
      [0.4, 0.36, 0.04],
      [0.36, 0.42, 0.03],
      [0.98, 0.04, -0.06],
      [0.92, 0.12, -0.08],
      [0.94, -0.1, -0.05],
    ],
    faces: [
      { material: 'M_PathDirt', indices: [0, 1, 2], order: 0 },
      { material: 'M_TopGrass', indices: [3, 4, 5], order: 1 },
      { material: 'M_CliffRock', indices: [6, 7, 8], order: 2 },
    ],
  };
  const field = {
    radial_segments: 3,
    rings: 1,
    heights: [
      [0, 0, 0],
      [100, 100, 100],
    ],
    masks: {
      slope: [
        [0.9, 0.9, 0.9],
        [0.9, 0.9, 0.9],
      ],
      talus: [
        [0.05, 0.05, 0.05],
        [0.05, 0.05, 0.05],
      ],
      lava_flow: [
        [0.65, 0.1, 0.1],
        [0.65, 0.1, 0.1],
      ],
    },
  };

  const metrics = qualityMetricsForMesh(mesh, field);

  assert.ok(metrics.routeHealth < 0.35);
  assert.ok(metrics.overDetail > 0.45);
  assert.ok(metrics.thinEdge > 0.18);
  assert.match(metrics.summary, /Route/);
  assert.equal(metrics.routeHealthLabel, `${Math.round(metrics.routeHealth * 100)}%`);
  assert.equal(metrics.risks.length, 3);
});

test('qualityMetricsForMesh detects coherent radial artifacts in terrain fields', () => {
  const mesh = {
    vertices: [
      [0, 0, 0],
      [1, 0, 0],
      [0, 1, 0],
    ],
    faces: [
      { material: 'M_TopGrass', indices: [0, 1, 2], order: 0 },
    ],
  };
  const radialSegments = 16;
  const rings = 10;
  const heights = Array.from({ length: rings + 1 }, (_, ring) => (
    Array.from({ length: radialSegments }, (_, segment) => (
      ring * 80 + (segment % 2 === 0 ? 240 : -240)
    ))
  ));
  const emptyMask = Array.from({ length: rings + 1 }, () => Array(radialSegments).fill(0));
  const field = {
    biome: 'fire',
    radial_segments: radialSegments,
    rings,
    heights,
    masks: {
      path: emptyMask,
      lava: emptyMask,
      crater_loop: emptyMask,
    },
  };

  const metrics = qualityMetricsForMesh(mesh, field);
  const report = qualityReportForMesh(mesh, field);

  assert.ok(metrics.radialArtifact > 0.45);
  assert.equal(metrics.radialArtifactLabel, `${Math.round(metrics.radialArtifact * 100)}%`);
  assert.match(metrics.summary, /radial risk/);
  assert.equal(report.metrics.radialArtifact, metrics.radialArtifact);
});

test('meshDeltaForFace and meshDeltaColorForFace describe preview bake height changes', () => {
  const fromMesh = {
    vertices: [
      [0, 0, 0.1],
      [1, 0, 0.1],
      [0, 1, 0.1],
      [1, 1, 0.2],
    ],
  };
  const toMesh = {
    vertices: [
      [0, 0, 0.18],
      [1, 0, 0.18],
      [0, 1, 0.18],
      [1, 1, -0.2],
    ],
  };
  const raised = meshDeltaForFace(fromMesh, toMesh, { indices: [0, 1, 2] });
  const lowered = meshDeltaForFace(fromMesh, toMesh, { indices: [1, 2, 3] });

  assert.equal(raised.direction, 'raised');
  assert.equal(raised.delta, 0.08);
  assert.ok(raised.intensity > 0.5);
  assert.equal(lowered.direction, 'lowered');
  assert.ok(lowered.delta < 0);
  assert.equal(meshDeltaColorForFace(raised, 1), 'rgba(255, 188, 79, 0.24)');
  assert.equal(meshDeltaColorForFace(lowered, 1), 'rgba(89, 190, 255, 0.24)');
  assert.equal(meshDeltaForFace(fromMesh, { vertices: [[0, 0, 0]] }, { indices: [0, 1, 2] }), null);
});

test('fieldFaceSampleForOrder returns ring segment height and process masks for probe HUDs', () => {
  const field = {
    radial_segments: 4,
    rings: 2,
    heights: [
      [0, 0, 0, 0],
      [100, 200, 300, 400],
      [500, 600, 700, 800],
    ],
    masks: {
      slope: [
        [0, 0, 0, 0],
        [0.1, 0.2, 0.3, 0.4],
        [0.5, 0.6, 0.7, 0.8],
      ],
      talus: [
        [0, 0, 0, 0],
        [0.2, 0.2, 0.2, 0.2],
        [1, 0.8, 0.1, 0.1],
      ],
      lava_flow: [
        [0, 0, 0, 0],
        [0.4, 0.4, 0.4, 0.4],
        [0.9, 0.9, 0.1, 0.1],
      ],
    },
  };

  const sample = fieldFaceSampleForOrder(field, 4);

  assert.equal(sample.ring, 2);
  assert.equal(sample.segment, 0);
  assert.equal(sample.heightM, 3.5);
  assert.deepEqual(sample.masks, {
    slope: 0.35,
    talus: 0.55,
    lavaFlow: 0.65,
  });
  assert.equal(fieldFaceSampleForOrder(field, 8), null);
});

test('faceHitAtPoint resolves overlapping projected faces by topmost draw order', () => {
  const regions = [
    {
      faceOrder: 1,
      material: 'M_TopGrass',
      points: [{ x: 0, y: 0 }, { x: 40, y: 0 }, { x: 40, y: 40 }, { x: 0, y: 40 }],
    },
    {
      faceOrder: 2,
      material: 'M_PathDirt',
      points: [{ x: 10, y: 10 }, { x: 50, y: 10 }, { x: 50, y: 50 }, { x: 10, y: 50 }],
    },
  ];

  assert.equal(faceHitAtPoint(regions, { x: 20, y: 20 }).faceOrder, 2);
  assert.equal(faceHitAtPoint(regions, { x: 5, y: 5 }).faceOrder, 1);
  assert.equal(faceHitAtPoint(regions, { x: 80, y: 80 }), null);
});

test('pending fire movement influence highlights likely moving vertices without deforming the mesh', () => {
  const mesh = {
    vertices: [
      [0, 0, 0],
      [0.5, 0, 0.05],
      [-0.62, 0.55, -0.1],
    ],
    faces: [
      { material: 'M_TopGrass', indices: [0, 1, 2] },
    ],
  };
  const layout = {
    biome: 'fire',
    landmarks: [
      { id: 'central_volcano', radius: 0.5, dominance: 1.2 },
      { id: 'lava_channels', count: 4 },
    ],
    paths: [
      { id: 'main_approach', width: 0.22 },
      { id: 'partial_crater_loop', coverage: 0.7 },
    ],
  };

  const footprintRadius = footprintRadiusForMesh(mesh.vertices);
  assert.ok(fireMovementInfluenceForVertex(mesh.vertices[1], layout, footprintRadius) > 0.35);
  assert.ok(fireMovementInfluenceForVertex(mesh.vertices[2], layout, footprintRadius) < 0.45);
  assert.equal(
    fireMovementInfluenceForVertex(mesh.vertices[1], { ...layout, biome: 'ice' }, footprintRadius),
    0,
  );
});

test('pending fire highlight is scoped to the active control material region', () => {
  const mesh = {
    vertices: [
      [0.39, 0, 0.05],
      [0.42, 0.04, 0.04],
      [0.36, -0.04, 0.02],
      [0.72, 0.02, 0.01],
      [0.78, 0.04, 0.02],
      [0.74, -0.05, 0.01],
      [0.67, 0.3, 0.01],
      [0.72, 0.32, 0.02],
      [0.62, 0.27, 0.01],
    ],
    faces: [
      { material: 'M_TopGrass', indices: [0, 1, 2] },
      { material: 'M_UndersideRock', indices: [0, 1, 2] },
      { material: 'M_PathDirt', indices: [3, 4, 5] },
      { material: 'M_ElementCrack', indices: [6, 7, 8] },
    ],
  };
  const layout = {
    biome: 'fire',
    landmarks: [
      { id: 'central_volcano', radius: 0.5, dominance: 1.2 },
      { id: 'lava_channels', count: 4 },
    ],
    paths: [
      { id: 'main_approach', width: 0.22 },
      { id: 'partial_crater_loop', coverage: 0.7 },
    ],
  };
  const radius = footprintRadiusForMesh(mesh.vertices);

  assert.ok(fireMovementHighlightForFace(mesh.faces[0], mesh, layout, radius, 'volcanoRadius') > 0.4);
  assert.equal(fireMovementHighlightForFace(mesh.faces[1], mesh, layout, radius, 'volcanoRadius'), 0);
  assert.ok(fireMovementHighlightForFace(mesh.faces[2], mesh, layout, radius, 'mainPathWidth') > 0.25);
  assert.equal(fireMovementHighlightForFace(mesh.faces[3], mesh, layout, radius, 'mainPathWidth'), 0);
  assert.ok(fireMovementHighlightForFace(mesh.faces[3], mesh, layout, radius, 'lavaCount') > 0.25);
  assert.equal(fireMovementHighlightForFace(mesh.faces[2], mesh, layout, radius, 'lavaCount'), 0);
});

test('loop and lava controls highlight generator-matched planned regions even before preview bake', () => {
  const layout = {
    biome: 'fire',
    landmarks: [
      { id: 'central_volcano', radius: 0.5, dominance: 1.2 },
      { id: 'lava_channels', count: 5, radius: 0.82 },
    ],
    paths: [
      { id: 'main_approach', width: 0.12 },
      { id: 'partial_crater_loop', coverage: 0.65, width: 0.08 },
    ],
  };
  const mesh = {
    vertices: [
      [0.5, 0, 0.04],
      [0.52, 0.04, 0.04],
      [0.48, -0.04, 0.04],
      [-0.5, 0, 0.04],
      [-0.52, 0.04, 0.04],
      [-0.48, -0.04, 0.04],
      [0.68, 0.3, 0.01],
      [0.72, 0.32, 0.01],
      [0.64, 0.28, 0.01],
      [0.68, -0.3, 0.01],
      [0.72, -0.32, 0.01],
      [0.64, -0.28, 0.01],
    ],
    faces: [
      { material: 'M_TopGrass', indices: [0, 1, 2] },
      { material: 'M_PathDirt', indices: [3, 4, 5] },
      { material: 'M_TopGrass', indices: [6, 7, 8] },
      { material: 'M_PathDirt', indices: [9, 10, 11] },
    ],
  };
  const radius = 1;

  assert.ok(fireMovementHighlightForFace(mesh.faces[0], mesh, layout, radius, 'loopCoverage') > 0.4);
  assert.equal(fireMovementHighlightForFace(mesh.faces[1], mesh, layout, radius, 'loopCoverage'), 0);
  assert.ok(fireMovementHighlightForFace(mesh.faces[2], mesh, layout, radius, 'lavaCount') > 0.4);
  assert.equal(fireMovementHighlightForFace(mesh.faces[3], mesh, layout, radius, 'lavaCount'), 0);
});

test('approach width highlights the planned widened route before path material is baked', () => {
  const layout = {
    biome: 'fire',
    landmarks: [
      { id: 'central_volcano', radius: 0.45, dominance: 1.1 },
      { id: 'lava_channels', count: 4, radius: 0.82 },
    ],
    paths: [
      { id: 'main_approach', width: 0.25 },
      { id: 'partial_crater_loop', coverage: 0.65, width: 0.08 },
    ],
  };
  const mesh = {
    vertices: [
      [0.68, 0.02, 0.01],
      [0.76, 0.04, 0.01],
      [0.72, -0.04, 0.01],
      [0.68, 0.02, -0.2],
      [0.76, 0.04, -0.2],
      [0.72, -0.04, -0.2],
    ],
    faces: [
      { material: 'M_TopGrass', indices: [0, 1, 2] },
      { material: 'M_UndersideRock', indices: [3, 4, 5] },
    ],
  };

  assert.ok(fireMovementHighlightForFace(mesh.faces[0], mesh, layout, 1, 'mainPathWidth') > 0.4);
  assert.equal(fireMovementHighlightForFace(mesh.faces[1], mesh, layout, 1, 'mainPathWidth'), 0);
});

test('approach width uses a lower highlight threshold so the whole route reads as one band', () => {
  assert.equal(fireMovementHighlightThreshold('mainPathWidth'), 0.1);
  assert.equal(fireMovementHighlightThreshold('loopCoverage'), 0.32);
  assert.equal(fireMovementHighlightThreshold('lavaCount'), 0.32);
});

test('generic movement highlight preserves fire behavior while enabling biome-specific controls', () => {
  const layout = {
    biome: 'fire',
    landmarks: [
      { id: 'central_volcano', radius: 0.5, dominance: 1.2 },
      { id: 'lava_channels', count: 4 },
    ],
    paths: [
      { id: 'main_approach', width: 0.22 },
      { id: 'partial_crater_loop', coverage: 0.7 },
    ],
  };
  const vertex = [0.5, 0, 0.05];

  assert.equal(
    biomeMovementInfluenceForVertex(vertex, layout, 1, 'volcanoRadius'),
    fireMovementInfluenceForVertex(vertex, layout, 1, 'volcanoRadius'),
  );
  assert.equal(biomeMovementHighlightThreshold('mainPathWidth'), fireMovementHighlightThreshold('mainPathWidth'));
});

test('forest movement highlights show root, vine, and mushroom edit footprints before rebake', () => {
  const layout = {
    biome: 'forest',
    landmarks: [
      { id: 'root_arch', center: [0.35, -0.1], radius: 0.22, dominance: 0.7 },
      { id: 'tree_stump_cave', center: [-0.25, 0.25], radius: 0.2, dominance: 0.72 },
      { id: 'vine_bridge_anchor', center: [0.62, 0.18], radius: 0.12, dominance: 0.38 },
    ],
    paths: [
      { id: 'forest_main_path', points: [[0.9, 0], [0.35, -0.1], [-0.25, 0.25]], width: 0.14 },
      { id: 'vine_bridge', points: [[0.62, 0.18], [0.2, 0.42]], width: 0.08 },
    ],
    zones: [
      { id: 'mushroom_pocket', center: [0.28, 0.34], radius_range: [0.18, 0.42] },
      { id: 'canopy_platform', center: [0, 0], radius_range: [0, 0.44] },
    ],
  };
  const mesh = {
    vertices: [
      [0.34, -0.1, 0.1],
      [0.39, -0.08, 0.1],
      [0.31, -0.13, 0.1],
      [0.42, 0.30, 0.08],
      [0.46, 0.27, 0.08],
      [0.39, 0.33, 0.08],
      [0.28, 0.34, 0.02],
      [0.34, 0.36, 0.02],
      [0.24, 0.30, 0.02],
      [0.86, -0.68, -0.2],
      [0.9, -0.70, -0.2],
      [0.82, -0.64, -0.2],
    ],
    faces: [
      { material: 'M_TopGrass', indices: [0, 1, 2] },
      { material: 'M_PathDirt', indices: [3, 4, 5] },
      { material: 'M_TopGrass', indices: [6, 7, 8] },
      { material: 'M_UndersideRock', indices: [9, 10, 11] },
    ],
  };

  assert.ok(biomeMovementHighlightForFace(mesh.faces[0], mesh, layout, 1, 'rootDominance') > 0.35);
  assert.ok(biomeMovementHighlightForFace(mesh.faces[1], mesh, layout, 1, 'vineBridgeWidth') > 0.35);
  assert.ok(biomeMovementHighlightForFace(mesh.faces[2], mesh, layout, 1, 'mushroomPocketOuter') > 0.35);
  assert.equal(biomeMovementHighlightForFace(mesh.faces[3], mesh, layout, 1, 'mushroomPocketOuter'), 0);
});

test('ice movement highlights show jagged wall, plate ring, resources, and deep crack regions', () => {
  const layout = {
    biome: 'ice',
    landmarks: [
      { id: 'primary_crystal_wall', radius: 0.54, dominance: 0.78, count: 4 },
      { id: 'secondary_spire_clusters', radius: 0.48, dominance: 0.62, count: 4 },
    ],
    paths: [
      { id: 'central_shelf', points: [[0, 0]], width: 0.34 },
      { id: 'broken_ice_ring', points: [[0.62, 0]], width: 0.1 },
    ],
    zones: [
      { id: 'deep_cracks', radius_range: [0.42, 0.92] },
      { id: 'central_ice_shelf', radius_range: [0, 0.34] },
    ],
  };
  const mesh = {
    vertices: [
      [0.21, 0.50, 0.5],
      [0.24, 0.52, 0.5],
      [0.18, 0.48, 0.5],
      [0.58, 0.00, 0.2],
      [0.61, 0.03, 0.2],
      [0.55, -0.03, 0.2],
      [0.46, 0.13, 0.35],
      [0.49, 0.15, 0.35],
      [0.43, 0.11, 0.35],
      [0.49, 0.49, -0.35],
      [0.52, 0.52, -0.35],
      [0.46, 0.46, -0.35],
      [0.9, -0.78, -0.4],
      [0.94, -0.80, -0.4],
      [0.86, -0.76, -0.4],
    ],
    faces: [
      { material: 'M_CliffRock', indices: [0, 1, 2] },
      { material: 'M_PathDirt', indices: [3, 4, 5] },
      { material: 'M_CliffRock', indices: [6, 7, 8] },
      { material: 'M_ElementCrack', indices: [9, 10, 11] },
      { material: 'M_UndersideRock', indices: [12, 13, 14] },
    ],
  };

  assert.ok(biomeMovementHighlightForFace(mesh.faces[0], mesh, layout, 1, 'crystalWallRadius') > 0.35);
  assert.ok(biomeMovementHighlightForFace(mesh.faces[1], mesh, layout, 1, 'brokenIceRingRadius') > 0.35);
  assert.ok(biomeMovementHighlightForFace(mesh.faces[2], mesh, layout, 1, 'resourceClusterCount') > 0.35);
  assert.ok(biomeMovementHighlightForFace(mesh.faces[3], mesh, layout, 1, 'deepCrackOuter') > 0.35);
  assert.equal(biomeMovementHighlightForFace(mesh.faces[4], mesh, layout, 1, 'deepCrackOuter'), 0);
});

test('forest and ice process labels describe pits and fractures instead of lava flow weathering', () => {
  assert.match(biomeControlLabels('forest').erosionAge.note, /pit|collapse|hollow/i);
  assert.match(biomeControlLabels('ice').erosionAge.note, /crevasse|fracture|crack/i);
});

test('morphMeshes interpolates same-topology server previews instead of hard swapping vertices', () => {
  const from = {
    vertices: [
      [0, 0, 0],
      [1, 0, 0],
    ],
    faces: [{ material: 'M_TopGrass', indices: [0, 1] }],
  };
  const to = {
    vertices: [
      [0, 0, 2],
      [1, 0, 4],
    ],
    faces: [{ material: 'M_ElementCrack', indices: [0, 1] }],
  };

  const halfway = morphMeshes(from, to, 0.5);

  assert.deepEqual(halfway.vertices, [
    [0, 0, 1],
    [1, 0, 2],
  ]);
  assert.equal(halfway.faces[0].material, 'M_ElementCrack');
  const mismatchedTarget = { ...to, vertices: [[0, 0, 1]] };
  assert.equal(morphMeshes(from, mismatchedTarget, 0.5), mismatchedTarget);
});

test('meshAtTransitionFrame returns the currently visible mesh for retargeted preview morphs', () => {
  const from = {
    vertices: [[0, 0, 0]],
    faces: [{ material: 'M_TopGrass', indices: [0] }],
  };
  const to = {
    vertices: [[0, 0, 10]],
    faces: [{ material: 'M_ElementCrack', indices: [0] }],
  };
  const transition = {
    from,
    to,
    startTime: 100,
    duration: 100,
  };

  const halfway = meshAtTransitionFrame(transition, from, 150, (value) => value);

  assert.deepEqual(halfway.vertices, [[0, 0, 5]]);
  assert.equal(meshAtTransitionFrame(null, from, 150), from);
  assert.equal(meshAtTransitionFrame(transition, from, 250), to);
});

test('current preview render never applies local geometry prediction', () => {
  const mesh = {
    vertices: [
      [0, 0, 0],
      [0.42, 0, 0.08],
    ],
    faces: [{ material: 'M_TopGrass', indices: [0, 1] }],
  };
  const layout = {
    biome: 'fire',
    landmarks: [
      { id: 'central_volcano', radius: 0.5, dominance: 1.2 },
      { id: 'lava_channels', count: 4 },
    ],
    paths: [
      { id: 'main_approach', width: 0.22 },
      { id: 'partial_crater_loop', coverage: 0.7 },
    ],
  };
  const signature = previewBakeSignature(layout);

  assert.equal(
    meshForPreviewRender(mesh, layout, {
      previewSignature: signature,
      currentSignature: signature,
    }),
    mesh,
  );
  assert.equal(
    meshForPreviewRender(mesh, layout, {
      previewSignature: 'old-preview',
      currentSignature: signature,
    }),
    mesh,
  );
});

test('yaw label normalizes orbit angle for shared 2D and 3D viewport HUDs', () => {
  assert.equal(yawLabel(0), 'Yaw 0 deg');
  assert.equal(yawLabel(Math.PI / 2), 'Yaw 90 deg');
  assert.equal(yawLabel(-Math.PI / 2), 'Yaw 270 deg');
});

test('fire live overlay derives immediate minimap feedback from unbaked layout controls', () => {
  const overlay = fireLiveOverlaySpec({
    biome: 'fire',
    landmarks: [
      { id: 'central_volcano', radius: 0.5, dominance: 1.1 },
      { id: 'lava_channels', count: 4, radius: 0.82 },
    ],
    paths: [
      { id: 'main_approach', width: 0.2 },
      { id: 'partial_crater_loop', coverage: 0.66 },
    ],
  });

  assert.deepEqual(overlay, {
    enabled: true,
    craterRadius: 0.5,
    craterLift: 1.1,
    pathWidth: 0.2,
    loopWidth: 0.08,
    loopCoverage: 0.66,
    lavaRadius: 0.82,
    lavaAngles: [0.42, 1.99, 3.56, 5.13],
  });
});

test('material palette is biome aware so fire terrain no longer renders as green grass', () => {
  assert.equal(materialColorForBiome('fire', 'M_AshPlateau', 1), 'rgb(82,74,65)');
  assert.equal(materialColorForBiome('fire', 'M_TopGrass', 1), 'rgb(82,74,65)');
  assert.equal(materialColorForBiome('forest', 'M_TopGrass', 1), 'rgb(83,120,90)');
  assert.equal(materialColorForBiome('ice', 'M_ElementCrack', 1), 'rgb(104,205,255)');
});

test('dense hero meshes use quieter wire strokes so detail reads as terrain instead of scratch noise', () => {
  assert.equal(meshWireAlphaForFaceCount(1536), 0.035);
  assert.ok(meshWireAlphaForFaceCount(22272) < 0.016);
});
