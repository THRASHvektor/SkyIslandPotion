import test from 'node:test';
import assert from 'node:assert/strict';

import {
  buildMeshyRoundtripCreateRequest,
  meshyResultGlbUrl,
  MESHY_TEXT_STYLE_PROMPT_MAX_LENGTH,
  sanitizeMeshyRoundtripTask,
} from './meshy_roundtrip.mjs';

test('buildMeshyRoundtripCreateRequest creates a safe retexture payload shape', () => {
  const request = buildMeshyRoundtripCreateRequest({
    operation: 'retexture',
    modelDataUri: 'data:model/gltf-binary;base64,AAAA',
    prompt: 'make orbit metal brighter',
    options: { hdTexture: true },
  });

  assert.equal(request.endpointPath, '/retexture');
  assert.equal(request.payload.model_url, 'data:model/gltf-binary;base64,AAAA');
  assert.equal(request.payload.text_style_prompt, 'make orbit metal brighter');
  assert.equal(request.payload.enable_pbr, true);
  assert.equal(request.payload.hd_texture, true);
  assert.deepEqual(request.payload.target_formats, ['glb']);
});

test('buildMeshyRoundtripCreateRequest creates a conservative remesh payload shape', () => {
  const request = buildMeshyRoundtripCreateRequest({
    operation: 'remesh',
    modelDataUri: 'data:model/gltf-binary;base64,AAAA',
    prompt: 'smooth tiny artifacts',
    options: { targetPolycount: 50000 },
  });

  assert.equal(request.endpointPath, '/remesh');
  assert.equal(request.payload.model_url, 'data:model/gltf-binary;base64,AAAA');
  assert.equal(request.payload.target_polycount, 50000);
  assert.equal(request.payload.topology, 'triangle');
  assert.deepEqual(request.payload.target_formats, ['glb']);
});

test('buildMeshyRoundtripCreateRequest rejects overlong retexture prompts before hitting Meshy', () => {
  assert.throws(
    () => buildMeshyRoundtripCreateRequest({
      operation: 'retexture',
      modelDataUri: 'data:model/gltf-binary;base64,AAAA',
      prompt: 'x'.repeat(MESHY_TEXT_STYLE_PROMPT_MAX_LENGTH + 1),
    }),
    /maximum is 800/,
  );
});

test('sanitizeMeshyRoundtripTask removes URLs but keeps useful task state', () => {
  const task = sanitizeMeshyRoundtripTask({
    id: 'task-1',
    status: 'SUCCEEDED',
    progress: 100,
    consumed_credits: 10,
    model_url: 'https://assets.meshy.ai/model.glb?Signature=secret',
    model_urls: {
      glb: 'https://assets.meshy.ai/model.glb?Signature=secret',
      obj: 'https://assets.meshy.ai/model.obj?Signature=secret',
    },
    texture_urls: [{ base_color: 'https://assets.meshy.ai/texture.png?Signature=secret' }],
    thumbnail_url: 'https://assets.meshy.ai/preview.png?Signature=secret',
  });

  assert.equal(task.id, 'task-1');
  assert.equal(task.status, 'SUCCEEDED');
  assert.equal(task.progress, 100);
  assert.equal(task.consumed_credits, 10);
  assert.deepEqual(task.returned_model_formats, ['glb', 'obj']);
  assert.equal(task.model_url, undefined);
  assert.equal(task.model_urls, undefined);
  assert.equal(task.texture_urls, undefined);
  assert.equal(task.thumbnail_url, undefined);
});

test('meshyResultGlbUrl finds the preferred GLB result URL', () => {
  assert.equal(
    meshyResultGlbUrl({
      model_urls: {
        obj: 'https://assets.meshy.ai/model.obj',
        glb: 'https://assets.meshy.ai/model.glb',
      },
    }),
    'https://assets.meshy.ai/model.glb',
  );
  assert.equal(meshyResultGlbUrl({ model_url: 'https://assets.meshy.ai/model.glb' }), 'https://assets.meshy.ai/model.glb');
  assert.equal(meshyResultGlbUrl({ model_urls: { obj: 'https://assets.meshy.ai/model.obj' } }), null);
});
