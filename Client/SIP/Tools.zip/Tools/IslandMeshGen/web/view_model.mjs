export function clamp(value, min, max) {
  return Math.min(max, Math.max(min, value));
}

const FIRE_TOP_SURFACE_MATERIALS = ['M_AshPlateau', 'M_TopGrass'];
const TOP_SURFACE_MATERIALS = new Set(['M_TopGrass', 'M_AshPlateau']);

function isTopSurfaceMaterial(material) {
  return TOP_SURFACE_MATERIALS.has(material);
}

function fireHighlightMaterials(extra = []) {
  return new Set([...FIRE_TOP_SURFACE_MATERIALS, ...extra]);
}

const PROCESS_CONTROL_LABELS = {
  detailEnergy: {
    title: 'Detail energy',
    metric: 'surface tension',
    note: 'Scales high-quality micro ridges and crust detail without changing the semantic footprint.',
  },
  erosionAge: {
    title: 'Erosion age',
    metric: 'weathering',
    note: 'Deepens flow cuts and strengthens long-lived drainage marks.',
  },
  depositionWeight: {
    title: 'Deposition weight',
    metric: 'talus build-up',
    note: 'Builds heavier scree and settled material on steep exposed bands.',
  },
};

const BIOME_CONTROL_LABELS = {
  fire: {
    volcanoDominance: {
      title: 'Volcano height',
      metric: 'rim lift',
      note: 'Raises the cone and crater rim that define the island silhouette.',
    },
    volcanoRadius: {
      title: 'Crater footprint',
      metric: 'terrain radius',
      note: 'Controls how much of the island is occupied by the volcanic body.',
    },
    mainPathWidth: {
      title: 'Approach width',
      metric: 'route width',
      note: 'Widens or narrows the readable walkable route into the crater.',
    },
    lavaCount: {
      title: 'Lava branches',
      metric: 'hazard count',
      note: 'Controls radial elemental cracks exported as hazard masks.',
    },
    loopCoverage: {
      title: 'Crater loop',
      metric: 'ring coverage',
      note: 'Sets how much combat path wraps around the crater arena.',
    },
    ...PROCESS_CONTROL_LABELS,
  },
  forest: {
    rootDominance: {
      title: 'Root arch mass',
      metric: 'root lift',
      note: 'Raises the baked root ridge so the forest reads as grown terrain, not a flat park.',
    },
    stumpCaveDominance: {
      title: 'Stump cave',
      metric: 'entrance cut',
      note: 'Controls the recessed tree-stump cave landmark and its surrounding terrain lip.',
    },
    mushroomPocketOuter: {
      title: 'Mushroom pocket',
      metric: 'pocket radius',
      note: 'Expands the bowl and raised rim used for PCG mushroom clusters.',
    },
    vineBridgeWidth: {
      title: 'Vine bridge',
      metric: 'route width',
      note: 'Widens the elevated vine-route mask so the bridge reads before props arrive.',
    },
    vineAnchorDominance: {
      title: 'Vine anchor',
      metric: 'ledge lift',
      note: 'Raises the attachment ledge where modular vine or root pieces can hide seams.',
    },
    canopyPlatformOuter: {
      title: 'Canopy platform',
      metric: 'arena radius',
      note: 'Sets the calm central platform radius before the forest breaks into roots and pockets.',
    },
    mainPathWidth: {
      title: 'Forest path',
      metric: 'route width',
      note: 'Controls the readable walkable route through the root arch and stump cave.',
    },
    ...PROCESS_CONTROL_LABELS,
    detailEnergy: {
      title: 'Root detail',
      metric: 'bark ridges',
      note: 'Scales root grain, mossy shelf noise, and pocket rim detail without moving the semantic anchors.',
    },
    erosionAge: {
      title: 'Root collapse',
      metric: 'pit depth',
      note: 'Deepens stump hollows, mushroom-pocket pits, and root-collapse cuts instead of lava-like flow channels.',
    },
    depositionWeight: {
      title: 'Forest fill',
      metric: 'organic build-up',
      note: 'Builds heavier soil lips and settled organic material around exposed roots and cave rims.',
    },
  },
  ice: {
    crystalWallRadius: {
      title: 'Crystal wall ring',
      metric: 'skyline radius',
      note: 'Moves the main ice wall inward or outward to change the island silhouette.',
    },
    crystalWallDominance: {
      title: 'Crystal wall height',
      metric: 'ridge lift',
      note: 'Raises the faceted wall mass that sells the glacier landmark from a distance.',
    },
    resourceClusterCount: {
      title: 'Resource clusters',
      metric: 'landmark count',
      note: 'Controls how many readable crystal-cluster regions are baked into the whitebox.',
    },
    resourceClusterRadius: {
      title: 'Resource radius',
      metric: 'cluster reach',
      note: 'Expands individual hard-material crystal cluster footprints.',
    },
    centralShelfWidth: {
      title: 'Central shelf',
      metric: 'arena width',
      note: 'Sets the readable flat combat shelf before cracks and plates interrupt it.',
    },
    brokenIceRingRadius: {
      title: 'Broken plate ring',
      metric: 'fracture radius',
      note: 'Moves the raised broken-ice step ring that gives the island layered topology.',
    },
    deepCrackOuter: {
      title: 'Deep crack reach',
      metric: 'hazard radius',
      note: 'Controls how far the deep blue crack hazard bands can travel outward.',
    },
    ...PROCESS_CONTROL_LABELS,
    detailEnergy: {
      title: 'Ice facets',
      metric: 'blade detail',
      note: 'Scales serrated crystal edges, chipped plates, and hard glacier facets without moving the anchors.',
    },
    erosionAge: {
      title: 'Crevasse depth',
      metric: 'fracture cut',
      note: 'Opens deeper crevasses and sharper crack shoulders rather than slow volcanic drainage marks.',
    },
    depositionWeight: {
      title: 'Snow pack',
      metric: 'drift build-up',
      note: 'Builds snow and ice rubble on exposed ledges while keeping the fracture cuts readable.',
    },
  },
};

const PROCESS_CONTROL_RANGES = {
  detailEnergy: { min: 0, max: 1.4, step: 0.01 },
  erosionAge: { min: 0, max: 1, step: 0.01 },
  depositionWeight: { min: 0, max: 1, step: 0.01 },
};

const BIOME_CONTROL_RANGES = {
  fire: {
    volcanoDominance: { min: 0.35, max: 1.2, step: 0.01 },
    volcanoRadius: { min: 0.28, max: 0.58, step: 0.01 },
    mainPathWidth: { min: 0.06, max: 0.55, step: 0.01 },
    loopCoverage: { min: 0, max: 1, step: 0.01 },
    lavaCount: { min: 1, max: 5, step: 1 },
    ...PROCESS_CONTROL_RANGES,
  },
  forest: {
    rootDominance: { min: 0.2, max: 1.1, step: 0.01 },
    stumpCaveDominance: { min: 0.2, max: 1.1, step: 0.01 },
    mushroomPocketOuter: { min: 0.26, max: 0.56, step: 0.01 },
    vineBridgeWidth: { min: 0.04, max: 0.18, step: 0.01 },
    vineAnchorDominance: { min: 0.12, max: 0.8, step: 0.01 },
    canopyPlatformOuter: { min: 0.3, max: 0.6, step: 0.01 },
    mainPathWidth: { min: 0.06, max: 0.35, step: 0.01 },
    ...PROCESS_CONTROL_RANGES,
  },
  ice: {
    crystalWallRadius: { min: 0.35, max: 0.72, step: 0.01 },
    crystalWallDominance: { min: 0.35, max: 1.1, step: 0.01 },
    resourceClusterCount: { min: 1, max: 8, step: 1 },
    resourceClusterRadius: { min: 0.28, max: 0.7, step: 0.01 },
    centralShelfWidth: { min: 0.2, max: 0.52, step: 0.01 },
    brokenIceRingRadius: { min: 0.45, max: 0.8, step: 0.01 },
    deepCrackOuter: { min: 0.58, max: 0.98, step: 0.01 },
    ...PROCESS_CONTROL_RANGES,
  },
};

export function biomeControlLabels(biome = 'fire') {
  return BIOME_CONTROL_LABELS[biome] || BIOME_CONTROL_LABELS.fire;
}

export function biomeControlRanges(biome = 'fire') {
  return BIOME_CONTROL_RANGES[biome] || BIOME_CONTROL_RANGES.fire;
}

export function volcanoControlLabels() {
  return biomeControlLabels('fire');
}

export function volcanoControlRanges() {
  return biomeControlRanges('fire');
}

const CONTROL_GROUP_ORDER = ['Form', 'Routes', 'PCG', 'Hazards', 'Process'];

export function controlGroupTabs(controls, groupOrder = CONTROL_GROUP_ORDER) {
  const groups = new Map();
  for (const control of controls || []) {
    const group = String(control?.group || '').trim();
    if (!group) continue;
    groups.set(group, (groups.get(group) || 0) + 1);
  }

  const orderedGroups = [
    ...groupOrder.filter((group) => groups.has(group)),
    ...Array.from(groups.keys()).filter((group) => !groupOrder.includes(group)),
  ];

  return orderedGroups.map((group) => ({
    id: group,
    label: group,
    count: groups.get(group),
  }));
}

export function controlsForActiveGroup(controls, activeGroup, groupOrder = CONTROL_GROUP_ORDER) {
  const tabs = controlGroupTabs(controls, groupOrder);
  const activeGroupIsVisible = tabs.some((tab) => tab.id === activeGroup);
  const resolvedGroup = activeGroupIsVisible ? activeGroup : (tabs[0]?.id || '');
  return {
    activeGroup: resolvedGroup,
    tabs,
    controls: (controls || []).filter((control) => control.group === resolvedGroup),
  };
}

export function clampOrbitCamera(camera) {
  return {
    yaw: Number.isFinite(camera.yaw) ? camera.yaw : 0,
    pitch: clamp(Number.isFinite(camera.pitch) ? camera.pitch : -0.72, -1.2, -0.18),
    zoom: clamp(Number.isFinite(camera.zoom) ? camera.zoom : 1, 0.55, 2.4),
    panX: Number.isFinite(camera.panX) ? camera.panX : 0,
    panY: Number.isFinite(camera.panY) ? camera.panY : 0,
  };
}

export function defaultOrbitCamera() {
  return clampOrbitCamera({ yaw: 0, pitch: -0.72, zoom: 1, panX: 0, panY: 0 });
}

export function yawLabel(yaw) {
  const degrees = Math.round((((yaw * 180) / Math.PI) % 360 + 360) % 360);
  return `Yaw ${degrees} deg`;
}

export function bakeButtonLabel(biome, state = {}) {
  const name = String(biome || '').replace(/_/g, ' ').replace(/\b\w/g, (letter) => letter.toUpperCase());
  if (state.generating) return `Baking ${name}...`;
  if (state.previewing) return 'Preview baking...';
  if (state.dirty) return `Bake ${name} Changes`;
  return `Bake ${name} Mesh`;
}

function quantizeNumber(value, step) {
  return Number((Math.round((value + Number.EPSILON) / step) * step).toFixed(4));
}

function quantizeForPreview(value, step) {
  if (typeof value === 'number') return quantizeNumber(value, step);
  if (Array.isArray(value)) return value.map((item) => quantizeForPreview(item, step));
  if (value && typeof value === 'object') {
    return Object.fromEntries(
      Object.entries(value).map(([key, item]) => [key, quantizeForPreview(item, step)]),
    );
  }
  return value;
}

export function previewQualityForBakeQuality(rawQuality = 'draft') {
  const quality = String(rawQuality || 'draft').toLowerCase();
  return quality === 'draft' ? 'draft' : 'preview';
}

const FINAL_BAKE_QUALITIES = new Set(['draft', 'preview', 'production', 'hero']);

function normalizeFinalBakeQuality(rawQuality = 'production') {
  const quality = String(rawQuality || 'production').toLowerCase();
  return FINAL_BAKE_QUALITIES.has(quality) ? quality : 'production';
}

function qualityDisplayLabel(quality) {
  return String(quality || 'production').toUpperCase();
}

export function previewQualityStatusForBakeQuality(rawQuality = 'production') {
  const finalQuality = normalizeFinalBakeQuality(rawQuality);
  const realtimeQuality = previewQualityForBakeQuality(finalQuality);
  const finalLabel = qualityDisplayLabel(finalQuality);
  const realtimeLabel = qualityDisplayLabel(realtimeQuality);
  const isRealtimeCapped = realtimeQuality !== finalQuality;
  return {
    finalQuality,
    finalLabel,
    realtimeQuality,
    realtimeLabel,
    inspectLabel: `Inspect ${finalLabel}`,
    isRealtimeCapped,
    idleStatus: isRealtimeCapped
      ? `Realtime ${realtimeLabel}; inspect ${finalLabel} for final topology`
      : `Realtime ${realtimeLabel} matches final topology`,
    currentStatus: `${finalLabel} snapshot current`,
    staleStatus: `${finalLabel} snapshot stale`,
  };
}

export function inspectBakeSignature(layout, options = {}) {
  const optionBag = options && typeof options === 'object' ? options : {};
  const step = typeof options === 'number'
    ? options
    : (Number.isFinite(optionBag.step) ? optionBag.step : 0.01);
  const quality = ['draft', 'preview', 'production', 'hero'].includes(String(optionBag.quality || '').toLowerCase())
    ? String(optionBag.quality).toLowerCase()
    : 'production';
  return JSON.stringify({
    quality,
    layout: quantizeForPreview(layout, step),
  });
}

export function previewBakeSignature(layout, options = {}) {
  const optionBag = options && typeof options === 'object' ? options : {};
  const step = typeof options === 'number'
    ? options
    : (Number.isFinite(optionBag.step) ? optionBag.step : 0.01);
  const quality = options && typeof options === 'object'
    ? previewQualityForBakeQuality(optionBag.quality || 'draft')
    : 'draft';
  return JSON.stringify({
    quality,
    layout: quantizeForPreview(layout, step),
  });
}

export function dragOrbitCamera(camera, deltaX, deltaY) {
  return clampOrbitCamera({
    ...camera,
    yaw: camera.yaw + deltaX * 0.006,
    pitch: camera.pitch + deltaY * 0.004,
  });
}

export function wheelOrbitCamera(camera, deltaY) {
  return clampOrbitCamera({
    ...camera,
    zoom: camera.zoom - deltaY * 0.001,
  });
}

export function semanticLegendForLayout(layout) {
  if (layout?.biome === 'fire') {
    return [
      {
        id: 'central_volcano',
        code: 'CV',
        label: 'Central volcano',
        color: '#ff6a38',
        description: 'volcano height and crater footprint controls',
      },
      {
        id: 'main_approach',
        code: 'AP',
        label: 'Approach route',
        color: '#d6a15a',
        description: 'approach width control and walkable route mask',
      },
      {
        id: 'partial_crater_loop',
        code: 'CL',
        label: 'Crater loop',
        color: '#ffcd7c',
        description: 'ring coverage control around the crater arena',
      },
      {
        id: 'lava_channels',
        code: 'LC',
        label: 'Lava channels',
        color: '#ff6438',
        description: 'lava branch count and elemental crack hazard',
      },
    ];
  }

  if (layout?.biome === 'ice') {
    return [
      {
        id: 'primary_crystal_wall',
        code: 'IW',
        label: 'Crystal wall',
        color: '#8eefff',
        description: 'tall ice blade crown and skyline radius',
      },
      {
        id: 'central_shelf',
        code: 'CS',
        label: 'Central shelf',
        color: '#e7fbff',
        description: 'bright playable ice arena and stable approach shelf',
      },
      {
        id: 'broken_ice_ring',
        code: 'BP',
        label: 'Broken plate ring',
        color: '#b9e8ff',
        description: 'angular fractured loop around the central shelf',
      },
      {
        id: 'deep_cracks',
        code: 'CR',
        label: 'Deep cracks',
        color: '#47bce9',
        description: 'sharp crevasse hazard cuts and raised shoulders',
      },
      {
        id: 'resource_crystals',
        code: 'RC',
        label: 'Resource crystals',
        color: '#d7fbff',
        description: 'secondary crystal cluster landmarks for gathering and PBR accents',
      },
    ];
  }

  if (layout?.biome === 'forest') {
    return [
      {
        id: 'canopy_platform',
        code: 'CP',
        label: 'Canopy platform',
        color: '#73d66f',
        description: 'soft playable tree-canopy island crown',
      },
      {
        id: 'root_arch',
        code: 'RA',
        label: 'Root arch',
        color: '#a7d76b',
        description: 'raised giant-root ridge and traversal landmark',
      },
      {
        id: 'tree_stump_cave',
        code: 'SC',
        label: 'Stump cave',
        color: '#9b7a52',
        description: 'hollow tree-stump cave cut with lifted rim',
      },
      {
        id: 'mushroom_pocket',
        code: 'MP',
        label: 'Mushroom pocket',
        color: '#b87dff',
        description: 'lush bowl pocket for mushroom and resource scatter',
      },
      {
        id: 'vine_bridge',
        code: 'VB',
        label: 'Vine bridge',
        color: '#65d4a0',
        description: 'thin elevated route between root and canopy anchors',
      },
    ];
  }

  const entries = [];
  const seen = new Set();
  const add = (entry) => {
    if (!seen.has(entry.id)) {
      seen.add(entry.id);
      entries.push(entry);
    }
  };

  for (const zone of layout.zones || []) {
    if (zone.kind === 'arena') {
      add({
        id: 'arena',
        label: 'Walkable arena',
        color: '#8d94a3',
        description: 'playable surface exported as a walkable zone',
      });
    } else if (zone.kind === 'hazard' || zone.walkable === false) {
      add({
        id: 'hazard',
        label: 'Hazard mask',
        color: '#ff6438',
        description: 'blocks traversal and exports as a hazard zone',
      });
    } else if (zone.kind === 'resource' || zone.kind === 'pcg') {
      add({
        id: 'pcg',
        label: 'PCG scatter area',
        color: '#68d391',
        description: 'feeds resource, foliage, or attachment scattering',
      });
    }
  }

  if ((layout.paths || []).length) {
    add({
      id: 'route',
      label: 'Route',
      color: '#d6a15a',
      description: 'walkable path carved into the heightfield',
    });
  }

  for (const landmark of layout.landmarks || []) {
    if (landmark.bake_mode === 'attachment') {
      add({
        id: 'attachment',
        label: 'Attachment anchor',
        color: '#9ee7b3',
        description: 'semantic socket for authored props or cave entrances',
      });
    } else {
      add({
        id: 'landmark',
        label: 'Terrain landmark',
        color: '#ff5a2d',
        description: 'large form baked into the terrain mesh',
      });
    }
  }

  return entries;
}

export function semanticBadgesForLayout(layout) {
  const badges = [];
  const add = (entry) => {
    if (!badges.some((badge) => badge.code === entry.code)) badges.push(entry);
  };

  const zones = layout.zones || [];
  const paths = layout.paths || [];
  const landmarks = layout.landmarks || [];

  if (layout.biome === 'fire') {
    const volcano = landmarks.find((item) => item.id === 'central_volcano');
    const approach = paths.find((path) => path.id === 'main_approach');
    const loop = paths.find((path) => path.id === 'partial_crater_loop');
    const lava = landmarks.find((item) => item.id === 'lava_channels');
    if (volcano) add({ id: volcano.id, code: 'CV', label: 'Volcano' });
    if (approach) add({ id: approach.id, code: 'AP', label: 'Approach' });
    if (loop) add({ id: loop.id, code: 'CL', label: 'Loop' });
    if (lava) add({ id: lava.id, code: 'LC', label: 'Lava' });
    return badges.slice(0, 4);
  }

  if (layout.biome === 'ice') {
    const wall = landmarks.find((item) => item.id === 'primary_crystal_wall');
    const shelf = paths.find((path) => path.id === 'central_shelf') || zones.find((zone) => zone.id === 'central_ice_shelf');
    const plate = paths.find((path) => path.id === 'broken_ice_ring');
    const cracks = zones.find((zone) => zone.id === 'deep_cracks');
    const crystals = zones.find((zone) => zone.id === 'resource_crystals') || landmarks.find((item) => item.id === 'secondary_spire_clusters');
    if (wall) add({ id: wall.id, code: 'IW', label: 'Crystal wall' });
    if (shelf) add({ id: shelf.id, code: 'CS', label: 'Central shelf' });
    if (plate) add({ id: plate.id, code: 'BP', label: 'Broken plate' });
    if (cracks) add({ id: cracks.id, code: 'CR', label: 'Deep cracks' });
    if (crystals) add({ id: crystals.id, code: 'RC', label: 'Resource crystals' });
    return badges.slice(0, 5);
  }

  if (layout.biome === 'forest') {
    const canopy = zones.find((zone) => zone.id === 'canopy_platform');
    const root = landmarks.find((item) => item.id === 'root_arch');
    const cave = landmarks.find((item) => item.id === 'tree_stump_cave') || zones.find((zone) => zone.id === 'glowing_root_cave');
    const mushroom = zones.find((zone) => zone.id === 'mushroom_pocket');
    const vine = paths.find((path) => path.id === 'vine_bridge');
    if (canopy) add({ id: canopy.id, code: 'CP', label: 'Canopy' });
    if (root) add({ id: root.id, code: 'RA', label: 'Root arch' });
    if (cave) add({ id: cave.id, code: 'SC', label: 'Stump cave' });
    if (mushroom) add({ id: mushroom.id, code: 'MP', label: 'Mushroom pocket' });
    if (vine) add({ id: vine.id, code: 'VB', label: 'Vine bridge' });
    return badges.slice(0, 5);
  }

  const arena = zones.find((zone) => zone.kind === 'arena' && zone.walkable !== false);
  if (arena) add({ id: arena.id, code: 'AR', label: 'Arena' });

  const hazard = zones.find((zone) => zone.kind === 'hazard' || zone.walkable === false);
  if (hazard) add({ id: hazard.id, code: 'HZ', label: 'Hazard' });

  const resource = zones.find((zone) => zone.kind === 'resource' || zone.kind === 'pcg');
  if (resource) add({ id: resource.id, code: 'PC', label: 'PCG area' });

  const route = paths.find((path) => path.kind?.includes('main')) || paths[0];
  if (route) add({ id: route.id, code: 'RT', label: 'Route' });

  const landmark = landmarks.find((item) => item.bake_mode === 'terrain') || landmarks[0];
  if (landmark) add({ id: landmark.id, code: 'LM', label: 'Landmark' });

  return badges.slice(0, 4);
}

function rotateTopDown(vertex, rotation) {
  const cos = Math.cos(rotation);
  const sin = Math.sin(rotation);
  return {
    x: vertex[0] * cos - vertex[1] * sin,
    y: vertex[0] * sin + vertex[1] * cos,
  };
}

function roundPixel(value) {
  return Number(value.toFixed(4));
}

export function topDownFrameForMesh(vertices, width, height, padding = 30, rotation = 0) {
  const bounds = vertices.reduce((acc, vertex) => {
    const point = rotateTopDown(vertex, rotation);
    acc.minX = Math.min(acc.minX, point.x);
    acc.maxX = Math.max(acc.maxX, point.x);
    acc.minY = Math.min(acc.minY, point.y);
    acc.maxY = Math.max(acc.maxY, point.y);
    return acc;
  }, { minX: Infinity, maxX: -Infinity, minY: Infinity, maxY: -Infinity });
  const spanX = Math.max(bounds.maxX - bounds.minX, 0.001);
  const spanY = Math.max(bounds.maxY - bounds.minY, 0.001);
  return {
    centerX: (bounds.minX + bounds.maxX) / 2,
    centerY: (bounds.minY + bounds.maxY) / 2,
    scale: Math.min((width - padding * 2) / spanX, (height - padding * 2) / spanY),
    width,
    height,
    rotation,
  };
}

export function stableTopDownFrameForMesh(vertices, width, height, padding = 30, rotation = 0) {
  const bounds = vertices.reduce((acc, vertex) => {
    acc.minX = Math.min(acc.minX, vertex[0]);
    acc.maxX = Math.max(acc.maxX, vertex[0]);
    acc.minY = Math.min(acc.minY, vertex[1]);
    acc.maxY = Math.max(acc.maxY, vertex[1]);
    return acc;
  }, { minX: Infinity, maxX: -Infinity, minY: Infinity, maxY: -Infinity });
  const centerX = (bounds.minX + bounds.maxX) / 2;
  const centerY = (bounds.minY + bounds.maxY) / 2;
  const radius = vertices.reduce((maxRadius, vertex) => {
    return Math.max(maxRadius, Math.hypot(vertex[0] - centerX, vertex[1] - centerY));
  }, 0.001);
  const rotatedCenter = rotateTopDown([centerX, centerY], rotation);
  return {
    centerX: rotatedCenter.x,
    centerY: rotatedCenter.y,
    scale: (Math.min(width, height) - padding * 2) / (radius * 2),
    width,
    height,
    rotation,
  };
}

export function projectTopDownVertex(vertex, frame) {
  const point = rotateTopDown(vertex, frame.rotation || 0);
  return {
    x: roundPixel(frame.width * 0.5 + (point.x - frame.centerX) * frame.scale),
    y: roundPixel(frame.height * 0.5 - (point.y - frame.centerY) * frame.scale),
  };
}

const FOOTPRINT_RADIUS_CACHE = new WeakMap();

export function footprintRadiusForMesh(vertices) {
  if (!Array.isArray(vertices)) return 0.001;
  const cached = FOOTPRINT_RADIUS_CACHE.get(vertices);
  if (cached) return cached;

  const radius = vertices.reduce((maxRadius, vertex) => {
    const vertexRadius = Math.hypot(vertex[0], vertex[1]);
    return Math.max(maxRadius, vertexRadius);
  }, 0.001);
  FOOTPRINT_RADIUS_CACHE.set(vertices, radius);
  return radius;
}

export function layoutPointToTopDown(point, frame, footprintRadius) {
  return projectTopDownVertex([
    Number(point[0] || 0) * footprintRadius,
    Number(point[1] || 0) * footprintRadius,
    0,
  ], frame);
}

function findById(items = [], id) {
  return items.find((item) => item.id === id);
}

const ICE_WALL_ANGLES = [1.18, 4.18, 0.28, 5.25];
const ICE_CLUSTER_ANGLES = [0.28, 2.05, 5.25, 3.08, 4.18, 1.18, 0.92, 3.82];
const ICE_CRACK_ANGLES = [0.78, 2.55, 4.75];

function countSlice(values, count, fallbackCount = values.length) {
  const resolved = Math.max(1, Math.min(values.length, Math.round(Number(count) || fallbackCount)));
  return values.slice(0, resolved);
}

function pathPoints(path, fallback = [[0, 0]]) {
  return Array.isArray(path?.points) && path.points.length
    ? path.points.map((point) => [Number(point[0] || 0), Number(point[1] || 0)])
    : fallback;
}

function radiusRangeOuter(zone, fallback) {
  return Array.isArray(zone?.radius_range) && Number.isFinite(Number(zone.radius_range[1]))
    ? Number(zone.radius_range[1])
    : fallback;
}

export function fireLiveOverlaySpec(layout) {
  if (layout.biome !== 'fire') return { enabled: false };
  const volcano = findById(layout.landmarks, 'central_volcano') || {};
  const lava = findById(layout.landmarks, 'lava_channels') || {};
  const mainPath = findById(layout.paths, 'main_approach') || {};
  const loop = findById(layout.paths, 'partial_crater_loop') || {};
  const lavaCount = Math.max(1, Math.round(lava.count || 1));
  return {
    enabled: true,
    craterRadius: Number(volcano.radius ?? 0.42),
    craterLift: Number(volcano.dominance ?? 0.85),
    pathWidth: Number(mainPath.width ?? 0.12),
    loopWidth: Number(loop.width ?? 0.08),
    loopCoverage: Number(loop.coverage ?? 0.55),
    lavaRadius: Number(lava.radius ?? 0.82),
    lavaAngles: Array.from({ length: lavaCount }, (_, index) => Number((0.42 + Math.PI * 2 * index / lavaCount).toFixed(2))),
  };
}

export function iceLiveOverlaySpec(layout) {
  if (layout?.biome !== 'ice') return { enabled: false };
  const wall = findById(layout.landmarks, 'primary_crystal_wall') || {};
  const crystals = findById(layout.landmarks, 'secondary_spire_clusters') || {};
  const shelfPath = findById(layout.paths, 'central_shelf') || {};
  const plate = findById(layout.paths, 'broken_ice_ring') || {};
  const shelfZone = findById(layout.zones, 'central_ice_shelf') || {};
  const crackZone = findById(layout.zones, 'deep_cracks') || {};
  const resourceZone = findById(layout.zones, 'resource_crystals') || {};
  return {
    enabled: true,
    biome: 'ice',
    wallRadius: Number(wall.radius ?? 0.54),
    wallDominance: Number(wall.dominance ?? 0.86),
    wallAngles: countSlice(ICE_WALL_ANGLES, wall.count, 4),
    centralShelfRadius: radiusRangeOuter(shelfZone, Number(shelfPath.width ?? 0.34)),
    plateRadius: Number(pathPoints(plate, [[0.62, 0]])[0][0] || 0.62),
    plateWidth: Number(plate.width ?? 0.1),
    crackInnerRadius: Array.isArray(crackZone.radius_range) ? Number(crackZone.radius_range[0] ?? 0.42) : 0.42,
    crackOuterRadius: radiusRangeOuter(crackZone, 0.92),
    crackAngles: ICE_CRACK_ANGLES,
    resourceInnerRadius: Array.isArray(resourceZone.radius_range) ? Number(resourceZone.radius_range[0] ?? 0.38) : 0.38,
    resourceOuterRadius: radiusRangeOuter(resourceZone, 0.76),
    resourceRadius: Number(crystals.radius ?? 0.48),
    resourceAngles: countSlice(ICE_CLUSTER_ANGLES, crystals.count, 4),
  };
}

export function forestLiveOverlaySpec(layout) {
  if (layout?.biome !== 'forest') return { enabled: false };
  const canopy = findById(layout.zones, 'canopy_platform') || {};
  const root = findById(layout.landmarks, 'root_arch') || {};
  const stump = findById(layout.landmarks, 'tree_stump_cave') || {};
  const mushroom = findById(layout.zones, 'mushroom_pocket') || {};
  const mainPath = findById(layout.paths, 'forest_main_path') || {};
  const vine = findById(layout.paths, 'vine_bridge') || {};
  return {
    enabled: true,
    biome: 'forest',
    canopyCenter: Array.isArray(canopy.center) ? canopy.center : [0, 0],
    canopyRadius: radiusRangeOuter(canopy, 0.44),
    rootCenter: Array.isArray(root.center) ? root.center : [0.35, -0.1],
    rootRadius: Number(root.radius ?? 0.22),
    stumpCenter: Array.isArray(stump.center) ? stump.center : [-0.25, 0.25],
    stumpRadius: Number(stump.radius ?? 0.2),
    mushroomCenter: Array.isArray(mushroom.center) ? mushroom.center : [0.28, 0.34],
    mushroomInnerRadius: Array.isArray(mushroom.radius_range) ? Number(mushroom.radius_range[0] ?? 0.18) : 0.18,
    mushroomOuterRadius: radiusRangeOuter(mushroom, 0.42),
    mainPathPoints: pathPoints(mainPath, [[0.9, 0], [0.35, -0.1], [-0.25, 0.25]]),
    mainPathWidth: Number(mainPath.width ?? 0.14),
    vineBridgePoints: pathPoints(vine, [[0.62, 0.18], [0.2, 0.42]]),
    vineBridgeWidth: Number(vine.width ?? 0.08),
  };
}

export function biomeLiveOverlaySpec(layout) {
  if (layout?.biome === 'fire') return { ...fireLiveOverlaySpec(layout), biome: 'fire' };
  if (layout?.biome === 'ice') return iceLiveOverlaySpec(layout);
  if (layout?.biome === 'forest') return forestLiveOverlaySpec(layout);
  return { enabled: false };
}

function smoothstep(edge0, edge1, value) {
  if (edge0 === edge1) return value >= edge1 ? 1 : 0;
  const x = clamp((value - edge0) / (edge1 - edge0), 0, 1);
  return x * x * (3 - 2 * x);
}

function angleDistance(a, b) {
  return Math.abs(Math.atan2(Math.sin(a - b), Math.cos(a - b)));
}

const PROCESS_HIGHLIGHT_SPECS = {
  detailEnergy: {
    traceKind: 'slope',
    label: 'Surface detail highlighted',
    threshold: 0.34,
    fillRgb: [156, 226, 238],
    strokeRgb: [223, 252, 255],
    alphaBase: 0.07,
    alphaRange: 0.25,
    strokeAlphaBase: 0.16,
    strokeAlphaRange: 0.36,
    lineWidth: 0.85,
    drawVertices: false,
  },
  erosionAge: {
    traceKind: 'lavaFlow',
    label: 'Erosion flow highlighted',
    threshold: 0.28,
    fillRgb: [255, 96, 38],
    strokeRgb: [255, 168, 94],
    alphaBase: 0.09,
    alphaRange: 0.31,
    strokeAlphaBase: 0.18,
    strokeAlphaRange: 0.42,
    lineWidth: 1.05,
    drawVertices: false,
  },
  depositionWeight: {
    traceKind: 'talus',
    label: 'Talus deposition highlighted',
    threshold: 0.26,
    fillRgb: [238, 178, 88],
    strokeRgb: [255, 226, 150],
    alphaBase: 0.09,
    alphaRange: 0.29,
    strokeAlphaBase: 0.18,
    strokeAlphaRange: 0.38,
    lineWidth: 1,
    drawVertices: false,
  },
};

function processHighlightSpec(controlId) {
  return PROCESS_HIGHLIGHT_SPECS[controlId] || null;
}

export function processHighlightSpecForControl(controlId) {
  const spec = processHighlightSpec(controlId);
  if (!spec) return null;
  return {
    ...spec,
    fillRgb: [...spec.fillRgb],
    strokeRgb: [...spec.strokeRgb],
  };
}

function rgbaFromChannels(channels, alpha) {
  return `rgba(${channels.map((channel) => Math.round(clamp(channel, 0, 255))).join(', ')}, ${Number(clamp(alpha, 0, 1).toFixed(3))})`;
}

export function processMovementHighlightStyle(controlId, influence, options = {}) {
  const spec = processHighlightSpec(controlId);
  if (!spec) return null;
  const amount = clamp(Number(influence) || 0, 0, 1);
  const pulse = clamp(Number(options.pulse) || 0, 0, 1);
  return {
    traceKind: spec.traceKind,
    label: spec.label,
    fill: rgbaFromChannels(spec.fillRgb, spec.alphaBase + amount * spec.alphaRange + pulse * 0.05),
    stroke: rgbaFromChannels(spec.strokeRgb, spec.strokeAlphaBase + amount * spec.strokeAlphaRange + pulse * 0.08),
    lineWidth: spec.lineWidth,
    drawVertices: spec.drawVertices,
  };
}

export function fireMovementInfluenceForVertex(vertex, layout, footprintRadius = 1, controlId = 'all') {
  if (!vertex || layout?.biome !== 'fire') return 0;
  const spec = fireLiveOverlaySpec(layout);
  if (!spec.enabled) return 0;

  const radius = Math.max(0.001, footprintRadius);
  const x = vertex[0] / radius;
  const y = vertex[1] / radius;
  const radialAlpha = Math.hypot(x, y);
  const angle = Math.atan2(y, x);
  const signedAngle = Math.abs(Math.atan2(Math.sin(angle), Math.cos(angle)));
  const craterRadius = clamp(spec.craterRadius, 0.12, 0.9);

  const rimBand = 1 - smoothstep(0.035, 0.14, Math.abs(radialAlpha - craterRadius));
  const coneBand = 1 - smoothstep(craterRadius * 0.36, Math.min(0.94, craterRadius * 1.55), radialAlpha);
  const pathBand = (1 - smoothstep(spec.pathWidth * 0.25, spec.pathWidth * 0.72, signedAngle))
    * smoothstep(0.08, 0.92, radialAlpha);
  const loopBand = (1 - smoothstep(0.035, 0.12, Math.abs(radialAlpha - craterRadius)))
    * (1 - smoothstep(spec.loopCoverage * Math.PI, spec.loopCoverage * Math.PI + 0.12, signedAngle));
  const lavaBand = spec.lavaAngles.reduce((strongest, lavaAngle) => {
    const angular = 1 - smoothstep(0.055, 0.17, angleDistance(angle, lavaAngle));
    const radial = smoothstep(0.28, 0.95, radialAlpha);
    return Math.max(strongest, angular * radial);
  }, 0);

  if (controlId === 'volcanoDominance' || controlId === 'volcanoRadius') {
    return clamp(Math.max(rimBand, coneBand * 0.22), 0, 1);
  }
  if (controlId === 'mainPathWidth') return clamp(pathBand, 0, 1);
  if (controlId === 'loopCoverage') return clamp(loopBand, 0, 1);
  if (controlId === 'lavaCount') return clamp(lavaBand, 0, 1);

  return clamp(Math.max(rimBand, coneBand * 0.5, pathBand * 0.72, loopBand * 0.56, lavaBand * 0.82), 0, 1);
}

function highlightMaterialsForControl(controlId) {
  if (controlId === 'volcanoDominance' || controlId === 'volcanoRadius') return fireHighlightMaterials();
  if (controlId === 'mainPathWidth') return fireHighlightMaterials(['M_PathDirt']);
  if (controlId === 'loopCoverage') return fireHighlightMaterials(['M_PathDirt']);
  if (controlId === 'lavaCount') return fireHighlightMaterials(['M_PathDirt', 'M_ElementCrack']);
  return fireHighlightMaterials(['M_PathDirt', 'M_ElementCrack']);
}

export function fireMovementHighlightThreshold(controlId) {
  const processSpec = processHighlightSpec(controlId);
  if (processSpec) return processSpec.threshold;
  if (controlId === 'mainPathWidth') return 0.1;
  return 0.32;
}

export function fireMovementHighlightForFace(face, mesh, layout, footprintRadius = 1, controlId = 'all') {
  if (!face || !mesh || layout?.biome !== 'fire') return 0;
  if (!highlightMaterialsForControl(controlId).has(face.material)) return 0;
  if (!Array.isArray(face.indices) || face.indices.length === 0) return 0;

  const influence = face.indices.reduce((sum, index) => (
    sum + fireMovementInfluenceForVertex(mesh.vertices[index], layout, footprintRadius, controlId)
  ), 0) / face.indices.length;
  return clamp(influence, 0, 1);
}

function normalizedVertex(vertex, footprintRadius = 1) {
  const radius = Math.max(0.001, footprintRadius);
  const x = Number(vertex?.[0] || 0) / radius;
  const y = Number(vertex?.[1] || 0) / radius;
  return {
    x,
    y,
    radialAlpha: Math.hypot(x, y),
    angle: Math.atan2(y, x),
  };
}

function layoutPoint(point, fallback = [0, 0]) {
  const source = Array.isArray(point) ? point : fallback;
  return [
    Number(source?.[0] ?? fallback[0] ?? 0),
    Number(source?.[1] ?? fallback[1] ?? 0),
  ];
}

function distanceToLayoutPoint(x, y, point) {
  const [px, py] = layoutPoint(point);
  return Math.hypot(x - px, y - py);
}

function distanceToSegment(x, y, start, end) {
  const [sx, sy] = layoutPoint(start);
  const [ex, ey] = layoutPoint(end);
  const dx = ex - sx;
  const dy = ey - sy;
  const lengthSquared = dx * dx + dy * dy;
  if (lengthSquared <= 0.000001) return Math.hypot(x - sx, y - sy);
  const t = clamp(((x - sx) * dx + (y - sy) * dy) / lengthSquared, 0, 1);
  return Math.hypot(x - (sx + dx * t), y - (sy + dy * t));
}

function pointInfluence(x, y, point, radius, inner = 0.2, outer = 1.4) {
  const safeRadius = Math.max(0.025, Number(radius) || 0.12);
  const distance = distanceToLayoutPoint(x, y, point);
  return 1 - smoothstep(safeRadius * inner, safeRadius * outer, distance);
}

function ringInfluence(radialAlpha, radius, inner = 0.035, outer = 0.16) {
  return 1 - smoothstep(inner, outer, Math.abs(radialAlpha - Number(radius || 0)));
}

function pathInfluence(x, y, path, widthMultiplier = 1.6) {
  const points = Array.isArray(path?.points) ? path.points : [];
  if (points.length === 0) return 0;
  const width = Math.max(0.025, Number(path?.width) || 0.08) * widthMultiplier;
  if (points.length === 1) return pointInfluence(x, y, points[0], width, 0.18, 1.25);
  let closest = Infinity;
  for (let index = 0; index < points.length - 1; index += 1) {
    closest = Math.min(closest, distanceToSegment(x, y, points[index], points[index + 1]));
  }
  return 1 - smoothstep(width * 0.25, width, closest);
}

function iceClusterAngles(count) {
  return ICE_CLUSTER_ANGLES.slice(0, clamp(Math.round(Number(count) || 1), 1, ICE_CLUSTER_ANGLES.length));
}

function angularInfluence(angle, angles, inner = 0.028, outer = 0.14) {
  return angles.reduce((strongest, baseAngle) => (
    Math.max(strongest, 1 - smoothstep(inner, outer, angleDistance(angle, baseAngle)))
  ), 0);
}

function forestMovementInfluenceForVertex(vertex, layout, footprintRadius = 1, controlId = 'all') {
  if (!vertex || layout?.biome !== 'forest') return 0;
  const { x, y, radialAlpha } = normalizedVertex(vertex, footprintRadius);
  const root = findById(layout.landmarks, 'root_arch') || {};
  const stump = findById(layout.landmarks, 'tree_stump_cave') || {};
  const vineAnchor = findById(layout.landmarks, 'vine_bridge_anchor') || {};
  const mainPath = findById(layout.paths, 'forest_main_path') || {};
  const vineBridge = findById(layout.paths, 'vine_bridge') || {};
  const mushroom = findById(layout.zones, 'mushroom_pocket') || {};
  const canopy = findById(layout.zones, 'canopy_platform') || {};
  const mushroomOuter = Number(mushroom.radius_range?.[1] ?? 0.42);
  const canopyOuter = Number(canopy.radius_range?.[1] ?? 0.44);

  const rootBand = pointInfluence(x, y, root.center || [0.35, -0.1], Number(root.radius ?? 0.22), 0.10, 1.45);
  const stumpBand = pointInfluence(x, y, stump.center || [-0.25, 0.25], Number(stump.radius ?? 0.2), 0.12, 1.65);
  const vineAnchorBand = pointInfluence(x, y, vineAnchor.center || [0.62, 0.18], Number(vineAnchor.radius ?? 0.12), 0.12, 1.8);
  const canopyBand = 1 - smoothstep(Math.max(0.04, canopyOuter * 0.70), Math.max(0.1, canopyOuter * 1.08), radialAlpha);
  const mainPathBand = pathInfluence(x, y, mainPath, 1.9);
  const vineBridgeBand = pathInfluence(x, y, vineBridge, 2.1);
  const mushroomBand = pointInfluence(x, y, mushroom.center || [0.28, 0.34], mushroomOuter, 0.08, 0.98);

  if (controlId === 'rootDominance') return clamp(rootBand, 0, 1);
  if (controlId === 'stumpCaveDominance') return clamp(stumpBand, 0, 1);
  if (controlId === 'vineAnchorDominance') return clamp(vineAnchorBand, 0, 1);
  if (controlId === 'canopyPlatformOuter') return clamp(canopyBand, 0, 1);
  if (controlId === 'mainPathWidth') return clamp(mainPathBand, 0, 1);
  if (controlId === 'vineBridgeWidth') return clamp(vineBridgeBand, 0, 1);
  if (controlId === 'mushroomPocketOuter') return clamp(mushroomBand, 0, 1);

  return clamp(Math.max(
    rootBand * 0.86,
    stumpBand * 0.86,
    vineAnchorBand * 0.7,
    canopyBand * 0.35,
    mainPathBand * 0.72,
    vineBridgeBand * 0.78,
    mushroomBand * 0.88,
  ), 0, 1);
}

function iceMovementInfluenceForVertex(vertex, layout, footprintRadius = 1, controlId = 'all') {
  if (!vertex || layout?.biome !== 'ice') return 0;
  const { radialAlpha, angle } = normalizedVertex(vertex, footprintRadius);
  const wall = findById(layout.landmarks, 'primary_crystal_wall') || {};
  const resources = findById(layout.landmarks, 'secondary_spire_clusters') || {};
  const centralShelf = findById(layout.paths, 'central_shelf') || {};
  const brokenRing = findById(layout.paths, 'broken_ice_ring') || {};
  const deepCracks = findById(layout.zones, 'deep_cracks') || {};
  const wallRadius = Number(wall.radius ?? 0.54);
  const wallAngles = [1.18, 4.18, 0.28, 5.25].slice(0, clamp(Math.round(Number(wall.count) || 2), 1, 4));
  const brokenRadius = brokenRing.points?.[0]
    ? Math.hypot(Number(brokenRing.points[0][0]) || 0, Number(brokenRing.points[0][1]) || 0) * 0.94
    : 0.58;
  const crackInner = Number(deepCracks.radius_range?.[0] ?? 0.42);
  const crackOuter = Number(deepCracks.radius_range?.[1] ?? 0.92);
  const resourceRadius = Number(resources.radius ?? 0.48);

  const wallRing = ringInfluence(radialAlpha, wallRadius, 0.026, 0.18);
  const wallBlade = wallRing * angularInfluence(angle, wallAngles, 0.024, 0.18);
  const centralShelfBand = 1 - smoothstep(
    Math.max(0.04, Number(centralShelf.width ?? 0.34) * 0.58),
    Math.max(0.1, Number(centralShelf.width ?? 0.34) * 1.18),
    radialAlpha,
  );
  const brokenRingBand = ringInfluence(radialAlpha, brokenRadius, 0.030, 0.17);
  const brokenPlateAngles = [0, 1.62, 3.26, 4.86];
  const brokenPlateBand = Math.max(brokenRingBand * 0.72, brokenRingBand * angularInfluence(angle, brokenPlateAngles, 0.12, 0.36));
  const resourceBand = ringInfluence(radialAlpha, resourceRadius, 0.035, 0.17)
    * angularInfluence(angle, iceClusterAngles(resources.count ?? 4), 0.028, 0.14);
  const crackRadial = smoothstep(crackInner, crackInner + 0.16, radialAlpha)
    * (1 - smoothstep(crackOuter - 0.02, crackOuter + 0.06, radialAlpha));
  const crackBand = crackRadial * angularInfluence(angle, [0.78, 2.55, 4.75], 0.026, 0.09);

  if (controlId === 'crystalWallRadius') return clamp(Math.max(wallRing * 0.58, wallBlade), 0, 1);
  if (controlId === 'crystalWallDominance') return clamp(Math.max(wallRing * 0.32, wallBlade), 0, 1);
  if (controlId === 'centralShelfWidth') return clamp(centralShelfBand, 0, 1);
  if (controlId === 'brokenIceRingRadius') return clamp(brokenPlateBand, 0, 1);
  if (controlId === 'resourceClusterCount' || controlId === 'resourceClusterRadius') return clamp(resourceBand, 0, 1);
  if (controlId === 'deepCrackOuter') return clamp(Math.max(crackBand, crackRadial * 0.24), 0, 1);

  return clamp(Math.max(
    wallBlade,
    wallRing * 0.42,
    centralShelfBand * 0.36,
    brokenPlateBand * 0.78,
    resourceBand * 0.88,
    crackBand * 0.95,
  ), 0, 1);
}

export function biomeMovementInfluenceForVertex(vertex, layout, footprintRadius = 1, controlId = 'all') {
  if (layout?.biome === 'fire') return fireMovementInfluenceForVertex(vertex, layout, footprintRadius, controlId);
  if (layout?.biome === 'forest') return forestMovementInfluenceForVertex(vertex, layout, footprintRadius, controlId);
  if (layout?.biome === 'ice') return iceMovementInfluenceForVertex(vertex, layout, footprintRadius, controlId);
  return 0;
}

function highlightMaterialsForBiomeControl(layout, controlId) {
  if (layout?.biome === 'fire') return highlightMaterialsForControl(controlId);
  if (layout?.biome === 'forest') {
    if (controlId === 'mainPathWidth' || controlId === 'vineBridgeWidth') return new Set(['M_TopGrass', 'M_PathDirt']);
    if (controlId === 'stumpCaveDominance') return new Set(['M_TopGrass', 'M_ElementCrack']);
    if (controlId === 'mushroomPocketOuter' || controlId === 'canopyPlatformOuter') return new Set(['M_TopGrass', 'M_PathDirt']);
    return new Set(['M_TopGrass', 'M_PathDirt', 'M_ElementCrack']);
  }
  if (layout?.biome === 'ice') {
    if (controlId === 'centralShelfWidth' || controlId === 'brokenIceRingRadius') return new Set(['M_TopGrass', 'M_PathDirt', 'M_CliffRock']);
    if (controlId === 'deepCrackOuter') return new Set(['M_TopGrass', 'M_ElementCrack', 'M_CliffRock']);
    if (controlId === 'resourceClusterCount' || controlId === 'resourceClusterRadius') return new Set(['M_TopGrass', 'M_CliffRock']);
    return new Set(['M_TopGrass', 'M_CliffRock', 'M_ElementCrack']);
  }
  return new Set(['M_TopGrass', 'M_PathDirt', 'M_ElementCrack', 'M_CliffRock']);
}

export function biomeMovementHighlightThreshold(controlId) {
  const processSpec = processHighlightSpec(controlId);
  if (processSpec) return processSpec.threshold;
  if (controlId === 'mainPathWidth' || controlId === 'vineBridgeWidth' || controlId === 'centralShelfWidth') return 0.1;
  if (controlId === 'deepCrackOuter') return 0.18;
  if (controlId === 'resourceClusterCount' || controlId === 'resourceClusterRadius') return 0.22;
  if (controlId === 'crystalWallRadius' || controlId === 'crystalWallDominance' || controlId === 'brokenIceRingRadius') return 0.24;
  return 0.32;
}

export function biomeMovementHighlightForFace(face, mesh, layout, footprintRadius = 1, controlId = 'all') {
  if (!face || !mesh || !layout) return 0;
  if (!highlightMaterialsForBiomeControl(layout, controlId).has(face.material)) return 0;
  if (!Array.isArray(face.indices) || face.indices.length === 0) return 0;

  const influence = face.indices.reduce((sum, index) => (
    sum + biomeMovementInfluenceForVertex(mesh.vertices[index], layout, footprintRadius, controlId)
  ), 0) / face.indices.length;
  return clamp(influence, 0, 1);
}

export function morphMeshes(fromMesh, toMesh, progress) {
  if (!fromMesh || !toMesh) return toMesh || fromMesh;
  if (fromMesh.vertices.length !== toMesh.vertices.length) return toMesh;

  const t = clamp(progress, 0, 1);
  return {
    ...toMesh,
    vertices: toMesh.vertices.map((target, index) => {
      const source = fromMesh.vertices[index];
      return [
        Number((source[0] + (target[0] - source[0]) * t).toFixed(6)),
        Number((source[1] + (target[1] - source[1]) * t).toFixed(6)),
        Number((source[2] + (target[2] - source[2]) * t).toFixed(6)),
      ];
    }),
    faces: toMesh.faces.map((face) => ({ ...face })),
  };
}

export function meshDeltaForFace(fromMesh, toMesh, face, scale = 0.14) {
  if (!fromMesh || !toMesh || !face || !Array.isArray(face.indices)) return null;
  if (!Array.isArray(fromMesh.vertices) || !Array.isArray(toMesh.vertices)) return null;
  if (fromMesh.vertices.length !== toMesh.vertices.length) return null;
  if (!face.indices.length) return null;

  const deltas = face.indices.map((index) => {
    const fromVertex = fromMesh.vertices[index];
    const toVertex = toMesh.vertices[index];
    if (!Array.isArray(fromVertex) || !Array.isArray(toVertex)) return null;
    const delta = Number(toVertex[2]) - Number(fromVertex[2]);
    return Number.isFinite(delta) ? delta : null;
  });
  if (deltas.some((delta) => delta === null)) return null;

  const delta = Number((deltas.reduce((sum, value) => sum + value, 0) / deltas.length).toFixed(3));
  const intensity = Number(clamp(Math.abs(delta) / Math.max(0.001, Number(scale) || 0.14), 0, 1).toFixed(3));
  if (intensity <= 0.015) return null;
  return {
    delta,
    intensity,
    direction: delta >= 0 ? 'raised' : 'lowered',
  };
}

export function meshDeltaColorForFace(delta, pulse = 1) {
  if (!delta) return 'rgba(0, 0, 0, 0)';
  const amount = clamp(Number(delta.intensity) || 0, 0, 1);
  const pulseAmount = clamp(Number(pulse) || 0, 0, 1);
  const alpha = Number((0.06 + amount * 0.32 * pulseAmount).toFixed(2));
  const channels = delta.direction === 'raised' ? [255, 188, 79] : [89, 190, 255];
  return `rgba(${channels[0]}, ${channels[1]}, ${channels[2]}, ${alpha})`;
}

function faceHeightStats(mesh, face) {
  if (!mesh || !face || !Array.isArray(face.indices) || !Array.isArray(mesh.vertices)) return null;
  const heights = face.indices
    .map((index) => Number(mesh.vertices[index]?.[2]))
    .filter(Number.isFinite);
  if (!heights.length) return null;
  const min = Math.min(...heights);
  const max = Math.max(...heights);
  const average = heights.reduce((sum, value) => sum + value, 0) / heights.length;
  return {
    min,
    max,
    average,
    range: max - min,
  };
}

const MESH_HEIGHT_PROFILE_CACHE = new WeakMap();

function meshHeightProfile(mesh) {
  if (!mesh || !Array.isArray(mesh.vertices)) return { min: 0, max: 1, span: 1 };
  const cached = MESH_HEIGHT_PROFILE_CACHE.get(mesh);
  if (cached) return cached;

  const heights = mesh.vertices
    .map((vertex) => Number(vertex?.[2]))
    .filter(Number.isFinite);
  if (!heights.length) return { min: 0, max: 1, span: 1 };

  const min = Math.min(...heights);
  const max = Math.max(...heights);
  const span = Math.max(0.001, max - min);
  const profile = { min, max, span };
  MESH_HEIGHT_PROFILE_CACHE.set(mesh, profile);
  return profile;
}

function normalizedFaceHeightStats(mesh, stats) {
  const profile = meshHeightProfile(mesh);
  return {
    average: clamp((stats.average - profile.min) / profile.span, 0, 1),
    range: clamp(stats.range / profile.span, 0, 1),
  };
}

function faceRadialAlpha(mesh, face) {
  if (!mesh || !face || !Array.isArray(face.indices) || !Array.isArray(mesh.vertices)) return 0;
  const radius = Math.max(0.001, footprintRadiusForMesh(mesh.vertices));
  let sum = 0;
  let count = 0;
  for (const index of face.indices) {
    const vertex = mesh.vertices[index];
    if (!Array.isArray(vertex)) continue;
    const x = Number(vertex[0]) || 0;
    const y = Number(vertex[1]) || 0;
    const value = Math.hypot(x, y) / radius;
    if (!Number.isFinite(value)) continue;
    sum += value;
    count += 1;
  }
  return count ? sum / count : 0;
}

function qualityRiskLabel(dominant) {
  return {
    routeDamage: 'Route damage',
    overDetail: 'Over-detail',
    thinEdge: 'Thin edge',
  }[dominant] || 'Stable';
}

const QUALITY_CACHE_NO_FIELD = {};
const QUALITY_RISK_CACHE = new WeakMap();
const QUALITY_METRICS_CACHE = new WeakMap();

function qualityFieldCacheKey(field) {
  return field && typeof field === 'object' ? field : QUALITY_CACHE_NO_FIELD;
}

function qualityCacheFor(rootCache, mesh, field, create = false) {
  if (!mesh || typeof mesh !== 'object') return null;
  const fieldKey = qualityFieldCacheKey(field);
  let byField = rootCache.get(mesh);
  if (!byField) {
    if (!create) return null;
    byField = new WeakMap();
    rootCache.set(mesh, byField);
  }

  let cache = byField.get(fieldKey);
  if (!cache) {
    if (!create) return null;
    cache = new WeakMap();
    byField.set(fieldKey, cache);
  }
  return cache;
}

export function qualityRiskForFace(mesh, field, face) {
  if (face && typeof face === 'object') {
    const cached = qualityCacheFor(QUALITY_RISK_CACHE, mesh, field)?.get(face);
    if (cached) return cached;
  }

  const stats = faceHeightStats(mesh, face);
  if (!stats) return null;
  const normalizedHeight = normalizedFaceHeightStats(mesh, stats);

  const sample = fieldFaceSampleForOrder(field, face.order);
  const slope = clamp(sample?.masks?.slope ?? 0, 0, 1);
  const talus = clamp(sample?.masks?.talus ?? 0, 0, 1);
  const lavaFlow = clamp(sample?.masks?.lavaFlow ?? 0, 0, 1);
  const heightBreakup = clamp(normalizedHeight.range * 2.4, 0, 1);
  const radial = faceRadialAlpha(mesh, face);
  const routeMaterial = face.material === 'M_PathDirt';
  const edgeMaterial = face.material === 'M_CliffRock';
  const edgeRadial = smoothstep(0.72, 0.98, radial);
  const lowHangingEdge = 1 - smoothstep(0.08, 0.32, normalizedHeight.average);
  const verticalSeam = smoothstep(0.18, 0.48, normalizedHeight.range);

  const routeDamage = routeMaterial
    ? clamp(slope * 0.52 + lavaFlow * 0.18 + heightBreakup * 0.18, 0, 1)
    : 0;
  const overDetail = isTopSurfaceMaterial(face.material)
    ? clamp(slope * (1 - talus * 0.42) * 0.78 + heightBreakup * 0.12, 0, 1)
    : clamp((slope * 0.45 + heightBreakup * 0.18) * (routeMaterial ? 0.45 : 0.2), 0, 1);
  const thinEdge = edgeMaterial
    ? clamp(edgeRadial * 0.24 + edgeRadial * verticalSeam * 0.22 + edgeRadial * lowHangingEdge * 0.34 + slope * 0.05, 0, 1)
    : 0;

  const risks = { routeDamage, overDetail, thinEdge };
  const [dominant, score] = Object.entries(risks).sort((a, b) => b[1] - a[1])[0] || ['stable', 0];

  const risk = {
    routeDamage: Number(routeDamage.toFixed(3)),
    overDetail: Number(overDetail.toFixed(3)),
    thinEdge: Number(thinEdge.toFixed(3)),
    score: Number(score.toFixed(3)),
    dominant: score > 0.08 ? dominant : 'stable',
    label: qualityRiskLabel(score > 0.08 ? dominant : 'stable'),
  };
  if (face && typeof face === 'object') {
    qualityCacheFor(QUALITY_RISK_CACHE, mesh, field, true).set(face, risk);
  }
  return risk;
}

export function qualityRiskColorForFace(risk, alphaScale = 1) {
  if (!risk || risk.score <= 0.02) return 'rgba(0, 0, 0, 0)';
  const palettes = {
    routeDamage: [255, 90, 62],
    overDetail: [236, 228, 156],
    thinEdge: [118, 205, 255],
    stable: [118, 205, 255],
  };
  const rgb = palettes[risk.dominant] || palettes.stable;
  const alpha = Number((0.14 + clamp(risk.score, 0, 1) * 0.62 * clamp(alphaScale, 0, 1)).toFixed(2));
  return `rgba(${rgb[0]}, ${rgb[1]}, ${rgb[2]}, ${alpha})`;
}

function qualitySeverity(score) {
  const amount = clamp(Number(score) || 0, 0, 1);
  if (amount >= 0.66) return { id: 'high', label: 'High' };
  if (amount >= 0.34) return { id: 'medium', label: 'Medium' };
  if (amount >= 0.08) return { id: 'low', label: 'Low' };
  return { id: 'stable', label: 'Stable' };
}

function qualityAdvisorTemplate(dominant) {
  const templates = {
    routeDamage: {
      title: 'Route damage risk',
      summary: 'Walkable route readability is under pressure.',
      reasons: [
        'This face belongs to the walkable route.',
        'Slope and lava-flow masks are cutting into the approach surface.',
      ],
      suggestion: 'Widen Approach width first; then reduce Erosion age or Lava branches if the route still breaks.',
      controls: [
        { id: 'mainPathWidth', label: 'Approach width', intent: 'widen route support' },
        { id: 'erosionAge', label: 'Erosion age', intent: 'soften carved flow cuts' },
        { id: 'lavaCount', label: 'Lava branches', intent: 'reduce hazard cuts' },
      ],
      layers: ['Route carve', 'Erosion age', 'Lava flow'],
    },
    overDetail: {
      title: 'Over-detail risk',
      summary: 'Surface noise may be louder than the silhouette.',
      reasons: [
        'Surface noise is high on a top terrain face.',
        'Talus deposition is not yet absorbing enough breakup.',
      ],
      suggestion: 'Lower Detail energy or raise Deposition weight to settle the noisy surface into broader terrain bands.',
      controls: [
        { id: 'detailEnergy', label: 'Detail energy', intent: 'lower micro ridges' },
        { id: 'depositionWeight', label: 'Deposition weight', intent: 'build stabilizing talus' },
      ],
      layers: ['Surface detail', 'Talus deposition'],
    },
    thinEdge: {
      title: 'Thin edge risk',
      summary: 'The silhouette edge may read too fragile.',
      reasons: [
        'This face sits on an exposed cliff band.',
        'The outer edge is steep and radially close to the island boundary.',
      ],
      suggestion: 'Increase Crater footprint or lower Volcano height to give the rim more mass before final bake.',
      controls: [
        { id: 'volcanoRadius', label: 'Crater footprint', intent: 'broaden silhouette mass' },
        { id: 'volcanoDominance', label: 'Volcano height', intent: 'reduce rim lift stress' },
      ],
      layers: ['Crater / cone', 'Base form'],
    },
    stable: {
      title: 'Stable terrain',
      summary: 'No strong diagnostic risk is active here.',
      reasons: ['Current masks are within a readable range for this material.'],
      suggestion: 'Keep this region as a reference while tuning nearby risk areas.',
      controls: [],
      layers: ['Final mesh'],
    },
  };
  return templates[dominant] || templates.stable;
}

export function qualityAdvisorForFace(mesh, field, face) {
  const risk = qualityRiskForFace(mesh, field, face);
  const dominant = risk?.dominant || 'stable';
  const template = qualityAdvisorTemplate(dominant);
  const severity = qualitySeverity(risk?.score || 0);
  const sample = fieldFaceSampleForOrder(field, face?.order);

  return {
    title: template.title,
    summary: template.summary,
    suggestion: template.suggestion,
    reasons: [...template.reasons],
    controls: template.controls.map((control) => ({ ...control })),
    layers: [...template.layers],
    risk,
    severity: severity.id,
    severityLabel: severity.label,
    sample,
  };
}

function averageRisk(risks, key, filter = () => true) {
  const values = risks.filter((entry) => filter(entry.face, entry.risk)).map((entry) => entry.risk[key]);
  return values.length ? Number((values.reduce((sum, value) => sum + value, 0) / values.length).toFixed(3)) : 0;
}

function fieldGridValue(grid, ring, segment, segmentCount = 0) {
  if (!Array.isArray(grid) || !grid.length) return null;
  const row = grid[ring];
  if (!Array.isArray(row) || !row.length) return null;
  const wrappedSegment = ((segment % row.length) + row.length) % row.length;
  const value = Number(row[wrappedSegment]);
  return Number.isFinite(value) ? value : null;
}

function fieldMaskValue(field, keys, ring, segment, segmentCount = 0) {
  const names = Array.isArray(keys) ? keys : [keys];
  for (const key of names) {
    const value = fieldGridValue(field?.masks?.[key], ring, segment, segmentCount);
    if (value !== null) return value;
  }
  return 0;
}

function radialArtifactMetricForField(field) {
  const heights = field?.heights;
  if (!Array.isArray(heights) || !heights.length) return 0;
  const segmentCount = Number(field?.radial_segments) || heights.find((row) => Array.isArray(row))?.length || 0;
  const ringCount = Number(field?.rings) || Math.max(0, heights.length - 1);
  if (segmentCount < 8 || ringCount < 4) return 0;

  let minHeight = Infinity;
  let maxHeight = -Infinity;
  for (let ring = 0; ring <= ringCount; ring += 1) {
    for (let segment = 0; segment < segmentCount; segment += 1) {
      const height = fieldGridValue(heights, ring, segment, segmentCount);
      if (height === null) continue;
      minHeight = Math.min(minHeight, height);
      maxHeight = Math.max(maxHeight, height);
    }
  }
  const heightRange = maxHeight - minHeight;
  if (!Number.isFinite(heightRange) || heightRange <= 1e-3) return 0;

  const segmentSums = Array(segmentCount).fill(0);
  const segmentHits = Array(segmentCount).fill(0);
  const firstRing = Math.max(1, Math.floor(ringCount * 0.3));
  const lastRing = Math.min(ringCount, Math.ceil(ringCount * 0.92));

  for (let ring = firstRing; ring <= lastRing; ring += 1) {
    const samples = [];
    for (let segment = 0; segment < segmentCount; segment += 1) {
      const path = fieldMaskValue(field, 'path', ring, segment, segmentCount);
      const lava = fieldMaskValue(field, ['lava', 'lavaFlow', 'lava_flow'], ring, segment, segmentCount);
      const craterLoop = fieldMaskValue(field, ['crater_loop', 'craterLoop'], ring, segment, segmentCount);
      if (Math.max(path, lava, craterLoop) > 0.25) continue;
      const height = fieldGridValue(heights, ring, segment, segmentCount);
      if (height === null) continue;
      samples.push({ segment, height });
    }
    if (samples.length < Math.max(4, Math.floor(segmentCount * 0.35))) continue;
    const ringMean = samples.reduce((sum, sample) => sum + sample.height, 0) / samples.length;
    for (const sample of samples) {
      segmentSums[sample.segment] += sample.height - ringMean;
      segmentHits[sample.segment] += 1;
    }
  }

  const coherentResiduals = segmentSums
    .map((sum, segment) => (segmentHits[segment] >= 2 ? Math.abs(sum / segmentHits[segment]) : null))
    .filter((value) => value !== null);
  if (coherentResiduals.length < Math.max(4, Math.floor(segmentCount * 0.35))) return 0;

  const coherentAmplitude = coherentResiduals.reduce((sum, value) => sum + value, 0) / coherentResiduals.length;
  return Number(smoothstep(0.035, 0.18, coherentAmplitude / heightRange).toFixed(3));
}

export function qualityMetricsForMesh(mesh, field) {
  if (!mesh || !Array.isArray(mesh.faces) || !mesh.faces.length) {
    return {
      routeHealth: 1,
      overDetail: 0,
      thinEdge: 0,
      radialArtifact: 0,
      overallHealth: 1,
      routeHealthLabel: '100%',
      overDetailLabel: '0%',
      thinEdgeLabel: '0%',
      radialArtifactLabel: '0%',
      overallLabel: '100%',
      summary: 'Quality pending mesh preview.',
      risks: [],
    };
  }
  const metricsCache = qualityCacheFor(QUALITY_METRICS_CACHE, mesh, field);
  const cachedMetrics = metricsCache?.get(mesh);
  if (cachedMetrics) return cachedMetrics;

  const risks = mesh.faces
    .map((face) => ({ face, risk: qualityRiskForFace(mesh, field, face) }))
    .filter((entry) => entry.risk);
  const routeDamage = averageRisk(risks, 'routeDamage', (face) => face.material === 'M_PathDirt');
  const overDetail = averageRisk(risks, 'overDetail', (face) => isTopSurfaceMaterial(face.material));
  const thinEdge = averageRisk(risks, 'thinEdge', (face) => face.material === 'M_CliffRock');
  const radialArtifact = radialArtifactMetricForField(field);
  const routeHealth = Number(clamp(1 - routeDamage, 0, 1).toFixed(3));
  const overallHealth = Number(clamp(1 - (
    routeDamage * 0.42
    + overDetail * 0.28
    + thinEdge * 0.20
    + radialArtifact * 0.10
  ), 0, 1).toFixed(3));
  const topRisks = risks
    .filter((entry) => entry.risk.score > 0.08)
    .sort((a, b) => b.risk.score - a.risk.score)
    .slice(0, 3)
    .map((entry) => ({
      label: entry.risk.label,
      score: entry.risk.score,
      scoreLabel: `${Math.round(entry.risk.score * 100)}%`,
      material: entry.face.material,
    }));

  const metrics = {
    routeHealth,
    overDetail,
    thinEdge,
    radialArtifact,
    overallHealth,
    routeHealthLabel: `${Math.round(routeHealth * 100)}%`,
    overDetailLabel: `${Math.round(overDetail * 100)}%`,
    thinEdgeLabel: `${Math.round(thinEdge * 100)}%`,
    radialArtifactLabel: `${Math.round(radialArtifact * 100)}%`,
    overallLabel: `${Math.round(overallHealth * 100)}%`,
    summary: `Route ${Math.round(routeHealth * 100)}% / detail risk ${Math.round(overDetail * 100)}% / edge risk ${Math.round(thinEdge * 100)}% / radial risk ${Math.round(radialArtifact * 100)}%`,
    risks: topRisks,
  };
  qualityCacheFor(QUALITY_METRICS_CACHE, mesh, field, true).set(mesh, metrics);
  return metrics;
}

function qualityIssueRegion(sample) {
  if (!sample) return null;
  return `R${String(sample.ring).padStart(2, '0')}/S${String(sample.segment).padStart(3, '0')}`;
}

function qualityIssueForFace(mesh, field, face) {
  const advisor = qualityAdvisorForFace(mesh, field, face);
  const score = advisor.risk?.score || 0;
  if (score <= 0.08) return null;
  return {
    type: advisor.risk.dominant,
    label: advisor.title,
    severity: advisor.severity,
    severityLabel: advisor.severityLabel,
    score,
    scoreLabel: `${Math.round(score * 100)}%`,
    material: face.material,
    faceOrder: face.order,
    region: qualityIssueRegion(advisor.sample),
    reasons: [...advisor.reasons],
    suggestion: advisor.suggestion,
    suggestedControls: advisor.controls.map((control) => ({ ...control })),
    layers: [...advisor.layers],
  };
}

function qualityControlIndex(issues) {
  const controls = {};
  for (const issue of issues) {
    for (const control of issue.suggestedControls) {
      controls[control.id] ||= {
        id: control.id,
        label: control.label,
        issueCount: 0,
        maxScore: 0,
      };
      controls[control.id].issueCount += 1;
      controls[control.id].maxScore = Math.max(controls[control.id].maxScore, issue.score);
    }
  }
  return Object.fromEntries(Object.entries(controls).map(([id, control]) => [
    id,
    {
      ...control,
      maxScore: Number(control.maxScore.toFixed(3)),
      maxScoreLabel: `${Math.round(control.maxScore * 100)}%`,
    },
  ]));
}

export function qualityNudgePlanForIssue(issue) {
  const plans = {
    overDetail: [
      { controlId: 'detailEnergy', delta: -0.08 },
      { controlId: 'depositionWeight', delta: 0.06 },
    ],
    routeDamage: [
      { controlId: 'mainPathWidth', delta: 0.02 },
      { controlId: 'erosionAge', delta: -0.04 },
    ],
    thinEdge: [
      { controlId: 'volcanoRadius', delta: 0.02 },
      { controlId: 'volcanoDominance', delta: -0.04 },
    ],
  };
  return (plans[issue?.type] || []).map((step) => ({ ...step }));
}

export function qualityNudgePlanSummaryForIssue(issue, labelMap = volcanoControlLabels()) {
  return qualityNudgePlanForIssue(issue).map((step) => ({
    ...step,
    label: labelMap?.[step.controlId]?.title || step.controlId,
    deltaLabel: nudgeDeltaLabel(step.delta),
    direction: step.delta > 0 ? 'raise' : step.delta < 0 ? 'lower' : 'hold',
  }));
}

function issueScoreLabel(score, fallback = '') {
  if (fallback) return fallback;
  return `${Math.round(clamp(Number(score) || 0, 0, 1) * 100)}%`;
}

function nudgeDeltaLabel(delta) {
  if (delta === null) return '';
  const points = Math.round(Math.abs(delta) * 100);
  if (points === 0) return '0%';
  return `${delta > 0 ? '+' : '-'}${points}%`;
}

export function qualityNudgeResultForIssue(beforeIssue, report) {
  if (!beforeIssue) return null;
  const beforeScore = clamp(Number(beforeIssue.score) || 0, 0, 1);
  const beforeLabel = issueScoreLabel(beforeScore, beforeIssue.scoreLabel);
  const faceOrder = Number(beforeIssue.faceOrder);
  if (!report) {
    return {
      status: 'pending',
      statusLabel: 'Waiting',
      label: 'Waiting for preview bake',
      summary: `${beforeIssue.label || 'Issue'} was ${beforeLabel}.`,
      beforeScore,
      afterScore: null,
      delta: null,
      deltaLabel: '',
      faceOrder,
      beforeIssue,
    };
  }

  const afterIssue = (report.topIssues || []).find((issue) => (
    Number(issue.faceOrder) === faceOrder
    && (!beforeIssue.type || issue.type === beforeIssue.type)
  ));
  const afterScore = afterIssue ? clamp(Number(afterIssue.score) || 0, 0, 1) : 0;
  const afterLabel = issueScoreLabel(afterScore, afterIssue?.scoreLabel);
  const delta = Number((afterScore - beforeScore).toFixed(3));
  const status = afterIssue
    ? (delta < -0.01 ? 'improved' : delta > 0.01 ? 'worse' : 'flat')
    : 'cleared';
  const statusLabel = {
    improved: 'Improved',
    worse: 'Worse',
    flat: 'Flat',
    cleared: 'Cleared',
  }[status];
  return {
    status,
    statusLabel,
    label: status === 'cleared' ? 'Cleared from top issues' : `${statusLabel} ${nudgeDeltaLabel(delta)}`,
    summary: afterIssue
      ? `${beforeIssue.label || 'Issue'} moved from ${beforeLabel} to ${afterLabel}.`
      : `${beforeIssue.label || 'Issue'} dropped out of the top issue list.`,
    beforeScore,
    afterScore,
    delta,
    deltaLabel: nudgeDeltaLabel(delta),
    faceOrder,
    beforeIssue,
  };
}

export function qualityReportForMesh(mesh, field, options = {}) {
  const metrics = qualityMetricsForMesh(mesh, field);
  const allIssues = (mesh?.faces || [])
    .map((face) => qualityIssueForFace(mesh, field, face))
    .filter(Boolean)
    .sort((a, b) => b.score - a.score);
  const maxIssues = Math.max(1, Number(options.maxIssues) || 12);
  const topIssues = allIssues.slice(0, maxIssues);

  return {
    schemaVersion: 1,
    generatedAt: options.generatedAt || null,
    biome: options.biome || field?.biome || 'unknown',
    quality: options.quality || 'unknown',
    topology: options.topology || {
      segments: field?.radial_segments || null,
      rings: field?.rings || null,
    },
    paths: {
      mesh: options.meshPath || null,
      layout: options.layoutPath || null,
      field: options.fieldPath || null,
    },
    mesh: {
      vertices: mesh?.vertices?.length || 0,
      faces: mesh?.faces?.length || 0,
    },
    metrics: {
      overallHealth: metrics.overallHealth,
      routeHealth: metrics.routeHealth,
      overDetail: metrics.overDetail,
      thinEdge: metrics.thinEdge,
      radialArtifact: metrics.radialArtifact,
      overallLabel: metrics.overallLabel,
      routeHealthLabel: metrics.routeHealthLabel,
      overDetailLabel: metrics.overDetailLabel,
      thinEdgeLabel: metrics.thinEdgeLabel,
      radialArtifactLabel: metrics.radialArtifactLabel,
    },
    summary: metrics.summary,
    issueCount: allIssues.length,
    topIssues,
    controlIndex: qualityControlIndex(topIssues),
  };
}

export function meshAtTransitionFrame(transition, fallbackMesh, time, easing = (value) => clamp(value, 0, 1)) {
  if (!transition) return fallbackMesh;
  const duration = Math.max(1, Number(transition.duration) || 1);
  const progress = (Number(time) - Number(transition.startTime)) / duration;
  if (progress >= 1) return transition.to || fallbackMesh;
  if (progress <= 0) return transition.from || fallbackMesh;
  return morphMeshes(transition.from || fallbackMesh, transition.to || fallbackMesh, easing(progress));
}

export function meshForPreviewRender(mesh, layout, { previewSignature, currentSignature } = {}) {
  void layout;
  void previewSignature;
  void currentSignature;
  return mesh;
}

export function meshWireAlphaForFaceCount(faceCount) {
  const count = Number(faceCount) || 0;
  if (count > 20000) return 0.012;
  if (count > 6000) return 0.02;
  return 0.035;
}

const MATERIAL_PALETTES = {
  fire: {
    M_AshPlateau: [82, 74, 65],
    M_TopGrass: [82, 74, 65],
    M_PathDirt: [188, 120, 54],
    M_CliffRock: [50, 52, 58],
    M_UndersideRock: [25, 27, 33],
    M_ElementCrack: [232, 72, 34],
  },
  ice: {
    M_TopGrass: [126, 168, 188],
    M_PathDirt: [190, 224, 231],
    M_CliffRock: [72, 94, 111],
    M_UndersideRock: [32, 44, 58],
    M_ElementCrack: [104, 205, 255],
  },
  forest: {
    M_TopGrass: [83, 120, 90],
    M_PathDirt: [177, 124, 62],
    M_CliffRock: [58, 62, 72],
    M_UndersideRock: [34, 36, 44],
    M_ElementCrack: [105, 210, 145],
  },
};

export function materialColorForBiome(biome, material, light) {
  const palette = MATERIAL_PALETTES[biome] || MATERIAL_PALETTES.forest;
  const base = palette[material] || [110, 116, 130];
  return `rgb(${base.map((value) => Math.round(value * light)).join(',')})`;
}

const MASK_VIEW_DEFINITIONS = {
  material: {
    id: 'material',
    label: 'Material',
    field: null,
  },
  slope: {
    id: 'slope',
    label: 'Slope',
    field: 'slope',
    low: [24, 30, 33],
    high: [172, 224, 218],
    alphaBase: 0.3,
    alphaRange: 0.64,
  },
  talus: {
    id: 'talus',
    label: 'Talus',
    field: 'talus',
    low: [35, 34, 31],
    high: [218, 174, 96],
    alphaBase: 0.3,
    alphaRange: 0.64,
  },
  lavaFlow: {
    id: 'lavaFlow',
    label: 'Lava Flow',
    field: 'lava_flow',
    low: [34, 29, 28],
    high: [242, 93, 38],
    alphaBase: 0.35,
    alphaRange: 0.6,
  },
};

export function maskViewOptions() {
  return ['material', 'slope', 'talus', 'lavaFlow'].map((id) => {
    const option = MASK_VIEW_DEFINITIONS[id];
    return { id: option.id, label: option.label };
  });
}

function maskFieldKey(maskView) {
  return MASK_VIEW_DEFINITIONS[maskView]?.field || null;
}

function fieldFaceCoordinates(field, faceOrder) {
  const segments = Number(field?.radial_segments);
  const rings = Number(field?.rings);
  const order = Number(faceOrder);
  if (!Number.isInteger(segments) || !Number.isInteger(rings) || !Number.isInteger(order)) return null;
  if (segments <= 0 || rings <= 0 || order < 0 || order >= segments * rings) return null;

  const ring = Math.floor(order / segments) + 1;
  const index = order % segments;
  return { ring, index, previousRing: Math.max(0, ring - 1), nextIndex: (index + 1) % segments, segments, rings };
}

function averageFieldFaceValue(grid, coordinates) {
  if (!Array.isArray(grid) || !coordinates) return null;
  const { ring, index, previousRing, nextIndex } = coordinates;
  const values = [
    grid[ring]?.[index],
    grid[ring]?.[nextIndex],
    grid[previousRing]?.[index],
    grid[previousRing]?.[nextIndex],
  ].map(Number);
  if (values.some((value) => !Number.isFinite(value))) return null;

  return Number((values.reduce((sum, value) => sum + value, 0) / values.length).toFixed(3));
}

export function maskValueForFaceOrder(field, faceOrder, maskView) {
  const key = maskFieldKey(maskView);
  if (!key) return null;
  return averageFieldFaceValue(field?.masks?.[key], fieldFaceCoordinates(field, faceOrder));
}

export function maskColorForValue(maskView, value) {
  const definition = MASK_VIEW_DEFINITIONS[maskView] || MASK_VIEW_DEFINITIONS.slope;
  const amount = clamp(Number(value) || 0, 0, 1);
  const low = definition.low || MASK_VIEW_DEFINITIONS.slope.low;
  const high = definition.high || MASK_VIEW_DEFINITIONS.slope.high;
  const rgb = low.map((channel, index) => Math.round(channel + (high[index] - channel) * amount));
  const alpha = Number((definition.alphaBase + definition.alphaRange * amount).toFixed(2));
  return `rgba(${rgb[0]}, ${rgb[1]}, ${rgb[2]}, ${alpha})`;
}

function rgbChannels(color) {
  const channels = String(color).match(/\d+/g)?.slice(0, 3).map(Number);
  return channels?.length === 3 && channels.every(Number.isFinite) ? channels : [110, 116, 130];
}

export function processTraceForFace(field, faceOrder) {
  const sample = fieldFaceSampleForOrder(field, faceOrder);
  if (!sample) return null;

  const slope = clamp(sample.masks.slope, 0, 1);
  const talus = clamp(sample.masks.talus, 0, 1);
  const lavaFlow = clamp(sample.masks.lavaFlow, 0, 1);
  const weighted = {
    slope: slope * 0.28,
    talus: talus * 0.8,
    lavaFlow: lavaFlow * 0.95,
  };
  const dominant = Object.entries(weighted).sort((a, b) => b[1] - a[1])[0]?.[0] || 'slope';

  return {
    slope,
    talus,
    lavaFlow,
    dominant,
    intensity: Number(clamp(Math.max(weighted.slope, weighted.talus, weighted.lavaFlow), 0, 1).toFixed(3)),
  };
}

export function processMovementHighlightForFace(field, faceOrder, controlId) {
  const spec = processHighlightSpec(controlId);
  if (!spec) return 0;
  const trace = processTraceForFace(field, faceOrder);
  if (!trace) return 0;
  return Number(clamp(trace[spec.traceKind] || 0, 0, 1).toFixed(3));
}

export function processTracePulseAlpha(startTime, time, duration = 900) {
  const start = Number(startTime);
  const current = Number(time);
  const span = Math.max(1, Number(duration) || 1);
  if (!Number.isFinite(start) || !Number.isFinite(current)) return 0;
  const progress = (current - start) / span;
  if (progress <= 0 || progress >= 1) return 0;
  return Number(Math.sin(progress * Math.PI).toFixed(3));
}

export function processTraceColorForFace(baseColor, field, faceOrder, options = {}) {
  if (options.enabled === false) return baseColor;
  const trace = options.trace || processTraceForFace(field, faceOrder);
  if (!trace || trace.intensity <= 0.02) return baseColor;

  const [baseR, baseG, baseB] = rgbChannels(baseColor);
  const slope = clamp(trace.slope, 0, 1);
  const lavaFlow = clamp(trace.lavaFlow, 0, 1);
  const talus = clamp(trace.talus, 0, 1) * (1 - lavaFlow * 0.5);
  const pulse = clamp(Number(options.pulse) || 0, 0, 1);

  const r = baseR + lavaFlow * 36 + talus * 32 - slope * 2 + pulse * (lavaFlow * 14 + talus * 5);
  const g = baseG - lavaFlow * 25 + talus * 29 - slope * 2 + pulse * (-lavaFlow * 5 + talus * 4);
  const b = baseB - lavaFlow * 26 + talus * 14 - slope * 2 + pulse * (-lavaFlow * 6 + talus * 3);

  return `rgb(${[r, g, b].map((channel) => Math.round(clamp(channel, 0, 255))).join(',')})`;
}

const PROCESS_MASK_METRICS = [
  { id: 'slope', label: 'Slope', threshold: 0.45 },
  { id: 'talus', label: 'Talus', threshold: 0.35 },
  { id: 'lavaFlow', label: 'Lava Flow', threshold: 0.55 },
];

export function processMaskCoverageMetrics(field) {
  const rings = Number(field?.rings);
  const segments = Number(field?.radial_segments);
  if (!Number.isInteger(rings) || !Number.isInteger(segments) || rings <= 0 || segments <= 0) return [];

  return PROCESS_MASK_METRICS.map((metric) => {
    const key = maskFieldKey(metric.id);
    const mask = field?.masks?.[key];
    const values = [];
    if (Array.isArray(mask)) {
      for (let ring = 1; ring <= rings; ring += 1) {
        for (let index = 0; index < segments; index += 1) {
          const value = Number(mask[ring]?.[index]);
          if (Number.isFinite(value)) values.push(clamp(value, 0, 1));
        }
      }
    }
    const average = values.length
      ? Number((values.reduce((sum, value) => sum + value, 0) / values.length).toFixed(3))
      : 0;
    const coverage = values.length
      ? Number((values.filter((value) => value >= metric.threshold).length / values.length).toFixed(3))
      : 0;
    return {
      ...metric,
      average,
      coverage,
      coverageLabel: `${Math.round(coverage * 100)}%`,
      averageLabel: average.toFixed(2),
    };
  });
}

const PROCESS_LAYER_DEFINITIONS = [
  {
    id: 'baseForm',
    label: 'Base form',
    tag: 'BASE',
    maskView: 'material',
    description: 'Island silhouette and underside mass.',
    tone: '#9aa4b5',
  },
  {
    id: 'craterCone',
    label: 'Crater / cone',
    tag: 'CONE',
    maskView: 'material',
    description: 'Volcano radius, rim, and central mass.',
    tone: '#c9794f',
  },
  {
    id: 'routeCarve',
    label: 'Route carve',
    tag: 'PATH',
    maskView: 'material',
    description: 'Approach width and partial crater loop.',
    tone: '#d6a15a',
  },
  {
    id: 'lavaFlow',
    label: 'Lava flow',
    tag: 'FLOW',
    maskView: 'lavaFlow',
    traceKind: 'lavaFlow',
    description: 'Generator-planned flow channels.',
    tone: '#f25d26',
  },
  {
    id: 'erosionAge',
    label: 'Erosion age',
    tag: 'ERODE',
    maskView: 'lavaFlow',
    traceKind: 'lavaFlow',
    description: 'Incision and weathering along flow paths.',
    tone: '#ff8f4f',
  },
  {
    id: 'talusDeposition',
    label: 'Talus deposition',
    tag: 'TALUS',
    maskView: 'talus',
    traceKind: 'talus',
    description: 'Slope-foot debris and settled material.',
    tone: '#e2ae55',
  },
  {
    id: 'surfaceDetail',
    label: 'Surface detail',
    tag: 'DETAIL',
    maskView: 'slope',
    traceKind: 'slope',
    description: 'Fine breakup constrained by steep faces.',
    tone: '#9ce2ee',
  },
  {
    id: 'qualityDiagnostics',
    label: 'Diagnostics',
    tag: 'CHECK',
    maskView: 'quality',
    description: 'Route, detail, and silhouette risk heatmap.',
    tone: '#ff5a62',
  },
  {
    id: 'finalMesh',
    label: 'Final mesh',
    tag: 'FINAL',
    maskView: 'material',
    description: 'Combined OBJ result after all layers.',
    tone: '#c7f4d1',
  },
];

const BIOME_PROCESS_LAYER_OVERRIDES = {
  forest: {
    craterCone: {
      label: 'Canopy / roots',
      tag: 'ROOT',
      description: 'Canopy platform, root arch, stump cave, and vine anchor mass.',
      tone: '#74c68a',
    },
    routeCarve: {
      label: 'Forest routes',
      description: 'Main path and vine bridge masks through the grown terrain.',
      tone: '#d09a5b',
    },
    lavaFlow: {
      label: 'Root flow',
      description: 'Generator-planned root, vine, and cave flow channels.',
      tone: '#70d996',
    },
    erosionAge: {
      label: 'Forest weathering',
      description: 'Weathering along root paths, cave lips, and living shelves.',
      tone: '#9bc77a',
    },
    talusDeposition: {
      label: 'Soil deposition',
      description: 'Settled soil and moss buildup on exposed forest shelves.',
      tone: '#c8a260',
    },
  },
  ice: {
    craterCone: {
      label: 'Wall / shelf',
      tag: 'WALL',
      description: 'Crystal wall ring, central shelf, and broken plate mass.',
      tone: '#87c9e6',
    },
    routeCarve: {
      label: 'Ice routes',
      description: 'Central shelf and broken-ice walkable route masks.',
      tone: '#c3e9f2',
    },
    lavaFlow: {
      label: 'Crack flow',
      description: 'Generator-planned crevasse and melt-channel flow paths.',
      tone: '#68cdff',
    },
    erosionAge: {
      label: 'Freeze erosion',
      description: 'Cold weathering and incision along glacier cracks.',
      tone: '#8fd8ff',
    },
    talusDeposition: {
      label: 'Snow deposition',
      description: 'Packed snow and ice debris accumulating on shelf shoulders.',
      tone: '#d4edf4',
    },
  },
};

function processLayerForBiome(layer, biome) {
  return {
    ...layer,
    ...(BIOME_PROCESS_LAYER_OVERRIDES[biome]?.[layer.id] || {}),
  };
}

export function processLayerStack(field = null, activeLayerId = null, qualityMetrics = null) {
  const biome = field?.biome || 'fire';
  const metricById = new Map(processMaskCoverageMetrics(field).map((metric) => [metric.id, metric]));
  return PROCESS_LAYER_DEFINITIONS.map((baseLayer) => {
    const layer = processLayerForBiome(baseLayer, biome);
    const metric = layer.traceKind ? metricById.get(layer.traceKind) : null;
    const needsQuality = layer.maskView === 'quality';
    const needsField = layer.maskView !== 'material' && !needsQuality;
    const coverageLabel = needsQuality
      ? (qualityMetrics?.overallLabel || '--')
      : (metric?.coverageLabel || (needsField ? '--' : 'OBJ'));
    const averageLabel = needsQuality
      ? (qualityMetrics?.routeHealthLabel ? `${qualityMetrics.routeHealthLabel} route` : '--')
      : (metric?.averageLabel || (needsField ? '--' : 'live'));
    return {
      ...layer,
      active: layer.id === activeLayerId,
      disabled: (needsField && !field) || (needsQuality && (!field || !qualityMetrics)),
      coverage: needsQuality ? (qualityMetrics?.overallHealth ?? null) : (metric?.coverage ?? null),
      coverageLabel,
      average: needsQuality ? (qualityMetrics?.overallHealth ?? null) : (metric?.average ?? null),
      averageLabel,
    };
  });
}

export function fieldFaceSampleForOrder(field, faceOrder) {
  const coordinates = fieldFaceCoordinates(field, faceOrder);
  if (!coordinates) return null;

  const heightCm = averageFieldFaceValue(field?.heights, coordinates);
  if (!Number.isFinite(heightCm)) return null;

  return {
    ring: coordinates.ring,
    segment: coordinates.index,
    heightM: Number((heightCm / 100).toFixed(2)),
    masks: {
      slope: maskValueForFaceOrder(field, faceOrder, 'slope') ?? 0,
      talus: maskValueForFaceOrder(field, faceOrder, 'talus') ?? 0,
      lavaFlow: maskValueForFaceOrder(field, faceOrder, 'lavaFlow') ?? 0,
    },
  };
}

function pointInPolygon(point, polygon) {
  let inside = false;
  for (let index = 0, previous = polygon.length - 1; index < polygon.length; previous = index, index += 1) {
    const currentPoint = polygon[index];
    const previousPoint = polygon[previous];
    const crosses = ((currentPoint.y > point.y) !== (previousPoint.y > point.y))
      && (point.x < ((previousPoint.x - currentPoint.x) * (point.y - currentPoint.y)) / ((previousPoint.y - currentPoint.y) || 1e-9) + currentPoint.x);
    if (crosses) inside = !inside;
  }
  return inside;
}

export function faceHitAtPoint(faceRegions, point) {
  if (!Array.isArray(faceRegions) || !point) return null;
  for (let index = faceRegions.length - 1; index >= 0; index -= 1) {
    const region = faceRegions[index];
    if (Array.isArray(region.points) && region.points.length >= 3 && pointInPolygon(point, region.points)) {
      return region;
    }
  }
  return null;
}
