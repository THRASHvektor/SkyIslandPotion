import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

import {
  bakeQualityOptions,
  contentTypeForPath,
  exportArgsForQuality,
  inspectPathsForBiome,
  normalizeBakeQuality,
  plantExportPreviewGroups,
  plantExportWorkspacePriority,
  plantProfileForSampleId,
  plantPreviewFileUrl,
  plantPreviewProjectPath,
  resolveLocalPlantUploadSampleFiles,
  resolveInboxPlantSampleFiles,
  resolvePlantPreviewFilePath,
  pathsForBiome,
  previewExportArgs,
  previewPathsForBiome,
  resolvePythonCommand,
  staticHeadersForPath,
} from './server_utils.mjs';

test('resolvePythonCommand uses PYTHON environment override without launcher args', () => {
  const resolved = resolvePythonCommand({
    env: { PYTHON: 'C:/Tools/Python/python.exe' },
    commandExists: () => false,
  });

  assert.deepEqual(resolved, {
    command: 'C:/Tools/Python/python.exe',
    args: [],
    label: 'PYTHON',
  });
});

test('resolvePythonCommand prefers python before Windows py launcher', () => {
  const resolved = resolvePythonCommand({
    env: {},
    commandExists: (command) => command === 'python' || command === 'py',
  });

  assert.deepEqual(resolved, {
    command: 'python',
    args: [],
    label: 'python',
  });
});

test('resolvePythonCommand falls back to py -3 when python is unavailable', () => {
  const resolved = resolvePythonCommand({
    env: {},
    commandExists: (command) => command === 'py',
    bundledPythonPath: '',
  });

  assert.deepEqual(resolved, {
    command: 'py',
    args: ['-3'],
    label: 'py -3',
  });
});

test('resolvePythonCommand reports an actionable error when no Python is available', () => {
  assert.throws(
    () => resolvePythonCommand({ env: {}, commandExists: () => false, bundledPythonPath: '' }),
    /Set PYTHON to a Python executable/
  );
});

test('contentTypeForPath serves ES modules with JavaScript MIME type', () => {
  assert.equal(contentTypeForPath('view_model.mjs'), 'application/javascript; charset=utf-8');
  assert.equal(contentTypeForPath('app.js'), 'application/javascript; charset=utf-8');
});

test('staticHeadersForPath prevents stale design-tool modules during live iteration', () => {
  assert.deepEqual(staticHeadersForPath('app.js'), {
    'Content-Type': 'application/javascript; charset=utf-8',
    'Cache-Control': 'no-store',
  });
});

test('plant export preview serves glTF packages with expected content types', () => {
  assert.equal(contentTypeForPath('Core.gltf'), 'model/gltf+json; charset=utf-8');
  assert.equal(contentTypeForPath('Core.bin'), 'application/octet-stream');
  assert.equal(contentTypeForPath('texture_0.jpg'), 'image/jpeg');
  assert.deepEqual(plantExportPreviewGroups(), ['Core', 'PrimarySilhouette', 'OrbitSet', 'BodyShell']);
});

test('plant export latest ranking treats default auto split as a fallback sample', () => {
  assert.ok(
    plantExportWorkspacePriority('CrownLily_local-upload-mr9h3xvd-Meshy_AI_Flamebound') >
      plantExportWorkspacePriority('CrownLily_flamebound-scepter-auto-split'),
  );
  assert.ok(
    plantExportWorkspacePriority('AetherVineC0_user_regroup') >
      plantExportWorkspacePriority('CrownLily_flamebound-scepter-auto-split'),
  );
});

test('inbox plant samples expose split and PBR GLB files as server-visible sample assets', () => {
  const sample = resolveInboxPlantSampleFiles(
    'C:/Project/Tools/IslandMeshGen',
    'CrownLilyC0',
    [
      'Meshy_AI_Flamebound Scepter_1783275149_part-segmentation.glb',
      'Meshy_AI_Flamebound_Scepter_0705185825_texture.glb',
    ],
  );

  assert.equal(sample.sampleId, 'CrownLilyC0');
  assert.equal(sample.plantProfile, 'CrownLily');
  assert.equal(plantProfileForSampleId('AetherVineC3'), 'AetherVine');
  assert.deepEqual(Object.keys(sample.files), ['split-glb', 'pbr-glb']);
  assert.equal(
    sample.files['split-glb'],
    'C:\\Project\\Tools\\IslandMeshGen\\mesh_inbox\\CrownLilyC0\\Meshy_AI_Flamebound Scepter_1783275149_part-segmentation.glb',
  );
  assert.equal(
    sample.files['pbr-glb'],
    'C:\\Project\\Tools\\IslandMeshGen\\mesh_inbox\\CrownLilyC0\\Meshy_AI_Flamebound_Scepter_0705185825_texture.glb',
  );
  assert.throws(
    () => resolveInboxPlantSampleFiles('C:/Project/Tools/IslandMeshGen', 'CrownLilyC0', ['only_texture.glb']),
    /split GLB and PBR GLB/,
  );
});

test('local plant uploads resolve to server-visible split and PBR GLB files inside upload workspace', () => {
  const sample = resolveLocalPlantUploadSampleFiles(
    'C:/Project/Tools/IslandMeshGen',
    'local-upload-crown-c1',
    {
      plantProfile: 'CrownLily',
      assets: {
        'split-glb': { fileName: 'split.glb', bytes: 11 },
        'pbr-glb': { fileName: 'pbr.glb', bytes: 22 },
      },
    },
  );

  assert.equal(sample.sampleId, 'local-upload-crown-c1');
  assert.equal(sample.plantProfile, 'CrownLily');
  assert.equal(sample.files['split-glb'], 'C:\\Project\\Tools\\IslandMeshGen\\output\\plant_regroup\\_local_uploads\\local-upload-crown-c1\\split.glb');
  assert.equal(sample.files['pbr-glb'], 'C:\\Project\\Tools\\IslandMeshGen\\output\\plant_regroup\\_local_uploads\\local-upload-crown-c1\\pbr.glb');
  assert.throws(
    () => resolveLocalPlantUploadSampleFiles(
      'C:/Project/Tools/IslandMeshGen',
      'local-upload-crown-c1',
      { assets: { 'split-glb': { fileName: '../split.glb' }, 'pbr-glb': { fileName: 'pbr.glb' } } },
    ),
    /Invalid local upload file name/,
  );
});

test('plant preview file paths stay inside export preview roots', () => {
  const toolRoot = 'C:/Project/Tools/IslandMeshGen';
  const allowed = resolvePlantPreviewFilePath(
    toolRoot,
    'mesh_inbox/_analysis_runs/AetherVineC0_user_regroup/03_pbr_parts/Core/Core.gltf',
  );

  assert.equal(
    allowed,
    'C:\\Project\\Tools\\IslandMeshGen\\mesh_inbox\\_analysis_runs\\AetherVineC0_user_regroup\\03_pbr_parts\\Core\\Core.gltf',
  );
  assert.equal(
    plantPreviewProjectPath(toolRoot, allowed),
    'mesh_inbox/_analysis_runs/AetherVineC0_user_regroup/03_pbr_parts/Core/Core.gltf',
  );
  assert.equal(
    plantPreviewFileUrl(toolRoot, allowed),
    '/api/plant/export-preview/file?path=mesh_inbox%2F_analysis_runs%2FAetherVineC0_user_regroup%2F03_pbr_parts%2FCore%2FCore.gltf',
  );
  assert.throws(
    () => resolvePlantPreviewFilePath(toolRoot, 'mesh_inbox/AetherVineC0/source.glb'),
    /outside plant export preview roots/,
  );
  assert.throws(
    () => resolvePlantPreviewFilePath(toolRoot, '../secret.txt'),
    /outside plant export preview roots/,
  );
});

test('preview paths stay inside the temporary preview directory for a biome', () => {
  const preview = previewPathsForBiome('C:/Project/Tools/IslandMeshGen', 'fire');
  const baked = pathsForBiome('C:/Project/Tools/IslandMeshGen', 'fire');

  assert.equal(preview.previewDir, 'C:\\Project\\Tools\\IslandMeshGen\\output\\.preview');
  assert.equal(preview.layoutPath, 'C:\\Project\\Tools\\IslandMeshGen\\output\\.preview\\fire_preview_layout.json');
  assert.equal(preview.meshPath, 'C:\\Project\\Tools\\IslandMeshGen\\output\\.preview\\fire_preview.obj');
  assert.equal(preview.manifestPath, 'C:\\Project\\Tools\\IslandMeshGen\\output\\.preview\\fire_preview.manifest.json');
  assert.equal(preview.fieldPath, 'C:\\Project\\Tools\\IslandMeshGen\\output\\.preview\\fire_preview.field.json');
  assert.equal(preview.qualityReportPath, 'C:\\Project\\Tools\\IslandMeshGen\\output\\.preview\\fire_preview.quality_report.json');
  assert.notEqual(preview.meshPath, baked.meshPath);
  assert.equal(baked.fieldPath, 'C:\\Project\\Tools\\IslandMeshGen\\output\\SM_ProcIsland_Fire_VolcanoLayout_200m.field.json');
  assert.equal(baked.qualityReportPath, 'C:\\Project\\Tools\\IslandMeshGen\\output\\SM_ProcIsland_Fire_VolcanoLayout_200m.quality_report.json');
});

test('high-res inspect paths stay inside a separate temporary inspect directory', () => {
  const inspect = inspectPathsForBiome('C:/Project/Tools/IslandMeshGen', 'fire');
  const preview = previewPathsForBiome('C:/Project/Tools/IslandMeshGen', 'fire');
  const baked = pathsForBiome('C:/Project/Tools/IslandMeshGen', 'fire');

  assert.equal(inspect.inspectDir, 'C:\\Project\\Tools\\IslandMeshGen\\output\\.inspect');
  assert.equal(inspect.layoutPath, 'C:\\Project\\Tools\\IslandMeshGen\\output\\.inspect\\fire_inspect_layout.json');
  assert.equal(inspect.meshPath, 'C:\\Project\\Tools\\IslandMeshGen\\output\\.inspect\\fire_inspect.obj');
  assert.equal(inspect.manifestPath, 'C:\\Project\\Tools\\IslandMeshGen\\output\\.inspect\\fire_inspect.manifest.json');
  assert.equal(inspect.fieldPath, 'C:\\Project\\Tools\\IslandMeshGen\\output\\.inspect\\fire_inspect.field.json');
  assert.equal(inspect.qualityReportPath, 'C:\\Project\\Tools\\IslandMeshGen\\output\\.inspect\\fire_inspect.quality_report.json');
  assert.notEqual(inspect.meshPath, preview.meshPath);
  assert.notEqual(inspect.meshPath, baked.meshPath);
});

test('preview export caps high-density bake quality at interactive preview topology', () => {
  assert.deepEqual(previewExportArgs(), {
    quality: 'draft',
    segments: 96,
    rings: 14,
  });
  assert.deepEqual(previewExportArgs('production'), {
    quality: 'preview',
    segments: 128,
    rings: 20,
  });
  assert.deepEqual(previewExportArgs('hero'), {
    quality: 'preview',
    segments: 128,
    rings: 20,
  });
});

test('bake quality profiles separate fast preview from production terrain density', () => {
  assert.equal(normalizeBakeQuality('unknown'), 'production');
  assert.deepEqual(exportArgsForQuality('production'), {
    quality: 'production',
    segments: 192,
    rings: 32,
  });
  assert.deepEqual(bakeQualityOptions().map((option) => option.id), ['draft', 'preview', 'production', 'hero']);
  assert.equal(bakeQualityOptions()[0].label, 'Draft');
});

test('preview header does not duplicate process layer mask selection controls', () => {
  const html = readFileSync(new URL('./index.html', import.meta.url), 'utf8');
  const app = readFileSync(new URL('./app.js', import.meta.url), 'utf8');

  assert.equal(html.includes('id="maskViewControl"'), false);
  assert.equal(html.includes('mask-view-toggle'), false);
  assert.equal(app.includes('maskViewOptions'), false);
  assert.equal(app.includes('querySelector(\'#maskViewControl\')'), false);
});

test('preview stage gets priority over controls in the authoring layout', () => {
  const html = readFileSync(new URL('./index.html', import.meta.url), 'utf8');
  const css = readFileSync(new URL('./styles.css', import.meta.url), 'utf8');
  const meshIndex = html.indexOf('class="mesh-preview"');
  const legendIndex = html.indexOf('id="layoutLegend"');
  const resetCameraIndex = html.indexOf('id="resetCameraButton"');
  const layerRailIndex = html.indexOf('id="maskCoverage"');
  const headingTitleIndex = html.indexOf('class="preview-title-row"');
  const previewGridIndex = html.indexOf('class="preview-grid"');
  const semanticDockIndex = html.indexOf('class="semantic-dock"');
  const controlIndex = html.indexOf('class="panel control-panel workbench-panel"');
  const bottomIndex = html.indexOf('class="bottom-grid"');

  assert.equal(html.includes('class="panel control-panel workbench-panel"'), true);
  assert.equal(html.includes('class="panel-heading preview-heading"'), true);
  assert.equal(html.includes('class="preview-title-row"'), true);
  assert.equal(html.includes('class="workbench-body"'), true);
  assert.equal(html.includes('class="map-legend viewport-legend"'), true);
  assert.equal(html.includes('class="mask-coverage layer-rail"'), true);
  assert.equal(headingTitleIndex < layerRailIndex, true);
  assert.equal(layerRailIndex < previewGridIndex, true);
  assert.equal(layerRailIndex < semanticDockIndex, true);
  assert.equal(meshIndex < legendIndex, true);
  assert.equal(legendIndex < resetCameraIndex, true);
  assert.equal(controlIndex < bottomIndex, true);
  assert.equal(css.includes('.hero-grid {\n  display: grid;\n  grid-template-columns: 1fr;'), true);
  assert.equal(css.includes('.preview-grid {\n  display: grid;\n  grid-template-columns: minmax(420px, 0.72fr) minmax(760px, 1.28fr);'), true);
  assert.equal(css.includes('.workbench-panel'), true);
  assert.equal(css.includes('.workbench-body'), true);
  assert.equal(css.includes('.preview-title-row'), true);
  assert.equal(css.includes('.preview-heading .layer-rail'), true);
  assert.equal(css.includes('grid-template-columns: repeat(auto-fit, minmax(92px, 1fr));'), true);
  assert.equal(css.includes('height: clamp(390px, 44vh, 540px)'), true);
  assert.equal(css.includes('transform: translateY(-1px);'), true);
  assert.equal(css.includes('overflow-x: auto'), false);
  assert.equal(css.includes('.mesh-preview .viewport-legend'), true);
  assert.equal(css.includes('position: sticky'), false);
});

test('mesh preview render loop is demand driven instead of permanently hot', () => {
  const app = readFileSync(new URL('./app.js', import.meta.url), 'utf8');

  assert.equal(app.includes('function requestMeshRender'), true);
  assert.equal(app.trimEnd().endsWith('requestAnimationFrame(drawMeshPreview);'), false);
  assert.equal(app.includes('requestMeshRender();'), true);
});

test('high-res inspect is an explicit final-quality snapshot flow, not the realtime preview flow', () => {
  const html = readFileSync(new URL('./index.html', import.meta.url), 'utf8');
  const app = readFileSync(new URL('./app.js', import.meta.url), 'utf8');
  const css = readFileSync(new URL('./styles.css', import.meta.url), 'utf8');
  const server = readFileSync(new URL('./server.mjs', import.meta.url), 'utf8');

  assert.equal(html.includes('id="inspectButton"'), true);
  assert.equal(html.includes('id="inspectStatus"'), true);
  assert.equal(html.includes('id="gpuMeshCanvas"'), true);
  assert.equal(app.includes('function runHighResInspect'), true);
  assert.equal(app.includes('function renderGpuInspectMesh'), true);
  assert.equal(app.includes('function setGpuInspectActive'), true);
  assert.equal(app.includes('previewQualityStatusForBakeQuality'), true);
  assert.equal(app.includes('float screenY = z * 1.55 * perspective * uZoom - y * 0.18;'), true);
  assert.equal(app.includes('gl_Position = vec4(screenX, screenY, -y * 0.08, 1.0);'), true);
  assert.equal(app.includes('inspectBakeSignature'), true);
  assert.equal(app.includes('lastInspectSignature'), true);
  assert.equal(app.includes('/api/inspect/'), true);
  assert.equal(app.includes("setPreviewMesh(authoritativeMesh, 'inspect')"), false);
  assert.equal(server.includes('const inspectMatch = requestPath.match'), true);
  assert.equal(server.includes('inspectPathsForBiome'), true);
  assert.equal(server.includes("const exportOptions = exportArgsForQuality(requestUrl.searchParams.get('quality'));"), true);
  assert.equal(css.includes('.inspect-button'), true);
  assert.equal(css.includes('.inspect-status'), true);
  assert.equal(css.includes('.mesh-preview.gpu-inspect-active .viewport-legend'), true);
});

test('app syncs final bake selection from generated manifest quality', () => {
  const app = readFileSync(new URL('./app.js', import.meta.url), 'utf8');

  assert.equal(app.includes('function syncBakeQualityFromManifest'), true);
  assert.equal(app.includes('manifest?.bake?.quality'), true);
  assert.equal(app.includes('loadManifest({ syncBakeQuality: true })'), true);
  assert.equal(app.includes('selectedBakeQuality = manifestQuality'), true);
});

test('gpu inspect renderer uses face normals and directional fill lighting for readable terrain depth', () => {
  const app = readFileSync(new URL('./app.js', import.meta.url), 'utf8');

  assert.equal(app.includes('attribute vec3 aNormal;'), true);
  assert.equal(app.includes('normalBuffer: gl.createBuffer()'), true);
  assert.equal(app.includes("normal: gl.getAttribLocation(program, 'aNormal')"), true);
  assert.equal(app.includes("keyLight: gl.getUniformLocation(program, 'uKeyLight')"), true);
  assert.equal(app.includes("fillLight: gl.getUniformLocation(program, 'uFillLight')"), true);
  assert.equal(app.includes('dot(normalize(aNormal), normalize(uKeyLight))'), true);
  assert.equal(app.includes('dot(normalize(aNormal), normalize(uFillLight))'), true);
  assert.equal(app.includes('gl.uniform3f(shader.keyLight'), true);
  assert.equal(app.includes('gl.uniform3f(shader.fillLight'), true);
  assert.equal(app.includes('gl.vertexAttribPointer(shader.normal, 3, gl.FLOAT, false, 0, 0)'), true);
});

test('gpu inspect render requests bypass hidden canvas redraws while the WebGL viewport is active', () => {
  const app = readFileSync(new URL('./app.js', import.meta.url), 'utf8');

  assert.match(app, /function requestMeshRender\(\) \{\s+if \(shouldRenderMeshWithWebgl\(\)\) \{\s+requestGpuInspectRender\(\);\s+return;\s+\}\s+meshRenderDirty = true;/);
});

test('mesh preview can switch between WebGL and Canvas render backends', () => {
  const html = readFileSync(new URL('./index.html', import.meta.url), 'utf8');
  const app = readFileSync(new URL('./app.js', import.meta.url), 'utf8');
  const css = readFileSync(new URL('./styles.css', import.meta.url), 'utf8');

  assert.equal(html.includes('id="rendererToggle"'), true);
  assert.equal(html.includes('data-renderer-mode="webgl"'), true);
  assert.equal(html.includes('data-renderer-mode="canvas"'), true);
  assert.equal(app.includes("let meshRendererMode = 'webgl';"), true);
  assert.equal(app.includes('function setMeshRendererMode'), true);
  assert.equal(app.includes('function updateRendererToggleUi'), true);
  assert.equal(app.includes('webgl-preview-active'), true);
  assert.equal(css.includes('.renderer-toggle'), true);
  assert.equal(css.includes('.mesh-preview.webgl-preview-active #meshCanvas'), true);
});

test('WebGL realtime preview receives authoring overlay attributes instead of relying on Canvas overlays', () => {
  const app = readFileSync(new URL('./app.js', import.meta.url), 'utf8');

  assert.equal(app.includes('overlayBuffer: gl.createBuffer()'), true);
  assert.equal(app.includes('attribute vec4 aOverlay;'), true);
  assert.equal(app.includes("overlay: gl.getAttribLocation(program, 'aOverlay')"), true);
  assert.equal(app.includes('overlayColorForFace'), true);
  assert.equal(app.includes('processTraceColorForFace(baseColor'), true);
  assert.equal(app.includes('qualityRiskColorForFace(risk'), true);
  assert.equal(app.includes('meshDeltaColorForFace(delta'), true);
  assert.equal(app.includes('biomeMovementHighlightForFace(face'), true);
  assert.equal(app.includes('processMovementHighlightForFace(frame.renderField'), true);
  assert.equal(app.includes('gl.vertexAttribPointer(shader.overlay, 4, gl.FLOAT, false, 0, 0)'), true);
});

test('2D material preview draws biome-specific range diagrams for ice and forest', () => {
  const app = readFileSync(new URL('./app.js', import.meta.url), 'utf8');

  assert.equal(app.includes('function drawFireLiveOverlay'), true);
  assert.equal(app.includes('function drawIceLiveOverlay'), true);
  assert.equal(app.includes('function drawForestLiveOverlay'), true);
  assert.equal(app.includes('biomeLiveOverlaySpec(layout)'), true);
  assert.equal(app.includes("spec.biome === 'ice'"), true);
  assert.equal(app.includes("spec.biome === 'forest'"), true);
});

test('WebGL realtime preview remains demand driven and skips hidden Canvas redraws', () => {
  const app = readFileSync(new URL('./app.js', import.meta.url), 'utf8');

  assert.match(app, /function requestMeshRender\(\) \{\s+if \(shouldRenderMeshWithWebgl\(\)\) \{\s+requestGpuInspectRender\(\);\s+return;\s+\}\s+meshRenderDirty = true;/);
  assert.equal(app.includes('if (meshRendererMode === \'canvas\') requestMeshRender();'), true);
});

test('high-res inspect keeps realtime preview field data separate from inspect field data', () => {
  const app = readFileSync(new URL('./app.js', import.meta.url), 'utf8');
  const inspectStart = app.indexOf('async function runHighResInspect()');
  const inspectEnd = app.indexOf('async function loadManifest()', inspectStart);
  const inspectBody = app.slice(inspectStart, inspectEnd);

  assert.equal(app.includes('let gpuInspectField = null;'), true);
  assert.equal(app.includes('const renderField = gpuInspectActive ? gpuInspectField || currentField : currentField;'), true);
  assert.equal(inspectBody.includes('gpuInspectField = payload.field || null;'), true);
  assert.equal(inspectBody.includes('currentField = payload.field || null;'), false);
});

test('starting a slider edit exits GPU inspect before realtime preview redraws', () => {
  const app = readFileSync(new URL('./app.js', import.meta.url), 'utf8');
  const beginStart = app.indexOf('function beginControlInteraction');
  const beginEnd = app.indexOf('function finishControlInteraction', beginStart);
  const beginBody = app.slice(beginStart, beginEnd);

  assert.equal(beginBody.includes('leaveGpuInspectForRealtimePreview();'), true);
  assert.match(beginBody, /leaveGpuInspectForRealtimePreview\(\);\s+requestMeshRender\(\);/);
});

test('preview baking pill keeps the active authoring control visible while fitting', () => {
  const app = readFileSync(new URL('./app.js', import.meta.url), 'utf8');

  assert.equal(app.includes('`${activeMovementHighlightLabel()} fitting`'), true);
});

test('map probe exposes quality advisor guidance and linked controls', () => {
  const app = readFileSync(new URL('./app.js', import.meta.url), 'utf8');
  const css = readFileSync(new URL('./styles.css', import.meta.url), 'utf8');

  assert.equal(app.includes('qualityAdvisorForFace'), true);
  assert.equal(app.includes('probe-advisor'), true);
  assert.equal(app.includes('data-control-id'), true);
  assert.equal(css.includes('.probe-advisor'), true);
  assert.equal(css.includes('.advisor-linked'), true);
});

test('server writes and serves quality reports next to baked meshes', () => {
  const server = readFileSync(new URL('./server.mjs', import.meta.url), 'utf8');

  assert.equal(server.includes('qualityReportForMesh'), true);
  assert.equal(server.includes('writeQualityReport'), true);
  assert.equal(server.includes('quality-report'), true);
  assert.equal(server.includes('qualityReportMatch'), true);
  assert.equal(server.includes('qualityReportPath'), true);
  assert.equal(server.includes('fieldData'), true);
  assert.equal(server.includes('qualityReportData'), true);
});

test('bake status exposes quality report summary and artifact path', () => {
  const app = readFileSync(new URL('./app.js', import.meta.url), 'utf8');

  assert.equal(app.includes('payload.qualitySummary'), true);
  assert.equal(app.includes('Report summary:'), true);
  assert.equal(app.includes('payload.qualityReport'), true);
  assert.equal(app.includes('Quality report:'), true);
});

test('quality report issues become an actionable repair queue', () => {
  const html = readFileSync(new URL('./index.html', import.meta.url), 'utf8');
  const app = readFileSync(new URL('./app.js', import.meta.url), 'utf8');
  const css = readFileSync(new URL('./styles.css', import.meta.url), 'utf8');
  const controlsIndex = html.indexOf('id="controlCards"');
  const repairIndex = html.indexOf('id="qualityRepairQueue"');
  const resetIndex = html.indexOf('id="resetButton"');
  const statusIndex = html.indexOf('id="generationStatus"');

  assert.equal(html.includes('id="qualityRepairQueue"'), true);
  assert.equal(html.includes('class="workbench-header"'), true);
  assert.equal(html.includes('class="workbench-main"'), true);
  assert.equal(controlsIndex < repairIndex, true);
  assert.equal(resetIndex < controlsIndex, true);
  assert.equal(statusIndex < controlsIndex, true);
  assert.equal(html.includes('quality-repair-queue hidden'), false);
  assert.equal(app.includes('function renderQualityRepairQueue'), true);
  assert.equal(app.includes('Quality checks pending'), true);
  assert.equal(app.includes('No top issues'), true);
  assert.equal(app.includes('function focusQualityIssue'), true);
  assert.equal(app.includes('activeQualityIssue'), true);
  assert.equal(app.includes('data-issue-index'), true);
  assert.equal(app.includes('payload.fieldData'), true);
  assert.equal(app.includes('payload.qualityReportData'), true);
  assert.equal(app.includes('qualityDiagnostics'), true);
  assert.equal(app.includes('control-count-${controlPage.controls.length}'), true);
  assert.equal(app.includes('class="control-group-tools"'), true);
  assert.equal(css.includes('.quality-repair-queue'), true);
  assert.equal(css.includes('grid-area: controls'), true);
  assert.equal(css.includes('grid-area: diagnostics'), true);
  assert.equal(css.includes('.control-group.control-count-2'), true);
  assert.equal(css.includes('.control-group.control-count-3'), true);
  assert.equal(css.includes('.control-group-tools'), true);
  assert.equal(css.includes('.process-trace-toggle.compact'), true);
  assert.equal(css.includes('.repair-issues {\n  display: grid;\n  gap: 5px;\n  max-height:'), true);
  assert.equal(css.includes('.repair-empty'), true);
  assert.equal(css.includes('.repair-issue.active'), true);
});

test('repair queue can apply conservative nudge actions', () => {
  const app = readFileSync(new URL('./app.js', import.meta.url), 'utf8');
  const css = readFileSync(new URL('./styles.css', import.meta.url), 'utf8');

  assert.equal(app.includes('qualityNudgePlanForIssue'), true);
  assert.equal(app.includes('qualityNudgePlanSummaryForIssue'), true);
  assert.equal(app.includes('function nudgeQualityIssue'), true);
  assert.equal(app.includes('function previewNudgePlan'), true);
  assert.equal(app.includes('function clearNudgePlanPreview'), true);
  assert.equal(app.includes('repair-nudge-plan'), true);
  assert.equal(app.includes('data-issue-nudge-index'), true);
  assert.equal(app.includes("addEventListener('mouseenter'"), true);
  assert.equal(app.includes("addEventListener('focus'"), true);
  assert.equal(app.includes('handleLayoutEdited(currentLayout'), true);
  assert.equal(css.includes('.repair-nudge'), true);
  assert.equal(css.includes('.repair-nudge-plan'), true);
  assert.equal(css.includes('.repair-nudge-chip'), true);
  assert.equal(css.includes('.repair-nudge:focus-visible'), true);
  assert.equal(css.includes('.repair-nudge:active'), true);
});

test('repair queue reports nudge before-after risk delta after preview bake', () => {
  const app = readFileSync(new URL('./app.js', import.meta.url), 'utf8');
  const css = readFileSync(new URL('./styles.css', import.meta.url), 'utf8');

  assert.equal(app.includes('qualityNudgeResultForIssue'), true);
  assert.equal(app.includes('activeNudgeReview'), true);
  assert.equal(app.includes('function updateNudgeReviewWithReport'), true);
  assert.equal(app.includes('repair-nudge-result'), true);
  assert.equal(app.includes('updateNudgeReviewWithReport(payload.qualityReport'), true);
  assert.equal(css.includes('.repair-nudge-result'), true);
  assert.equal(css.includes('.repair-nudge-result.improved'), true);
  assert.equal(css.includes('.repair-nudge-result.worse'), true);
});

test('plant page exposes exported PBR part preview controls', () => {
  const html = readFileSync(new URL('./plant.html', import.meta.url), 'utf8');
  const app = readFileSync(new URL('./plant_regroup.js', import.meta.url), 'utf8');
  const css = readFileSync(new URL('./plant_styles.css', import.meta.url), 'utf8');
  const server = readFileSync(new URL('./server.mjs', import.meta.url), 'utf8');

  assert.equal(html.includes('id="pbrPreviewCanvas"'), true);
  assert.equal(html.includes('id="loadLatestPreviewButton"'), true);
  assert.equal(html.includes('id="packPbrGlbsButton"'), true);
  assert.equal(html.includes('data-pbr-preview-mode="textured"'), true);
  assert.equal(html.includes('id="pbrPartToggleList"'), true);
  assert.equal(html.includes('id="meshyRoundtripPanel"'), true);
  assert.equal(html.includes('id="sendMeshyRoundtripButton"'), true);
  assert.equal(html.includes('id="meshyRoundtripTargetHint"'), true);
  assert.equal(html.includes('id="variantManagerPanel"'), true);
  assert.equal(html.includes('id="variantList"'), true);
  assert.equal(html.includes('id="compareOriginalButton"'), true);
  assert.equal(html.includes('id="compareVariantButton"'), true);
  assert.equal(html.includes('id="compareMixedButton"'), true);
  assert.equal(app.includes('async function loadPbrExportPreview'), true);
  assert.equal(app.includes('async function packPbrGlbs'), true);
  assert.equal(app.includes('async function startMeshyRoundtrip'), true);
  assert.equal(app.includes('Export Current Parts First'), true);
  assert.equal(app.includes('This button will not switch workspaces.'), true);
  assert.equal(app.includes('roundtripTrusted: true'), true);
  assert.equal(app.includes('current manual export'), true);
  assert.equal(app.includes('Meshy send will use this exact PBR preview.'), true);
  assert.equal(app.includes('async function pollMeshyRoundtrip'), true);
  assert.equal(app.includes('function setMeshyRoundtripTarget'), true);
  assert.equal(app.includes('function syncSemanticTargetToMeshyRoundtrip'), true);
  assert.equal(app.includes('function latestMeshyRoundtripRunForGroup'), true);
  assert.equal(app.includes('function currentMeshyRoundtripRun'), true);
  assert.equal(app.includes('data-pbr-target-group'), true);
  assert.equal(app.includes('data-pbr-visibility-group'), true);
  assert.equal(app.includes('async function loadRoundtripResultAsVariant'), true);
  assert.equal(app.includes('function renderVariantManager'), true);
  assert.equal(app.includes('function activePbrPreviewPart'), true);
  assert.equal(app.includes('function setVariantCompareMode'), true);
  assert.equal(app.includes('/api/plant/export-preview'), true);
  assert.equal(app.includes('/api/plant/pack-pbr-glbs'), true);
  assert.equal(app.includes('/api/plant/meshy-roundtrip/start'), true);
  assert.equal(app.includes('/api/plant/meshy-roundtrip/poll'), true);
  assert.equal(app.includes('function renderPbrPreviewScene'), true);
  assert.equal(app.includes('function resolvePreviewAssetUrl'), true);
  assert.equal(server.includes('/api/plant/pack-pbr-glbs'), true);
  assert.equal(server.includes('packPlantPbrGlbs'), true);
  assert.equal(server.includes('/api/plant/meshy-roundtrip/start'), true);
  assert.equal(server.includes('startPlantMeshyRoundtrip'), true);
  assert.equal(css.includes('.export-preview-panel'), true);
  assert.equal(css.includes('.pbr-part-toggle'), true);
  assert.equal(css.includes('.pbr-part-toggle.targeted'), true);
  assert.equal(css.includes('.pbr-part-action'), true);
  assert.equal(css.includes('.meshy-roundtrip-panel'), true);
  assert.equal(css.includes('.variant-manager-panel'), true);
});
