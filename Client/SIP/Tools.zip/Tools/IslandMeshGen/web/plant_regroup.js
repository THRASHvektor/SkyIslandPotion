const $ = (selector) => document.querySelector(selector);

const ui = {
  partCountMetric: $('#partCountMetric'),
  triCountMetric: $('#triCountMetric'),
  mappingModeMetric: $('#mappingModeMetric'),
  splitAssetName: $('#splitAssetName'),
  pbrAssetName: $('#pbrAssetName'),
  strategyName: $('#strategyName'),
  splitGlbInput: $('#splitGlbInput'),
  splitObjInput: $('#splitObjInput'),
  splitMtlInput: $('#splitMtlInput'),
  pbrGlbInput: $('#pbrGlbInput'),
  loadLocalButton: $('#loadLocalButton'),
  importStatus: $('#importStatus'),
  reloadSampleButton: $('#reloadSampleButton'),
  autoSuggestButton: $('#autoSuggestButton'),
  selectedSummary: $('#selectedSummary'),
  showAllPartsButton: $('#showAllPartsButton'),
  partSearchInput: $('#partSearchInput'),
  partList: $('#partList'),
  viewerStatus: $('#viewerStatus'),
  clearSelectionButton: $('#clearSelectionButton'),
  resetCameraButton: $('#resetCameraButton'),
  colorModeControl: $('#colorModeControl'),
  explodeRange: $('#explodeRange'),
  explodeValue: $('#explodeValue'),
  plantCanvas: $('#plantCanvas'),
  viewportHud: $('#viewportHud'),
  loadingVeil: $('#loadingVeil'),
  selectionDetails: $('#selectionDetails'),
  activeGroupLabel: $('#activeGroupLabel'),
  assignSelectedButton: $('#assignSelectedButton'),
  plantProfileControl: $('#plantProfileControl'),
  groupList: $('#groupList'),
  soloSelectedButton: $('#soloSelectedButton'),
  resetGroupsButton: $('#resetGroupsButton'),
  manifestStatus: $('#manifestStatus'),
  manifestPreview: $('#manifestPreview'),
  copyManifestButton: $('#copyManifestButton'),
  projectionDiagnosticsButton: $('#projectionDiagnosticsButton'),
  exportPbrPartsButton: $('#exportPbrPartsButton'),
  saveManifestButton: $('#saveManifestButton'),
  downloadManifestButton: $('#downloadManifestButton'),
  assetReportStatus: $('#assetReportStatus'),
  assetReport: $('#assetReport'),
  pbrPreviewStatus: $('#pbrPreviewStatus'),
  loadLatestPreviewButton: $('#loadLatestPreviewButton'),
  packPbrGlbsButton: $('#packPbrGlbsButton'),
  pbrPreviewFitButton: $('#pbrPreviewFitButton'),
  pbrPreviewModeControl: $('#pbrPreviewModeControl'),
  pbrPreviewExplodeRange: $('#pbrPreviewExplodeRange'),
  pbrPreviewExplodeValue: $('#pbrPreviewExplodeValue'),
  pbrPreviewCanvas: $('#pbrPreviewCanvas'),
  pbrPreviewHud: $('#pbrPreviewHud'),
  pbrPreviewVeil: $('#pbrPreviewVeil'),
  pbrPartToggleList: $('#pbrPartToggleList'),
  pbrPreviewReport: $('#pbrPreviewReport'),
  meshyRoundtripStatus: $('#meshyRoundtripStatus'),
  meshyRoundtripGroup: $('#meshyRoundtripGroup'),
  meshyRoundtripTargetHint: $('#meshyRoundtripTargetHint'),
  meshyRoundtripOperation: $('#meshyRoundtripOperation'),
  meshyRoundtripPrompt: $('#meshyRoundtripPrompt'),
  meshyRoundtripPromptMeter: $('#meshyRoundtripPromptMeter'),
  sendMeshyRoundtripButton: $('#sendMeshyRoundtripButton'),
  pollMeshyRoundtripButton: $('#pollMeshyRoundtripButton'),
  meshyRoundtripReport: $('#meshyRoundtripReport'),
  variantManagerStatus: $('#variantManagerStatus'),
  compareOriginalButton: $('#compareOriginalButton'),
  compareVariantButton: $('#compareVariantButton'),
  compareMixedButton: $('#compareMixedButton'),
  variantList: $('#variantList'),
};

const semanticGroups = [
  { id: 'Core', color: '#ffcf70' },
  { id: 'PrimarySilhouette', color: '#69d6c9' },
  { id: 'OrbitSet', color: '#9f8cff' },
  { id: 'BodyShell', color: '#d95f5f' },
];

const meshyTextStylePromptMaxLength = 800;
const defaultAutoSplitWorkspacePattern = /flamebound-scepter-auto-split/i;
const groupById = new Map(semanticGroups.map((group) => [group.id, group]));
const unassignedColor = '#69717d';
const plantProfiles = {
  CrownLily: {
    label: 'CrownLily',
    groupLabels: {
      Core: '灯芯球',
      PrimarySilhouette: '浮空花冠',
      OrbitSet: '轨道',
      BodyShell: '根盘 + 灯茎',
    },
  },
  AetherVine: {
    label: 'AetherVine',
    groupLabels: {
      PrimarySilhouette: '星轨弧',
      Core: '星核',
      OrbitSet: '星点 + 符文片',
      BodyShell: '根结 + 主藤',
    },
  },
};
const fallbackPalette = [
  [0.14, 0.58, 0.86],
  [0.88, 0.38, 0.22],
  [0.68, 0.82, 0.36],
  [0.62, 0.44, 0.95],
  [0.94, 0.72, 0.26],
  [0.22, 0.78, 0.68],
  [0.92, 0.42, 0.62],
  [0.72, 0.78, 0.86],
];

const state = {
  sample: null,
  mesh: null,
  parts: [],
  selectedPartIds: new Set(),
  assignments: new Map(),
  hiddenPartIds: new Set(),
  soloPartIds: new Set(),
  activeGroup: 'Core',
  plantProfile: 'CrownLily',
  colorMode: 'semantic',
  explodeAmount: 0,
  filter: '',
  manifestText: '{}',
  renderer: null,
  sourceMode: 'sample',
  localImport: {
    busy: false,
    pendingTimer: 0,
    loadedSignature: '',
  },
  pbrPreview: {
    payload: null,
    roundtripTrusted: false,
    sourceLabel: 'none',
    pack: null,
    roundtrip: {
      configured: false,
      activeRun: null,
      runs: [],
      lastError: '',
      polling: false,
      busy: false,
      timer: null,
    },
    parts: [],
    variants: new Map(),
    activeVariants: new Map(),
    compareMode: 'original',
    hiddenGroups: new Set(),
    renderer: null,
    mode: 'textured',
    explodeAmount: 0.24,
    camera: {
      yaw: 0.64,
      pitch: -0.18,
      zoom: 3.1,
      dragging: false,
      moved: false,
      lastX: 0,
      lastY: 0,
    },
  },
  camera: {
    yaw: 0.64,
    pitch: -0.24,
    zoom: 3.1,
    dragging: false,
    moved: false,
    lastX: 0,
    lastY: 0,
  },
};

async function init() {
  bindUi();
  setupRenderer();
  setupPbrPreviewRenderer();
  renderModeButtons();
  renderPbrPreviewModeButtons();
  renderGroupList();
  renderPbrPreviewShell();
  renderMeshyRoundtripShell();
  renderVariantManager();
  updateManifestPreview();
  checkMeshyRoundtripStatus();
  await loadSample();
  tryAutoLoadLatestPbrExportPreview();
}

function bindUi() {
  ui.reloadSampleButton.addEventListener('click', () => loadSample());
  ui.loadLocalButton.addEventListener('click', () => loadLocalFiles({ force: true }));
  for (const input of [ui.splitGlbInput, ui.pbrGlbInput, ui.splitObjInput, ui.splitMtlInput]) {
    input.addEventListener('change', () => {
      updateImportStatus();
      scheduleLocalGlbAutoLoad();
    });
  }
  ui.autoSuggestButton.addEventListener('click', () => {
    autoSuggestGroups();
    updateAllUi();
  });
  ui.clearSelectionButton.addEventListener('click', () => {
    state.selectedPartIds.clear();
    updateAllUi();
  });
  ui.resetCameraButton.addEventListener('click', () => {
    resetCamera();
    renderScene();
  });
  ui.colorModeControl.addEventListener('click', (event) => {
    const button = event.target.closest('[data-color-mode]');
    if (!button) return;
    state.colorMode = button.dataset.colorMode;
    renderModeButtons();
    renderPartList();
    renderScene();
  });
  ui.explodeRange.addEventListener('input', () => {
    state.explodeAmount = clamp(Number(ui.explodeRange.value || 0) / 100, 0, 1);
    ui.explodeValue.textContent = String(Math.round(state.explodeAmount * 100));
    renderScene();
  });
  ui.showAllPartsButton.addEventListener('click', () => {
    state.hiddenPartIds.clear();
    state.soloPartIds.clear();
    updateAllUi();
  });
  ui.soloSelectedButton.addEventListener('click', () => {
    state.soloPartIds = new Set(state.selectedPartIds);
    updateAllUi();
  });
  ui.resetGroupsButton.addEventListener('click', () => {
    state.assignments.clear();
    updateAllUi();
  });
  ui.assignSelectedButton.addEventListener('click', () => {
    assignSelectedToActiveGroup();
  });
  ui.copyManifestButton.addEventListener('click', async () => {
    await navigator.clipboard.writeText(state.manifestText);
    ui.manifestStatus.textContent = 'Copied';
    window.setTimeout(() => {
      ui.manifestStatus.textContent = 'Semantic draft';
    }, 1100);
  });
  ui.projectionDiagnosticsButton.addEventListener('click', () => analyzeProjection());
  ui.exportPbrPartsButton.addEventListener('click', () => exportPbrParts());
  ui.saveManifestButton.addEventListener('click', () => saveManifestToOutput());
  ui.loadLatestPreviewButton.addEventListener('click', () => loadPbrExportPreview());
  ui.packPbrGlbsButton.addEventListener('click', () => packPbrGlbs());
  ui.sendMeshyRoundtripButton.addEventListener('click', () => startMeshyRoundtrip());
  ui.pollMeshyRoundtripButton.addEventListener('click', () => pollMeshyRoundtrip());
  ui.compareOriginalButton.addEventListener('click', () => setVariantCompareMode('original'));
  ui.compareVariantButton.addEventListener('click', () => setVariantCompareMode('variant'));
  ui.compareMixedButton.addEventListener('click', () => setVariantCompareMode('mixed'));
  ui.variantList.addEventListener('click', (event) => handleVariantListClick(event));
  ui.meshyRoundtripGroup.addEventListener('change', () => {
    setMeshyRoundtripTarget(ui.meshyRoundtripGroup.value, { forcePrompt: false, source: 'manual' });
  });
  ui.meshyRoundtripOperation.addEventListener('change', () => {
    syncMeshyRoundtripPrompt({ force: true });
    state.pbrPreview.roundtrip.lastError = '';
    renderMeshyRoundtripShell();
  });
  ui.meshyRoundtripPrompt.addEventListener('input', () => {
    state.pbrPreview.roundtrip.lastError = '';
    renderMeshyRoundtripShell();
  });
  ui.pbrPreviewFitButton.addEventListener('click', () => {
    resetPbrPreviewCamera();
    renderPbrPreviewScene();
  });
  ui.pbrPreviewModeControl.addEventListener('click', (event) => {
    const button = event.target.closest('[data-pbr-preview-mode]');
    if (!button) return;
    state.pbrPreview.mode = button.dataset.pbrPreviewMode;
    renderPbrPreviewModeButtons();
    renderPbrPreviewScene();
  });
  ui.pbrPreviewExplodeRange.addEventListener('input', () => {
    state.pbrPreview.explodeAmount = clamp(Number(ui.pbrPreviewExplodeRange.value || 0) / 100, 0, 1);
    ui.pbrPreviewExplodeValue.textContent = String(Math.round(state.pbrPreview.explodeAmount * 100));
    renderPbrPreviewScene();
  });
  ui.pbrPartToggleList.addEventListener('click', (event) => {
    const visibilityButton = event.target.closest('[data-pbr-visibility-group]');
    if (visibilityButton) {
      const groupId = visibilityButton.dataset.pbrVisibilityGroup;
      if (state.pbrPreview.hiddenGroups.has(groupId)) {
        state.pbrPreview.hiddenGroups.delete(groupId);
      } else {
        state.pbrPreview.hiddenGroups.add(groupId);
      }
      renderPbrPartToggles();
      renderPbrPreviewScene();
      return;
    }
    const targetButton = event.target.closest('[data-pbr-target-group]');
    if (targetButton) {
      syncSemanticTargetToMeshyRoundtrip(targetButton.dataset.pbrTargetGroup, { forcePrompt: false });
      return;
    }
    const row = event.target.closest('[data-pbr-group-id]');
    if (!row) return;
    syncSemanticTargetToMeshyRoundtrip(row.dataset.pbrGroupId, { forcePrompt: false });
  });
  ui.downloadManifestButton.addEventListener('click', () => {
    const blob = new Blob([state.manifestText], { type: 'application/json' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = 'plant_regroup_manifest.json';
    link.click();
    URL.revokeObjectURL(link.href);
  });
  ui.partSearchInput.addEventListener('input', () => {
    state.filter = ui.partSearchInput.value.trim().toLowerCase();
    renderPartList();
  });
  ui.partList.addEventListener('click', (event) => {
    const hideButton = event.target.closest('[data-action="hide"]');
    const row = event.target.closest('[data-part-id]');
    if (!row) return;
    const partId = row.dataset.partId;
    if (hideButton) {
      toggleHidden(partId);
      return;
    }
    togglePartSelection(partId, event.ctrlKey || event.metaKey || event.shiftKey);
  });
  ui.groupList.addEventListener('click', (event) => {
    const card = event.target.closest('[data-group-id]');
    if (!card) return;
    syncSemanticTargetToMeshyRoundtrip(card.dataset.groupId, { forcePrompt: false });
  });
  ui.plantProfileControl.addEventListener('click', (event) => {
    const button = event.target.closest('[data-profile]');
    if (!button) return;
    state.plantProfile = button.dataset.profile;
    renderModeButtons();
    autoSuggestGroups({ silent: true });
    updateAllUi();
  });
  bindCanvasEvents();
  bindPbrPreviewCanvasEvents();
  window.addEventListener('resize', () => {
    renderScene();
    renderPbrPreviewScene();
  });
}

async function loadSample() {
  setLoading(true, 'Fetching Meshy sample...');
  ui.viewerStatus.textContent = 'Loading sample';
  try {
    resetWorkingState();
    state.sourceMode = 'sample';
    ui.importStatus.textContent = 'Sample asset active';
    const sample = await fetchJson(`/api/plant/sample${activeSampleQueryString()}`);
    state.sample = sample;
    if (sample.plantProfile && plantProfiles[sample.plantProfile]) {
      state.plantProfile = sample.plantProfile;
    }
    renderSampleHeader();
    const hasSplitObj = Boolean(sample.assets?.['split-obj']);
    const hasSplitGlb = Boolean(sample.assets?.['split-glb']);
    if (!hasSplitObj && !hasSplitGlb) {
      throw new Error('Sample has no Split GLB or legacy OBJ asset.');
    }
    setLoading(true, hasSplitObj ? 'Downloading split OBJ and MTL...' : 'Downloading split GLB...');
    const mesh = hasSplitObj
      ? await loadSampleObjMesh(sample)
      : await loadSampleGlbMesh(sample);
    await nextFrame();
    state.mesh = mesh;
    state.parts = mesh.parts;
    uploadMesh(mesh);
    autoSuggestGroups({ silent: true });
    resetCamera();
    updateAllUi();
    setLoading(false);
    ui.viewerStatus.textContent = 'Ready';
  } catch (error) {
    console.error(error);
    setLoading(false);
    ui.viewerStatus.textContent = 'Load failed';
    ui.selectionDetails.textContent = error.message;
  }
}

function activeSampleQueryString() {
  const sampleId = new URLSearchParams(window.location.search).get('sample');
  return sampleId ? `?id=${encodeURIComponent(sampleId)}` : '';
}

async function loadSampleObjMesh(sample) {
  const [objText, mtlText] = await Promise.all([
    fetchText(sample.assets['split-obj'].url),
    sample.assets['split-mtl'] ? fetchText(sample.assets['split-mtl'].url) : Promise.resolve(''),
  ]);
  setLoading(true, 'Parsing Meshy split OBJ...');
  await nextFrame();
  return parseObjToMesh(objText, parseMtl(mtlText));
}

async function loadSampleGlbMesh(sample) {
  const splitGlb = sample.assets['split-glb'];
  if (!splitGlb) throw new Error('Sample has no Split GLB asset.');
  const arrayBuffer = await fetchArrayBuffer(splitGlb.url);
  setLoading(true, 'Parsing Meshy split GLB...');
  await nextFrame();
  return parseGlbToMesh(arrayBuffer);
}

async function loadLocalFiles(options = {}) {
  const splitGlbFile = ui.splitGlbInput.files?.[0] || null;
  const objFile = ui.splitObjInput.files?.[0];
  const mtlFile = ui.splitMtlInput.files?.[0] || null;
  const pbrGlbFile = ui.pbrGlbInput.files?.[0] || null;
  const importSignature = currentLocalImportSignature();
  if (state.localImport.busy) {
    ui.importStatus.textContent = 'Local load already running';
    return;
  }
  if (!splitGlbFile && !objFile) {
    ui.importStatus.textContent = 'Choose Split GLB';
    return;
  }
  state.localImport.busy = true;
  ui.loadLocalButton.disabled = true;
  setLoading(true, 'Reading local Meshy files...');
  ui.viewerStatus.textContent = 'Loading local';
  try {
    resetWorkingState();
    state.sourceMode = 'local';
    state.sample = localSampleFromFiles({ splitGlbFile, objFile, mtlFile, pbrGlbFile });
    renderSampleHeader();
    setLoading(true, splitGlbFile ? 'Parsing local Split GLB...' : 'Parsing local legacy OBJ...');
    await nextFrame();
    const mesh = splitGlbFile
      ? parseGlbToMesh(await readLocalArrayBufferFile(splitGlbFile))
      : parseObjToMesh(
        await readLocalTextFile(objFile),
        parseMtl(mtlFile ? await readLocalTextFile(mtlFile) : ''),
      );
    state.mesh = mesh;
    state.parts = mesh.parts;
    uploadMesh(mesh);
    autoSuggestGroups({ silent: true });
    resetCamera();
    if (splitGlbFile && pbrGlbFile) {
      setLoading(true, 'Uploading local GLBs for export...');
      const uploadedSample = await uploadLocalGlbsForExport({ splitGlbFile, pbrGlbFile });
      state.sample = uploadedSample;
      state.sourceMode = 'sample';
      state.localImport.loadedSignature = importSignature;
      renderSampleHeader();
      ui.importStatus.textContent = 'Local GLBs uploaded for export';
    } else if (pbrGlbFile) {
      state.localImport.loadedSignature = '';
      ui.importStatus.textContent = 'Local preview only; export needs Split GLB + PBR GLB';
    } else {
      state.localImport.loadedSignature = '';
      ui.importStatus.textContent = 'Local preview only; choose PBR GLB for export';
    }
    updateAllUi();
    setLoading(false);
    ui.viewerStatus.textContent = 'Ready';
  } catch (error) {
    console.error(error);
    state.localImport.loadedSignature = '';
    setLoading(false);
    ui.viewerStatus.textContent = 'Local load failed';
    ui.importStatus.textContent = 'Local load failed';
    ui.selectionDetails.textContent = error.message;
  } finally {
    state.localImport.busy = false;
    ui.loadLocalButton.disabled = false;
    if (!options.force && currentLocalImportSignature() !== importSignature) {
      scheduleLocalGlbAutoLoad();
    }
  }
}

async function uploadLocalGlbsForExport({ splitGlbFile, pbrGlbFile }) {
  const uploadId = [
    'local-upload',
    Date.now().toString(36),
    safeIdFromName(splitGlbFile.name).slice(0, 48),
    safeIdFromName(pbrGlbFile.name).slice(0, 48),
  ].join('-').slice(0, 140);
  await uploadLocalGlbAsset({ uploadId, assetKey: 'split-glb', file: splitGlbFile });
  const pbrUpload = await uploadLocalGlbAsset({ uploadId, assetKey: 'pbr-glb', file: pbrGlbFile });
  if (!pbrUpload.sample) {
    throw new Error('Local GLB upload did not produce a complete export sample.');
  }
  return pbrUpload.sample;
}

async function uploadLocalGlbAsset({ uploadId, assetKey, file }) {
  const params = new URLSearchParams({
    uploadId,
    assetKey,
    fileName: file.name,
    plantProfile: state.plantProfile,
  });
  const response = await fetch(`/api/plant/local-upload?${params.toString()}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/octet-stream' },
    body: file,
  });
  const payload = await response.json();
  if (!response.ok || !payload.ok) {
    throw new Error(payload.error || `Local GLB upload failed: ${response.status}`);
  }
  return payload;
}

function resetWorkingState() {
  state.selectedPartIds.clear();
  state.hiddenPartIds.clear();
  state.soloPartIds.clear();
  state.assignments.clear();
}

async function fetchJson(url) {
  const response = await fetch(url, { cache: 'no-store' });
  if (!response.ok) throw new Error(`Request failed: ${response.status} ${url}`);
  return response.json();
}

async function fetchText(url) {
  const response = await fetch(url, { cache: 'no-store' });
  if (!response.ok) throw new Error(`Request failed: ${response.status} ${url}`);
  return response.text();
}

async function fetchArrayBuffer(url) {
  const response = await fetch(url, { cache: 'no-store' });
  if (!response.ok) throw new Error(`Request failed: ${response.status} ${url}`);
  return response.arrayBuffer();
}

function readLocalTextFile(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.addEventListener('load', () => resolve(String(reader.result || '')));
    reader.addEventListener('error', () => reject(reader.error || new Error(`Could not read ${file.name}`)));
    reader.readAsText(file);
  });
}

function readLocalArrayBufferFile(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.addEventListener('load', () => resolve(reader.result));
    reader.addEventListener('error', () => reject(reader.error || new Error(`Could not read ${file.name}`)));
    reader.readAsArrayBuffer(file);
  });
}

function localSampleFromFiles({ splitGlbFile, objFile, mtlFile, pbrGlbFile }) {
  const splitFile = splitGlbFile || objFile;
  const sampleId = `local_${safeIdFromName(splitFile?.name || 'split')}`;
  const assets = {};
  if (splitGlbFile) assets['split-glb'] = fileAssetInfo('split-glb', splitGlbFile);
  if (objFile) assets['split-obj'] = fileAssetInfo('split-obj', objFile);
  if (mtlFile) assets['split-mtl'] = fileAssetInfo('split-mtl', mtlFile);
  if (pbrGlbFile) assets['pbr-glb'] = fileAssetInfo('pbr-glb', pbrGlbFile);
  return {
    ok: true,
    sampleId,
    label: 'Local Meshy Auto Split',
    assetRoot: 'browser-local-files',
    assets,
    mapping: {
      recommendedMode: 'PartSurfaceProjection',
      directFaceIndexAvailable: false,
      reason: splitGlbFile
        ? 'Local Split GLB preserves Meshy split nodes/primitives for browser regrouping. PBR cutting still needs projection because topology may differ.'
        : 'Local legacy OBJ preserves split groups for regrouping. PBR cutting should still be validated by topology before choosing face-index or projection mapping.',
    },
    defaultGroups: semanticGroups.map((group) => group.id),
  };
}

function fileAssetInfo(key, file) {
  return {
    key,
    fileName: file.name,
    bytes: file.size,
    url: 'browser-local-file',
  };
}

function updateImportStatus() {
  const names = [
    ui.splitGlbInput.files?.[0]?.name,
    ui.pbrGlbInput.files?.[0]?.name,
    ui.splitObjInput.files?.[0]?.name,
    ui.splitMtlInput.files?.[0]?.name,
  ].filter(Boolean);
  if (!names.length) {
    ui.importStatus.textContent = 'Sample asset active';
    return;
  }
  if (ui.splitGlbInput.files?.[0] && ui.pbrGlbInput.files?.[0]) {
    const signature = currentLocalImportSignature();
    ui.importStatus.textContent = signature === state.localImport.loadedSignature
      ? 'Local GLBs uploaded for export'
      : 'Two GLBs staged; loading soon';
    return;
  }
  ui.importStatus.textContent = `${names.length} local file${names.length > 1 ? 's' : ''} staged`;
}

function scheduleLocalGlbAutoLoad() {
  const splitGlbFile = ui.splitGlbInput.files?.[0] || null;
  const pbrGlbFile = ui.pbrGlbInput.files?.[0] || null;
  if (!splitGlbFile || !pbrGlbFile) return;
  const signature = currentLocalImportSignature();
  if (!signature || signature === state.localImport.loadedSignature) return;
  window.clearTimeout(state.localImport.pendingTimer);
  ui.importStatus.textContent = 'Two GLBs selected; loading for export...';
  state.localImport.pendingTimer = window.setTimeout(() => {
    if (currentLocalImportSignature() !== signature) return;
    loadLocalFiles({ auto: true });
  }, 120);
}

function currentLocalImportSignature() {
  const signatureFor = (file) => (
    file ? `${file.name}:${file.size}:${file.lastModified}` : ''
  );
  return [
    signatureFor(ui.splitGlbInput.files?.[0]),
    signatureFor(ui.pbrGlbInput.files?.[0]),
    signatureFor(ui.splitObjInput.files?.[0]),
    signatureFor(ui.splitMtlInput.files?.[0]),
  ].join('|');
}

function nextFrame() {
  return new Promise((resolve) => requestAnimationFrame(resolve));
}

function parseMtl(text) {
  const colors = new Map();
  let materialName = null;
  for (const rawLine of text.split(/\r?\n/)) {
    const line = rawLine.trim();
    if (!line || line.startsWith('#')) continue;
    if (line.startsWith('newmtl ')) {
      materialName = line.slice(7).trim();
      continue;
    }
    if (materialName && line.startsWith('Kd ')) {
      const values = line.slice(3).trim().split(/\s+/).map(Number);
      if (values.length >= 3 && values.every(Number.isFinite)) {
        colors.set(materialName, values.slice(0, 3));
      }
    }
  }
  return colors;
}

function parseObjToMesh(text, materialColors) {
  const startedAt = performance.now();
  const sourceVertices = [];
  const positions = [];
  const normals = [];
  const colors = [];
  const parts = [];
  let currentPart = null;
  let currentMaterial = 'default';
  let triCount = 0;

  const beginPart = (name) => {
    const safeName = name || `mesh_${parts.length}`;
    currentPart = {
      id: `part-${parts.length}`,
      name: safeName,
      material: currentMaterial,
      color: materialColors.get(currentMaterial) || fallbackColor(parts.length),
      start: positions.length / 3,
      count: 0,
      triCount: 0,
      bbox: createEmptyBounds(),
    };
    parts.push(currentPart);
    return currentPart;
  };

  const ensurePart = () => currentPart || beginPart(`mesh_${parts.length}`);
  const lines = text.split(/\r?\n/);

  for (const rawLine of lines) {
    if (!rawLine) continue;
    const lead = rawLine.charCodeAt(0);
    if (lead === 118 && rawLine.startsWith('v ')) {
      const values = rawLine.slice(2).trim().split(/\s+/).map(Number);
      if (values.length >= 3) {
        const x = values[0];
        const y = values[2];
        const z = -values[1];
        sourceVertices.push([x, y, z]);
      }
      continue;
    }
    if (lead === 111 && rawLine.startsWith('o ')) {
      beginPart(rawLine.slice(2).trim());
      continue;
    }
    if (lead === 103 && rawLine.startsWith('g ')) {
      const name = rawLine.slice(2).trim();
      if (name && (!currentPart || currentPart.count > 0)) beginPart(name);
      continue;
    }
    if (rawLine.startsWith('usemtl ')) {
      currentMaterial = rawLine.slice(7).trim() || currentMaterial;
      const part = ensurePart();
      if (part.count === 0) {
        part.material = currentMaterial;
        part.color = materialColors.get(currentMaterial) || part.color;
      }
      continue;
    }
    if (lead === 102 && rawLine.startsWith('f ')) {
      const part = ensurePart();
      const faceIndices = rawLine.slice(2).trim().split(/\s+/)
        .map((token) => parseObjVertexIndex(token, sourceVertices.length))
        .filter((index) => index >= 0 && index < sourceVertices.length);
      if (faceIndices.length < 3) continue;
      for (let i = 1; i < faceIndices.length - 1; i += 1) {
        const a = sourceVertices[faceIndices[0]];
        const b = sourceVertices[faceIndices[i]];
        const c = sourceVertices[faceIndices[i + 1]];
        addTriangle(part, a, b, c, positions, normals, colors);
        triCount += 1;
      }
    }
  }

  const liveParts = parts.filter((part) => part.count > 0);
  const bounds = boundsFromPositions(positions);
  const positionArray = new Float32Array(positions);
  const normalizeTransform = normalizePositions(positionArray, bounds);
  const mesh = {
    positions: positionArray,
    normals: new Float32Array(normals),
    colors: new Float32Array(colors),
    parts: liveParts,
    sourceVertexCount: sourceVertices.length,
    triangleCount: triCount,
    bounds,
    normalizeTransform,
    parseMs: Math.round(performance.now() - startedAt),
  };
  annotateParts(mesh);
  return mesh;
}

function parseGlbToMesh(arrayBuffer) {
  const startedAt = performance.now();
  const { doc, bin } = readGlb(arrayBuffer);
  const positions = [];
  const normals = [];
  const colors = [];
  const parts = [];
  const materialColors = glbMaterialColors(doc);
  const worldMatrices = glbWorldMatrices(doc);
  let triCount = 0;
  let sourceVertexCount = 0;

  for (const entry of glbNodeMeshEntries(doc)) {
    const mesh = doc.meshes?.[entry.meshIndex];
    if (!mesh) continue;
    const world = worldMatrices.get(entry.nodeIndex) || mat4Identity();
    const baseName = entry.nodeName || mesh.name || `mesh_${entry.meshIndex}`;
    for (let primitiveIndex = 0; primitiveIndex < (mesh.primitives || []).length; primitiveIndex += 1) {
      const primitive = mesh.primitives[primitiveIndex];
      if ((primitive.mode ?? 4) !== 4 || !primitive.attributes?.POSITION) continue;
      const positionAccessor = readGlbAccessor(doc, bin, primitive.attributes.POSITION);
      if (positionAccessor.width < 3) continue;
      const indicesAccessor = primitive.indices != null ? readGlbAccessor(doc, bin, primitive.indices) : null;
      const materialIndex = primitive.material ?? -1;
      const materialName = doc.materials?.[materialIndex]?.name || `material_${materialIndex}`;
      const partName = mesh.primitives.length > 1 ? `${baseName}_prim${primitiveIndex}` : baseName;
      const part = {
        id: `part-${parts.length}`,
        name: partName,
        material: materialName,
        color: materialColors.get(materialIndex) || fallbackColor(parts.length),
        start: positions.length / 3,
        count: 0,
        triCount: 0,
        bbox: createEmptyBounds(),
      };
      parts.push(part);
      sourceVertexCount += positionAccessor.count;

      const vertexAt = (index) => transformGlbPoint([
        positionAccessor.data[index * positionAccessor.width],
        positionAccessor.data[index * positionAccessor.width + 1],
        positionAccessor.data[index * positionAccessor.width + 2],
      ], world);

      if (indicesAccessor) {
        const faceCount = Math.floor(indicesAccessor.data.length / 3);
        for (let face = 0; face < faceCount; face += 1) {
          const offset = face * 3;
          const a = vertexAt(indicesAccessor.data[offset]);
          const b = vertexAt(indicesAccessor.data[offset + 1]);
          const c = vertexAt(indicesAccessor.data[offset + 2]);
          addTriangle(part, a, b, c, positions, normals, colors);
          triCount += 1;
        }
      } else {
        const faceCount = Math.floor(positionAccessor.count / 3);
        for (let face = 0; face < faceCount; face += 1) {
          const offset = face * 3;
          addTriangle(part, vertexAt(offset), vertexAt(offset + 1), vertexAt(offset + 2), positions, normals, colors);
          triCount += 1;
        }
      }
    }
  }

  const liveParts = parts.filter((part) => part.count > 0);
  if (!liveParts.length) {
    throw new Error('Split GLB has no triangle mesh primitives with POSITION data.');
  }
  const bounds = boundsFromPositions(positions);
  const positionArray = new Float32Array(positions);
  const normalizeTransform = normalizePositions(positionArray, bounds);
  const mesh = {
    positions: positionArray,
    normals: new Float32Array(normals),
    colors: new Float32Array(colors),
    parts: liveParts,
    sourceVertexCount,
    triangleCount: triCount,
    bounds,
    normalizeTransform,
    parseMs: Math.round(performance.now() - startedAt),
  };
  annotateParts(mesh);
  return mesh;
}

function readGlb(arrayBuffer) {
  const view = new DataView(arrayBuffer);
  if (view.byteLength < 20) throw new Error('GLB file is too small.');
  const magic = view.getUint32(0, true);
  const version = view.getUint32(4, true);
  const totalLength = view.getUint32(8, true);
  if (magic !== 0x46546c67 || version !== 2) {
    throw new Error('Expected GLB 2.0 file.');
  }
  let offset = 12;
  let doc = null;
  let bin = null;
  const decoder = new TextDecoder();
  while (offset < totalLength) {
    const chunkLength = view.getUint32(offset, true);
    const chunkType = view.getUint32(offset + 4, true);
    offset += 8;
    if (chunkType === 0x4e4f534a) {
      doc = JSON.parse(decoder.decode(new Uint8Array(arrayBuffer, offset, chunkLength)));
    } else if (chunkType === 0x004e4942) {
      bin = arrayBuffer.slice(offset, offset + chunkLength);
    }
    offset += chunkLength;
  }
  if (!doc) throw new Error('GLB has no JSON chunk.');
  return { doc, bin: bin || new ArrayBuffer(0) };
}

function glbMaterialColors(doc) {
  const colors = new Map();
  for (let index = 0; index < (doc.materials || []).length; index += 1) {
    const factor = doc.materials[index]?.pbrMetallicRoughness?.baseColorFactor;
    if (Array.isArray(factor) && factor.length >= 3) colors.set(index, factor.slice(0, 3));
  }
  return colors;
}

function glbNodeMeshEntries(doc) {
  const entries = [];
  for (let nodeIndex = 0; nodeIndex < (doc.nodes || []).length; nodeIndex += 1) {
    const node = doc.nodes[nodeIndex];
    if (node.mesh == null) continue;
    entries.push({
      nodeIndex,
      meshIndex: node.mesh,
      nodeName: node.name || null,
    });
  }
  return entries;
}

function readGlbAccessor(doc, bin, accessorIndex) {
  const accessor = doc.accessors?.[accessorIndex];
  if (!accessor) throw new Error(`Missing GLB accessor ${accessorIndex}.`);
  if (accessor.sparse) throw new Error('Sparse GLB accessors are not supported yet.');
  const bufferView = doc.bufferViews?.[accessor.bufferView];
  if (!bufferView) throw new Error(`Missing GLB bufferView ${accessor.bufferView}.`);
  const componentSize = glbComponentSize(accessor.componentType);
  const width = glbAccessorWidth(accessor.type);
  const count = accessor.count || 0;
  const byteOffset = (bufferView.byteOffset || 0) + (accessor.byteOffset || 0);
  const stride = bufferView.byteStride || componentSize * width;
  const packed = stride === componentSize * width;
  const totalValues = count * width;
  const data = glbAccessorTypedArray(accessor.componentType, totalValues);
  const sourceView = new DataView(bin);
  for (let row = 0; row < count; row += 1) {
    for (let col = 0; col < width; col += 1) {
      data[row * width + col] = readGlbComponent(sourceView, byteOffset + row * stride + col * componentSize, accessor.componentType);
    }
  }
  return { data: packed ? data : data, width, count };
}

function glbAccessorTypedArray(componentType, totalValues) {
  if (componentType === 5120) return new Int8Array(totalValues);
  if (componentType === 5121) return new Uint8Array(totalValues);
  if (componentType === 5122) return new Int16Array(totalValues);
  if (componentType === 5123) return new Uint16Array(totalValues);
  if (componentType === 5125) return new Uint32Array(totalValues);
  if (componentType === 5126) return new Float32Array(totalValues);
  throw new Error(`Unsupported GLB component type ${componentType}.`);
}

function readGlbComponent(view, offset, componentType) {
  if (componentType === 5120) return view.getInt8(offset);
  if (componentType === 5121) return view.getUint8(offset);
  if (componentType === 5122) return view.getInt16(offset, true);
  if (componentType === 5123) return view.getUint16(offset, true);
  if (componentType === 5125) return view.getUint32(offset, true);
  if (componentType === 5126) return view.getFloat32(offset, true);
  throw new Error(`Unsupported GLB component type ${componentType}.`);
}

function glbComponentSize(componentType) {
  if (componentType === 5120 || componentType === 5121) return 1;
  if (componentType === 5122 || componentType === 5123) return 2;
  if (componentType === 5125 || componentType === 5126) return 4;
  throw new Error(`Unsupported GLB component type ${componentType}.`);
}

function glbAccessorWidth(type) {
  if (type === 'SCALAR') return 1;
  if (type === 'VEC2') return 2;
  if (type === 'VEC3') return 3;
  if (type === 'VEC4') return 4;
  if (type === 'MAT4') return 16;
  throw new Error(`Unsupported GLB accessor type ${type}.`);
}

function glbWorldMatrices(doc) {
  const nodes = doc.nodes || [];
  const matrices = new Map();
  const roots = glbSceneRoots(doc);
  const visit = (nodeIndex, parent) => {
    const node = nodes[nodeIndex];
    if (!node) return;
    const world = mat4MultiplyColumnMajor(parent, glbNodeMatrix(node));
    matrices.set(nodeIndex, world);
    for (const child of node.children || []) visit(child, world);
  };
  for (const root of roots) visit(root, mat4Identity());
  for (let index = 0; index < nodes.length; index += 1) {
    if (!matrices.has(index)) matrices.set(index, glbNodeMatrix(nodes[index]));
  }
  return matrices;
}

function glbSceneRoots(doc) {
  const scene = doc.scenes?.[doc.scene || 0];
  if (scene?.nodes?.length) return scene.nodes;
  return (doc.nodes || []).map((_, index) => index);
}

function glbNodeMatrix(node) {
  if (Array.isArray(node.matrix) && node.matrix.length === 16) return new Float32Array(node.matrix);
  const matrix = quatToMat4(node.rotation || [0, 0, 0, 1]);
  const scale = node.scale || [1, 1, 1];
  matrix[0] *= scale[0]; matrix[1] *= scale[0]; matrix[2] *= scale[0];
  matrix[4] *= scale[1]; matrix[5] *= scale[1]; matrix[6] *= scale[1];
  matrix[8] *= scale[2]; matrix[9] *= scale[2]; matrix[10] *= scale[2];
  const translation = node.translation || [0, 0, 0];
  matrix[12] = translation[0];
  matrix[13] = translation[1];
  matrix[14] = translation[2];
  return matrix;
}

function quatToMat4(rotation) {
  const [x, y, z, w] = rotation;
  const x2 = x + x;
  const y2 = y + y;
  const z2 = z + z;
  const xx = x * x2;
  const xy = x * y2;
  const xz = x * z2;
  const yy = y * y2;
  const yz = y * z2;
  const zz = z * z2;
  const wx = w * x2;
  const wy = w * y2;
  const wz = w * z2;
  return new Float32Array([
    1 - yy - zz, xy + wz, xz - wy, 0,
    xy - wz, 1 - xx - zz, yz + wx, 0,
    xz + wy, yz - wx, 1 - xx - yy, 0,
    0, 0, 0, 1,
  ]);
}

function mat4Identity() {
  return new Float32Array([
    1, 0, 0, 0,
    0, 1, 0, 0,
    0, 0, 1, 0,
    0, 0, 0, 1,
  ]);
}

function mat4MultiplyColumnMajor(a, b) {
  const out = new Float32Array(16);
  for (let column = 0; column < 4; column += 1) {
    for (let row = 0; row < 4; row += 1) {
      out[column * 4 + row] =
        a[0 * 4 + row] * b[column * 4 + 0] +
        a[1 * 4 + row] * b[column * 4 + 1] +
        a[2 * 4 + row] * b[column * 4 + 2] +
        a[3 * 4 + row] * b[column * 4 + 3];
    }
  }
  return out;
}

function transformGlbPoint(point, matrix) {
  const [x, y, z] = point;
  return [
    matrix[0] * x + matrix[4] * y + matrix[8] * z + matrix[12],
    matrix[1] * x + matrix[5] * y + matrix[9] * z + matrix[13],
    matrix[2] * x + matrix[6] * y + matrix[10] * z + matrix[14],
  ];
}

function parseObjVertexIndex(token, vertexCount) {
  const value = Number(token.split('/')[0]);
  if (!Number.isFinite(value) || value === 0) return -1;
  return value < 0 ? vertexCount + value : value - 1;
}

function addTriangle(part, a, b, c, positions, normals, colors) {
  const normal = triangleNormal(a, b, c);
  const color = part.color;
  for (const point of [a, b, c]) {
    positions.push(point[0], point[1], point[2]);
    normals.push(normal[0], normal[1], normal[2]);
    colors.push(color[0], color[1], color[2]);
    expandBounds(part.bbox, point);
  }
  part.count += 3;
  part.triCount += 1;
}

function triangleNormal(a, b, c) {
  const ux = b[0] - a[0];
  const uy = b[1] - a[1];
  const uz = b[2] - a[2];
  const vx = c[0] - a[0];
  const vy = c[1] - a[1];
  const vz = c[2] - a[2];
  const nx = uy * vz - uz * vy;
  const ny = uz * vx - ux * vz;
  const nz = ux * vy - uy * vx;
  const length = Math.hypot(nx, ny, nz) || 1;
  return [nx / length, ny / length, nz / length];
}

function fallbackColor(index) {
  return fallbackPalette[index % fallbackPalette.length];
}

function createEmptyBounds() {
  return {
    min: [Infinity, Infinity, Infinity],
    max: [-Infinity, -Infinity, -Infinity],
  };
}

function expandBounds(bounds, point) {
  for (let axis = 0; axis < 3; axis += 1) {
    if (point[axis] < bounds.min[axis]) bounds.min[axis] = point[axis];
    if (point[axis] > bounds.max[axis]) bounds.max[axis] = point[axis];
  }
}

function boundsFromPositions(positions) {
  const bounds = createEmptyBounds();
  for (let i = 0; i < positions.length; i += 3) {
    expandBounds(bounds, [positions[i], positions[i + 1], positions[i + 2]]);
  }
  return bounds;
}

function normalizePositions(positionArray, bounds) {
  const center = [
    (bounds.min[0] + bounds.max[0]) * 0.5,
    (bounds.min[1] + bounds.max[1]) * 0.5,
    (bounds.min[2] + bounds.max[2]) * 0.5,
  ];
  const extents = [
    bounds.max[0] - bounds.min[0],
    bounds.max[1] - bounds.min[1],
    bounds.max[2] - bounds.min[2],
  ];
  const radius = Math.max(extents[0], extents[1], extents[2]) || 1;
  const scale = 2.05 / radius;
  for (let i = 0; i < positionArray.length; i += 3) {
    positionArray[i] = (positionArray[i] - center[0]) * scale;
    positionArray[i + 1] = (positionArray[i + 1] - center[1]) * scale;
    positionArray[i + 2] = (positionArray[i + 2] - center[2]) * scale;
  }
  return { center, scale };
}

function annotateParts(mesh) {
  const bounds = mesh.bounds;
  const transform = mesh.normalizeTransform || { center: [0, 0, 0], scale: 1 };
  const globalHeight = Math.max(bounds.max[1] - bounds.min[1], 0.000001);
  const centerX = (bounds.min[0] + bounds.max[0]) * 0.5;
  const centerZ = (bounds.min[2] + bounds.max[2]) * 0.5;
  let maxRadius = 0.000001;
  for (const part of mesh.parts) {
    part.center = [
      (part.bbox.min[0] + part.bbox.max[0]) * 0.5,
      (part.bbox.min[1] + part.bbox.max[1]) * 0.5,
      (part.bbox.min[2] + part.bbox.max[2]) * 0.5,
    ];
    part.extent = [
      part.bbox.max[0] - part.bbox.min[0],
      part.bbox.max[1] - part.bbox.min[1],
      part.bbox.max[2] - part.bbox.min[2],
    ];
    part.normalizedCenter = transformPoint(part.center, transform);
    part.normalizedExtent = part.extent.map((value) => value * transform.scale);
    part.heightRatio = (part.center[1] - bounds.min[1]) / globalHeight;
    part.radius = Math.hypot(part.center[0] - centerX, part.center[2] - centerZ);
    maxRadius = Math.max(maxRadius, part.radius);
  }
  for (const part of mesh.parts) {
    part.radialRatio = part.radius / maxRadius;
    part.colorHex = rgbToHex(part.color);
  }
}

function transformPoint(point, transform) {
  return [
    (point[0] - transform.center[0]) * transform.scale,
    (point[1] - transform.center[1]) * transform.scale,
    (point[2] - transform.center[2]) * transform.scale,
  ];
}

function autoSuggestGroups(options = {}) {
  if (!state.parts.length) return;
  const triCounts = state.parts.map((part) => part.triCount).sort((a, b) => a - b);
  const medianTriangles = triCounts[Math.floor(triCounts.length * 0.5)] || 1;
  const highTriangles = triCounts[Math.floor(triCounts.length * 0.74)] || medianTriangles;
  for (const part of state.parts) {
    const features = partSemanticFeatures(part, medianTriangles, highTriangles);
    const group = state.plantProfile === 'AetherVine'
      ? suggestAetherVineGroup(features)
      : suggestCrownLilyGroup(features);
    state.assignments.set(part.id, group);
  }
  if (!options.silent) {
    ui.manifestStatus.textContent = 'Auto suggested';
    window.setTimeout(() => {
      ui.manifestStatus.textContent = 'Semantic draft';
    }, 1200);
  }
}

function partSemanticFeatures(part, medianTriangles, highTriangles) {
  const [ex, ey, ez] = part.extent;
  const horizontal = Math.max(ex, ez, 0.000001);
  const normalizedHorizontal = Math.max(part.normalizedExtent?.[0] || 0, part.normalizedExtent?.[2] || 0, 0.000001);
  const normalizedVertical = Math.max(part.normalizedExtent?.[1] || 0, 0.000001);
  const nameText = `${part.name} ${part.material}`.toLowerCase();
  const [r, g, b] = part.color;
  return {
    part,
    h: part.heightRatio,
    r: part.radialRatio,
    verticality: ey / horizontal,
    flatness: horizontal / Math.max(ey, 0.000001),
    normalizedFlatness: normalizedHorizontal / normalizedVertical,
    isSmall: part.triCount < medianTriangles * 0.72,
    isLarge: part.triCount >= highTriangles || part.triCount > medianTriangles * 1.7,
    warmColor: r > g * 0.95 && r > b * 0.9,
    coolColor: b > r * 0.85 || g > r * 1.05,
    nameText,
  };
}

function suggestCrownLilyGroup(f) {
  const scores = {
    Core: 0,
    PrimarySilhouette: 0,
    OrbitSet: 0,
    BodyShell: 0,
  };
  scores.BodyShell += scoreIf(f.h < 0.24, 3.1);
  scores.BodyShell += scoreIf(f.h < 0.42 && f.r < 0.48, 1.2);
  scores.BodyShell += scoreIf(f.verticality > 1.45 && f.r < 0.5, 2.0);
  scores.BodyShell += keywordScore(f.nameText, ['root', 'stem', 'body', 'shell', 'base', 'vine', 'trunk'], 1.5);

  scores.Core += scoreIf(f.r < 0.24 && f.h > 0.22 && f.h < 0.78, 3.0);
  scores.Core += scoreIf(!f.isLarge && f.r < 0.34, 1.2);
  scores.Core += scoreIf(f.warmColor && f.r < 0.42, 0.8);
  scores.Core += keywordScore(f.nameText, ['core', 'orb', 'bulb', 'heart', 'kernel'], 1.8);

  scores.OrbitSet += scoreIf(f.r > 0.58 && f.h > 0.28, 2.8);
  scores.OrbitSet += scoreIf(f.isSmall && f.r > 0.34, 1.2);
  scores.OrbitSet += scoreIf(f.flatness > 2.25 && f.r > 0.42, 1.0);
  scores.OrbitSet += keywordScore(f.nameText, ['orbit', 'ring', 'rune', 'star', 'spark', 'halo'], 2.0);

  scores.PrimarySilhouette += scoreIf(f.isLarge, 2.4);
  scores.PrimarySilhouette += scoreIf(f.flatness > 1.36 && f.h > 0.34, 1.7);
  scores.PrimarySilhouette += scoreIf(f.h > 0.48 && f.r < 0.72, 1.0);
  scores.PrimarySilhouette += scoreIf(f.coolColor && f.h > 0.35, 0.5);
  scores.PrimarySilhouette += keywordScore(f.nameText, ['petal', 'leaf', 'crown', 'silhouette', 'blade'], 2.0);
  return highestScoringGroup(scores);
}

function suggestAetherVineGroup(f) {
  const scores = {
    Core: 0,
    PrimarySilhouette: 0,
    OrbitSet: 0,
    BodyShell: 0,
  };
  scores.PrimarySilhouette += scoreIf(f.isLarge, 3.0);
  scores.PrimarySilhouette += scoreIf(f.flatness > 1.55 || f.normalizedFlatness > 1.55, 1.6);
  scores.PrimarySilhouette += scoreIf(f.h > 0.34 && f.r > 0.22, 1.0);
  scores.PrimarySilhouette += keywordScore(f.nameText, ['arc', 'trail', 'sweep', 'vine', 'curve', 'ribbon'], 2.1);

  scores.Core += scoreIf(f.r < 0.26 && f.h > 0.24 && f.h < 0.8, 2.8);
  scores.Core += scoreIf(!f.isLarge && f.warmColor && f.r < 0.4, 1.0);
  scores.Core += keywordScore(f.nameText, ['core', 'orb', 'starcore', 'heart', 'crystal'], 1.9);

  scores.OrbitSet += scoreIf(f.isSmall && f.r > 0.24, 1.8);
  scores.OrbitSet += scoreIf(f.r > 0.62, 1.6);
  scores.OrbitSet += scoreIf(f.flatness < 1.2 && f.h > 0.36, 0.6);
  scores.OrbitSet += keywordScore(f.nameText, ['star', 'rune', 'dot', 'spark', 'fragment', 'orbit'], 2.2);

  scores.BodyShell += scoreIf(f.h < 0.26, 2.5);
  scores.BodyShell += scoreIf(f.verticality > 1.4 && f.r < 0.45, 1.5);
  scores.BodyShell += keywordScore(f.nameText, ['root', 'knot', 'body', 'base', 'stem', 'trunk'], 1.8);
  return highestScoringGroup(scores);
}

function scoreIf(condition, score) {
  return condition ? score : 0;
}

function keywordScore(text, words, score) {
  return words.some((word) => text.includes(word)) ? score : 0;
}

function highestScoringGroup(scores) {
  let bestGroup = 'PrimarySilhouette';
  let bestScore = -Infinity;
  for (const [group, score] of Object.entries(scores)) {
    if (score > bestScore) {
      bestGroup = group;
      bestScore = score;
    }
  }
  return bestGroup;
}

function assignSelectedToActiveGroup() {
  for (const partId of state.selectedPartIds) {
    state.assignments.set(partId, state.activeGroup);
  }
  updateAllUi();
}

function toggleHidden(partId) {
  if (state.hiddenPartIds.has(partId)) state.hiddenPartIds.delete(partId);
  else state.hiddenPartIds.add(partId);
  renderPartList();
  renderScene();
}

function togglePartSelection(partId, additive) {
  if (!additive) state.selectedPartIds.clear();
  if (state.selectedPartIds.has(partId) && additive) state.selectedPartIds.delete(partId);
  else state.selectedPartIds.add(partId);
  updateAllUi();
}

function updateAllUi() {
  renderModeButtons();
  renderMetrics();
  renderPartList();
  renderGroupList();
  renderSelectionDetails();
  renderAssetReport();
  updateManifestPreview();
  renderScene();
}

function renderSampleHeader() {
  const sample = state.sample;
  if (!sample) return;
  ui.splitAssetName.textContent = sample.assets?.['split-glb']?.fileName || sample.assets?.['split-obj']?.fileName || 'No split GLB loaded';
  ui.pbrAssetName.textContent = sample.assets?.['pbr-glb']?.fileName || 'No PBR GLB selected';
  ui.strategyName.textContent = sample.mapping?.recommendedMode || 'PartSurfaceProjection';
  ui.mappingModeMetric.textContent = 'Projection';
}

function renderMetrics() {
  const mesh = state.mesh;
  ui.partCountMetric.textContent = mesh ? formatNumber(state.parts.length) : '--';
  ui.triCountMetric.textContent = mesh ? compactNumber(mesh.triangleCount) : '--';
  ui.selectedSummary.textContent = `${state.selectedPartIds.size} selected`;
}

function renderModeButtons() {
  ui.colorModeControl.querySelectorAll('[data-color-mode]').forEach((button) => {
    button.classList.toggle('active', button.dataset.colorMode === state.colorMode);
  });
  ui.plantProfileControl.querySelectorAll('[data-profile]').forEach((button) => {
    button.classList.toggle('active', button.dataset.profile === state.plantProfile);
  });
  ui.explodeRange.value = String(Math.round(state.explodeAmount * 100));
  ui.explodeValue.textContent = String(Math.round(state.explodeAmount * 100));
  renderActiveGroupLabel();
}

function renderPartList() {
  if (!state.parts.length) {
    ui.partList.innerHTML = '<div class="asset-report-row"><strong>No parts loaded</strong></div>';
    return;
  }
  const rows = state.parts
    .filter((part) => {
      if (!state.filter) return true;
      const haystack = `${part.name} ${part.material} ${state.assignments.get(part.id) || ''}`.toLowerCase();
      return haystack.includes(state.filter);
    })
    .map((part) => {
      const group = state.assignments.get(part.id) || 'Unassigned';
      const selected = state.selectedPartIds.has(part.id) ? ' selected' : '';
      const hidden = state.hiddenPartIds.has(part.id) ? ' hidden-part' : '';
      const swatchColor = colorHexForPart(part);
      return `
        <div class="part-row${selected}${hidden}" data-part-id="${escapeHtml(part.id)}">
          <span class="part-swatch" style="background:${swatchColor}"></span>
          <div class="part-main">
            <div class="part-title">
              <span class="part-name">${escapeHtml(part.name)}</span>
            </div>
            <div class="part-meta">
              <span>${escapeHtml(part.material)}</span>
              <span>${formatNumber(part.triCount)} tris</span>
              <span>${escapeHtml(group)}</span>
            </div>
          </div>
          <div class="part-actions">
            <button class="part-mini-button${state.hiddenPartIds.has(part.id) ? ' active' : ''}" data-action="hide" type="button">${state.hiddenPartIds.has(part.id) ? 'Show' : 'Hide'}</button>
          </div>
        </div>
      `;
    })
    .join('');
  ui.partList.innerHTML = rows || '<div class="asset-report-row"><strong>No matching parts</strong></div>';
}

function renderGroupList() {
  const counts = summarizeGroups();
  renderActiveGroupLabel();
  ui.groupList.innerHTML = semanticGroups.map((group) => {
    const summary = counts.get(group.id) || { parts: 0, triangles: 0 };
    const active = group.id === state.activeGroup ? ' active' : '';
    const label = groupDisplayLabel(group.id);
    return `
      <div class="group-card${active}" data-group-id="${escapeHtml(group.id)}">
        <span class="group-swatch" style="background:${group.color}"></span>
        <div>
          <strong>${escapeHtml(group.id)}</strong>
          <code>${escapeHtml(label)}</code>
          <span>${compactNumber(summary.triangles)} tris</span>
        </div>
        <span class="group-count">${summary.parts}</span>
      </div>
    `;
  }).join('');
}

function summarizeGroups() {
  const counts = new Map(semanticGroups.map((group) => [group.id, { parts: 0, triangles: 0 }]));
  for (const part of state.parts) {
    const groupId = state.assignments.get(part.id);
    if (!counts.has(groupId)) continue;
    const summary = counts.get(groupId);
    summary.parts += 1;
    summary.triangles += part.triCount;
  }
  return counts;
}

function renderActiveGroupLabel() {
  ui.activeGroupLabel.textContent = `${state.activeGroup} / ${groupDisplayLabel(state.activeGroup)}`;
}

function syncSemanticTargetToMeshyRoundtrip(groupId, options = {}) {
  setMeshyRoundtripTarget(groupId, { ...options, syncActiveGroup: true });
}

function setMeshyRoundtripTarget(groupId, {
  forcePrompt = false,
  syncActiveGroup = true,
  render = true,
} = {}) {
  const nextGroup = semanticGroups.some((group) => group.id === groupId) ? groupId : 'Core';
  if (syncActiveGroup) state.activeGroup = nextGroup;
  if (ui.meshyRoundtripGroup.value !== nextGroup) {
    ui.meshyRoundtripGroup.value = nextGroup;
  }
  if (state.pbrPreview.roundtrip.activeRun?.group !== nextGroup) {
    state.pbrPreview.roundtrip.activeRun = latestMeshyRoundtripRunForGroup(nextGroup);
  }
  syncMeshyRoundtripPrompt({ force: forcePrompt });
  renderMeshyRoundtripTargetHint();
  if (!render) return;
  renderGroupList();
  renderMeshyRoundtripShell();
  renderPbrPartToggles();
}

function renderMeshyRoundtripTargetHint() {
  if (!ui.meshyRoundtripTargetHint) return;
  const groupId = ui.meshyRoundtripGroup.value || state.activeGroup || 'Core';
  ui.meshyRoundtripTargetHint.textContent = `Linked to semantic group ${groupId} / ${groupDisplayLabel(groupId)}`;
}

function latestMeshyRoundtripRunForGroup(groupId) {
  return state.pbrPreview.roundtrip.runs.find((run) => run?.group === groupId) || null;
}

function currentMeshyRoundtripRun() {
  const groupId = ui.meshyRoundtripGroup.value || state.activeGroup || 'Core';
  const activeRun = state.pbrPreview.roundtrip.activeRun;
  if (activeRun?.group === groupId) return activeRun;
  return latestMeshyRoundtripRunForGroup(groupId);
}

function groupDisplayLabel(groupId) {
  return plantProfiles[state.plantProfile]?.groupLabels?.[groupId] || groupId;
}

function colorHexForPart(part) {
  if (state.colorMode === 'meshy') return part.colorHex;
  const group = groupById.get(state.assignments.get(part.id));
  return group?.color || unassignedColor;
}

function colorRgbForPart(part) {
  if (state.colorMode === 'meshy') return part.color;
  return hexToRgb01(colorHexForPart(part));
}

function renderSelectionDetails() {
  const selectedParts = state.parts.filter((part) => state.selectedPartIds.has(part.id));
  if (!selectedParts.length) {
    ui.selectionDetails.textContent = 'No part selected.';
    return;
  }
  const triangles = selectedParts.reduce((sum, part) => sum + part.triCount, 0);
  const groups = [...new Set(selectedParts.map((part) => state.assignments.get(part.id) || 'Unassigned'))].join(', ');
  ui.selectionDetails.textContent = `${selectedParts.map((part) => part.name).join(', ')} | ${formatNumber(triangles)} tris | ${groups}`;
}

function renderAssetReport() {
  if (!state.sample || !state.mesh) return;
  const rows = [];
  appendAssetReportRow(rows, 'Split OBJ', state.sample.assets?.['split-obj']);
  appendAssetReportRow(rows, 'Split MTL', state.sample.assets?.['split-mtl']);
  appendAssetReportRow(rows, 'Split GLB', state.sample.assets?.['split-glb']);
  appendAssetReportRow(rows, 'PBR GLB', state.sample.assets?.['pbr-glb']);
  rows.push(['Parsed', `${formatNumber(state.mesh.sourceVertexCount)} source verts`, `${formatNumber(state.mesh.triangleCount)} tris`]);
  rows.push(['Parse Time', `${state.mesh.parseMs} ms`, 'OBJ groups -> semantic draft']);
  ui.assetReportStatus.textContent = 'Parsed';
  ui.assetReport.innerHTML = rows.map(([label, value, extra]) => `
    <div class="asset-report-row">
      <span>${escapeHtml(label)}</span>
      <strong>${escapeHtml(value)}</strong>
      <code>${escapeHtml(extra)}</code>
    </div>
  `).join('');
}

function appendAssetReportRow(rows, label, asset) {
  if (!asset) return;
  rows.push([label, asset.fileName, formatBytes(asset.bytes)]);
}

function updateManifestPreview() {
  const manifest = buildManifest();
  state.manifestText = JSON.stringify(manifest, null, 2);
  ui.manifestPreview.textContent = state.manifestText;
}

async function saveManifestToOutput() {
  ui.manifestStatus.textContent = 'Saving...';
  try {
    const response = await fetch('/api/plant/save-regroup-manifest', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: state.manifestText,
    });
    const payload = await response.json();
    if (!response.ok || !payload.ok) {
      throw new Error(payload.error || `Save failed with ${response.status}`);
    }
    ui.manifestStatus.textContent = `Saved ${payload.saved.fileName}`;
    renderSavedReport(payload.saved);
  } catch (error) {
    console.error(error);
    ui.manifestStatus.textContent = 'Save failed';
    ui.selectionDetails.textContent = error.message;
  }
}

async function analyzeProjection() {
  ui.manifestStatus.textContent = 'Analyzing projection...';
  ui.projectionDiagnosticsButton.disabled = true;
  try {
    const response = await fetch('/api/plant/projection-diagnostics', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: state.manifestText,
    });
    const payload = await response.json();
    if (!response.ok || !payload.ok) {
      throw new Error(payload.error || `Projection diagnostics failed with ${response.status}`);
    }
    ui.manifestStatus.textContent = `Projection ${payload.report.verdict.level}`;
    renderProjectionReport(payload);
  } catch (error) {
    console.error(error);
    ui.manifestStatus.textContent = 'Projection failed';
    ui.selectionDetails.textContent = error.message;
  } finally {
    ui.projectionDiagnosticsButton.disabled = false;
  }
}

async function exportPbrParts() {
  ui.manifestStatus.textContent = 'Exporting PBR parts...';
  ui.exportPbrPartsButton.disabled = true;
  ui.packPbrGlbsButton.disabled = true;
  try {
    const response = await fetch('/api/plant/export-pbr-parts', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: state.manifestText,
    });
    const payload = await response.json();
    if (!response.ok || !payload.ok) {
      throw new Error(payload.error || `PBR part export failed with ${response.status}`);
    }
    ui.manifestStatus.textContent = `Exported ${payload.report.exports.length} PBR parts`;
    renderPbrExportReport(payload);
    await loadPbrExportPreview(payload.projectPath, {
      roundtripTrusted: true,
      sourceLabel: 'current manual export',
    });
  } catch (error) {
    console.error(error);
    ui.manifestStatus.textContent = 'Export failed';
    ui.selectionDetails.textContent = error.message;
  } finally {
    ui.exportPbrPartsButton.disabled = false;
  }
}

async function packPbrGlbs() {
  if (!state.pbrPreview.payload?.partsDir) {
    ui.manifestStatus.textContent = 'Load export before packing';
    ui.pbrPreviewStatus.textContent = 'No export loaded';
    ui.selectionDetails.textContent = 'Pack GLBs needs the current PBR Parts Preview to be loaded first.';
    updatePackButtonState();
    return;
  }
  ui.manifestStatus.textContent = 'Packing complete GLBs...';
  ui.pbrPreviewStatus.textContent = 'Packing GLBs';
  ui.packPbrGlbsButton.disabled = true;
  try {
    const response = await fetch('/api/plant/pack-pbr-glbs', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        partsDir: state.pbrPreview.payload.partsDir,
      }),
    });
    const payload = await response.json();
    if (!response.ok || !payload.ok) {
      throw new Error(payload.error || `GLB pack failed with ${response.status}`);
    }
    state.pbrPreview.pack = payload;
    ui.manifestStatus.textContent = `Packed ${payload.exports.length} GLBs`;
    ui.pbrPreviewStatus.textContent = `${payload.workspaceName} GLBs ready`;
    renderPackedGlbReport(payload);
    renderPbrPreviewReport();
  } catch (error) {
    console.error(error);
    ui.manifestStatus.textContent = 'GLB pack failed';
    ui.pbrPreviewStatus.textContent = 'GLB pack failed';
    ui.selectionDetails.textContent = error.message;
  } finally {
    updatePackButtonState();
  }
}

async function checkMeshyRoundtripStatus() {
  try {
    const payload = await fetchJson('/api/plant/meshy-status');
    state.pbrPreview.roundtrip.configured = Boolean(payload.configured);
    ui.meshyRoundtripStatus.textContent = payload.configured ? 'Ready' : 'No API key';
    renderMeshyRoundtripShell();
  } catch (error) {
    console.error(error);
    ui.meshyRoundtripStatus.textContent = 'Status unavailable';
  }
}

async function startMeshyRoundtrip() {
  const group = ui.meshyRoundtripGroup.value;
  const operation = ui.meshyRoundtripOperation.value;
  const prompt = ui.meshyRoundtripPrompt.value.trim();
  if (!prompt) {
    ui.meshyRoundtripStatus.textContent = 'Prompt empty';
    return;
  }
  const promptError = meshyPromptLimitError();
  if (promptError) {
    state.pbrPreview.roundtrip.lastError = promptError;
    ui.meshyRoundtripStatus.textContent = 'Prompt too long';
    renderMeshyRoundtripShell();
    return;
  }
  if (!state.pbrPreview.payload?.partsDir) {
    state.pbrPreview.roundtrip.lastError = 'Load or export PBR parts before sending a Meshy variant.';
    ui.meshyRoundtripStatus.textContent = 'No export loaded';
    renderMeshyRoundtripShell();
    return;
  }
  if (isDefaultAutoSplitPreview()) {
    state.pbrPreview.roundtrip.lastError = 'This preview is the untrusted default auto-split fallback. Export PBR Parts from the current semantic assignment first; Send to Meshy will not switch workspaces for you.';
    ui.meshyRoundtripStatus.textContent = 'Export current parts first';
    renderMeshyRoundtripShell();
    return;
  }
  ui.sendMeshyRoundtripButton.disabled = true;
  ui.pollMeshyRoundtripButton.disabled = true;
  state.pbrPreview.roundtrip.busy = true;
  ui.meshyRoundtripStatus.textContent = 'Submitting...';
  try {
    const response = await fetch('/api/plant/meshy-roundtrip/start', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        partsDir: state.pbrPreview.payload?.partsDir || null,
        group,
        operation,
        prompt,
        options: {
          hdTexture: false,
          targetPolycount: 60000,
        },
      }),
    });
    const payload = await response.json();
    if (!response.ok || !payload.ok) {
      throw new Error(payload.error || `Meshy submit failed with ${response.status}`);
    }
    state.pbrPreview.roundtrip.lastError = '';
    state.pbrPreview.roundtrip.activeRun = payload.run;
    state.pbrPreview.roundtrip.runs = [payload.run, ...state.pbrPreview.roundtrip.runs.filter((run) => run.runDir !== payload.run.runDir)];
    ui.meshyRoundtripStatus.textContent = `${payload.run.group} submitted`;
    renderMeshyRoundtripShell();
    renderVariantManager();
    scheduleMeshyRoundtripPoll();
  } catch (error) {
    console.error(error);
    state.pbrPreview.roundtrip.lastError = error.message;
    ui.meshyRoundtripStatus.textContent = 'Submit failed';
    ui.meshyRoundtripReport.innerHTML = roundtripErrorRow(error.message);
  } finally {
    state.pbrPreview.roundtrip.busy = false;
    ui.sendMeshyRoundtripButton.disabled = false;
    ui.pollMeshyRoundtripButton.disabled = false;
    renderMeshyRoundtripShell();
  }
}

async function pollMeshyRoundtrip() {
  const run = currentMeshyRoundtripRun();
  if (!run?.runDir) {
    await loadMeshyRoundtripList();
    const latestRun = currentMeshyRoundtripRun();
    if (!latestRun?.runDir) {
      ui.meshyRoundtripStatus.textContent = 'No task';
      return;
    }
  }
  const active = currentMeshyRoundtripRun();
  ui.pollMeshyRoundtripButton.disabled = true;
  state.pbrPreview.roundtrip.busy = true;
  ui.meshyRoundtripStatus.textContent = 'Checking...';
  try {
    const response = await fetch('/api/plant/meshy-roundtrip/poll', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ runDir: active.runDir }),
    });
    const payload = await response.json();
    if (!response.ok || !payload.ok) {
      throw new Error(payload.error || `Meshy poll failed with ${response.status}`);
    }
    state.pbrPreview.roundtrip.activeRun = payload.run;
    state.pbrPreview.roundtrip.runs = [payload.run, ...state.pbrPreview.roundtrip.runs.filter((item) => item.runDir !== payload.run.runDir)];
    ui.meshyRoundtripStatus.textContent = roundtripStatusLabel(payload.run);
    renderMeshyRoundtripShell();
    if (payload.run.result && state.pbrPreview.parts.length) {
      try {
        await loadRoundtripResultAsVariant(payload.run);
      } catch (variantError) {
        console.warn('Meshy result is ready but could not be loaded as a variant yet.', variantError);
        ui.variantManagerStatus.textContent = 'Variant load skipped';
      }
    }
    renderVariantManager();
    if (roundtripStillRunning(payload.run)) scheduleMeshyRoundtripPoll();
  } catch (error) {
    console.error(error);
    state.pbrPreview.roundtrip.lastError = error.message;
    ui.meshyRoundtripStatus.textContent = 'Check failed';
    ui.meshyRoundtripReport.innerHTML = roundtripErrorRow(error.message);
  } finally {
    state.pbrPreview.roundtrip.busy = false;
    ui.pollMeshyRoundtripButton.disabled = false;
    renderMeshyRoundtripShell();
  }
}

async function loadMeshyRoundtripList() {
  const query = state.pbrPreview.payload?.partsDir ? `?path=${encodeURIComponent(state.pbrPreview.payload.partsDir)}` : '';
  try {
    const payload = await fetchJson(`/api/plant/meshy-roundtrip/list${query}`);
    state.pbrPreview.roundtrip.runs = payload.runs || [];
    state.pbrPreview.roundtrip.activeRun = latestMeshyRoundtripRunForGroup(ui.meshyRoundtripGroup.value || state.activeGroup || 'Core');
    renderMeshyRoundtripShell();
    renderVariantManager();
  } catch (error) {
    console.error(error);
  }
}

function scheduleMeshyRoundtripPoll() {
  if (state.pbrPreview.roundtrip.timer) window.clearTimeout(state.pbrPreview.roundtrip.timer);
  state.pbrPreview.roundtrip.timer = window.setTimeout(() => {
    state.pbrPreview.roundtrip.timer = null;
    pollMeshyRoundtrip();
  }, 9000);
}

function roundtripStillRunning(run) {
  return ['SUBMITTED', 'PENDING', 'IN_PROGRESS'].includes(String(run?.status || '').toUpperCase());
}

function roundtripStatusLabel(run) {
  const status = String(run?.status || 'UNKNOWN');
  const progress = Number(run?.progress || 0);
  if (status === 'SUCCEEDED') return `${run.group} result ready`;
  if (status === 'FAILED') return `${run.group} failed`;
  if (status === 'IN_PROGRESS' || status === 'PENDING') return `${run.group} ${status} ${progress}%`;
  return `${run?.group || 'Task'} ${status}`;
}

function renderSavedReport(saved) {
  const row = document.createElement('div');
  row.className = 'asset-report-row';
  row.innerHTML = `
    <span>Saved Manifest</span>
    <strong>${escapeHtml(saved.fileName)}</strong>
    <code>${escapeHtml(saved.projectPath)}</code>
  `;
  ui.assetReport.prepend(row);
}

function renderProjectionReport(payload) {
  const report = payload.report;
  const distance = report.projection.distance;
  const groupRows = Object.entries(report.projection.groups)
    .filter(([, value]) => value.estimated_faces > 0)
    .sort((a, b) => b[1].estimated_faces - a[1].estimated_faces)
    .slice(0, 7)
    .map(([name, value]) => `${name} ${compactNumber(value.estimated_faces)}`)
    .join(' | ');
  const row = document.createElement('div');
  row.className = `asset-report-row projection-report ${escapeHtml(report.verdict.level)}`;
  row.innerHTML = `
    <span>Projection Diagnostics</span>
    <strong>${escapeHtml(report.verdict.level)} - p90 ${distance.p90}, p95 ${distance.p95}</strong>
    <code>${escapeHtml(groupRows)} | ${escapeHtml(payload.projectPath)} | ${report.elapsed_ms} ms</code>
  `;
  ui.assetReport.prepend(row);
}

function renderPbrExportReport(payload) {
  const report = payload.report;
  const exportRows = report.exports
    .map((item) => `${item.group} ${compactNumber(item.faces)}`)
    .join(' | ');
  const row = document.createElement('div');
  row.className = 'asset-report-row pbr-export-report';
  row.innerHTML = `
    <span>PBR Part Export</span>
    <strong>${report.exports.length} glTF parts - ${compactNumber(report.counts.pbr_faces)} source faces</strong>
    <code>${escapeHtml(exportRows)} | ${escapeHtml(payload.projectPath)} | ${report.elapsed_ms} ms</code>
  `;
  ui.assetReport.prepend(row);
}

function renderPackedGlbReport(payload) {
  const glbRows = payload.exports
    .map((item) => `${item.group} ${formatBytes(item.bytes)}`)
    .join(' | ');
  const row = document.createElement('div');
  row.className = 'asset-report-row pbr-export-report';
  row.innerHTML = `
    <span>Complete GLB Pack</span>
    <strong>${payload.exports.length} self-contained .glb files</strong>
    <code>${escapeHtml(glbRows)} | ${escapeHtml(payload.outputDir)} | ${payload.elapsed_ms} ms</code>
  `;
  ui.assetReportStatus.textContent = 'GLBs packed';
  ui.assetReport.prepend(row);
}

function isDefaultAutoSplitWorkspace(workspaceName) {
  return defaultAutoSplitWorkspacePattern.test(String(workspaceName || ''));
}

function isDefaultAutoSplitPreview() {
  return isDefaultAutoSplitWorkspace(state.pbrPreview.payload?.workspaceName) && !state.pbrPreview.roundtripTrusted;
}

function tryAutoLoadLatestPbrExportPreview() {
  loadPbrExportPreview('', { automatic: true }).catch((error) => {
    console.warn('Latest PBR preview auto-load failed.', error);
  });
}

async function loadPbrExportPreview(rawPath = '', {
  automatic = false,
  roundtripTrusted = false,
  sourceLabel = '',
} = {}) {
  setPbrPreviewLoading(true, 'Loading exported PBR parts...');
  ui.pbrPreviewStatus.textContent = rawPath ? 'Loading export' : (automatic ? 'Checking latest export' : 'Loading latest export');
  ui.loadLatestPreviewButton.disabled = true;
  ui.packPbrGlbsButton.disabled = true;
  state.pbrPreview.payload = null;
  state.pbrPreview.roundtripTrusted = false;
  state.pbrPreview.sourceLabel = 'loading';
  state.pbrPreview.pack = null;
  try {
    const query = rawPath ? `?path=${encodeURIComponent(rawPath)}` : '';
    const payload = await fetchJson(`/api/plant/export-preview${query}`);
    if (automatic && isDefaultAutoSplitWorkspace(payload.workspaceName)) {
      ui.pbrPreviewStatus.textContent = 'No semantic export auto-loaded';
      ui.pbrPreviewReport.innerHTML = `
        <div class="asset-report-row">
          <span>Preview Workspace</span>
          <strong>Default auto-split skipped</strong>
          <code>Use Load Latest Export manually only if you really want the demo fallback.</code>
        </div>
      `;
      setPbrPreviewLoading(false);
      state.pbrPreview.sourceLabel = 'auto latest skipped default fallback';
      return;
    }
    const groups = payload.groups.filter((group) => group.hasGltf && group.gltfUrl);
    if (!groups.length) throw new Error('No exported glTF part packages were found.');
    const parts = [];
    for (const group of groups) {
      setPbrPreviewLoading(true, `Loading ${group.id}...`);
      parts.push(await loadPbrPreviewPart(group));
      await nextFrame();
    }
    normalizePbrPreviewParts(parts);
    state.pbrPreview.payload = payload;
    state.pbrPreview.roundtripTrusted = Boolean(roundtripTrusted);
    state.pbrPreview.sourceLabel = sourceLabel || (rawPath ? 'explicit export preview' : (automatic ? 'auto latest export' : 'latest export'));
    state.pbrPreview.pack = null;
    state.pbrPreview.parts = parts;
    state.pbrPreview.variants = new Map();
    state.pbrPreview.activeVariants = new Map();
    state.pbrPreview.compareMode = 'original';
    state.pbrPreview.hiddenGroups.clear();
    await uploadPbrPreviewParts(parts);
    resetPbrPreviewCamera();
    renderPbrPreviewShell();
    renderVariantManager();
    renderPbrPreviewScene();
    ui.pbrPreviewStatus.textContent = `${payload.workspaceName} loaded`;
    await loadMeshyRoundtripList();
    setPbrPreviewLoading(false);
  } catch (error) {
    console.error(error);
    ui.pbrPreviewStatus.textContent = 'Preview load failed';
    ui.pbrPreviewReport.innerHTML = `
      <div class="asset-report-row">
        <span>Preview Error</span>
        <strong>Could not load export</strong>
        <code>${escapeHtml(error.message)}</code>
      </div>
    `;
    setPbrPreviewLoading(false);
  } finally {
    ui.loadLatestPreviewButton.disabled = false;
    updatePackButtonState();
  }
}

async function loadPbrPreviewPart(group) {
  const gltf = await fetchJson(group.gltfUrl);
  const bufferInfo = gltf.buffers?.[0];
  if (!bufferInfo?.uri) throw new Error(`${group.id} glTF has no external buffer.`);
  const bin = await fetchArrayBuffer(resolvePreviewAssetUrl(group.folderPath, bufferInfo.uri));
  return buildPbrPreviewPart(group, gltf, bin, {
    faces: group.faces,
    vertices: group.vertices,
    textureFolderPath: group.folderPath,
  });
}

async function loadPbrPreviewPartFromGlb(group, glbUrl, run = null) {
  const { doc, bin } = readGlb(await fetchArrayBuffer(glbUrl));
  return buildPbrPreviewPart(group, doc, bin, {
    textureFolderPath: group.folderPath || '',
    sourceUrl: glbUrl,
    variantRun: run,
  });
}

function buildPbrPreviewPart(group, gltf, bin, {
  faces = null,
  vertices = null,
  textureFolderPath = '',
  sourceUrl = '',
  variantRun = null,
} = {}) {
  const primitive = firstTrianglePrimitive(gltf);
  const attributes = primitive.attributes || {};
  const positionsAccessor = readGlbAccessor(gltf, bin, attributes.POSITION);
  const normalsAccessor = attributes.NORMAL != null ? readGlbAccessor(gltf, bin, attributes.NORMAL) : null;
  const texcoordAccessor = attributes.TEXCOORD_0 != null ? readGlbAccessor(gltf, bin, attributes.TEXCOORD_0) : null;
  const indexAccessor = primitive.indices != null ? readGlbAccessor(gltf, bin, primitive.indices) : null;
  const vertexCount = positionsAccessor.count;
  const positions = new Float32Array(vertexCount * 3);
  const normals = new Float32Array(vertexCount * 3);
  const texcoords = new Float32Array(vertexCount * 2);
  const bounds = createEmptyBounds();

  for (let i = 0; i < vertexCount; i += 1) {
    const x = positionsAccessor.data[i * positionsAccessor.width];
    const y = positionsAccessor.data[i * positionsAccessor.width + 1];
    const z = positionsAccessor.data[i * positionsAccessor.width + 2];
    positions[i * 3] = x;
    positions[i * 3 + 1] = y;
    positions[i * 3 + 2] = z;
    expandBounds(bounds, [x, y, z]);
    if (normalsAccessor) {
      normals[i * 3] = normalsAccessor.data[i * normalsAccessor.width];
      normals[i * 3 + 1] = normalsAccessor.data[i * normalsAccessor.width + 1];
      normals[i * 3 + 2] = normalsAccessor.data[i * normalsAccessor.width + 2];
    } else {
      normals[i * 3 + 1] = 1;
    }
    if (texcoordAccessor) {
      texcoords[i * 2] = texcoordAccessor.data[i * texcoordAccessor.width];
      texcoords[i * 2 + 1] = texcoordAccessor.data[i * texcoordAccessor.width + 1];
    }
  }

  let indices;
  if (indexAccessor) {
    indices = new Uint32Array(indexAccessor.data.length);
    indices.set(indexAccessor.data);
  } else {
    indices = new Uint32Array(vertexCount);
    for (let i = 0; i < vertexCount; i += 1) indices[i] = i;
  }

  const material = gltf.materials?.[primitive.material ?? 0] || {};
  const baseColor = material.pbrMetallicRoughness?.baseColorFactor?.slice(0, 3) || semanticColorForGroup(group.id);
  const textureUrl = pbrBaseColorTextureUrl(gltf, material, textureFolderPath, bin);
  return {
    id: group.id,
    group,
    sourceUrl,
    variantRun,
    positions,
    normals,
    texcoords,
    indices,
    bounds,
    baseColor,
    semanticColor: semanticColorForGroup(group.id),
    textureUrl,
    texture: null,
    buffers: null,
    indexCount: indices.length,
    faces: faces ?? Math.floor(indices.length / 3),
    vertices: vertices ?? vertexCount,
    center: [
      (bounds.min[0] + bounds.max[0]) * 0.5,
      (bounds.min[1] + bounds.max[1]) * 0.5,
      (bounds.min[2] + bounds.max[2]) * 0.5,
    ],
  };
}

function firstTrianglePrimitive(gltf) {
  for (const mesh of gltf.meshes || []) {
    for (const primitive of mesh.primitives || []) {
      if ((primitive.mode ?? 4) === 4 && primitive.attributes?.POSITION != null) return primitive;
    }
  }
  throw new Error('glTF package has no triangle POSITION primitive.');
}

function pbrBaseColorTextureUrl(gltf, material, folderPath, bin = null) {
  const textureIndex = material.pbrMetallicRoughness?.baseColorTexture?.index;
  if (textureIndex == null) return null;
  const texture = gltf.textures?.[textureIndex];
  const image = gltf.images?.[texture?.source];
  if (!image) return null;
  if (image.uri) return resolvePreviewAssetUrl(folderPath, image.uri);
  if (image.bufferView != null && bin) return gltfImageBufferViewUrl(gltf, bin, image);
  return null;
}

function gltfImageBufferViewUrl(gltf, bin, image) {
  const bufferView = gltf.bufferViews?.[image.bufferView];
  if (!bufferView) return null;
  const start = bufferView.byteOffset || 0;
  const end = start + (bufferView.byteLength || 0);
  const blob = new Blob([bin.slice(start, end)], { type: image.mimeType || 'image/png' });
  return URL.createObjectURL(blob);
}

function resolvePreviewAssetUrl(folderPath, uri) {
  if (/^https?:\/\//i.test(uri) || uri.startsWith('data:')) return uri;
  const stack = String(folderPath || '').replaceAll('\\', '/').split('/').filter(Boolean);
  for (const segment of String(uri || '').replaceAll('\\', '/').split('/')) {
    if (!segment || segment === '.') continue;
    if (segment === '..') {
      stack.pop();
    } else {
      stack.push(segment);
    }
  }
  return `/api/plant/export-preview/file?path=${encodeURIComponent(stack.join('/'))}`;
}

function normalizePbrPreviewParts(parts) {
  const bounds = createEmptyBounds();
  for (const part of parts) {
    expandBounds(bounds, part.bounds.min);
    expandBounds(bounds, part.bounds.max);
  }
  const center = [
    (bounds.min[0] + bounds.max[0]) * 0.5,
    (bounds.min[1] + bounds.max[1]) * 0.5,
    (bounds.min[2] + bounds.max[2]) * 0.5,
  ];
  const scale = 2.05 / Math.max(
    bounds.max[0] - bounds.min[0],
    bounds.max[1] - bounds.min[1],
    bounds.max[2] - bounds.min[2],
    0.000001,
  );
  for (const part of parts) {
    for (let i = 0; i < part.positions.length; i += 3) {
      part.positions[i] = (part.positions[i] - center[0]) * scale;
      part.positions[i + 1] = (part.positions[i + 1] - center[1]) * scale;
      part.positions[i + 2] = (part.positions[i + 2] - center[2]) * scale;
    }
    part.bounds = boundsFromPositions(part.positions);
    part.center = centerFromBounds(part.bounds);
    part.normalizedCenter = [...part.center];
  }
}

function alignVariantPartToOriginalPart(variantPart, originalPart) {
  const originalBounds = boundsFromPositions(originalPart.positions);
  const variantBounds = boundsFromPositions(variantPart.positions);
  const originalCenter = centerFromBounds(originalBounds);
  const variantCenter = centerFromBounds(variantBounds);
  const originalSize = maxDimensionFromBounds(originalBounds);
  const variantSize = Math.max(maxDimensionFromBounds(variantBounds), 0.000001);
  const scale = originalSize / variantSize;
  for (let i = 0; i < variantPart.positions.length; i += 3) {
    variantPart.positions[i] = (variantPart.positions[i] - variantCenter[0]) * scale + originalCenter[0];
    variantPart.positions[i + 1] = (variantPart.positions[i + 1] - variantCenter[1]) * scale + originalCenter[1];
    variantPart.positions[i + 2] = (variantPart.positions[i + 2] - variantCenter[2]) * scale + originalCenter[2];
  }
  variantPart.bounds = boundsFromPositions(variantPart.positions);
  variantPart.center = centerFromBounds(variantPart.bounds);
  variantPart.normalizedCenter = originalPart.normalizedCenter || originalCenter;
  return variantPart;
}

function centerFromBounds(bounds) {
  return [
    (bounds.min[0] + bounds.max[0]) * 0.5,
    (bounds.min[1] + bounds.max[1]) * 0.5,
    (bounds.min[2] + bounds.max[2]) * 0.5,
  ];
}

function maxDimensionFromBounds(bounds) {
  return Math.max(
    bounds.max[0] - bounds.min[0],
    bounds.max[1] - bounds.min[1],
    bounds.max[2] - bounds.min[2],
    0,
  );
}

function renderPbrPreviewShell() {
  renderPbrPreviewModeButtons();
  renderPbrPartToggles();
  renderPbrPreviewReport();
  renderVariantManager();
  updatePackButtonState();
}

function updatePackButtonState() {
  ui.packPbrGlbsButton.disabled = !state.pbrPreview.payload?.partsDir;
}

function renderPbrPreviewModeButtons() {
  for (const button of ui.pbrPreviewModeControl.querySelectorAll('[data-pbr-preview-mode]')) {
    button.classList.toggle('active', button.dataset.pbrPreviewMode === state.pbrPreview.mode);
  }
}

function renderPbrPartToggles() {
  const parts = state.pbrPreview.parts;
  if (!parts.length) {
    ui.pbrPartToggleList.innerHTML = `
      <div class="asset-report-row">
        <span>Parts</span>
        <strong>No export loaded</strong>
        <code>Use Load Latest Export after cutting PBR parts.</code>
      </div>
    `;
    return;
  }
  ui.pbrPartToggleList.innerHTML = parts.map((part) => {
    const hidden = state.pbrPreview.hiddenGroups.has(part.id);
    const displayPart = activePbrPreviewPart(part);
    const variantLabel = displayPart === part ? 'A' : 'B';
    const targeted = ui.meshyRoundtripGroup.value === part.id;
    return `
      <div class="pbr-part-toggle${hidden ? ' disabled' : ''}${targeted ? ' targeted' : ''}" role="button" tabindex="0" data-pbr-group-id="${escapeHtml(part.id)}">
        <span class="group-swatch" style="background:${escapeHtml(groupById.get(part.id)?.color || unassignedColor)}"></span>
        <span>
          <strong>${escapeHtml(part.id)}</strong>
          <span>${compactNumber(displayPart.faces)} faces | ${compactNumber(displayPart.vertices)} verts | ${variantLabel}</span>
        </span>
        <span class="pbr-part-actions">
          <button class="pbr-part-action${targeted ? ' active' : ''}" type="button" data-pbr-target-group="${escapeHtml(part.id)}">Target</button>
          <button class="pbr-part-action" type="button" data-pbr-visibility-group="${escapeHtml(part.id)}">${hidden ? 'Off' : 'On'}</button>
        </span>
      </div>
    `;
  }).join('');
}

function renderPbrPreviewReport() {
  const payload = state.pbrPreview.payload;
  if (!payload) {
    ui.pbrPreviewReport.innerHTML = `
      <div class="asset-report-row">
        <span>Export Workspace</span>
        <strong>Awaiting load</strong>
        <code>Latest export will come from output/plant_regroup or mesh_inbox/_analysis_runs.</code>
      </div>
    `;
    return;
  }
  const displayParts = pbrPreviewPartsForRender();
  const totalFaces = displayParts.reduce((sum, part) => sum + part.faces, 0);
  const totalVertices = displayParts.reduce((sum, part) => sum + part.vertices, 0);
  const variantCount = [...state.pbrPreview.variants.values()].reduce((sum, variants) => sum + variants.length, 0);
  const packed = state.pbrPreview.pack;
  const defaultFallbackRow = isDefaultAutoSplitWorkspace(payload.workspaceName) && !state.pbrPreview.roundtripTrusted ? `
    <div class="asset-report-row">
      <span>Workspace Guard</span>
      <strong>Demo fallback only</strong>
      <code>This auto-split workspace is not a clean semantic regroup; Meshy send is blocked here.</code>
    </div>
  ` : '';
  const trustedExportRow = state.pbrPreview.roundtripTrusted ? `
    <div class="asset-report-row pbr-export-report">
      <span>Roundtrip Source</span>
      <strong>Current regroup export</strong>
      <code>${escapeHtml(state.pbrPreview.sourceLabel)} | Meshy send will use this exact PBR preview.</code>
    </div>
  ` : '';
  const packedRows = packed ? `
    <div class="asset-report-row pbr-export-report">
      <span>Complete GLBs</span>
      <strong>${packed.exports.length} files ready</strong>
      <code>${escapeHtml(packed.outputDir)}</code>
    </div>
    ${packed.exports.map((item) => `
      <div class="asset-report-row">
        <span>${escapeHtml(item.group)}</span>
        <strong>${escapeHtml(item.fileName)} - ${formatBytes(item.bytes)}</strong>
        <code>${escapeHtml(item.path)}</code>
      </div>
    `).join('')}
  ` : '';
  ui.pbrPreviewReport.innerHTML = `
    <div class="asset-report-row pbr-export-report">
      <span>Preview Workspace</span>
      <strong>${escapeHtml(payload.workspaceName)}</strong>
      <code>${escapeHtml(payload.partsDir)}</code>
    </div>
    <div class="asset-report-row">
      <span>Loaded Parts</span>
      <strong>${displayParts.length} groups | ${compactNumber(totalFaces)} faces</strong>
      <code>${compactNumber(totalVertices)} vertices | ${payload.textures.length} shared textures | ${variantCount} variants</code>
    </div>
    ${trustedExportRow}
    ${defaultFallbackRow}
    ${packedRows}
  `;
}

function renderVariantManager() {
  if (!ui.variantList) return;
  renderVariantCompareButtons();
  const preview = state.pbrPreview;
  const loadedVariants = [...preview.variants.values()].flat();
  const resultRuns = preview.roundtrip.runs.filter((run) => run?.result?.url);
  if (!preview.payload) {
    ui.variantManagerStatus.textContent = 'Load PBR export first';
    ui.variantList.innerHTML = `
      <div class="asset-report-row">
        <span>Variants</span>
        <strong>No PBR preview loaded</strong>
        <code>Load Latest Export, then load Meshy result.glb variants here.</code>
      </div>
    `;
    return;
  }

  const activeCount = [...preview.parts]
    .filter((part) => activePbrPreviewPart(part) !== part)
    .length;
  ui.variantManagerStatus.textContent = `${loadedVariants.length} loaded | ${activeCount} active`;
  ui.variantList.innerHTML = semanticGroups.map((group) => renderVariantGroupCard(group, resultRuns)).join('');
}

function renderVariantGroupCard(group, resultRuns) {
  const preview = state.pbrPreview;
  const originalPart = preview.parts.find((part) => part.id === group.id);
  const variants = preview.variants.get(group.id) || [];
  const activeId = preview.activeVariants.get(group.id);
  const activeVariant = variants.find((variant) => variant.id === activeId);
  const displayVariant = activeVariant || (preview.compareMode === 'variant' ? variants[0] : null);
  const groupRuns = resultRuns.filter((run) => run.group === group.id);
  const availableRuns = groupRuns.filter((run) => !loadedVariantForRun(run));
  const status = displayVariant && preview.compareMode !== 'original'
    ? `B ${displayVariant.label}`
    : 'A Original';
  const originalMeta = originalPart
    ? `${compactNumber(originalPart.faces)} faces | ${compactNumber(originalPart.vertices)} verts`
    : 'Original part not loaded';
  const variantRows = variants.map((variant) => `
    <div class="variant-row${variant.id === activeId && preview.compareMode !== 'original' ? ' active' : ''}">
      <span class="group-swatch" style="background:${escapeHtml(group.color)}"></span>
      <span>
        <strong>${escapeHtml(variant.label)}</strong>
        <code>${escapeHtml(variant.run.operation || 'meshy')} | ${formatBytes(variant.run.result?.bytes || 0)}</code>
      </span>
      <span class="variant-row-actions">
        <button class="variant-action-button${variant.id === activeId ? ' active' : ''}" type="button" data-variant-group="${escapeHtml(group.id)}" data-variant-use="${escapeHtml(variant.id)}">Use</button>
        <button class="variant-action-button" type="button" data-variant-group="${escapeHtml(group.id)}" data-variant-remove="${escapeHtml(variant.id)}">Drop</button>
      </span>
    </div>
  `).join('');
  const availableRows = availableRuns.map((run) => `
    <div class="variant-row">
      <span class="group-swatch" style="background:${escapeHtml(group.color)}"></span>
      <span>
        <strong>${escapeHtml(variantLabelForRun(run))}</strong>
        <code>${escapeHtml(run.result.path)} | ${formatBytes(run.result.bytes || 0)}</code>
      </span>
      <span class="variant-row-actions">
        <button class="variant-action-button" type="button" data-variant-load-run="${escapeHtml(run.runDir)}">Load</button>
      </span>
    </div>
  `).join('');
  const emptyRow = !variantRows && !availableRows ? `
    <div class="variant-row">
      <span class="group-swatch" style="background:${escapeHtml(group.color)}"></span>
      <span>
        <strong>No Meshy result</strong>
        <code>Poll or load a succeeded run for this group.</code>
      </span>
      <span></span>
    </div>
  ` : '';
  return `
    <div class="variant-group-card">
      <div class="variant-group-head">
        <span class="group-swatch" style="background:${escapeHtml(group.color)}"></span>
        <span>
          <strong>${escapeHtml(group.id)}</strong>
          <code>${escapeHtml(status)} | ${originalMeta}</code>
        </span>
        <button class="variant-action-button${!displayVariant || preview.compareMode === 'original' ? ' active' : ''}" type="button" data-variant-original="${escapeHtml(group.id)}">Original</button>
      </div>
      ${variantRows}
      ${availableRows}
      ${emptyRow}
    </div>
  `;
}

function renderVariantCompareButtons() {
  const mode = state.pbrPreview.compareMode;
  ui.compareOriginalButton.classList.toggle('active', mode === 'original');
  ui.compareVariantButton.classList.toggle('active', mode === 'variant');
  ui.compareMixedButton.classList.toggle('active', mode === 'mixed');
}

function setVariantCompareMode(mode) {
  if (!['original', 'variant', 'mixed'].includes(mode)) return;
  state.pbrPreview.compareMode = mode;
  renderVariantCompareButtons();
  renderPbrPartToggles();
  renderPbrPreviewReport();
  renderVariantManager();
  renderPbrPreviewScene();
}

async function handleVariantListClick(event) {
  const loadButton = event.target.closest('[data-variant-load-run]');
  if (loadButton) {
    const runDir = loadButton.dataset.variantLoadRun;
    const run = state.pbrPreview.roundtrip.runs.find((item) => item.runDir === runDir);
    if (!run) return;
    try {
      await loadRoundtripResultAsVariant(run);
    } catch (error) {
      console.error(error);
      ui.variantManagerStatus.textContent = 'Variant load failed';
    }
    return;
  }

  const originalButton = event.target.closest('[data-variant-original]');
  if (originalButton) {
    state.pbrPreview.activeVariants.delete(originalButton.dataset.variantOriginal);
    state.pbrPreview.compareMode = 'mixed';
    renderPbrPreviewShell();
    renderPbrPreviewScene();
    return;
  }

  const useButton = event.target.closest('[data-variant-use]');
  if (useButton) {
    const groupId = useButton.dataset.variantGroup;
    const variantId = useButton.dataset.variantUse;
    if (variantById(groupId, variantId)) {
      state.pbrPreview.activeVariants.set(groupId, variantId);
      state.pbrPreview.compareMode = 'variant';
      renderPbrPreviewShell();
      renderPbrPreviewScene();
    }
    return;
  }

  const removeButton = event.target.closest('[data-variant-remove]');
  if (removeButton) {
    const groupId = removeButton.dataset.variantGroup;
    const variantId = removeButton.dataset.variantRemove;
    const next = (state.pbrPreview.variants.get(groupId) || []).filter((variant) => variant.id !== variantId);
    state.pbrPreview.variants.set(groupId, next);
    if (state.pbrPreview.activeVariants.get(groupId) === variantId) state.pbrPreview.activeVariants.delete(groupId);
    renderPbrPreviewShell();
    renderPbrPreviewScene();
  }
}

async function loadRoundtripResultAsVariant(run) {
  if (!run?.result?.url) throw new Error('Meshy run has no local result.glb URL yet.');
  const originalPart = state.pbrPreview.parts.find((part) => part.id === run.group);
  if (!originalPart) throw new Error(`Load PBR export first; original ${run.group} part is missing.`);
  const existing = loadedVariantForRun(run);
  if (existing) {
    state.pbrPreview.activeVariants.set(run.group, existing.id);
    state.pbrPreview.compareMode = 'variant';
    renderPbrPreviewShell();
    renderPbrPreviewScene();
    return existing;
  }

  setPbrPreviewLoading(true, `Loading ${run.group} Meshy variant...`);
  const group = originalPart.group || { id: run.group, folderPath: '' };
  try {
    const variantPart = await loadPbrPreviewPartFromGlb(group, run.result.url, run);
    alignVariantPartToOriginalPart(variantPart, originalPart);
    variantPart.id = originalPart.id;
    variantPart.semanticColor = originalPart.semanticColor;
    await uploadPbrPreviewParts([variantPart]);
    const variant = {
      id: variantIdFromRun(run),
      label: variantLabelForRun(run),
      group: run.group,
      run,
      part: variantPart,
      loadedAt: new Date().toISOString(),
    };
    const variants = state.pbrPreview.variants.get(run.group) || [];
    state.pbrPreview.variants.set(run.group, [...variants.filter((item) => item.id !== variant.id), variant]);
    state.pbrPreview.activeVariants.set(run.group, variant.id);
    state.pbrPreview.compareMode = 'variant';
    ui.variantManagerStatus.textContent = `${run.group} variant loaded`;
    renderPbrPreviewShell();
    renderPbrPreviewScene();
    return variant;
  } finally {
    setPbrPreviewLoading(false);
  }
}

function activePbrPreviewPart(originalPart) {
  if (state.pbrPreview.compareMode === 'original') return originalPart;
  const variants = state.pbrPreview.variants.get(originalPart.id) || [];
  const activeId = state.pbrPreview.activeVariants.get(originalPart.id);
  const active = variants.find((variant) => variant.id === activeId);
  if (active) return active.part;
  if (state.pbrPreview.compareMode === 'variant') return variants[0]?.part || originalPart;
  return originalPart;
}

function pbrPreviewPartsForRender() {
  return state.pbrPreview.parts.map((part) => activePbrPreviewPart(part));
}

function loadedVariantForRun(run) {
  return variantById(run.group, variantIdFromRun(run));
}

function variantById(groupId, variantId) {
  return (state.pbrPreview.variants.get(groupId) || []).find((variant) => variant.id === variantId) || null;
}

function variantIdFromRun(run) {
  return `${run.runDir || run.taskId || 'meshy'}::${run.result?.path || ''}`;
}

function variantLabelForRun(run) {
  const operation = String(run.operation || 'meshy').replace(/^\w/, (letter) => letter.toUpperCase());
  const leaf = String(run.runDir || run.taskId || 'variant').replaceAll('\\', '/').split('/').pop() || 'variant';
  const shortLeaf = leaf.replace(/^\d{8}_\d{6}_?/, '').replace(`${run.group}_`, '');
  return `${operation} ${shortLeaf}`;
}

function renderMeshyRoundtripShell() {
  syncMeshyRoundtripPrompt({ force: false });
  renderMeshyRoundtripTargetHint();
  const roundtrip = state.pbrPreview.roundtrip;
  const run = currentMeshyRoundtripRun();
  const promptError = updateMeshyPromptMeter();
  const hasLoadedExport = Boolean(state.pbrPreview.payload?.partsDir);
  const defaultAutoSplitLoaded = isDefaultAutoSplitPreview();
  ui.sendMeshyRoundtripButton.textContent = defaultAutoSplitLoaded ? 'Export Current Parts First' : 'Send to Meshy';
  ui.sendMeshyRoundtripButton.disabled = !roundtrip.configured || roundtrip.busy || !hasLoadedExport || defaultAutoSplitLoaded || Boolean(promptError);
  ui.pollMeshyRoundtripButton.disabled = roundtrip.busy || !run || defaultAutoSplitLoaded;
  if (!roundtrip.configured) {
    ui.meshyRoundtripReport.innerHTML = `
      <div class="asset-report-row">
        <span>Meshy API</span>
        <strong>Server key missing</strong>
        <code>Set MESHY_API_KEY before sending a part.</code>
      </div>
    `;
    return;
  }
  if (!hasLoadedExport) {
    ui.meshyRoundtripReport.innerHTML = `
      <div class="asset-report-row">
        <span>Roundtrip</span>
        <strong>Load PBR parts first</strong>
        <code>Export PBR Parts or Load Latest Export before sending a Meshy variant.</code>
      </div>
    `;
    return;
  }
  if (defaultAutoSplitLoaded) {
    if (!roundtrip.busy) ui.meshyRoundtripStatus.textContent = 'Demo fallback blocked';
    ui.meshyRoundtripReport.innerHTML = `
      <div class="asset-report-row">
        <span>Roundtrip Guard</span>
        <strong>Demo auto-split blocked</strong>
        <code>This button will not switch workspaces. Export PBR Parts from the current assignment, then send that exact preview.</code>
      </div>
    `;
    return;
  }
  if (promptError) {
    ui.meshyRoundtripReport.innerHTML = roundtripErrorRow(promptError);
    return;
  }
  if (roundtrip.lastError) {
    ui.meshyRoundtripReport.innerHTML = roundtripErrorRow(roundtrip.lastError);
    return;
  }
  if (!run) {
    ui.meshyRoundtripReport.innerHTML = `
      <div class="asset-report-row">
        <span>Roundtrip</span>
        <strong>Ready for selected part</strong>
        <code>${escapeHtml(ui.meshyRoundtripGroup.value)} | ${escapeHtml(ui.meshyRoundtripOperation.value)}</code>
      </div>
    `;
    return;
  }
  const resultRow = run.result ? `
    <div class="asset-report-row pbr-export-report">
      <span>Result GLB</span>
      <strong>${escapeHtml(run.group)} - ${formatBytes(run.result.bytes)}</strong>
      <code>${escapeHtml(run.result.path)}</code>
    </div>
  ` : '';
  ui.meshyRoundtripReport.innerHTML = `
    <div class="asset-report-row">
      <span>Active Task</span>
      <strong>${escapeHtml(run.group)} | ${escapeHtml(run.operation)} | ${escapeHtml(run.status)}</strong>
      <code>${escapeHtml(run.runDir)} | ${Number(run.progress || 0)}%</code>
    </div>
    ${resultRow}
  `;
}

function syncMeshyRoundtripPrompt({ force = false } = {}) {
  if (!ui.meshyRoundtripPrompt) return;
  const current = ui.meshyRoundtripPrompt.value.trim();
  const currentDefault = ui.meshyRoundtripPrompt.dataset.defaultPrompt || '';
  if (current && current !== currentDefault && !force) return;
  const next = defaultMeshyRoundtripPrompt(ui.meshyRoundtripGroup.value, ui.meshyRoundtripOperation.value);
  ui.meshyRoundtripPrompt.dataset.defaultPrompt = next;
  ui.meshyRoundtripPrompt.value = next;
  updateMeshyPromptMeter();
}

function meshyPromptLimitError() {
  const operation = ui.meshyRoundtripOperation.value;
  if (operation !== 'retexture') return '';
  const length = Array.from(ui.meshyRoundtripPrompt.value.trim()).length;
  if (length <= meshyTextStylePromptMaxLength) return '';
  return `Retexture prompt is ${length} characters; Meshy allows ${meshyTextStylePromptMaxLength}. Shorten it before sending.`;
}

function updateMeshyPromptMeter() {
  if (!ui.meshyRoundtripPromptMeter) return meshyPromptLimitError();
  const operation = ui.meshyRoundtripOperation.value;
  const length = Array.from(ui.meshyRoundtripPrompt.value.trim()).length;
  const limit = operation === 'retexture' ? meshyTextStylePromptMaxLength : null;
  ui.meshyRoundtripPromptMeter.classList.toggle('warning', Boolean(limit && length > limit * 0.9 && length <= limit));
  ui.meshyRoundtripPromptMeter.classList.toggle('error', Boolean(limit && length > limit));
  ui.meshyRoundtripPromptMeter.textContent = limit
    ? `${length} / ${limit}`
    : `${length} chars`;
  return meshyPromptLimitError();
}

function defaultMeshyRoundtripPrompt(groupId, operation) {
  const groupPrompts = {
    Core: 'the luminous inner core, bright alchemical glow, clean readable center mass, preserve the same silhouette and pivot',
    PrimarySilhouette: 'the main floating plant silhouette, elegant large readable arcs, richer surface detail, preserve the original outer contour',
    OrbitSet: 'the orbital ring and rune set, polished arcane metal, stronger blue emissive runes, crisp separation from the core',
    BodyShell: 'the root shell and stem base, denser organic root texture, grounded base form, preserve the modular attachment feel',
  };
  const base = groupPrompts[groupId] || 'the selected modular plant part';
  if (operation === 'remesh') {
    return `Smooth and clean ${base}. Remove tiny Meshy segmentation artifacts, keep the approximate scale, pivot, part identity, and assembly boundary. Output should remain a usable standalone GLB part.`;
  }
  return `Retexture ${base}. Keep the same geometry, scale, pivot, and modular part boundary. Create a high quality stylized PBR game asset with no baked lighting and no new unrelated appendages.`;
}

function roundtripErrorRow(message) {
  return `
    <div class="asset-report-row">
      <span>Meshy Error</span>
      <strong>Roundtrip unavailable</strong>
      <code>${escapeHtml(message)}</code>
    </div>
  `;
}

function buildManifest() {
  const semantic = Object.fromEntries(semanticGroups.map((group) => [group.id, []]));
  const unassignedParts = [];
  for (const part of state.parts) {
    const groupId = state.assignments.get(part.id);
    const partPayload = {
      id: part.id,
      name: part.name,
      material: part.material,
      triangles: part.triCount,
      height_ratio: roundNumber(part.heightRatio, 4),
      radial_ratio: roundNumber(part.radialRatio, 4),
      bbox: {
        min: part.bbox.min.map((value) => roundNumber(value, 6)),
        max: part.bbox.max.map((value) => roundNumber(value, 6)),
      },
    };
    if (semantic[groupId]) semantic[groupId].push(partPayload);
    else unassignedParts.push(partPayload);
  }
  const sample = state.sample || { assets: {}, mapping: {} };
  return {
    schema: 'SkyIslandPotion.PlantRegroupManifest.v1',
    plant_profile: state.plantProfile,
    semantic_schema: semanticGroups.map((group) => ({
      id: group.id,
      label: groupDisplayLabel(group.id),
      color: group.color,
    })),
    file_name: `plant_regroup_${safeIdFromName(sample.sampleId || sample.assets?.['split-obj']?.fileName || 'local')}.json`,
    generated_at: new Date().toISOString(),
    source: {
      sample_id: sample.sampleId || null,
      split_obj: sample.assets?.['split-obj']?.fileName || null,
      split_mtl: sample.assets?.['split-mtl']?.fileName || null,
      split_glb: sample.assets?.['split-glb']?.fileName || null,
      pbr_glb: sample.assets?.['pbr-glb']?.fileName || null,
      source_mode: state.sourceMode,
    },
    mapping: {
      recommended_mode: sample.mapping?.recommendedMode || 'PartSurfaceProjection',
      direct_face_index_available: false,
      note: 'This manifest captures human/heuristic regrouping first. PBR cutting should project PBR faces onto the regrouped split surfaces.',
    },
    semantic_groups: semantic,
    unassigned_parts: unassignedParts,
  };
}

function setupRenderer() {
  const gl = ui.plantCanvas.getContext('webgl', {
    antialias: true,
    preserveDrawingBuffer: true,
  });
  if (!gl) {
    ui.viewerStatus.textContent = 'WebGL unavailable';
    return;
  }
  const mainProgram = createProgram(gl, mainVertexShader, mainFragmentShader);
  const pickProgram = createProgram(gl, pickVertexShader, pickFragmentShader);
  state.renderer = {
    gl,
    mainProgram,
    pickProgram,
    buffers: {},
    pickTarget: null,
    mainLocations: {
      aPosition: gl.getAttribLocation(mainProgram, 'aPosition'),
      aNormal: gl.getAttribLocation(mainProgram, 'aNormal'),
      aColor: gl.getAttribLocation(mainProgram, 'aColor'),
      uMvp: gl.getUniformLocation(mainProgram, 'uMvp'),
      uOffset: gl.getUniformLocation(mainProgram, 'uOffset'),
      uInflate: gl.getUniformLocation(mainProgram, 'uInflate'),
      uOverride: gl.getUniformLocation(mainProgram, 'uOverride'),
      uOverrideColor: gl.getUniformLocation(mainProgram, 'uOverrideColor'),
      uAlpha: gl.getUniformLocation(mainProgram, 'uAlpha'),
      uSelectionEffect: gl.getUniformLocation(mainProgram, 'uSelectionEffect'),
      uTime: gl.getUniformLocation(mainProgram, 'uTime'),
    },
    pickLocations: {
      aPosition: gl.getAttribLocation(pickProgram, 'aPosition'),
      uMvp: gl.getUniformLocation(pickProgram, 'uMvp'),
      uOffset: gl.getUniformLocation(pickProgram, 'uOffset'),
      uPickColor: gl.getUniformLocation(pickProgram, 'uPickColor'),
    },
  };
}

function setupPbrPreviewRenderer() {
  const gl = ui.pbrPreviewCanvas.getContext('webgl', {
    antialias: true,
    preserveDrawingBuffer: true,
  });
  if (!gl) {
    ui.pbrPreviewStatus.textContent = 'WebGL unavailable';
    return;
  }
  const uintExtension = gl.getExtension('OES_element_index_uint');
  if (!uintExtension) {
    ui.pbrPreviewStatus.textContent = 'Uint32 indices unavailable';
    return;
  }
  const program = createProgram(gl, pbrPreviewVertexShader, pbrPreviewFragmentShader);
  state.pbrPreview.renderer = {
    gl,
    program,
    buffersReady: false,
    locations: {
      aPosition: gl.getAttribLocation(program, 'aPosition'),
      aNormal: gl.getAttribLocation(program, 'aNormal'),
      aTexCoord: gl.getAttribLocation(program, 'aTexCoord'),
      uMvp: gl.getUniformLocation(program, 'uMvp'),
      uOffset: gl.getUniformLocation(program, 'uOffset'),
      uColor: gl.getUniformLocation(program, 'uColor'),
      uUseTexture: gl.getUniformLocation(program, 'uUseTexture'),
      uTexture: gl.getUniformLocation(program, 'uTexture'),
    },
  };
}

async function uploadPbrPreviewParts(parts) {
  const renderer = state.pbrPreview.renderer;
  if (!renderer) return;
  const { gl } = renderer;
  for (const part of parts) {
    part.buffers = {
      position: uploadArrayBuffer(gl, part.positions),
      normal: uploadArrayBuffer(gl, part.normals),
      texcoord: uploadArrayBuffer(gl, part.texcoords),
      index: uploadElementArrayBuffer(gl, part.indices),
    };
    if (part.textureUrl) {
      part.texture = await loadPbrTexture(gl, part.textureUrl);
    }
  }
  renderer.buffersReady = true;
}

function uploadElementArrayBuffer(gl, data) {
  const buffer = gl.createBuffer();
  gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, buffer);
  gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, data, gl.STATIC_DRAW);
  return buffer;
}

async function loadPbrTexture(gl, url) {
  try {
    const response = await fetch(url, { cache: 'no-store' });
    if (!response.ok) throw new Error(`Texture request failed: ${response.status}`);
    const blob = await response.blob();
    const image = await createImageBitmap(blob);
    const texture = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, texture);
    gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, true);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, image);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    return texture;
  } catch (error) {
    console.warn('Texture load failed', url, error);
    return null;
  }
}

function uploadMesh(mesh) {
  if (!state.renderer) return;
  const { gl, buffers } = state.renderer;
  buffers.position = uploadArrayBuffer(gl, mesh.positions);
  buffers.normal = uploadArrayBuffer(gl, mesh.normals);
  buffers.color = uploadArrayBuffer(gl, mesh.colors);
}

function uploadArrayBuffer(gl, data) {
  const buffer = gl.createBuffer();
  gl.bindBuffer(gl.ARRAY_BUFFER, buffer);
  gl.bufferData(gl.ARRAY_BUFFER, data, gl.STATIC_DRAW);
  return buffer;
}

function createProgram(gl, vertexSource, fragmentSource) {
  const vertexShader = compileShader(gl, gl.VERTEX_SHADER, vertexSource);
  const fragmentShader = compileShader(gl, gl.FRAGMENT_SHADER, fragmentSource);
  const program = gl.createProgram();
  gl.attachShader(program, vertexShader);
  gl.attachShader(program, fragmentShader);
  gl.linkProgram(program);
  if (!gl.getProgramParameter(program, gl.LINK_STATUS)) {
    throw new Error(gl.getProgramInfoLog(program) || 'WebGL program link failed');
  }
  return program;
}

function compileShader(gl, type, source) {
  const shader = gl.createShader(type);
  gl.shaderSource(shader, source);
  gl.compileShader(shader);
  if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
    throw new Error(gl.getShaderInfoLog(shader) || 'WebGL shader compile failed');
  }
  return shader;
}

function renderScene() {
  if (!state.renderer || !state.mesh) return;
  const { gl, mainProgram, mainLocations, buffers } = state.renderer;
  resizeCanvasToDisplaySize(ui.plantCanvas);
  const width = ui.plantCanvas.width;
  const height = ui.plantCanvas.height;
  gl.viewport(0, 0, width, height);
  gl.clearColor(0.035, 0.047, 0.062, 1);
  gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
  gl.enable(gl.DEPTH_TEST);
  gl.depthFunc(gl.LEQUAL);
  gl.disable(gl.BLEND);
  gl.useProgram(mainProgram);
  const mvp = cameraMatrix(width / Math.max(height, 1));
  gl.uniformMatrix4fv(mainLocations.uMvp, false, mvp);
  gl.uniform1f(mainLocations.uTime, performance.now() * 0.001);
  bindMainAttributes(gl, mainLocations, buffers);
  gl.uniform1f(mainLocations.uAlpha, 1);
  for (const part of visibleParts()) {
    setPartDrawUniforms(gl, mainLocations, part, 1);
    gl.drawArrays(gl.TRIANGLES, part.start, part.count);
  }
  if (state.selectedPartIds.size) {
    gl.enable(gl.BLEND);
    gl.blendFunc(gl.SRC_ALPHA, gl.ONE);
    gl.depthMask(false);
    gl.enable(gl.POLYGON_OFFSET_FILL);
    gl.polygonOffset(-1, -1);
    gl.uniform1i(mainLocations.uOverride, 0);
    gl.uniform1i(mainLocations.uSelectionEffect, 1);
    gl.uniform1f(mainLocations.uInflate, 0.028);
    gl.uniform1f(mainLocations.uAlpha, 0.88);
    for (const part of visibleParts()) {
      if (state.selectedPartIds.has(part.id)) {
        const offset = explodeOffsetForPart(part);
        gl.uniform3f(mainLocations.uOffset, offset[0], offset[1], offset[2]);
        gl.drawArrays(gl.TRIANGLES, part.start, part.count);
      }
    }
    gl.depthMask(true);
    gl.disable(gl.POLYGON_OFFSET_FILL);
  }
  const explodeLabel = state.explodeAmount > 0 ? ` | Exploded ${Math.round(state.explodeAmount * 100)}` : '';
  ui.viewportHud.textContent = `Yaw ${Math.round(radiansToDegrees(state.camera.yaw))} deg${explodeLabel}`;
}

function renderPbrPreviewScene() {
  const preview = state.pbrPreview;
  if (!preview.renderer) return;
  const { gl, program, locations } = preview.renderer;
  resizeCanvasToDisplaySize(ui.pbrPreviewCanvas);
  const width = ui.pbrPreviewCanvas.width;
  const height = ui.pbrPreviewCanvas.height;
  gl.viewport(0, 0, width, height);
  gl.clearColor(0.035, 0.047, 0.062, 1);
  gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
  gl.enable(gl.DEPTH_TEST);
  gl.depthFunc(gl.LEQUAL);
  gl.disable(gl.BLEND);
  if (!preview.parts.length || !preview.renderer.buffersReady) return;
  gl.useProgram(program);
  gl.uniformMatrix4fv(locations.uMvp, false, cameraMatrixFor(preview.camera, width / Math.max(height, 1)));
  gl.uniform1i(locations.uTexture, 0);
  let visibleCount = 0;
  const renderParts = pbrPreviewPartsForRender();
  for (const part of renderParts) {
    if (preview.hiddenGroups.has(part.id) || !part.buffers) continue;
    visibleCount += 1;
    bindPbrPreviewPart(gl, locations, part);
    const offset = pbrPreviewOffsetForPart(part);
    gl.uniform3f(locations.uOffset, offset[0], offset[1], offset[2]);
    const color = preview.mode === 'semantic' ? part.semanticColor : part.baseColor;
    gl.uniform3f(locations.uColor, color[0], color[1], color[2]);
    const useTexture = preview.mode === 'textured' && Boolean(part.texture);
    gl.uniform1i(locations.uUseTexture, useTexture ? 1 : 0);
    if (useTexture) {
      gl.activeTexture(gl.TEXTURE0);
      gl.bindTexture(gl.TEXTURE_2D, part.texture);
    }
    gl.drawElements(gl.TRIANGLES, part.indexCount, gl.UNSIGNED_INT, 0);
  }
  const explodeLabel = preview.explodeAmount > 0 ? ` | Exploded ${Math.round(preview.explodeAmount * 100)}` : '';
  const compareLabel = preview.compareMode === 'original'
    ? 'A original'
    : preview.compareMode === 'variant'
      ? 'B variant'
      : 'mixed';
  ui.pbrPreviewHud.textContent = `${visibleCount}/${preview.parts.length} parts | ${preview.mode} | ${compareLabel}${explodeLabel}`;
}

function bindPbrPreviewPart(gl, locations, part) {
  gl.bindBuffer(gl.ARRAY_BUFFER, part.buffers.position);
  gl.enableVertexAttribArray(locations.aPosition);
  gl.vertexAttribPointer(locations.aPosition, 3, gl.FLOAT, false, 0, 0);
  gl.bindBuffer(gl.ARRAY_BUFFER, part.buffers.normal);
  gl.enableVertexAttribArray(locations.aNormal);
  gl.vertexAttribPointer(locations.aNormal, 3, gl.FLOAT, false, 0, 0);
  gl.bindBuffer(gl.ARRAY_BUFFER, part.buffers.texcoord);
  gl.enableVertexAttribArray(locations.aTexCoord);
  gl.vertexAttribPointer(locations.aTexCoord, 2, gl.FLOAT, false, 0, 0);
  gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, part.buffers.index);
}

function pbrPreviewOffsetForPart(part) {
  const t = state.pbrPreview.explodeAmount;
  if (t <= 0) return [0, 0, 0];
  const center = part.normalizedCenter || [0, 0, 0];
  let dirX = center[0];
  let dirZ = center[2];
  const length = Math.hypot(dirX, dirZ);
  if (length < 0.0001) {
    const fallback = fallbackDirectionForGroup(part.id);
    dirX = fallback[0];
    dirZ = fallback[1];
  } else {
    dirX /= length;
    dirZ /= length;
  }
  if (part.id === 'Core') return [0, 0.18 * t, 0.12 * t];
  if (part.id === 'PrimarySilhouette') return [dirX * 0.5 * t, 0.18 * t, dirZ * 0.5 * t];
  if (part.id === 'OrbitSet') return [dirX * 0.76 * t, 0.04 * t, dirZ * 0.76 * t];
  if (part.id === 'BodyShell') return [dirX * 0.14 * t, -0.52 * t, dirZ * 0.14 * t];
  return [dirX * 0.24 * t, 0, dirZ * 0.24 * t];
}

function setPartDrawUniforms(gl, locations, part, alpha) {
  const offset = explodeOffsetForPart(part);
  gl.uniform3f(locations.uOffset, offset[0], offset[1], offset[2]);
  gl.uniform1f(locations.uInflate, 0);
  gl.uniform1i(locations.uSelectionEffect, 0);
  gl.uniform1f(locations.uAlpha, alpha);
  if (state.colorMode === 'semantic') {
    const [r, g, b] = colorRgbForPart(part);
    gl.uniform1i(locations.uOverride, 1);
    gl.uniform3f(locations.uOverrideColor, r, g, b);
  } else {
    gl.uniform1i(locations.uOverride, 0);
  }
}

function explodeOffsetForPart(part) {
  const t = state.explodeAmount;
  if (t <= 0) return [0, 0, 0];
  const groupId = state.assignments.get(part.id);
  const center = part.normalizedCenter || [0, 0, 0];
  let dirX = center[0];
  let dirZ = center[2];
  const length = Math.hypot(dirX, dirZ);
  if (length < 0.0001) {
    const fallback = fallbackDirectionForGroup(groupId);
    dirX = fallback[0];
    dirZ = fallback[1];
  } else {
    dirX /= length;
    dirZ /= length;
  }
  if (groupId === 'Core') return [0, 0.16 * t, 0.12 * t];
  if (groupId === 'PrimarySilhouette') return [dirX * 0.42 * t, 0.18 * t, dirZ * 0.42 * t];
  if (groupId === 'OrbitSet') return [dirX * 0.68 * t, 0.04 * t, dirZ * 0.68 * t];
  if (groupId === 'BodyShell') return [dirX * 0.12 * t, -0.46 * t, dirZ * 0.12 * t];
  return [dirX * 0.22 * t, -0.06 * t, dirZ * 0.22 * t];
}

function fallbackDirectionForGroup(groupId) {
  if (groupId === 'OrbitSet') return [1, 0.25];
  if (groupId === 'PrimarySilhouette') return [-0.65, 0.76];
  if (groupId === 'BodyShell') return [0, -1];
  return [0, 1];
}

function bindMainAttributes(gl, locations, buffers) {
  gl.bindBuffer(gl.ARRAY_BUFFER, buffers.position);
  gl.enableVertexAttribArray(locations.aPosition);
  gl.vertexAttribPointer(locations.aPosition, 3, gl.FLOAT, false, 0, 0);
  gl.bindBuffer(gl.ARRAY_BUFFER, buffers.normal);
  gl.enableVertexAttribArray(locations.aNormal);
  gl.vertexAttribPointer(locations.aNormal, 3, gl.FLOAT, false, 0, 0);
  gl.bindBuffer(gl.ARRAY_BUFFER, buffers.color);
  gl.enableVertexAttribArray(locations.aColor);
  gl.vertexAttribPointer(locations.aColor, 3, gl.FLOAT, false, 0, 0);
}

function bindPickAttributes(gl, locations, buffers) {
  gl.bindBuffer(gl.ARRAY_BUFFER, buffers.position);
  gl.enableVertexAttribArray(locations.aPosition);
  gl.vertexAttribPointer(locations.aPosition, 3, gl.FLOAT, false, 0, 0);
}

function visibleParts() {
  if (state.soloPartIds.size) {
    return state.parts.filter((part) => state.soloPartIds.has(part.id) && !state.hiddenPartIds.has(part.id));
  }
  return state.parts.filter((part) => !state.hiddenPartIds.has(part.id));
}

function bindCanvasEvents() {
  ui.plantCanvas.addEventListener('pointerdown', (event) => {
    state.camera.dragging = true;
    state.camera.moved = false;
    state.camera.lastX = event.clientX;
    state.camera.lastY = event.clientY;
    ui.plantCanvas.setPointerCapture(event.pointerId);
    ui.plantCanvas.classList.add('dragging');
  });
  ui.plantCanvas.addEventListener('pointermove', (event) => {
    if (!state.camera.dragging) return;
    const dx = event.clientX - state.camera.lastX;
    const dy = event.clientY - state.camera.lastY;
    if (Math.abs(dx) + Math.abs(dy) > 2) state.camera.moved = true;
    state.camera.yaw += dx * 0.008;
    state.camera.pitch = clamp(state.camera.pitch + dy * 0.006, -1.25, 1.25);
    state.camera.lastX = event.clientX;
    state.camera.lastY = event.clientY;
    renderScene();
  });
  ui.plantCanvas.addEventListener('pointerup', (event) => {
    ui.plantCanvas.releasePointerCapture(event.pointerId);
    ui.plantCanvas.classList.remove('dragging');
    const wasDrag = state.camera.moved;
    state.camera.dragging = false;
    if (!wasDrag) {
      const part = pickPart(event.clientX, event.clientY);
      if (part) togglePartSelection(part.id, event.ctrlKey || event.metaKey || event.shiftKey);
    }
  });
  ui.plantCanvas.addEventListener('pointercancel', () => {
    state.camera.dragging = false;
    ui.plantCanvas.classList.remove('dragging');
  });
  ui.plantCanvas.addEventListener('wheel', (event) => {
    event.preventDefault();
    state.camera.zoom = clamp(state.camera.zoom + event.deltaY * 0.002, 1.55, 7.2);
    renderScene();
  }, { passive: false });
}

function bindPbrPreviewCanvasEvents() {
  ui.pbrPreviewCanvas.addEventListener('pointerdown', (event) => {
    const camera = state.pbrPreview.camera;
    camera.dragging = true;
    camera.moved = false;
    camera.lastX = event.clientX;
    camera.lastY = event.clientY;
    ui.pbrPreviewCanvas.setPointerCapture(event.pointerId);
    ui.pbrPreviewCanvas.classList.add('dragging');
  });
  ui.pbrPreviewCanvas.addEventListener('pointermove', (event) => {
    const camera = state.pbrPreview.camera;
    if (!camera.dragging) return;
    const dx = event.clientX - camera.lastX;
    const dy = event.clientY - camera.lastY;
    if (Math.abs(dx) + Math.abs(dy) > 2) camera.moved = true;
    camera.yaw += dx * 0.008;
    camera.pitch = clamp(camera.pitch + dy * 0.006, -1.25, 1.25);
    camera.lastX = event.clientX;
    camera.lastY = event.clientY;
    renderPbrPreviewScene();
  });
  ui.pbrPreviewCanvas.addEventListener('pointerup', (event) => {
    const camera = state.pbrPreview.camera;
    ui.pbrPreviewCanvas.releasePointerCapture(event.pointerId);
    ui.pbrPreviewCanvas.classList.remove('dragging');
    camera.dragging = false;
  });
  ui.pbrPreviewCanvas.addEventListener('pointercancel', () => {
    state.pbrPreview.camera.dragging = false;
    ui.pbrPreviewCanvas.classList.remove('dragging');
  });
  ui.pbrPreviewCanvas.addEventListener('wheel', (event) => {
    event.preventDefault();
    const camera = state.pbrPreview.camera;
    camera.zoom = clamp(camera.zoom + event.deltaY * 0.002, 1.55, 7.2);
    renderPbrPreviewScene();
  }, { passive: false });
}

function pickPart(clientX, clientY) {
  if (!state.renderer || !state.mesh) return null;
  const { gl, pickProgram, pickLocations, buffers } = state.renderer;
  resizeCanvasToDisplaySize(ui.plantCanvas);
  const width = ui.plantCanvas.width;
  const height = ui.plantCanvas.height;
  const target = ensurePickTarget(width, height);
  gl.bindFramebuffer(gl.FRAMEBUFFER, target.framebuffer);
  gl.viewport(0, 0, width, height);
  gl.clearColor(0, 0, 0, 1);
  gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
  gl.enable(gl.DEPTH_TEST);
  gl.useProgram(pickProgram);
  gl.uniformMatrix4fv(pickLocations.uMvp, false, cameraMatrix(width / Math.max(height, 1)));
  bindPickAttributes(gl, pickLocations, buffers);
  for (const part of visibleParts()) {
    const index = state.parts.indexOf(part) + 1;
    const color = encodePickColor(index);
    const offset = explodeOffsetForPart(part);
    gl.uniform3f(pickLocations.uOffset, offset[0], offset[1], offset[2]);
    gl.uniform3f(pickLocations.uPickColor, color[0], color[1], color[2]);
    gl.drawArrays(gl.TRIANGLES, part.start, part.count);
  }
  const rect = ui.plantCanvas.getBoundingClientRect();
  const pixelX = Math.floor((clientX - rect.left) * width / rect.width);
  const pixelY = Math.floor(height - ((clientY - rect.top) * height / rect.height));
  const pixel = new Uint8Array(4);
  gl.readPixels(pixelX, pixelY, 1, 1, gl.RGBA, gl.UNSIGNED_BYTE, pixel);
  gl.bindFramebuffer(gl.FRAMEBUFFER, null);
  const partIndex = decodePickColor(pixel) - 1;
  return state.parts[partIndex] || null;
}

function ensurePickTarget(width, height) {
  const { gl } = state.renderer;
  const existing = state.renderer.pickTarget;
  if (existing && existing.width === width && existing.height === height) return existing;
  if (existing) {
    gl.deleteFramebuffer(existing.framebuffer);
    gl.deleteTexture(existing.texture);
    gl.deleteRenderbuffer(existing.depth);
  }
  const framebuffer = gl.createFramebuffer();
  gl.bindFramebuffer(gl.FRAMEBUFFER, framebuffer);
  const texture = gl.createTexture();
  gl.bindTexture(gl.TEXTURE_2D, texture);
  gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, width, height, 0, gl.RGBA, gl.UNSIGNED_BYTE, null);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
  const depth = gl.createRenderbuffer();
  gl.bindRenderbuffer(gl.RENDERBUFFER, depth);
  gl.renderbufferStorage(gl.RENDERBUFFER, gl.DEPTH_COMPONENT16, width, height);
  gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, texture, 0);
  gl.framebufferRenderbuffer(gl.FRAMEBUFFER, gl.DEPTH_ATTACHMENT, gl.RENDERBUFFER, depth);
  gl.bindFramebuffer(gl.FRAMEBUFFER, null);
  state.renderer.pickTarget = { framebuffer, texture, depth, width, height };
  return state.renderer.pickTarget;
}

function encodePickColor(index) {
  return [
    ((index >> 16) & 255) / 255,
    ((index >> 8) & 255) / 255,
    (index & 255) / 255,
  ];
}

function decodePickColor(pixel) {
  return (pixel[0] << 16) | (pixel[1] << 8) | pixel[2];
}

function resetCamera() {
  state.camera.yaw = 0.64;
  state.camera.pitch = -0.24;
  state.camera.zoom = 3.1;
}

function cameraMatrix(aspect) {
  return cameraMatrixFor(state.camera, aspect);
}

function resetPbrPreviewCamera() {
  state.pbrPreview.camera.yaw = 0.64;
  state.pbrPreview.camera.pitch = -0.18;
  state.pbrPreview.camera.zoom = 3.1;
}

function cameraMatrixFor(camera, aspect) {
  const projection = mat4Perspective(degreesToRadians(42), aspect, 0.05, 50);
  const view = mat4LookAt([0, 0, camera.zoom], [0, 0, 0], [0, 1, 0]);
  const rotation = mat4Multiply(mat4RotateX(camera.pitch), mat4RotateY(camera.yaw));
  return mat4Multiply(projection, mat4Multiply(view, rotation));
}

function mat4Perspective(fovy, aspect, near, far) {
  const f = 1 / Math.tan(fovy / 2);
  const nf = 1 / (near - far);
  return new Float32Array([
    f / aspect, 0, 0, 0,
    0, f, 0, 0,
    0, 0, (far + near) * nf, -1,
    0, 0, (2 * far * near) * nf, 0,
  ]);
}

function mat4LookAt(eye, center, up) {
  const z = normalizeVec3([eye[0] - center[0], eye[1] - center[1], eye[2] - center[2]]);
  const x = normalizeVec3(crossVec3(up, z));
  const y = crossVec3(z, x);
  return new Float32Array([
    x[0], y[0], z[0], 0,
    x[1], y[1], z[1], 0,
    x[2], y[2], z[2], 0,
    -dotVec3(x, eye), -dotVec3(y, eye), -dotVec3(z, eye), 1,
  ]);
}

function mat4RotateX(angle) {
  const c = Math.cos(angle);
  const s = Math.sin(angle);
  return new Float32Array([
    1, 0, 0, 0,
    0, c, s, 0,
    0, -s, c, 0,
    0, 0, 0, 1,
  ]);
}

function mat4RotateY(angle) {
  const c = Math.cos(angle);
  const s = Math.sin(angle);
  return new Float32Array([
    c, 0, -s, 0,
    0, 1, 0, 0,
    s, 0, c, 0,
    0, 0, 0, 1,
  ]);
}

function mat4Multiply(a, b) {
  const out = new Float32Array(16);
  for (let column = 0; column < 4; column += 1) {
    for (let row = 0; row < 4; row += 1) {
      out[column * 4 + row] =
        a[0 * 4 + row] * b[column * 4 + 0] +
        a[1 * 4 + row] * b[column * 4 + 1] +
        a[2 * 4 + row] * b[column * 4 + 2] +
        a[3 * 4 + row] * b[column * 4 + 3];
    }
  }
  return out;
}

function normalizeVec3(vector) {
  const length = Math.hypot(vector[0], vector[1], vector[2]) || 1;
  return [vector[0] / length, vector[1] / length, vector[2] / length];
}

function crossVec3(a, b) {
  return [
    a[1] * b[2] - a[2] * b[1],
    a[2] * b[0] - a[0] * b[2],
    a[0] * b[1] - a[1] * b[0],
  ];
}

function dotVec3(a, b) {
  return a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
}

function resizeCanvasToDisplaySize(canvas) {
  const ratio = Math.min(window.devicePixelRatio || 1, 2);
  const rect = canvas.getBoundingClientRect();
  const width = Math.max(1, Math.floor(rect.width * ratio));
  const height = Math.max(1, Math.floor(rect.height * ratio));
  if (canvas.width !== width || canvas.height !== height) {
    canvas.width = width;
    canvas.height = height;
  }
}

function setLoading(isLoading, label = '') {
  ui.loadingVeil.classList.toggle('hidden', !isLoading);
  if (label) ui.loadingVeil.textContent = label;
}

function setPbrPreviewLoading(isLoading, label = '') {
  ui.pbrPreviewVeil.classList.toggle('hidden', !isLoading);
  if (label) ui.pbrPreviewVeil.textContent = label;
}

function formatNumber(value) {
  return Number(value || 0).toLocaleString('en-US');
}

function compactNumber(value) {
  const number = Number(value || 0);
  if (number >= 1000000) return `${(number / 1000000).toFixed(2)}M`;
  if (number >= 1000) return `${(number / 1000).toFixed(1)}K`;
  return String(number);
}

function formatBytes(bytes) {
  const value = Number(bytes || 0);
  if (value >= 1024 * 1024) return `${(value / 1024 / 1024).toFixed(1)} MB`;
  if (value >= 1024) return `${(value / 1024).toFixed(1)} KB`;
  return `${value} B`;
}

function roundNumber(value, digits) {
  const scale = 10 ** digits;
  return Math.round(value * scale) / scale;
}

function rgbToHex(color) {
  const [r, g, b] = color.map((value) => clamp(Math.round(value * 255), 0, 255));
  return `#${hexByte(r)}${hexByte(g)}${hexByte(b)}`;
}

function hexToRgb01(hex) {
  const clean = String(hex || unassignedColor).replace('#', '');
  const value = clean.length === 3
    ? clean.split('').map((part) => part + part).join('')
    : clean.padEnd(6, '0').slice(0, 6);
  return [
    parseInt(value.slice(0, 2), 16) / 255,
    parseInt(value.slice(2, 4), 16) / 255,
    parseInt(value.slice(4, 6), 16) / 255,
  ];
}

function semanticColorForGroup(groupId) {
  return hexToRgb01(groupById.get(groupId)?.color || unassignedColor);
}

function hexByte(value) {
  return value.toString(16).padStart(2, '0');
}

function escapeHtml(value) {
  return String(value)
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#39;');
}

function safeIdFromName(value) {
  const safe = String(value || 'local')
    .replace(/\.[a-z0-9]+$/i, '')
    .replace(/[^a-zA-Z0-9._-]+/g, '_')
    .replace(/^_+|_+$/g, '')
    .slice(0, 72);
  return safe || 'local';
}

function clamp(value, min, max) {
  return Math.min(max, Math.max(min, value));
}

function degreesToRadians(value) {
  return value * Math.PI / 180;
}

function radiansToDegrees(value) {
  return value * 180 / Math.PI;
}

const mainVertexShader = `
  attribute vec3 aPosition;
  attribute vec3 aNormal;
  attribute vec3 aColor;
  uniform mat4 uMvp;
  uniform vec3 uOffset;
  uniform float uInflate;
  uniform bool uOverride;
  uniform vec3 uOverrideColor;
  varying vec3 vColor;
  varying float vLight;
  varying vec3 vNormal;
  varying vec3 vModelPosition;
  void main() {
    vec3 normal = normalize(aNormal);
    vec3 displaced = aPosition + uOffset + normal * uInflate;
    gl_Position = uMvp * vec4(displaced, 1.0);
    float key = max(dot(normal, normalize(vec3(-0.36, 0.82, 0.44))), 0.0);
    float rim = max(dot(normal, normalize(vec3(0.68, 0.24, -0.62))), 0.0);
    vLight = 0.40 + key * 0.64 + rim * 0.24;
    vColor = uOverride ? uOverrideColor : aColor;
    vNormal = normal;
    vModelPosition = displaced;
  }
`;

const mainFragmentShader = `
  precision mediump float;
  uniform float uAlpha;
  uniform bool uSelectionEffect;
  uniform float uTime;
  varying vec3 vColor;
  varying float vLight;
  varying vec3 vNormal;
  varying vec3 vModelPosition;
  void main() {
    if (uSelectionEffect) {
      vec3 normal = normalize(vNormal);
      float rim = pow(1.0 - abs(normal.z), 1.75);
      float scan = 0.5 + 0.5 * sin(vModelPosition.y * 30.0 + uTime * 3.8);
      float pulse = 0.5 + 0.5 * sin(uTime * 4.1);
      vec3 glowA = vec3(0.18, 0.95, 1.0);
      vec3 glowB = vec3(1.0, 0.78, 0.18);
      vec3 glow = mix(glowA, glowB, clamp(scan * 0.42 + pulse * 0.22, 0.0, 1.0));
      float alpha = (0.22 + rim * 0.34 + scan * 0.12) * uAlpha;
      gl_FragColor = vec4(glow, alpha);
      return;
    }
    gl_FragColor = vec4(vColor * vLight, uAlpha);
  }
`;

const pickVertexShader = `
  attribute vec3 aPosition;
  uniform mat4 uMvp;
  uniform vec3 uOffset;
  void main() {
    gl_Position = uMvp * vec4(aPosition + uOffset, 1.0);
  }
`;

const pickFragmentShader = `
  precision mediump float;
  uniform vec3 uPickColor;
  void main() {
    gl_FragColor = vec4(uPickColor, 1.0);
  }
`;

const pbrPreviewVertexShader = `
  attribute vec3 aPosition;
  attribute vec3 aNormal;
  attribute vec2 aTexCoord;
  uniform mat4 uMvp;
  uniform vec3 uOffset;
  varying vec3 vNormal;
  varying vec2 vTexCoord;
  void main() {
    vNormal = normalize(aNormal);
    vTexCoord = aTexCoord;
    gl_Position = uMvp * vec4(aPosition + uOffset, 1.0);
  }
`;

const pbrPreviewFragmentShader = `
  precision mediump float;
  uniform vec3 uColor;
  uniform bool uUseTexture;
  uniform sampler2D uTexture;
  varying vec3 vNormal;
  varying vec2 vTexCoord;
  void main() {
    vec3 normal = normalize(vNormal);
    float key = max(dot(normal, normalize(vec3(-0.36, 0.82, 0.44))), 0.0);
    float rim = max(dot(normal, normalize(vec3(0.68, 0.24, -0.62))), 0.0);
    float light = 0.42 + key * 0.62 + rim * 0.22;
    vec3 color = uColor;
    if (uUseTexture) {
      color *= texture2D(uTexture, vTexCoord).rgb;
    }
    gl_FragColor = vec4(color * light, 1.0);
  }
`;

init();
