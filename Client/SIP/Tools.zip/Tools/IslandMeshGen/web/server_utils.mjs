import { existsSync } from 'node:fs';
import { basename, extname } from 'node:path';
import { dirname, isAbsolute, join, relative, resolve, sep } from 'node:path';
import { spawnSync } from 'node:child_process';

export const SUPPORTED_BIOMES = ['fire', 'ice', 'forest'];

export const BIOME_META = {
  fire: {
    label: 'Fire Volcano Island',
    layoutFile: 'fire_volcano_demo.json',
    meshFile: 'SM_ProcIsland_Fire_VolcanoLayout_200m.obj',
    manifestFile: 'SM_ProcIsland_Fire_VolcanoLayout_200m.manifest.json',
    fieldFile: 'SM_ProcIsland_Fire_VolcanoLayout_200m.field.json',
    qualityReportFile: 'SM_ProcIsland_Fire_VolcanoLayout_200m.quality_report.json',
  },
  ice: {
    label: 'Ice Glacier Island',
    layoutFile: 'ice_glacier_demo.json',
    meshFile: 'SM_ProcIsland_Ice_Glacier_200m.obj',
    manifestFile: 'SM_ProcIsland_Ice_Glacier_200m.manifest.json',
    fieldFile: 'SM_ProcIsland_Ice_Glacier_200m.field.json',
    qualityReportFile: 'SM_ProcIsland_Ice_Glacier_200m.quality_report.json',
  },
  forest: {
    label: 'Forest Canopy Island',
    layoutFile: 'forest_canopy_demo.json',
    meshFile: 'SM_ProcIsland_Forest_Layout_200m.obj',
    manifestFile: 'SM_ProcIsland_Forest_Layout_200m.manifest.json',
    fieldFile: 'SM_ProcIsland_Forest_Layout_200m.field.json',
    qualityReportFile: 'SM_ProcIsland_Forest_Layout_200m.quality_report.json',
  },
};

export const BAKE_QUALITY_PROFILES = {
  draft: {
    id: 'draft',
    label: 'Draft',
    description: 'Fast whitebox topology for interactive checks.',
    segments: 96,
    rings: 14,
  },
  preview: {
    id: 'preview',
    label: 'Preview',
    description: 'Moderate terrain sampling for visual review.',
    segments: 128,
    rings: 20,
  },
  production: {
    id: 'production',
    label: 'Production',
    description: 'Denser semantic terrain bake for Unreal import.',
    segments: 192,
    rings: 32,
  },
  hero: {
    id: 'hero',
    label: 'Hero',
    description: 'High-density output reserved for close inspection and future Nanite tests.',
    segments: 384,
    rings: 56,
  },
};

export function normalizeBiome(rawBiome) {
  const biome = String(rawBiome || '').toLowerCase();
  if (!SUPPORTED_BIOMES.includes(biome)) {
    throw new Error(`Unsupported biome "${rawBiome}". Supported biomes: ${SUPPORTED_BIOMES.join(', ')}`);
  }
  return biome;
}

export function normalizeBakeQuality(rawQuality) {
  const quality = String(rawQuality || 'production').toLowerCase();
  return BAKE_QUALITY_PROFILES[quality] ? quality : 'production';
}

export function exportArgsForQuality(rawQuality) {
  const profile = BAKE_QUALITY_PROFILES[normalizeBakeQuality(rawQuality)];
  return {
    quality: profile.id,
    segments: profile.segments,
    rings: profile.rings,
  };
}

export function normalizePreviewBakeQuality(rawQuality = 'draft') {
  const quality = String(rawQuality || 'draft').toLowerCase();
  return quality === 'draft' ? 'draft' : 'preview';
}

export function bakeQualityOptions() {
  return Object.values(BAKE_QUALITY_PROFILES).map((profile) => ({ ...profile }));
}

export function pathsForBiome(toolRoot, rawBiome) {
  const biome = normalizeBiome(rawBiome);
  const meta = BIOME_META[biome];
  return {
    biome,
    meta,
    layoutPath: join(toolRoot, 'layouts', meta.layoutFile),
    meshPath: join(toolRoot, 'output', meta.meshFile),
    manifestPath: join(toolRoot, 'output', meta.manifestFile),
    fieldPath: join(toolRoot, 'output', meta.fieldFile),
    qualityReportPath: join(toolRoot, 'output', meta.qualityReportFile),
  };
}

export function previewPathsForBiome(toolRoot, rawBiome) {
  const biome = normalizeBiome(rawBiome);
  const previewDir = join(toolRoot, 'output', '.preview');
  return {
    biome,
    previewDir,
    layoutPath: join(previewDir, `${biome}_preview_layout.json`),
    meshPath: join(previewDir, `${biome}_preview.obj`),
    manifestPath: join(previewDir, `${biome}_preview.manifest.json`),
    fieldPath: join(previewDir, `${biome}_preview.field.json`),
    qualityReportPath: join(previewDir, `${biome}_preview.quality_report.json`),
  };
}

export function inspectPathsForBiome(toolRoot, rawBiome) {
  const biome = normalizeBiome(rawBiome);
  const inspectDir = join(toolRoot, 'output', '.inspect');
  return {
    biome,
    inspectDir,
    layoutPath: join(inspectDir, `${biome}_inspect_layout.json`),
    meshPath: join(inspectDir, `${biome}_inspect.obj`),
    manifestPath: join(inspectDir, `${biome}_inspect.manifest.json`),
    fieldPath: join(inspectDir, `${biome}_inspect.field.json`),
    qualityReportPath: join(inspectDir, `${biome}_inspect.quality_report.json`),
  };
}

export function previewExportArgs(rawQuality = 'draft') {
  return exportArgsForQuality(normalizePreviewBakeQuality(rawQuality));
}

const CONTENT_TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.mjs': 'application/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.gltf': 'model/gltf+json; charset=utf-8',
  '.glb': 'model/gltf-binary',
  '.bin': 'application/octet-stream',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.png': 'image/png',
  '.webp': 'image/webp',
};

export function contentTypeForPath(filePath) {
  return CONTENT_TYPES[extname(filePath)] || 'application/octet-stream';
}

export function staticHeadersForPath(filePath) {
  return {
    'Content-Type': contentTypeForPath(filePath),
    'Cache-Control': 'no-store',
  };
}

const PLANT_EXPORT_PREVIEW_GROUPS = ['Core', 'PrimarySilhouette', 'OrbitSet', 'BodyShell'];
export const DEFAULT_PLANT_SAMPLE_ID = 'flamebound-scepter-auto-split';

export function plantExportPreviewGroups() {
  return [...PLANT_EXPORT_PREVIEW_GROUPS];
}

export function plantExportWorkspacePriority(workspaceName) {
  const name = String(workspaceName || '');
  if (/local-upload/i.test(name)) return 30;
  if (/user[_-]regroup/i.test(name)) return 25;
  if (/^(CrownLily|AetherVine)C\d+/i.test(name) || /_(CrownLily|AetherVine)C\d+/i.test(name)) return 20;
  if (/flamebound-scepter-auto-split/i.test(name)) return 0;
  return 10;
}

export function normalizePlantSampleId(rawSampleId) {
  return String(rawSampleId || DEFAULT_PLANT_SAMPLE_ID).trim() || DEFAULT_PLANT_SAMPLE_ID;
}

export function plantProfileForSampleId(rawSampleId) {
  const sampleId = normalizePlantSampleId(rawSampleId);
  if (/^AetherVineC\d+$/i.test(sampleId)) return 'AetherVine';
  return 'CrownLily';
}

export function isInboxPlantSampleId(rawSampleId) {
  return /^(CrownLily|AetherVine)C\d+$/i.test(normalizePlantSampleId(rawSampleId));
}

export function isLocalPlantUploadSampleId(rawSampleId) {
  return /^local-upload-[a-zA-Z0-9._-]+$/.test(normalizePlantSampleId(rawSampleId));
}

export function safePlantUploadId(rawInput) {
  const safe = String(rawInput || '')
    .replace(/[^a-zA-Z0-9._-]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 96);
  return safe || `local-upload-${Date.now().toString(36)}`;
}

export function safePlantUploadFileName(rawName, fallback = 'asset.glb') {
  const raw = String(rawName || fallback);
  if (raw !== basename(raw) || raw.includes('/') || raw.includes('\\')) {
    throw new Error(`Invalid local upload file name "${rawName}".`);
  }
  const safe = raw
    .replace(/[^a-zA-Z0-9 ._()-]+/g, '_')
    .replace(/^\.+/, '')
    .slice(0, 140);
  if (!safe) throw new Error(`Invalid local upload file name "${rawName}".`);
  return safe;
}

export function localPlantUploadRoot(toolRoot) {
  return resolve(toolRoot, 'output', 'plant_regroup', '_local_uploads');
}

export function resolveLocalPlantUploadSampleFiles(toolRoot, rawSampleId, uploadManifest = {}) {
  const sampleId = safePlantUploadId(normalizePlantSampleId(rawSampleId));
  if (!isLocalPlantUploadSampleId(sampleId)) {
    throw new Error(`Unsupported local plant upload sample "${rawSampleId}".`);
  }
  const root = localPlantUploadRoot(toolRoot);
  const sampleRoot = resolve(root, sampleId);
  const assets = uploadManifest.assets || {};
  const splitName = safePlantUploadFileName(assets['split-glb']?.fileName, 'split.glb');
  const pbrName = safePlantUploadFileName(assets['pbr-glb']?.fileName, 'pbr.glb');
  const splitPath = resolve(sampleRoot, splitName);
  const pbrPath = resolve(sampleRoot, pbrName);
  if (!pathIsInside(splitPath, sampleRoot) || !pathIsInside(pbrPath, sampleRoot)) {
    throw new Error(`Local plant upload "${sampleId}" escaped its upload workspace.`);
  }
  return {
    sampleId,
    label: uploadManifest.label || `${uploadManifest.plantProfile || 'Plant'} Local GLB Upload`,
    plantProfile: uploadManifest.plantProfile || plantProfileForSampleId(uploadManifest.plantProfile),
    assetRoot: plantPreviewProjectPath(toolRoot, sampleRoot),
    files: {
      'split-glb': splitPath,
      'pbr-glb': pbrPath,
    },
    mapping: {
      recommendedMode: 'PartSurfaceProjection',
      directFaceIndexAvailable: false,
      reason: 'Browser-selected local GLBs were uploaded into the tool output workspace so PBR export can access the same files on the server.',
    },
  };
}

export function resolveDefaultPlantSampleFiles(toolRoot) {
  const sampleRoot = resolve(toolRoot, 'Meshy_AI_Flamebound_Scepter_0705185936_texture_obj');
  const splitRoot = resolve(sampleRoot, 'Meshy_AI_Flamebound Scepter_1783275149_part-segmentation');
  const pbrObjRoot = resolve(sampleRoot, 'Meshy_AI_Flamebound_Scepter_0705185936_texture_obj');
  return {
    sampleId: DEFAULT_PLANT_SAMPLE_ID,
    label: 'Meshy Flamebound Scepter Auto Split',
    plantProfile: 'CrownLily',
    assetRoot: 'Tools/IslandMeshGen/Meshy_AI_Flamebound_Scepter_0705185936_texture_obj',
    files: {
      'split-obj': resolve(splitRoot, 'Meshy_AI_Flamebound Scepter_1783275149_part-segmentation.obj'),
      'split-mtl': resolve(splitRoot, 'Meshy_AI_Flamebound Scepter_1783275149_part-segmentation.mtl'),
      'split-glb': resolve(sampleRoot, 'Meshy_AI_Flamebound Scepter_1783275149_part-segmentation.glb'),
      'pbr-glb': resolve(sampleRoot, 'Meshy_AI_Flamebound_Scepter_0705185825_texture.glb'),
      'pbr-obj': resolve(pbrObjRoot, 'Meshy_AI_Flamebound_Scepter_0705185936_texture.obj'),
      'pbr-png': resolve(pbrObjRoot, 'Meshy_AI_Flamebound_Scepter_0705185936_texture.png'),
    },
    mapping: {
      recommendedMode: 'PartSurfaceProjection',
      directFaceIndexAvailable: false,
      reason: 'The split white OBJ/GLB and full PBR GLB are not the same topology, so regrouping should produce a semantic manifest first. PBR cutting should later project PBR face centers onto semantic split surfaces.',
    },
  };
}

export function resolveInboxPlantSampleFiles(toolRoot, rawSampleId, fileNames) {
  const sampleId = normalizePlantSampleId(rawSampleId);
  if (!isInboxPlantSampleId(sampleId)) {
    throw new Error(`Unsupported plant inbox sample "${rawSampleId}". Expected CrownLilyC# or AetherVineC#.`);
  }
  const names = [...fileNames].filter((name) => /\.glb$/i.test(name));
  const splitName = names.find((name) => /part-segmentation/i.test(name));
  const pbrName = names.find((name) => /texture/i.test(name) && !/part-segmentation/i.test(name));
  if (!splitName || !pbrName) {
    throw new Error(`Plant inbox sample "${sampleId}" needs one split GLB and PBR GLB.`);
  }
  const plantProfile = plantProfileForSampleId(sampleId);
  return {
    sampleId,
    label: `${plantProfile} ${sampleId.replace(/^[A-Za-z]+/, '')} Inbox GLB Pair`,
    plantProfile,
    assetRoot: `Tools/IslandMeshGen/mesh_inbox/${sampleId}`,
    files: {
      'split-glb': resolve(toolRoot, 'mesh_inbox', sampleId, splitName),
      'pbr-glb': resolve(toolRoot, 'mesh_inbox', sampleId, pbrName),
    },
    mapping: {
      recommendedMode: 'PartSurfaceProjection',
      directFaceIndexAvailable: false,
      reason: 'Inbox GLB pair is server-visible, so the web regrouping surface and PBR cutter can use the same selected Meshy sample.',
    },
  };
}

export function plantExportPreviewRoots(toolRoot) {
  return [
    resolve(toolRoot, 'output', 'plant_regroup'),
    resolve(toolRoot, 'mesh_inbox', '_analysis_runs'),
  ];
}

export function resolvePlantPreviewFilePath(toolRoot, rawPath) {
  const cleanPath = normalizePlantPreviewInputPath(toolRoot, rawPath);
  const resolvedPath = resolve(cleanPath);
  const insideRoot = plantExportPreviewRoots(toolRoot).some((root) => pathIsInside(resolvedPath, root));
  if (!insideRoot) {
    throw new Error(`Plant preview path is outside plant export preview roots: ${rawPath}`);
  }
  return resolvedPath;
}

export function plantPreviewProjectPath(toolRoot, filePath) {
  return relative(resolve(toolRoot), resolve(filePath)).replaceAll('\\', '/');
}

export function plantPreviewFileUrl(toolRoot, filePath) {
  const projectPath = plantPreviewProjectPath(toolRoot, filePath);
  return `/api/plant/export-preview/file?path=${encodeURIComponent(projectPath)}`;
}

function normalizePlantPreviewInputPath(toolRoot, rawPath) {
  const raw = String(rawPath || '').trim();
  if (!raw) throw new Error('Plant preview path is empty.');
  const normalizedRaw = raw.replaceAll('\\', '/');
  const marker = 'Tools/IslandMeshGen/';
  const markerIndex = normalizedRaw.indexOf(marker);
  if (markerIndex >= 0 && !isAbsolute(raw)) {
    return resolve(toolRoot, normalizedRaw.slice(markerIndex + marker.length));
  }
  if (isAbsolute(raw)) return raw;
  return resolve(toolRoot, normalizedRaw);
}

function pathIsInside(filePath, rootPath) {
  const resolvedFile = resolve(filePath).toLowerCase();
  const resolvedRoot = resolve(rootPath).toLowerCase();
  return resolvedFile === resolvedRoot || resolvedFile.startsWith(`${resolvedRoot}${sep}`);
}

function defaultCommandExists(command) {
  const result = process.platform === 'win32'
    ? spawnSync('where', [command], { stdio: 'ignore' })
    : spawnSync('sh', ['-lc', `command -v ${command}`], { stdio: 'ignore' });
  return result.status === 0;
}

function defaultBundledPythonPath() {
  if (!process.execPath) return '';
  const dependencyRoot = resolve(dirname(process.execPath), '..', '..');
  const executable = process.platform === 'win32' ? 'python.exe' : 'python';
  return join(dependencyRoot, 'python', executable);
}

export function resolvePythonCommand({
  env = process.env,
  commandExists = defaultCommandExists,
  fileExists = existsSync,
  bundledPythonPath = defaultBundledPythonPath(),
} = {}) {
  if (env.PYTHON) {
    return { command: env.PYTHON, args: [], label: 'PYTHON' };
  }

  if (commandExists('python')) {
    return { command: 'python', args: [], label: 'python' };
  }

  if (bundledPythonPath && fileExists(bundledPythonPath)) {
    return { command: bundledPythonPath, args: [], label: 'bundled python' };
  }

  if (commandExists('py')) {
    return { command: 'py', args: ['-3'], label: 'py -3' };
  }

  throw new Error('No Python executable found. Set PYTHON to a Python executable before using Generate.');
}
