export const MESHY_BASE_URL = 'https://api.meshy.ai/openapi/v1';
export const MESHY_ROUNDTRIP_OPERATIONS = ['retexture', 'remesh'];
export const MESHY_TEXT_STYLE_PROMPT_MAX_LENGTH = 800;

export function buildMeshyRoundtripCreateRequest({
  operation,
  modelDataUri,
  prompt,
  options = {},
}) {
  const normalizedOperation = normalizeRoundtripOperation(operation);
  if (!modelDataUri) throw new Error('Meshy roundtrip requires a model data URI.');
  const cleanPrompt = String(prompt || '').trim();
  if (!cleanPrompt) throw new Error('Meshy roundtrip requires a prompt.');

  if (normalizedOperation === 'retexture') {
    if (cleanPrompt.length > MESHY_TEXT_STYLE_PROMPT_MAX_LENGTH) {
      throw new Error(`Meshy retexture prompt is ${cleanPrompt.length} characters; maximum is ${MESHY_TEXT_STYLE_PROMPT_MAX_LENGTH}.`);
    }
    return {
      endpointPath: '/retexture',
      payload: {
        model_url: modelDataUri,
        text_style_prompt: cleanPrompt,
        ai_model: options.aiModel || 'meshy-6',
        enable_original_uv: Boolean(options.enableOriginalUv ?? false),
        enable_pbr: true,
        hd_texture: Boolean(options.hdTexture ?? false),
        remove_lighting: Boolean(options.removeLighting ?? true),
        target_formats: ['glb'],
        alpha_thumbnail: true,
      },
    };
  }

  return {
    endpointPath: '/remesh',
    payload: {
      model_url: modelDataUri,
      ai_model: options.aiModel || 'meshy-6',
      topology: options.topology || 'triangle',
      target_polycount: Number(options.targetPolycount || 60000),
      target_formats: ['glb'],
    },
  };
}

export function sanitizeMeshyRoundtripRequest(request, sourceBytes = 0, sourceSha256 = '') {
  return {
    ...request,
    payload: {
      ...request.payload,
      model_url: `<source GLB data URI; ${sourceBytes} bytes${sourceSha256 ? `; sha256 ${sourceSha256}` : ''}>`,
    },
  };
}

export function sanitizeMeshyRoundtripTask(task) {
  if (!task || typeof task !== 'object') return {};
  const textureSets = Array.isArray(task.texture_urls)
    ? task.texture_urls.map((set) => Object.keys(set || {}).sort())
    : [];
  return {
    id: task.id || null,
    type: task.type || null,
    status: task.status || null,
    progress: Number(task.progress || 0),
    created_at: task.created_at || null,
    started_at: task.started_at || null,
    finished_at: task.finished_at || null,
    expires_at: task.expires_at || null,
    task_error: task.task_error || null,
    consumed_credits: task.consumed_credits ?? task.consumedCredits ?? null,
    returned_model_formats: Object.keys(task.model_urls || {}).sort(),
    returned_texture_sets: textureSets,
    has_thumbnail: Boolean(task.thumbnail_url),
    has_alpha_thumbnail: Boolean(task.alpha_thumbnail_url),
  };
}

export function meshyResultGlbUrl(task) {
  if (typeof task?.model_urls?.glb === 'string' && task.model_urls.glb) return task.model_urls.glb;
  if (typeof task?.model_url === 'string' && /\.glb(?:[?#]|$)/i.test(task.model_url)) return task.model_url;
  return null;
}

export function normalizeRoundtripOperation(operation) {
  const normalized = String(operation || 'retexture').toLowerCase();
  if (!MESHY_ROUNDTRIP_OPERATIONS.includes(normalized)) {
    throw new Error(`Unsupported Meshy roundtrip operation "${operation}".`);
  }
  return normalized;
}
