import {
  bakeButtonLabel,
  biomeLiveOverlaySpec,
  biomeControlLabels,
  biomeControlRanges,
  defaultOrbitCamera,
  controlsForActiveGroup,
  dragOrbitCamera,
  faceHitAtPoint,
  fieldFaceSampleForOrder,
  fireLiveOverlaySpec,
  biomeMovementHighlightForFace,
  biomeMovementHighlightThreshold,
  footprintRadiusForMesh,
  inspectBakeSignature,
  layoutPointToTopDown,
  materialColorForBiome,
  maskColorForValue,
  maskValueForFaceOrder,
  meshDeltaColorForFace,
  meshDeltaForFace,
  meshAtTransitionFrame,
  meshWireAlphaForFaceCount,
  previewBakeSignature,
  previewQualityStatusForBakeQuality,
  previewQualityForBakeQuality,
  processHighlightSpecForControl,
  processLayerStack,
  processMovementHighlightForFace,
  processMovementHighlightStyle,
  processTraceColorForFace,
  processTraceForFace,
  processTracePulseAlpha,
  qualityMetricsForMesh,
  qualityAdvisorForFace,
  qualityNudgePlanForIssue,
  qualityNudgePlanSummaryForIssue,
  qualityNudgeResultForIssue,
  qualityRiskColorForFace,
  qualityRiskForFace,
  projectTopDownVertex,
  semanticBadgesForLayout,
  semanticLegendForLayout,
  stableTopDownFrameForMesh,
  wheelOrbitCamera,
  yawLabel,
} from './view_model.mjs?v=advisor-20260705';

const biomeChips = document.querySelector('#biomeChips');
const controlCards = document.querySelector('#controlCards');
const controlTitle = document.querySelector('#controlTitle');
const coherenceToggle = document.querySelector('#coherenceToggle');
const jsonPreview = document.querySelector('#jsonPreview');
const generateButton = document.querySelector('#generateButton');
const bakeQualitySelect = document.querySelector('#bakeQualitySelect');
const resetButton = document.querySelector('#resetButton');
const autoLinkToggle = document.querySelector('#autoLinkToggle');
const designHealth = document.querySelector('#designHealth');
const generationStatus = document.querySelector('#generationStatus');
const qualityRepairQueue = document.querySelector('#qualityRepairQueue');
const diameterMetric = document.querySelector('#diameterMetric');
const seedMetric = document.querySelector('#seedMetric');
const meshCanvas = document.querySelector('#meshCanvas');
const gpuMeshCanvas = document.querySelector('#gpuMeshCanvas');
const layoutCanvas = document.querySelector('#layoutCanvas');
const meshStatus = document.querySelector('#meshStatus');
const manifestPreview = document.querySelector('#manifestPreview');
const manifestStatus = document.querySelector('#manifestStatus');
const layoutLegend = document.querySelector('#layoutLegend');
const semanticSummary = document.querySelector('#semanticSummary');
const maskCoverage = document.querySelector('#maskCoverage');
const resetCameraButton = document.querySelector('#resetCameraButton');
const inspectButton = document.querySelector('#inspectButton');
const inspectStatus = document.querySelector('#inspectStatus');
const rendererToggle = document.querySelector('#rendererToggle');
const previewStatePill = document.querySelector('#previewStatePill');
const mapYawHud = document.querySelector('#mapYawHud');
const meshYawHud = document.querySelector('#meshYawHud');
const mapProbeHud = document.querySelector('#mapProbeHud');
const meshContext = meshCanvas.getContext('2d');
const layoutContext = layoutCanvas.getContext('2d');

let currentBiome = 'fire';
let availableBiomes = [];
let bakeQualityProfiles = [];
let selectedBakeQuality = 'production';
let currentLayout = null;
let previewMesh = null;
let authoritativeMesh = null;
let currentField = null;
let gpuInspectField = null;
let meshTransition = null;
let previewStartTime = performance.now();
let meshCamera = defaultOrbitCamera();
let meshDrag = null;
let layoutDirty = false;
let previewing = false;
let generating = false;
let previewMeshMode = 'baked';
let previewTimer = null;
let previewAbortController = null;
let previewRequestId = 0;
let lastPreviewSignature = '';
let inspecting = false;
let inspectRequestId = 0;
let lastInspectSignature = '';
let meshRendererMode = 'webgl';
let gpuInspectActive = false;
let gpuInspectMesh = null;
let gpuInspectRenderer = null;
let gpuInspectRenderHandle = 0;
let controlInteractionActive = false;
let pendingPreviewAfterInteraction = false;
let activeHighlightControlId = null;
let activeControlGroup = 'Form';
let selectedMaskView = 'material';
let activeProcessLayerId = 'finalMesh';
let mapHitRegions = [];
let processTracesEnabled = true;
let processTracePulse = null;
let meshDeltaPulse = null;
let meshRenderHandle = 0;
let meshRenderDirty = true;
let activeAdvisorControlIds = new Set();
let currentQualityReport = null;
let activeQualityIssue = null;
let activeNudgeReview = null;
let layoutEditVersion = 0;
let pendingMovementHighlightCache = null;

const PREVIEW_BAKE_DELAY_MS = 90;
const CONTROL_SETTLE_BAKE_DELAY_MS = 150;
const PREVIEW_MORPH_MS = 360;
const PROCESS_TRACE_PULSE_MS = 900;
const MESH_DELTA_PULSE_MS = 1250;

function redrawLayoutIfReady() {
  if (currentLayout) drawLayoutPreview(currentLayout);
}

function meshAnimationActive() {
  return Boolean(meshTransition || meshDrag || processTracePulse || meshDeltaPulse);
}

function shouldRenderMeshWithWebgl() {
  return Boolean(gpuInspectActive || (meshRendererMode === 'webgl' && previewMesh && ensureGpuInspectRenderer()));
}

function requestMeshRender() {
  if (shouldRenderMeshWithWebgl()) {
    requestGpuInspectRender();
    return;
  }
  meshRenderDirty = true;
  if (!meshRenderHandle) {
    meshRenderHandle = requestAnimationFrame(drawMeshPreview);
  }
}

function updateViewportHud() {
  const label = yawLabel(meshCamera.yaw);
  mapYawHud.textContent = label;
  meshYawHud.textContent = label;
}

function activeMovementHighlightLabel() {
  const controlLabel = currentLayout
    ? controlSpec(currentLayout).find((control) => control.id === activeHighlightControlId)?.title
    : null;
  if (controlLabel) return `${controlLabel} highlighted`;
  const processLabel = processHighlightSpecForControl(activeHighlightControlId)?.label;
  if (processLabel) return processLabel;
  return controlLabel ? `${controlLabel} highlighted` : 'Movement highlighted';
}

function updateInspectUi() {
  if (!inspectButton || !inspectStatus) return;
  const qualityStatus = previewQualityStatusForBakeQuality(selectedBakeQuality);
  const hasLayout = Boolean(currentLayout);
  const signature = currentInspectSignature();
  const hasCurrentSnapshot = hasLayout && signature && signature === lastInspectSignature;
  const staleSnapshot = hasLayout && Boolean(lastInspectSignature) && !hasCurrentSnapshot;
  inspectButton.disabled = !hasLayout || generating || previewing || inspecting;
  inspectButton.textContent = inspecting ? 'Inspecting...' : qualityStatus.inspectLabel;
  inspectButton.title = `Bake a ${qualityStatus.finalQuality} snapshot for visual inspection without changing final export artifacts. Realtime uses ${qualityStatus.realtimeQuality}.`;
  inspectStatus.classList.toggle('ready', hasCurrentSnapshot && !inspecting);
  inspectStatus.classList.toggle('stale', staleSnapshot && !inspecting);
  inspectStatus.classList.toggle('active', inspecting);
  if (inspecting) {
    inspectStatus.textContent = `${qualityStatus.finalLabel} inspect running`;
  } else if (hasCurrentSnapshot) {
    inspectStatus.textContent = qualityStatus.currentStatus;
  } else if (staleSnapshot) {
    inspectStatus.textContent = qualityStatus.staleStatus;
  } else {
    inspectStatus.textContent = qualityStatus.idleStatus;
  }
}

function updateBakeUi() {
  generateButton.disabled = generating || previewing || inspecting || !currentLayout;
  bakeQualitySelect.disabled = generating || previewing || inspecting || !currentLayout;
  generateButton.textContent = bakeButtonLabel(currentBiome, {
    dirty: layoutDirty,
    previewing,
    generating,
  });

  previewStatePill.classList.toggle('dirty', layoutDirty);
  previewStatePill.classList.toggle('previewing', previewing);
  previewStatePill.classList.toggle('baked', !layoutDirty && !previewing);
  if (generating) {
    previewStatePill.textContent = 'Baking final mesh';
  } else if (inspecting) {
    previewStatePill.textContent = 'Inspect baking';
  } else if (previewing && activeHighlightControlId) {
    previewStatePill.textContent = `${activeMovementHighlightLabel()} fitting`;
  } else if (previewing) {
    previewStatePill.textContent = 'Preview baking';
  } else if (layoutDirty && previewMeshMode === 'intent') {
    previewStatePill.textContent = activeMovementHighlightLabel();
  } else if (layoutDirty && previewMeshMode === 'preview') {
    previewStatePill.textContent = 'Preview fitted';
  } else if (layoutDirty) {
    previewStatePill.textContent = 'Live edits pending';
  } else {
    previewStatePill.textContent = 'Baked mesh';
  }

  resetButton.disabled = generating || previewing || inspecting || !layoutDirty;
  updateInspectUi();
}

function renderProcessLayerStack() {
  if (!currentField && selectedMaskView !== 'material') {
    selectedMaskView = 'material';
    activeProcessLayerId = 'finalMesh';
  }
  const qualityMetrics = previewMesh ? qualityMetricsForMesh(previewMesh, currentField) : null;
  const layers = processLayerStack(currentField, activeProcessLayerId, qualityMetrics);
  maskCoverage.classList.add('process-layer-stack');
  maskCoverage.innerHTML = layers.map((layer) => `
    <button
      class="process-layer ${layer.active ? 'active' : ''}"
      type="button"
      data-layer-id="${escapeHtml(layer.id)}"
      data-mask-view="${escapeHtml(layer.maskView)}"
      title="${escapeHtml(`${layer.label}: ${layer.description}`)}"
      style="--layer-tone:${escapeHtml(layer.tone)}; --layer-fill:${Math.round((layer.average ?? 0) * 100)}%;"
      ${layer.disabled ? 'disabled' : ''}
    >
      <span>${escapeHtml(layer.tag)}</span>
      <b>${escapeHtml(layer.label)}</b>
      <em>${escapeHtml(layer.coverageLabel)}</em>
      <i></i>
    </button>
  `).join('');

  maskCoverage.querySelectorAll('button').forEach((button) => {
    button.addEventListener('click', () => {
      if (button.disabled) return;
      activeProcessLayerId = button.dataset.layerId || 'finalMesh';
      selectedMaskView = button.dataset.maskView || 'material';
      renderProcessLayerStack();
      if (processTracesEnabled) triggerProcessTracePulse();
      requestMeshRender();
      redrawLayoutIfReady();
    });
  });
}

function cancelPreviewBake() {
  if (previewTimer) {
    clearTimeout(previewTimer);
    previewTimer = null;
  }
  if (previewAbortController) {
    previewAbortController.abort();
    previewAbortController = null;
  }
}

function invalidatePendingMovementHighlightCache() {
  pendingMovementHighlightCache = null;
}

function markLayoutDirty() {
  layoutDirty = true;
  layoutEditVersion += 1;
  invalidatePendingMovementHighlightCache();
  if (currentLayout && currentInspectSignature() !== lastInspectSignature) {
    leaveGpuInspectForRealtimePreview({ stale: true, forceStatus: true });
  }
  if (currentLayout && currentPreviewSignature() !== lastPreviewSignature) {
    previewMeshMode = 'intent';
    if (previewMesh) {
      meshStatus.textContent = `${previewMesh.vertices.length} vertices · ${previewMesh.faces.length} faces · ${activeMovementHighlightLabel().toLowerCase()} pending fit`;
    }
  }
  requestMeshRender();
  updateBakeUi();
}

function requestPreviewAfterEdit() {
  pendingPreviewAfterInteraction = true;
  if (!controlInteractionActive) {
    schedulePreviewBake(CONTROL_SETTLE_BAKE_DELAY_MS);
  }
}

function leaveGpuInspectForRealtimePreview({ stale = false, forceStatus = false } = {}) {
  const hadGpuInspect = gpuInspectActive;
  if (gpuInspectActive) setGpuInspectActive(false);
  if ((hadGpuInspect || forceStatus) && stale && previewMesh) {
    meshStatus.textContent = `${previewMesh.vertices.length} vertices · ${previewMesh.faces.length} faces · realtime preview active; inspect snapshot stale`;
  }
  return hadGpuInspect;
}

function beginControlInteraction(controlId = null) {
  if (activeHighlightControlId !== controlId) invalidatePendingMovementHighlightCache();
  activeHighlightControlId = controlId;
  if (controlInteractionActive) return;
  controlInteractionActive = true;
  pendingPreviewAfterInteraction = false;
  cancelPreviewBake();
  previewRequestId += 1;
  previewing = false;
  leaveGpuInspectForRealtimePreview();
  requestMeshRender();
  updateBakeUi();
}

function finishControlInteraction() {
  if (!controlInteractionActive) return;
  controlInteractionActive = false;
  if (pendingPreviewAfterInteraction) {
    schedulePreviewBake(CONTROL_SETTLE_BAKE_DELAY_MS);
  }
  requestMeshRender();
}

const fallbackBiomes = [
  { biome: 'fire', label: 'Fire Volcano Island' },
  { biome: 'ice', label: 'Ice Glacier Island' },
  { biome: 'forest', label: 'Forest Canopy Island' },
];

const fallbackBakeQualityProfiles = [
  { id: 'draft', label: 'Draft', description: 'Fast whitebox topology for checks.', segments: 96, rings: 14 },
  { id: 'preview', label: 'Preview', description: 'Moderate terrain sampling.', segments: 128, rings: 20 },
  { id: 'production', label: 'Production', description: 'Denser terrain bake for Unreal import.', segments: 192, rings: 32 },
  { id: 'hero', label: 'Hero', description: 'High-density output for close inspection.', segments: 384, rings: 56 },
];

function activeBakeQualityProfiles() {
  return bakeQualityProfiles.length ? bakeQualityProfiles : fallbackBakeQualityProfiles;
}

function bakeQualityProfileFor(id) {
  return activeBakeQualityProfiles().find((profile) => profile.id === id) || null;
}

function syncBakeQualityFromManifest(manifest) {
  const manifestQuality = String(manifest?.bake?.quality || '').toLowerCase();
  if (!manifestQuality || manifestQuality === selectedBakeQuality || !bakeQualityProfileFor(manifestQuality)) return false;
  selectedBakeQuality = manifestQuality;
  renderBakeQualityOptions();
  lastPreviewSignature = currentPreviewSignature();
  updateInspectUi();
  return true;
}

function processLayerForControl(controlId) {
  return {
    detailEnergy: { layerId: 'surfaceDetail', maskView: 'slope' },
    erosionAge: { layerId: 'erosionAge', maskView: 'lavaFlow' },
    depositionWeight: { layerId: 'talusDeposition', maskView: 'talus' },
  }[controlId] || null;
}

function processLayerForQualityIssue(issue) {
  return {
    routeDamage: { layerId: 'qualityDiagnostics', maskView: 'quality' },
    overDetail: { layerId: 'qualityDiagnostics', maskView: 'quality' },
    thinEdge: { layerId: 'qualityDiagnostics', maskView: 'quality' },
  }[issue?.type] || { layerId: 'qualityDiagnostics', maskView: 'quality' };
}

function controlGroupForId(controlId) {
  return controlSpec(currentLayout).find((control) => control.id === controlId)?.group || null;
}

function findById(items, id) {
  return items.find((item) => item.id === id);
}

function setById(items, id, key, value) {
  const item = findById(items, id);
  if (item) item[key] = value;
}

function setRadiusRangeMax(items, id, value) {
  const item = findById(items, id);
  if (!item) return;
  const [inner = 0, outer = value] = item.radius_range || [];
  item.radius_range = [inner, Math.max(inner + 0.01, value ?? outer)];
}

function setPathPointRadius(items, id, value) {
  const item = findById(items, id);
  if (!item) return;
  const point = item.points?.[0] || [value, 0];
  const angle = Math.atan2(Number(point[1]) || 0, Number(point[0]) || 0);
  const safeAngle = Number.isFinite(angle) ? angle : 0;
  item.points = [
    [
      Number((Math.cos(safeAngle) * value).toFixed(4)),
      Number((Math.sin(safeAngle) * value).toFixed(4)),
    ],
    ...(item.points || []).slice(1),
  ];
}

function ensureProcessControls(layout) {
  layout.process = {
    detail_energy: 1.0,
    erosion_age: 0.45,
    deposition_weight: 0.55,
    ...(layout.process || {}),
  };
  return layout.process;
}

function clamp(value, min, max) {
  return Math.min(max, Math.max(min, value));
}

function roundTo(value, step) {
  return Math.round(value / step) * step;
}

function biomeLabel(biome) {
  return availableBiomes.find((item) => item.biome === biome)?.label || biome;
}

function currentPreviewSignature(layout = currentLayout) {
  return layout ? previewBakeSignature(layout, { quality: previewQualityForBakeQuality(selectedBakeQuality) }) : '';
}

function currentInspectSignature(layout = currentLayout) {
  return layout ? inspectBakeSignature(layout, { quality: selectedBakeQuality }) : '';
}

function titleCase(value) {
  return String(value).replace(/_/g, ' ').replace(/\b\w/g, (letter) => letter.toUpperCase());
}

function applyVolcanicCoherence(layout) {
  const volcano = findById(layout.landmarks, 'central_volcano');
  const lava = findById(layout.landmarks, 'lava_channels');
  const mainPath = findById(layout.paths, 'main_approach');
  const loop = findById(layout.paths, 'partial_crater_loop');
  if (!volcano || !lava || !mainPath || !loop) return;

  const t = clamp((volcano.dominance - 0.35) / (1.2 - 0.35), 0, 1);
  volcano.radius = Number(roundTo(0.34 + t * 0.16, 0.01).toFixed(2));
  mainPath.width = Number(roundTo(0.18 - t * 0.06, 0.01).toFixed(2));
  lava.count = Math.round(2 + t * 2);
  loop.coverage = Number(roundTo(0.32 + t * 0.38, 0.01).toFixed(2));
}

function updateDesignHealth(layout) {
  const warnings = [];
  let stableText = `Layout inventory: ${layout.landmarks.length} landmarks, ${layout.paths.length} paths, ${layout.zones.length} zones`;

  if (layout.biome === 'fire') {
    const volcano = findById(layout.landmarks, 'central_volcano');
    const mainPath = findById(layout.paths, 'main_approach');
    const loop = findById(layout.paths, 'partial_crater_loop');
    const lava = findById(layout.landmarks, 'lava_channels');
    if (volcano && mainPath && volcano.radius < 0.34 && mainPath.width > 0.2) warnings.push('wide road with tiny crater');
    if (volcano && loop && volcano.radius < 0.34 && loop.coverage > 0.65) warnings.push('large ring around small volcano');
    if (volcano && lava && volcano.dominance < 0.55 && lava.count > 3) warnings.push('too many lava channels for weak volcano');
    stableText = 'Layout coherence: stable volcanic composition';
  } else if (layout.biome === 'forest') {
    const root = findById(layout.landmarks, 'root_arch');
    const stump = findById(layout.landmarks, 'tree_stump_cave');
    const vineBridge = findById(layout.paths, 'vine_bridge');
    const mushroom = findById(layout.zones, 'mushroom_pocket');
    const canopy = findById(layout.zones, 'canopy_platform');
    const mushroomOuter = mushroom?.radius_range?.[1] ?? 0;
    const canopyOuter = canopy?.radius_range?.[1] ?? 0;
    if (vineBridge && vineBridge.width < 0.055) warnings.push('vine bridge may read too thin');
    if (mushroomOuter > canopyOuter + 0.12) warnings.push('mushroom pocket overreaches canopy platform');
    if ((root?.dominance ?? 1) < 0.32 && (stump?.dominance ?? 1) < 0.32) warnings.push('root and cave landmarks are both too quiet');
    stableText = 'Layout coherence: readable forest platform, roots, pockets, and bridge';
  } else if (layout.biome === 'ice') {
    const wall = findById(layout.landmarks, 'primary_crystal_wall');
    const resource = findById(layout.landmarks, 'secondary_spire_clusters');
    const centralShelf = findById(layout.paths, 'central_shelf');
    const brokenRing = findById(layout.paths, 'broken_ice_ring');
    const deepCracks = findById(layout.zones, 'deep_cracks');
    const brokenRadius = brokenRing?.points?.[0]
      ? Math.hypot(Number(brokenRing.points[0][0]) || 0, Number(brokenRing.points[0][1]) || 0) * 0.94
      : 0.58;
    if (wall && centralShelf && centralShelf.width > wall.radius * 0.82) warnings.push('central shelf nearly swallows crystal wall');
    if (resource && resource.count > 6 && resource.radius > 0.58) warnings.push('resource clusters may merge into one noisy band');
    if (deepCracks && brokenRadius > (deepCracks.radius_range?.[1] ?? 1) - 0.08) warnings.push('broken plate ring is too close to crack boundary');
    stableText = 'Layout coherence: readable glacier shelf, wall, cracks, and resource clusters';
  }

  designHealth.classList.toggle('warning', warnings.length > 0);
  designHealth.textContent = warnings.length
    ? `Layout coherence warning: ${warnings.join(', ')}`
    : stableText;
}

function controlSpec(layout) {
  const labels = biomeControlLabels(layout.biome);
  const ranges = biomeControlRanges(layout.biome);
  const process = ensureProcessControls(layout);

  const processControls = [
    { id: 'detailEnergy', group: 'Process', ...labels.detailEnergy, ...ranges.detailEnergy, value: process.detail_energy, field: 'process.detail_energy', update: (value) => { process.detail_energy = value; } },
    { id: 'erosionAge', group: 'Process', ...labels.erosionAge, ...ranges.erosionAge, value: process.erosion_age, field: 'process.erosion_age', update: (value) => { process.erosion_age = value; } },
    { id: 'depositionWeight', group: 'Process', ...labels.depositionWeight, ...ranges.depositionWeight, value: process.deposition_weight, field: 'process.deposition_weight', update: (value) => { process.deposition_weight = value; } },
  ];

  if (layout.biome === 'forest') {
    const root = findById(layout.landmarks, 'root_arch');
    const stump = findById(layout.landmarks, 'tree_stump_cave');
    const vineAnchor = findById(layout.landmarks, 'vine_bridge_anchor');
    const mainPath = findById(layout.paths, 'forest_main_path');
    const vineBridge = findById(layout.paths, 'vine_bridge');
    const mushroom = findById(layout.zones, 'mushroom_pocket');
    const canopy = findById(layout.zones, 'canopy_platform');
    return [
      { id: 'rootDominance', group: 'Form', ...labels.rootDominance, ...ranges.rootDominance, value: root?.dominance ?? 0.7, field: 'root_arch.dominance', update: (value) => setById(layout.landmarks, 'root_arch', 'dominance', value) },
      { id: 'stumpCaveDominance', group: 'Form', ...labels.stumpCaveDominance, ...ranges.stumpCaveDominance, value: stump?.dominance ?? 0.72, field: 'tree_stump_cave.dominance', update: (value) => setById(layout.landmarks, 'tree_stump_cave', 'dominance', value) },
      { id: 'canopyPlatformOuter', group: 'Form', ...labels.canopyPlatformOuter, ...ranges.canopyPlatformOuter, value: canopy?.radius_range?.[1] ?? 0.44, field: 'canopy_platform.radius_range[1]', update: (value) => setRadiusRangeMax(layout.zones, 'canopy_platform', value) },
      { id: 'vineAnchorDominance', group: 'Form', ...labels.vineAnchorDominance, ...ranges.vineAnchorDominance, value: vineAnchor?.dominance ?? 0.38, field: 'vine_bridge_anchor.dominance', update: (value) => setById(layout.landmarks, 'vine_bridge_anchor', 'dominance', value) },
      { id: 'mainPathWidth', group: 'Routes', ...labels.mainPathWidth, ...ranges.mainPathWidth, value: mainPath?.width ?? 0.14, field: 'forest_main_path.width', update: (value) => setById(layout.paths, 'forest_main_path', 'width', value) },
      { id: 'vineBridgeWidth', group: 'Routes', ...labels.vineBridgeWidth, ...ranges.vineBridgeWidth, value: vineBridge?.width ?? 0.08, field: 'vine_bridge.width', update: (value) => setById(layout.paths, 'vine_bridge', 'width', value) },
      { id: 'mushroomPocketOuter', group: 'PCG', ...labels.mushroomPocketOuter, ...ranges.mushroomPocketOuter, value: mushroom?.radius_range?.[1] ?? 0.42, field: 'mushroom_pocket.radius_range[1]', update: (value) => setRadiusRangeMax(layout.zones, 'mushroom_pocket', value) },
      ...processControls,
    ];
  }

  if (layout.biome === 'ice') {
    const wall = findById(layout.landmarks, 'primary_crystal_wall');
    const resource = findById(layout.landmarks, 'secondary_spire_clusters');
    const centralShelf = findById(layout.paths, 'central_shelf');
    const brokenRing = findById(layout.paths, 'broken_ice_ring');
    const deepCracks = findById(layout.zones, 'deep_cracks');
    const brokenRadius = brokenRing?.points?.[0]
      ? Math.hypot(Number(brokenRing.points[0][0]) || 0, Number(brokenRing.points[0][1]) || 0) * 0.94
      : 0.58;
    return [
      { id: 'crystalWallRadius', group: 'Form', ...labels.crystalWallRadius, ...ranges.crystalWallRadius, value: wall?.radius ?? 0.54, field: 'primary_crystal_wall.radius', update: (value) => setById(layout.landmarks, 'primary_crystal_wall', 'radius', value) },
      { id: 'crystalWallDominance', group: 'Form', ...labels.crystalWallDominance, ...ranges.crystalWallDominance, value: wall?.dominance ?? 0.78, field: 'primary_crystal_wall.dominance', update: (value) => setById(layout.landmarks, 'primary_crystal_wall', 'dominance', value) },
      { id: 'brokenIceRingRadius', group: 'Form', ...labels.brokenIceRingRadius, ...ranges.brokenIceRingRadius, value: Number(brokenRadius.toFixed(4)), field: 'broken_ice_ring.points[0].radius', update: (value) => setPathPointRadius(layout.paths, 'broken_ice_ring', value / 0.94) },
      { id: 'centralShelfWidth', group: 'Routes', ...labels.centralShelfWidth, ...ranges.centralShelfWidth, value: centralShelf?.width ?? 0.34, field: 'central_shelf.width', update: (value) => { setById(layout.paths, 'central_shelf', 'width', value); setRadiusRangeMax(layout.zones, 'central_ice_shelf', value); } },
      { id: 'resourceClusterCount', group: 'PCG', ...labels.resourceClusterCount, ...ranges.resourceClusterCount, value: resource?.count ?? 4, field: 'secondary_spire_clusters.count', update: (value) => setById(layout.landmarks, 'secondary_spire_clusters', 'count', Math.round(value)) },
      { id: 'resourceClusterRadius', group: 'PCG', ...labels.resourceClusterRadius, ...ranges.resourceClusterRadius, value: resource?.radius ?? 0.48, field: 'secondary_spire_clusters.radius', update: (value) => { setById(layout.landmarks, 'secondary_spire_clusters', 'radius', value); setRadiusRangeMax(layout.zones, 'resource_crystals', Math.max(0.38, value + 0.28)); } },
      { id: 'deepCrackOuter', group: 'Hazards', ...labels.deepCrackOuter, ...ranges.deepCrackOuter, value: deepCracks?.radius_range?.[1] ?? 0.92, field: 'deep_cracks.radius_range[1]', update: (value) => setRadiusRangeMax(layout.zones, 'deep_cracks', value) },
      ...processControls,
    ];
  }

  const volcano = findById(layout.landmarks, 'central_volcano');
  const lava = findById(layout.landmarks, 'lava_channels');
  const mainPath = findById(layout.paths, 'main_approach');
  const loop = findById(layout.paths, 'partial_crater_loop');
  return [
    { id: 'volcanoDominance', group: 'Form', ...labels.volcanoDominance, ...ranges.volcanoDominance, value: volcano?.dominance ?? 0.85, field: 'central_volcano.dominance', update: (value) => setById(layout.landmarks, 'central_volcano', 'dominance', value) },
    { id: 'volcanoRadius', group: 'Form', ...labels.volcanoRadius, ...ranges.volcanoRadius, value: volcano?.radius ?? 0.42, field: 'central_volcano.radius', update: (value) => setById(layout.landmarks, 'central_volcano', 'radius', value) },
    { id: 'mainPathWidth', group: 'Routes', ...labels.mainPathWidth, ...ranges.mainPathWidth, value: mainPath?.width ?? 0.12, field: 'main_approach.width', update: (value) => setById(layout.paths, 'main_approach', 'width', value) },
    { id: 'loopCoverage', group: 'Routes', ...labels.loopCoverage, ...ranges.loopCoverage, value: loop?.coverage ?? 0.55, field: 'partial_crater_loop.coverage', update: (value) => setById(layout.paths, 'partial_crater_loop', 'coverage', value) },
    { id: 'lavaCount', group: 'Hazards', ...labels.lavaCount, ...ranges.lavaCount, value: lava?.count ?? 3, field: 'lava_channels.count', update: (value) => setById(layout.landmarks, 'lava_channels', 'count', Math.round(value)) },
    ...processControls,
  ];
}

function parseObj(text) {
  const vertices = [];
  const faces = [];
  let material = 'M_TopGrass';
  for (const line of text.split('\n')) {
    if (line.startsWith('v ')) {
      const [, x, y, z] = line.trim().split(/\s+/);
      vertices.push([Number(x), Number(y), Number(z)]);
    } else if (line.startsWith('usemtl ')) {
      material = line.trim().slice(7);
    } else if (line.startsWith('f ')) {
      const indices = line.trim().split(/\s+/).slice(1).map((part) => Number(part.split('/')[0]) - 1);
      if (indices.length >= 3) faces.push({ indices, material, order: faces.length });
    }
  }
  return normalizeMesh({ vertices, faces });
}

function normalizeMesh(mesh) {
  const bounds = mesh.vertices.reduce((acc, vertex) => {
    acc.minX = Math.min(acc.minX, vertex[0]);
    acc.maxX = Math.max(acc.maxX, vertex[0]);
    acc.minY = Math.min(acc.minY, vertex[1]);
    acc.maxY = Math.max(acc.maxY, vertex[1]);
    acc.minZ = Math.min(acc.minZ, vertex[2]);
    acc.maxZ = Math.max(acc.maxZ, vertex[2]);
    return acc;
  }, { minX: Infinity, maxX: -Infinity, minY: Infinity, maxY: -Infinity, minZ: Infinity, maxZ: -Infinity });
  const center = [
    (bounds.minX + bounds.maxX) / 2,
    (bounds.minY + bounds.maxY) / 2,
    (bounds.minZ + bounds.maxZ) / 2,
  ];
  const span = Math.max(bounds.maxX - bounds.minX, bounds.maxY - bounds.minY, bounds.maxZ - bounds.minZ, 1);
  return {
    vertices: mesh.vertices.map((vertex) => [
      (vertex[0] - center[0]) / span,
      (vertex[1] - center[1]) / span,
      (vertex[2] - center[2]) / span,
    ]),
    faces: mesh.faces,
    bounds,
  };
}

function materialColor(material, light) {
  return materialColorForBiome(currentBiome, material, light);
}

function rgbTriplet(color) {
  return (color.match(/\d+/g)?.map(Number) || [110, 116, 130]).slice(0, 3);
}

function rgbaTuple(color, fallbackAlpha = 1) {
  const channels = (color.match(/[\d.]+/g)?.map(Number) || [0, 0, 0]).slice(0, 4);
  return [
    clamp((channels[0] ?? 0) / 255, 0, 1),
    clamp((channels[1] ?? 0) / 255, 0, 1),
    clamp((channels[2] ?? 0) / 255, 0, 1),
    clamp(channels[3] ?? fallbackAlpha, 0, 1),
  ];
}

function subtract3(a, b) {
  return [a[0] - b[0], a[1] - b[1], a[2] - b[2]];
}

function cross3(a, b) {
  return [
    a[1] * b[2] - a[2] * b[1],
    a[2] * b[0] - a[0] * b[2],
    a[0] * b[1] - a[1] * b[0],
  ];
}

function normalize3(vector) {
  const length = Math.hypot(vector[0], vector[1], vector[2]);
  if (!Number.isFinite(length) || length <= 0.000001) return [0, 0, 1];
  return [vector[0] / length, vector[1] / length, vector[2] / length];
}

function faceNormalForTriangle(a, b, c) {
  return normalize3(cross3(subtract3(b, a), subtract3(c, a)));
}

function createGpuShader(gl, type, source) {
  const shader = gl.createShader(type);
  gl.shaderSource(shader, source);
  gl.compileShader(shader);
  if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
    throw new Error(gl.getShaderInfoLog(shader) || 'WebGL shader compilation failed');
  }
  return shader;
}

function createGpuProgram(gl) {
  const vertexShader = createGpuShader(gl, gl.VERTEX_SHADER, `
    attribute vec3 aPosition;
    attribute vec3 aNormal;
    attribute vec3 aColor;
    attribute vec4 aOverlay;
    uniform float uYaw;
    uniform float uPitch;
    uniform float uZoom;
    uniform vec3 uKeyLight;
    uniform vec3 uFillLight;
    varying vec3 vColor;
    varying vec4 vOverlay;
    void main() {
      float cy = cos(uYaw);
      float sy = sin(uYaw);
      float cp = cos(uPitch);
      float sp = sin(uPitch);
      float x = aPosition.x * cy - aPosition.y * sy;
      float yawY = aPosition.x * sy + aPosition.y * cy;
      float y = yawY * cp - aPosition.z * sp;
      float z = yawY * sp + aPosition.z * cp;
      float perspective = 1.5 / max(0.35, 1.7 + y);
      float screenX = x * 1.28 * perspective * uZoom;
      float screenY = z * 1.55 * perspective * uZoom - y * 0.18;
      gl_Position = vec4(screenX, screenY, -y * 0.08, 1.0);
      vec3 normal = normalize(aNormal);
      float key = max(dot(normalize(aNormal), normalize(uKeyLight)), 0.0);
      float fill = max(dot(normalize(aNormal), normalize(uFillLight)), 0.0);
      float keyBack = max(dot(-normal, normalize(uKeyLight)), 0.0);
      float backFill = max(dot(-normal, normalize(uFillLight)), 0.0);
      float slopeDetail = 1.0 - abs(normal.z);
      float heightLight = clamp(0.5 + aPosition.z * 0.65, 0.0, 1.0);
      float shade = 0.5 + key * 0.4 + fill * 0.2 + keyBack * 0.16 + backFill * 0.14 + slopeDetail * 0.1 + heightLight * 0.08 - y * 0.03;
      vec3 litColor = aColor * clamp(shade, 0.54, 1.3);
      vec3 shadowLift = aColor * 0.62 + vec3(0.04, 0.046, 0.058);
      vColor = max(litColor, shadowLift);
      vOverlay = aOverlay;
    }
  `);
  const fragmentShader = createGpuShader(gl, gl.FRAGMENT_SHADER, `
    precision mediump float;
    varying vec3 vColor;
    varying vec4 vOverlay;
    void main() {
      vec3 color = mix(vColor, vOverlay.rgb, clamp(vOverlay.a, 0.0, 0.86));
      gl_FragColor = vec4(color, 1.0);
    }
  `);
  const program = gl.createProgram();
  gl.attachShader(program, vertexShader);
  gl.attachShader(program, fragmentShader);
  gl.linkProgram(program);
  if (!gl.getProgramParameter(program, gl.LINK_STATUS)) {
    throw new Error(gl.getProgramInfoLog(program) || 'WebGL program link failed');
  }
  return {
    program,
    position: gl.getAttribLocation(program, 'aPosition'),
    normal: gl.getAttribLocation(program, 'aNormal'),
    color: gl.getAttribLocation(program, 'aColor'),
    overlay: gl.getAttribLocation(program, 'aOverlay'),
    yaw: gl.getUniformLocation(program, 'uYaw'),
    pitch: gl.getUniformLocation(program, 'uPitch'),
    zoom: gl.getUniformLocation(program, 'uZoom'),
    keyLight: gl.getUniformLocation(program, 'uKeyLight'),
    fillLight: gl.getUniformLocation(program, 'uFillLight'),
  };
}

function ensureGpuInspectRenderer() {
  if (!gpuMeshCanvas) return null;
  if (gpuInspectRenderer) return gpuInspectRenderer;
  const gl = gpuMeshCanvas.getContext('webgl', { antialias: true }) || gpuMeshCanvas.getContext('experimental-webgl', { antialias: true });
  if (!gl) return null;
  const shader = createGpuProgram(gl);
  gpuInspectRenderer = {
    gl,
    shader,
    positionBuffer: gl.createBuffer(),
    normalBuffer: gl.createBuffer(),
    colorBuffer: gl.createBuffer(),
    overlayBuffer: gl.createBuffer(),
    uploadedMesh: null,
    uploadedKey: '',
    vertexCount: 0,
  };
  return gpuInspectRenderer;
}

function gpuUploadFrame(time = performance.now()) {
  const renderField = gpuInspectActive ? gpuInspectField || currentField : currentField;
  const processPulse = processTracePulse ? processTracePulseForFrame(time) : 0;
  const deltaPulse = meshDeltaPulse ? meshDeltaPulseForFrame(time) : 0;
  return {
    renderField,
    processPulse,
    deltaPulse,
    showProcessTraces: processTracesEnabled && renderField,
    showQualityOverlay: selectedMaskView === 'quality' && renderField,
    issueFaceOrder: activeQualityFaceOrder(),
    pendingMovement: pendingMovementHighlightActive(),
  };
}

function gpuUploadKey(mesh, frame) {
  return [
    gpuInspectActive ? 'inspect' : 'preview',
    meshRendererMode,
    currentBiome,
    selectedMaskView,
    activeProcessLayerId,
    frame.showProcessTraces ? 'trace' : 'no-trace',
    frame.renderField ? `${frame.renderField.radial_segments || 0}x${frame.renderField.rings || 0}` : 'no-field',
    activeHighlightControlId || 'no-highlight',
    frame.pendingMovement ? 'pending' : 'settled',
    layoutEditVersion,
    frame.issueFaceOrder ?? 'no-issue',
    frame.processPulse.toFixed(2),
    frame.deltaPulse.toFixed(2),
    meshTransition ? 'transition' : 'static',
    previewMeshMode,
    mesh?.vertices?.length || 0,
    mesh?.faces?.length || 0,
  ].join('|');
}

function baseColorForFace(face, faceOrder, frame) {
  const baseColor = materialColor(face.material, 0.88);
  return processTraceColorForFace(baseColor, frame.renderField, faceOrder, {
    enabled: frame.showProcessTraces,
    pulse: frame.processPulse,
    trace: frame.showProcessTraces ? focusedTraceForFace(faceOrder, frame.renderField) : null,
  });
}

function overlayColorForFace(face, mesh, faceOrder, frame) {
  if (frame.issueFaceOrder !== null && Number(faceOrder) === frame.issueFaceOrder) {
    return [1, 0.92, 0.56, 0.56];
  }

  if (frame.deltaPulse > 0 && meshDeltaPulse) {
    const delta = meshDeltaForFace(meshDeltaPulse.from, meshDeltaPulse.to, face);
    if (delta && delta.intensity > 0.08) {
      return rgbaTuple(meshDeltaColorForFace(delta, frame.deltaPulse), 0);
    }
  }

  if (frame.pendingMovement) {
    const processSpec = processHighlightSpecForControl(activeHighlightControlId);
    if (processSpec && frame.renderField) {
      const influence = processMovementHighlightForFace(frame.renderField, faceOrder, activeHighlightControlId);
      if (influence > processSpec.threshold) {
        return rgbaTuple(processMovementHighlightStyle(activeHighlightControlId, influence, { pulse: frame.processPulse })?.fill || 'rgba(0,0,0,0)', 0);
      }
    } else {
      const influence = biomeMovementHighlightForFace(face, mesh, currentLayout, footprintRadiusForMesh(mesh.vertices), activeHighlightControlId);
      if (influence > biomeMovementHighlightThreshold(activeHighlightControlId)) {
        return [0.27, 0.84, 1, 0.08 + influence * 0.26];
      }
    }
  }

  if (frame.showQualityOverlay) {
    const risk = qualityRiskForFace(mesh, frame.renderField, face);
    return rgbaTuple(qualityRiskColorForFace(risk, 0.86), 0);
  }

  return [0, 0, 0, 0];
}

function uploadGpuInspectMesh(mesh, options = {}) {
  const renderer = ensureGpuInspectRenderer();
  if (!renderer || !mesh) return false;
  const frame = options.frame || gpuUploadFrame(options.time);
  const uploadKey = gpuUploadKey(mesh, frame);
  if (renderer.uploadedMesh === mesh && renderer.uploadedKey === uploadKey) return renderer.vertexCount > 0;

  const positions = [];
  const normals = [];
  const colors = [];
  const overlays = [];
  for (let faceIndex = 0; faceIndex < mesh.faces.length; faceIndex += 1) {
    const face = mesh.faces[faceIndex];
    if (!face.indices || face.indices.length < 3) continue;
    const faceOrder = Number.isInteger(face.order) ? face.order : faceIndex;
    const [r, g, b] = rgbTriplet(baseColorForFace(face, faceOrder, frame)).map((value) => value / 255);
    const overlay = overlayColorForFace(face, mesh, faceOrder, frame);
    for (let i = 1; i < face.indices.length - 1; i += 1) {
      const triangle = [mesh.vertices[face.indices[0]], mesh.vertices[face.indices[i]], mesh.vertices[face.indices[i + 1]]];
      if (triangle.some((vertex) => !vertex)) continue;
      const normal = faceNormalForTriangle(triangle[0], triangle[1], triangle[2]);
      for (const vertex of triangle) {
        positions.push(vertex[0], vertex[1], vertex[2]);
        normals.push(normal[0], normal[1], normal[2]);
        colors.push(r, g, b);
        overlays.push(overlay[0], overlay[1], overlay[2], overlay[3]);
      }
    }
  }
  const { gl } = renderer;
  renderer.vertexCount = positions.length / 3;
  renderer.uploadedMesh = mesh;
  renderer.uploadedKey = uploadKey;
  gl.bindBuffer(gl.ARRAY_BUFFER, renderer.positionBuffer);
  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(positions), gl.STATIC_DRAW);
  gl.bindBuffer(gl.ARRAY_BUFFER, renderer.normalBuffer);
  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(normals), gl.STATIC_DRAW);
  gl.bindBuffer(gl.ARRAY_BUFFER, renderer.colorBuffer);
  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(colors), gl.STATIC_DRAW);
  gl.bindBuffer(gl.ARRAY_BUFFER, renderer.overlayBuffer);
  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(overlays), gl.STATIC_DRAW);
  return renderer.vertexCount > 0;
}

function resizeGpuInspectCanvas() {
  if (!gpuMeshCanvas) return;
  const rect = gpuMeshCanvas.getBoundingClientRect();
  const scale = window.devicePixelRatio || 1;
  const width = Math.max(1, Math.round(rect.width * scale));
  const height = Math.max(1, Math.round(rect.height * scale));
  if (gpuMeshCanvas.width !== width) gpuMeshCanvas.width = width;
  if (gpuMeshCanvas.height !== height) gpuMeshCanvas.height = height;
}

function renderGpuInspectMesh() {
  gpuInspectRenderHandle = 0;
  const time = performance.now();
  const renderMesh = gpuInspectActive ? gpuInspectMesh : meshForFrame(time);
  if (!renderMesh || (!gpuInspectActive && meshRendererMode !== 'webgl')) return;
  const renderer = ensureGpuInspectRenderer();
  if (!renderer) return;
  if (!uploadGpuInspectMesh(renderMesh, { time })) return;
  updateMeshRendererSurface();
  resizeGpuInspectCanvas();
  const { gl, shader } = renderer;
  gl.viewport(0, 0, gpuMeshCanvas.width, gpuMeshCanvas.height);
  gl.clearColor(0.055, 0.063, 0.082, 1);
  gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
  gl.enable(gl.DEPTH_TEST);
  gl.depthFunc(gl.LEQUAL);
  gl.useProgram(shader.program);
  gl.uniform1f(shader.yaw, meshCamera.yaw);
  gl.uniform1f(shader.pitch, meshCamera.pitch);
  gl.uniform1f(shader.zoom, meshCamera.zoom);
  gl.uniform3f(shader.keyLight, -0.38, -0.5, 0.78);
  gl.uniform3f(shader.fillLight, 0.58, 0.42, 0.34);
  gl.bindBuffer(gl.ARRAY_BUFFER, renderer.positionBuffer);
  gl.enableVertexAttribArray(shader.position);
  gl.vertexAttribPointer(shader.position, 3, gl.FLOAT, false, 0, 0);
  gl.bindBuffer(gl.ARRAY_BUFFER, renderer.normalBuffer);
  gl.enableVertexAttribArray(shader.normal);
  gl.vertexAttribPointer(shader.normal, 3, gl.FLOAT, false, 0, 0);
  gl.bindBuffer(gl.ARRAY_BUFFER, renderer.colorBuffer);
  gl.enableVertexAttribArray(shader.color);
  gl.vertexAttribPointer(shader.color, 3, gl.FLOAT, false, 0, 0);
  gl.bindBuffer(gl.ARRAY_BUFFER, renderer.overlayBuffer);
  gl.enableVertexAttribArray(shader.overlay);
  gl.vertexAttribPointer(shader.overlay, 4, gl.FLOAT, false, 0, 0);
  gl.drawArrays(gl.TRIANGLES, 0, renderer.vertexCount);
  if (!gpuInspectActive && meshTransition && currentLayout) {
    drawLayoutPreview(currentLayout, renderMesh, { refreshLegend: false });
  }
  if (!gpuInspectActive && meshAnimationActive()) requestMeshRender();
}

function requestGpuInspectRender() {
  if (!gpuInspectRenderHandle) {
    gpuInspectRenderHandle = requestAnimationFrame(renderGpuInspectMesh);
  }
}

function updateRendererToggleUi() {
  if (!rendererToggle) return;
  rendererToggle.querySelectorAll('button[data-renderer-mode]').forEach((button) => {
    const active = button.dataset.rendererMode === meshRendererMode;
    button.classList.toggle('active', active);
    button.setAttribute('aria-pressed', String(active));
  });
}

function updateMeshRendererSurface() {
  const rendererReady = Boolean(ensureGpuInspectRenderer());
  const webglPreviewActive = Boolean(!gpuInspectActive && meshRendererMode === 'webgl' && rendererReady && previewMesh);
  meshCanvas.parentElement.classList.toggle('gpu-inspect-active', gpuInspectActive);
  meshCanvas.parentElement.classList.toggle('webgl-preview-active', webglPreviewActive);
  gpuMeshCanvas?.classList.toggle('hidden', !(gpuInspectActive || webglPreviewActive));
  updateRendererToggleUi();
  return webglPreviewActive;
}

function setMeshRendererMode(mode) {
  const nextMode = mode === 'canvas' ? 'canvas' : 'webgl';
  if (nextMode === 'webgl' && !ensureGpuInspectRenderer()) {
    meshRendererMode = 'canvas';
  } else {
    meshRendererMode = nextMode;
  }
  if (meshRendererMode === 'canvas') setGpuInspectActive(false);
  if (gpuInspectRenderer) {
    gpuInspectRenderer.uploadedMesh = null;
    gpuInspectRenderer.uploadedKey = '';
  }
  updateMeshRendererSurface();
  updateRendererToggleUi();
  if (meshRendererMode === 'canvas') requestMeshRender();
  else requestGpuInspectRender();
}

function setGpuInspectActive(active, mesh = gpuInspectMesh) {
  const renderer = active ? ensureGpuInspectRenderer() : gpuInspectRenderer;
  gpuInspectActive = Boolean(active && renderer && mesh);
  gpuInspectMesh = gpuInspectActive ? mesh : null;
  if (!gpuInspectActive) gpuInspectField = null;
  updateMeshRendererSurface();
  if (gpuInspectActive) {
    if (!uploadGpuInspectMesh(mesh)) {
      gpuInspectActive = false;
      gpuInspectMesh = null;
      gpuInspectField = null;
      updateMeshRendererSurface();
      return false;
    }
    if (meshRenderHandle) {
      cancelAnimationFrame(meshRenderHandle);
      meshRenderHandle = 0;
    }
    meshRenderDirty = false;
    requestGpuInspectRender();
  }
  if (!gpuInspectActive && meshRendererMode === 'webgl') requestGpuInspectRender();
  return gpuInspectActive;
}

function triggerProcessTracePulse() {
  processTracePulse = {
    startTime: performance.now(),
    duration: PROCESS_TRACE_PULSE_MS,
  };
  requestMeshRender();
}

function triggerMeshDeltaPulse(fromMesh, toMesh) {
  if (!fromMesh || !toMesh || fromMesh.vertices.length !== toMesh.vertices.length) return;
  meshDeltaPulse = {
    from: fromMesh,
    to: toMesh,
    startTime: performance.now(),
    duration: MESH_DELTA_PULSE_MS,
  };
  requestMeshRender();
}

function processTracePulseForFrame(time) {
  if (!processTracePulse) return 0;
  const alpha = processTracePulseAlpha(processTracePulse.startTime, time, processTracePulse.duration);
  if (alpha <= 0 && time > processTracePulse.startTime + processTracePulse.duration) {
    processTracePulse = null;
  }
  return alpha;
}

function meshDeltaPulseForFrame(time) {
  if (!meshDeltaPulse) return 0;
  const alpha = processTracePulseAlpha(meshDeltaPulse.startTime, time, meshDeltaPulse.duration);
  if (alpha <= 0 && time > meshDeltaPulse.startTime + meshDeltaPulse.duration) {
    meshDeltaPulse = null;
  }
  return alpha;
}

function activeProcessTraceKind(field = currentField) {
  const activeLayer = processLayerStack(field, activeProcessLayerId).find((layer) => layer.active);
  if (activeLayer?.traceKind) return activeLayer.traceKind;
  if (selectedMaskView === 'quality') return null;
  if (selectedMaskView !== 'material') return selectedMaskView;
  return null;
}

function focusedTraceForFace(faceOrder, field = currentField) {
  const trace = processTraceForFace(field, faceOrder);
  const focusKind = activeProcessTraceKind(field);
  if (!trace || !focusKind) return trace;
  return {
    ...trace,
    slope: focusKind === 'slope' ? trace.slope : 0,
    talus: focusKind === 'talus' ? trace.talus : 0,
    lavaFlow: focusKind === 'lavaFlow' ? trace.lavaFlow : 0,
    dominant: focusKind,
    intensity: trace[focusKind] || 0,
  };
}

function materialColorWithAlpha(material, light, alpha) {
  const rgb = materialColorForBiome(currentBiome, material, light).match(/\d+/g)?.map(Number) || [110, 116, 130];
  return `rgba(${rgb[0]}, ${rgb[1]}, ${rgb[2]}, ${alpha})`;
}

function activeQualityFaceOrder() {
  const faceOrder = Number(activeQualityIssue?.faceOrder);
  return Number.isFinite(faceOrder) ? faceOrder : null;
}

function drawQualityIssueHighlight(context, points, { lineWidth = 2, glow = 10 } = {}) {
  if (!points?.length) return;
  context.save();
  context.globalCompositeOperation = 'screen';
  context.shadowColor = 'rgba(255, 222, 143, 0.72)';
  context.shadowBlur = glow;
  context.beginPath();
  context.moveTo(points[0].x, points[0].y);
  for (const point of points.slice(1)) context.lineTo(point.x, point.y);
  context.closePath();
  context.fillStyle = 'rgba(255, 196, 89, 0.2)';
  context.fill();
  context.strokeStyle = 'rgba(255, 235, 169, 0.86)';
  context.lineWidth = lineWidth;
  context.stroke();
  context.restore();
}

function easeInOut(value) {
  const t = clamp(value, 0, 1);
  return t * t * (3 - 2 * t);
}

function setPreviewMesh(nextMesh, mode, { transition = false, duration = PREVIEW_MORPH_MS } = {}) {
  const now = performance.now();
  const fromMesh = transition
    ? meshAtTransitionFrame(meshTransition, previewMesh, now, easeInOut)
    : previewMesh;
  previewMesh = nextMesh;
  previewMeshMode = mode;
  invalidatePendingMovementHighlightCache();

  if (transition && fromMesh && nextMesh && fromMesh.vertices.length === nextMesh.vertices.length) {
    meshTransition = {
      from: fromMesh,
      to: nextMesh,
      mode,
      startTime: now,
      duration,
    };
  } else {
    meshTransition = null;
  }
  requestMeshRender();
}

function meshForFrame(time) {
  if (!meshTransition) return previewMesh;
  const progress = (time - meshTransition.startTime) / meshTransition.duration;
  if (progress >= 1) {
    previewMesh = meshTransition.to;
    previewMeshMode = meshTransition.mode;
    meshTransition = null;
    invalidatePendingMovementHighlightCache();
    if (currentLayout) drawLayoutPreview(currentLayout);
    updateBakeUi();
    return previewMesh;
  }
  return meshAtTransitionFrame(meshTransition, previewMesh, time, easeInOut);
}

function pendingMovementHighlightActive() {
  return layoutDirty
    && activeHighlightControlId
    && currentPreviewSignature() !== lastPreviewSignature;
}

function pendingMovementHighlightCacheKey(mesh) {
  return [
    currentBiome,
    activeHighlightControlId || 'none',
    layoutEditVersion,
    mesh?.vertices?.length || 0,
    mesh?.faces?.length || 0,
  ].join('|');
}

function pendingMovementHighlightData(mesh) {
  if (!mesh || !currentLayout) return { faces: [], vertexInfluence: new Map() };
  const key = pendingMovementHighlightCacheKey(mesh);
  if (pendingMovementHighlightCache?.key === key && pendingMovementHighlightCache.mesh === mesh) {
    return pendingMovementHighlightCache.data;
  }

  const footprintRadius = footprintRadiusForMesh(mesh.vertices);
  const highlightThreshold = biomeMovementHighlightThreshold(activeHighlightControlId);
  const vertexInfluence = new Map();
  const faces = [];

  mesh.faces.forEach((face, faceIndex) => {
    const influence = biomeMovementHighlightForFace(
      face,
      mesh,
      currentLayout,
      footprintRadius,
      activeHighlightControlId,
    );
    if (influence <= highlightThreshold) return;
    for (const index of face.indices) {
      vertexInfluence.set(index, Math.max(vertexInfluence.get(index) || 0, influence));
    }
    faces.push({
      faceIndex,
      influence,
      indices: face.indices,
    });
  });

  const data = { faces, vertexInfluence };
  pendingMovementHighlightCache = { key, mesh, data };
  return data;
}

function drawPendingMovementHighlights(mesh, projected) {
  if (!pendingMovementHighlightActive()) return;

  const processSpec = processHighlightSpecForControl(activeHighlightControlId);
  if (processSpec) {
    drawProcessPendingMovementHighlights(mesh, projected);
    return;
  }

  const highlightData = pendingMovementHighlightData(mesh);
  const highlightedFaces = highlightData.faces.map((face) => ({
    ...face,
    depth: face.indices.reduce((sum, index) => sum + projected[index].depth, 0) / face.indices.length,
    points: face.indices.map((index) => projected[index]),
  })).sort((a, b) => a.depth - b.depth);

  meshContext.save();
  meshContext.globalCompositeOperation = 'screen';
  for (const face of highlightedFaces) {
    meshContext.beginPath();
    meshContext.moveTo(face.points[0].x, face.points[0].y);
    for (const point of face.points.slice(1)) meshContext.lineTo(point.x, point.y);
    meshContext.closePath();
    meshContext.fillStyle = `rgba(68, 213, 255, ${0.06 + face.influence * 0.2})`;
    meshContext.fill();
  }

  meshContext.globalCompositeOperation = 'source-over';
  for (const [index, influence] of highlightData.vertexInfluence) {
    if (influence < 0.5) continue;
    const point = projected[index];
    const radius = 1 + influence * 1.7;
    meshContext.beginPath();
    meshContext.arc(point.x, point.y, radius, 0, Math.PI * 2);
    meshContext.fillStyle = `rgba(151, 244, 255, ${0.14 + influence * 0.42})`;
    meshContext.fill();
  }
  meshContext.restore();
}

function drawProcessPendingMovementHighlights(mesh, projected) {
  if (!currentField) return;

  const processPulse = processTracePulseForFrame(performance.now());
  const processSpec = processHighlightSpecForControl(activeHighlightControlId);
  const highlightedFaces = mesh.faces.map((face, faceIndex) => {
    const faceOrder = Number.isInteger(face.order) ? face.order : faceIndex;
    const influence = processMovementHighlightForFace(currentField, faceOrder, activeHighlightControlId);
    const depth = face.indices.reduce((sum, index) => sum + projected[index].depth, 0) / face.indices.length;
    return {
      influence,
      depth,
      points: face.indices.map((index) => projected[index]),
    };
  }).filter((face) => face.influence > processSpec.threshold).sort((a, b) => a.depth - b.depth);

  meshContext.save();
  meshContext.globalCompositeOperation = 'screen';
  for (const face of highlightedFaces) {
    const style = processMovementHighlightStyle(activeHighlightControlId, face.influence, { pulse: processPulse });
    meshContext.beginPath();
    meshContext.moveTo(face.points[0].x, face.points[0].y);
    for (const point of face.points.slice(1)) meshContext.lineTo(point.x, point.y);
    meshContext.closePath();
    meshContext.fillStyle = style.fill;
    meshContext.fill();
    meshContext.strokeStyle = style.stroke;
    meshContext.lineWidth = style.lineWidth;
    meshContext.stroke();
  }
  meshContext.restore();
}

function drawMeshDeltaPulse(mesh, projected, time) {
  const pulse = meshDeltaPulseForFrame(time);
  if (!pulse || !meshDeltaPulse) return;

  const deltaFaces = mesh.faces.map((face) => {
    const delta = meshDeltaForFace(meshDeltaPulse.from, meshDeltaPulse.to, face);
    const depth = face.indices.reduce((sum, index) => sum + projected[index].depth, 0) / face.indices.length;
    return {
      delta,
      depth,
      points: face.indices.map((index) => projected[index]),
    };
  }).filter((face) => face.delta && face.delta.intensity > 0.08).sort((a, b) => a.depth - b.depth);

  meshContext.save();
  meshContext.globalCompositeOperation = 'screen';
  for (const face of deltaFaces) {
    meshContext.beginPath();
    meshContext.moveTo(face.points[0].x, face.points[0].y);
    for (const point of face.points.slice(1)) meshContext.lineTo(point.x, point.y);
    meshContext.closePath();
    meshContext.fillStyle = meshDeltaColorForFace(face.delta, pulse);
    meshContext.fill();
  }
  meshContext.restore();
}

function rotateVertex(vertex, camera) {
  const cos = Math.cos(camera.yaw);
  const sin = Math.sin(camera.yaw);
  const x = vertex[0] * cos - vertex[1] * sin;
  const y = vertex[0] * sin + vertex[1] * cos;
  const z = vertex[2];
  const pitch = camera.pitch;
  const cp = Math.cos(pitch);
  const sp = Math.sin(pitch);
  return [x, y * cp - z * sp, y * sp + z * cp];
}

function drawMeshPreview(time) {
  meshRenderHandle = 0;
  if (!meshRenderDirty && !meshAnimationActive()) return;
  meshRenderDirty = false;

  const width = meshCanvas.width;
  const height = meshCanvas.height;
  meshContext.clearRect(0, 0, width, height);
  meshContext.fillStyle = '#0e1015';
  meshContext.fillRect(0, 0, width, height);

  const renderMesh = meshForFrame(time);
  if (!renderMesh) {
    if (meshAnimationActive()) requestMeshRender();
    return;
  }

  const projected = renderMesh.vertices.map((vertex) => {
    const [x, y, z] = rotateVertex(vertex, meshCamera);
    const perspective = 1.5 / (1.7 + y);
    return {
      x: width * 0.5 + meshCamera.panX + x * width * 1.28 * perspective * meshCamera.zoom,
      y: height * 0.55 + meshCamera.panY - z * height * 1.55 * perspective * meshCamera.zoom + y * height * 0.18,
      depth: y,
      light: clamp(0.58 + z * 0.75 - y * 0.2, 0.34, 1.15),
    };
  });

  const renderFaces = renderMesh.faces.map((face) => {
    const points = face.indices.map((index) => projected[index]);
    const depth = points.reduce((sum, point) => sum + point.depth, 0) / points.length;
    const light = points.reduce((sum, point) => sum + point.light, 0) / points.length;
    return { points, depth, light, material: face.material, order: face.order, indices: face.indices };
  }).sort((a, b) => a.depth - b.depth);

  const processPulse = processTracePulseForFrame(time);
  const showProcessTraces = processTracesEnabled && currentField;
  const showQualityOverlay = selectedMaskView === 'quality' && currentField;
  const issueFaceOrder = activeQualityFaceOrder();
  let activeIssueFace = null;
  for (const face of renderFaces) {
    if (issueFaceOrder !== null && Number(face.order) === issueFaceOrder) activeIssueFace = face;
    meshContext.beginPath();
    meshContext.moveTo(face.points[0].x, face.points[0].y);
    for (const point of face.points.slice(1)) meshContext.lineTo(point.x, point.y);
    meshContext.closePath();
    const baseColor = materialColor(face.material, face.light);
    meshContext.fillStyle = processTraceColorForFace(baseColor, currentField, face.order, {
      enabled: showProcessTraces,
      pulse: processPulse,
      trace: showProcessTraces ? focusedTraceForFace(face.order) : null,
    });
    meshContext.fill();
    if (showQualityOverlay) {
      const risk = qualityRiskForFace(renderMesh, currentField, face);
      meshContext.save();
      meshContext.globalCompositeOperation = 'screen';
      meshContext.fillStyle = qualityRiskColorForFace(risk, 0.86);
      meshContext.fill();
      meshContext.restore();
    }
    meshContext.strokeStyle = `rgba(255,255,255,${meshWireAlphaForFaceCount(renderMesh.faces.length)})`;
    meshContext.stroke();
  }
  drawQualityIssueHighlight(meshContext, activeIssueFace?.points, { lineWidth: 2.2, glow: 14 });

  drawMeshDeltaPulse(renderMesh, projected, time);
  drawPendingMovementHighlights(renderMesh, projected);

  if (meshTransition && currentLayout) {
    drawLayoutPreview(currentLayout, renderMesh, { refreshLegend: false });
  }

  if (meshAnimationActive()) requestMeshRender();
}

meshCanvas.addEventListener('pointerdown', (event) => {
  meshCanvas.setPointerCapture(event.pointerId);
  meshDrag = {
    pointerId: event.pointerId,
    x: event.clientX,
    y: event.clientY,
  };
  meshCanvas.classList.add('dragging');
});

meshCanvas.addEventListener('pointermove', (event) => {
  if (!meshDrag || meshDrag.pointerId !== event.pointerId) return;
  meshCamera = dragOrbitCamera(meshCamera, event.clientX - meshDrag.x, event.clientY - meshDrag.y);
  meshDrag.x = event.clientX;
  meshDrag.y = event.clientY;
  updateViewportHud();
  requestMeshRender();
  redrawLayoutIfReady();
});

meshCanvas.addEventListener('pointerup', (event) => {
  if (meshDrag?.pointerId === event.pointerId) {
    meshDrag = null;
    meshCanvas.classList.remove('dragging');
    requestMeshRender();
  }
});

meshCanvas.addEventListener('pointercancel', () => {
  meshDrag = null;
  meshCanvas.classList.remove('dragging');
  requestMeshRender();
});

meshCanvas.addEventListener('wheel', (event) => {
  event.preventDefault();
  meshCamera = wheelOrbitCamera(meshCamera, event.deltaY);
  updateViewportHud();
  requestMeshRender();
  redrawLayoutIfReady();
}, { passive: false });

window.addEventListener('pointerup', finishControlInteraction);
window.addEventListener('pointercancel', finishControlInteraction);

meshCanvas.addEventListener('dblclick', () => {
  meshCamera = defaultOrbitCamera();
  updateViewportHud();
  requestMeshRender();
  redrawLayoutIfReady();
});

resetCameraButton.addEventListener('click', () => {
  meshCamera = defaultOrbitCamera();
  updateViewportHud();
  requestMeshRender();
  redrawLayoutIfReady();
});

layoutCanvas.addEventListener('pointermove', updateMapProbeAtPointer);
layoutCanvas.addEventListener('pointerleave', hideMapProbe);
layoutCanvas.addEventListener('pointercancel', hideMapProbe);

function escapeHtml(value) {
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function maskPercent(value) {
  return `${Math.round(clamp(Number(value) || 0, 0, 1) * 100)}%`;
}

function hideMapProbe() {
  mapProbeHud.classList.add('hidden');
  setAdvisorControlFocus([]);
}

function sameControlFocus(controlIds) {
  if (activeAdvisorControlIds.size !== controlIds.length) return false;
  return controlIds.every((id) => activeAdvisorControlIds.has(id));
}

function setAdvisorControlFocus(controlIds) {
  const ids = controlIds.filter(Boolean);
  if (sameControlFocus(ids)) return;
  activeAdvisorControlIds = new Set(ids);
  controlCards.querySelectorAll('[data-control-id]').forEach((card) => {
    const active = activeAdvisorControlIds.has(card.dataset.controlId);
    card.classList.toggle('advisor-linked', active);
  });
}

function renderAdvisorControls(controls) {
  if (!controls.length) return '<span class="advisor-control muted">No linked control</span>';
  return controls.map((control) => `
    <span class="advisor-control" title="${escapeHtml(control.intent)}">${escapeHtml(control.label)}</span>
  `).join('');
}

function renderAdvisorLayers(layers) {
  if (!layers?.length) return '';
  return `<em class="advisor-layers">${layers.map(escapeHtml).join(' / ')}</em>`;
}

function renderNudgePlan(steps) {
  if (!steps.length) return '';
  const planLabel = steps.map((step) => `${step.label} ${step.deltaLabel}`).join(' / ');
  return `
    <div class="repair-nudge-plan" title="${escapeHtml(`Nudge plan: ${planLabel}`)}">
      <b>Nudge plan</b>
      ${steps.map((step) => `
        <span class="repair-nudge-chip ${escapeHtml(step.direction)}">
          ${escapeHtml(step.label)}
          <em>${escapeHtml(step.deltaLabel)}</em>
        </span>
      `).join('')}
    </div>
  `;
}

function renderQualityRepairQueue(report = currentQualityReport) {
  currentQualityReport = report || null;
  const issues = currentQualityReport?.topIssues?.slice(0, 4) || [];
  qualityRepairQueue.classList.remove('hidden', 'is-pending', 'is-stable', 'has-issues');
  qualityRepairQueue.classList.toggle('is-pending', !currentQualityReport);
  qualityRepairQueue.classList.toggle('is-stable', Boolean(currentQualityReport && !issues.length));
  qualityRepairQueue.classList.toggle('has-issues', Boolean(issues.length));

  const summary = currentQualityReport?.summary
    || (currentQualityReport ? `${currentQualityReport.issueCount || issues.length} issues` : 'waiting for preview');
  const nudgeResult = activeNudgeReview ? `
    <div class="repair-nudge-result ${escapeHtml(activeNudgeReview.status)}">
      <b>${escapeHtml(activeNudgeReview.statusLabel)}</b>
      <span>${escapeHtml(activeNudgeReview.deltaLabel || activeNudgeReview.label)}</span>
      <small>${escapeHtml(activeNudgeReview.summary)}</small>
    </div>
  ` : '';

  if (!currentQualityReport) {
    activeQualityIssue = null;
    setAdvisorControlFocus([]);
    qualityRepairQueue.innerHTML = `
      <div class="repair-queue-head">
        <b>Quality Issues</b>
        <span>${escapeHtml(summary)}</span>
      </div>
      <div class="repair-empty pending">
        <b>Quality checks pending</b>
        <span>Preview bake will surface repair targets here.</span>
      </div>
    `;
    return;
  }

  if (!issues.length) {
    activeQualityIssue = null;
    setAdvisorControlFocus([]);
    qualityRepairQueue.innerHTML = `
      <div class="repair-queue-head">
        <b>Quality Issues</b>
        <span>${escapeHtml(summary)}</span>
      </div>
      ${nudgeResult}
      <div class="repair-empty stable">
        <b>No top issues</b>
        <span>Mesh checks are clean for this preview.</span>
      </div>
    `;
    return;
  }

  if (activeQualityIssue && !issues.some((issue) => issue.faceOrder === activeQualityIssue.faceOrder)) {
    activeQualityIssue = null;
  }
  qualityRepairQueue.innerHTML = `
    <div class="repair-queue-head">
      <b>Quality Issues</b>
      <span>${escapeHtml(summary)}</span>
    </div>
    ${nudgeResult}
    <div class="repair-issues">
      ${issues.map((issue, index) => {
        const active = activeQualityIssue?.faceOrder === issue.faceOrder;
        const controls = (issue.suggestedControls || []).map((control) => control.label).slice(0, 2).join(' / ');
        const nudgePlan = qualityNudgePlanSummaryForIssue(issue);
        const nudgeTitle = nudgePlan.length
          ? `Apply: ${nudgePlan.map((step) => `${step.label} ${step.deltaLabel}`).join(' / ')}`
          : 'No nudge plan available';
        return `
          <div class="repair-issue ${escapeHtml(issue.severity || 'low')} ${active ? 'active' : ''}">
            <button class="repair-issue-main" type="button" data-issue-index="${index}">
              <span>${escapeHtml(issue.scoreLabel || maskPercent(issue.score))}</span>
              <b>${escapeHtml(issue.label)}</b>
              <em>${escapeHtml(issue.region || `Face ${issue.faceOrder}`)}</em>
              <small>${escapeHtml(controls || issue.suggestion || 'Review diagnostics')}</small>
            </button>
            <button class="repair-nudge" type="button" title="${escapeHtml(nudgeTitle)}" data-issue-nudge-index="${index}">Nudge</button>
            ${renderNudgePlan(nudgePlan)}
          </div>
        `;
      }).join('')}
    </div>
  `;
  qualityRepairQueue.querySelectorAll('[data-issue-index]').forEach((button) => {
    button.addEventListener('click', () => focusQualityIssue(Number(button.dataset.issueIndex)));
  });
  qualityRepairQueue.querySelectorAll('[data-issue-nudge-index]').forEach((button) => {
    const issueIndex = Number(button.dataset.issueNudgeIndex);
    button.addEventListener('click', () => nudgeQualityIssue(issueIndex));
    button.addEventListener('mouseenter', () => previewNudgePlan(issueIndex));
    button.addEventListener('focus', () => previewNudgePlan(issueIndex));
    button.addEventListener('mouseleave', clearNudgePlanPreview);
    button.addEventListener('blur', clearNudgePlanPreview);
  });
}

function updateNudgeReviewWithReport(report) {
  if (!activeNudgeReview?.beforeIssue || !report) return;
  activeNudgeReview = qualityNudgeResultForIssue(activeNudgeReview.beforeIssue, report);
}

function focusQualityIssue(issueIndex) {
  const issue = currentQualityReport?.topIssues?.[issueIndex];
  if (!issue) return;

  activeQualityIssue = { ...issue, issueIndex };
  const layer = processLayerForQualityIssue(issue);
  activeProcessLayerId = layer.layerId;
  selectedMaskView = layer.maskView;
  const controlIds = (issue.suggestedControls || []).map((control) => control.id);
  const firstGroup = controlIds.map(controlGroupForId).find(Boolean);
  if (firstGroup) activeControlGroup = firstGroup;
  activeHighlightControlId = controlIds[0] || null;
  setAdvisorControlFocus(controlIds);
  if (currentLayout) renderBiomeControls(currentLayout);
  renderProcessLayerStack();
  renderQualityRepairQueue();
  setAdvisorControlFocus(controlIds);
  controlCards.querySelector('.advisor-linked')?.scrollIntoView({ block: 'nearest' });
  requestMeshRender();
  redrawLayoutIfReady();
}

function previewNudgePlan(issueIndex) {
  const issue = currentQualityReport?.topIssues?.[issueIndex];
  const controlIds = qualityNudgePlanForIssue(issue).map((step) => step.controlId).filter(Boolean);
  if (!controlIds.length) return;
  activeHighlightControlId = controlIds[0];
  setAdvisorControlFocus(controlIds);
  requestMeshRender();
  redrawLayoutIfReady();
}

function clearNudgePlanPreview() {
  const controlIds = activeQualityIssue
    ? (activeQualityIssue.suggestedControls || []).map((control) => control.id).filter(Boolean)
    : [];
  activeHighlightControlId = controlIds[0] || null;
  setAdvisorControlFocus(controlIds);
  requestMeshRender();
  redrawLayoutIfReady();
}

function nudgeQualityIssue(issueIndex) {
  const issue = currentQualityReport?.topIssues?.[issueIndex];
  if (!issue || currentLayout?.biome !== 'fire') return;
  const plan = qualityNudgePlanForIssue(issue);
  if (!plan.length) return;

  activeNudgeReview = qualityNudgeResultForIssue(issue, null);
  focusQualityIssue(issueIndex);
  const controls = controlSpec(currentLayout);
  const applied = [];
  for (const step of plan) {
    const control = controls.find((candidate) => candidate.id === step.controlId);
    if (!control) continue;
    const previous = Number(control.value);
    const next = Number(clamp(roundTo(previous + step.delta, control.step), control.min, control.max).toFixed(4));
    if (!Number.isFinite(next) || next === previous) continue;
    control.update(next);
    applied.push(`${control.title}: ${formatControlValue(control, next)}`);
  }

  if (!applied.length) {
    generationStatus.textContent = `No safe nudge available for ${issue.label}.`;
    return;
  }

  if (autoLinkToggle.checked && plan.some((step) => step.controlId === 'volcanoDominance')) {
    applyVolcanicCoherence(currentLayout);
  }
  activeHighlightControlId = plan[0]?.controlId || null;
  renderControls(currentLayout);
  renderQualityRepairQueue();
  setAdvisorControlFocus(plan.map((step) => step.controlId));
  handleLayoutEdited(currentLayout);
  generationStatus.textContent = `Nudged ${issue.label}: ${applied.join(', ')}. Preview bake queued.`;
}

function renderMapProbe(hit, event) {
  if (!hit) {
    hideMapProbe();
    return;
  }

  const sample = hit.sample || fieldFaceSampleForOrder(currentField, hit.faceOrder);
  if (!sample) {
    hideMapProbe();
    return;
  }

  const advisor = hit.mesh && hit.face
    ? qualityAdvisorForFace(hit.mesh, currentField, hit.face)
    : null;
  setAdvisorControlFocus(advisor?.controls.map((control) => control.id) || []);

  const mapRect = layoutCanvas.parentElement.getBoundingClientRect();
  const probeWidth = 292;
  const probeHeight = 266;
  const left = clamp(event.clientX - mapRect.left + 14, 8, Math.max(8, mapRect.width - probeWidth - 8));
  const top = clamp(event.clientY - mapRect.top + 14, 8, Math.max(8, mapRect.height - probeHeight - 8));

  mapProbeHud.style.left = `${left}px`;
  mapProbeHud.style.top = `${top}px`;
  mapProbeHud.innerHTML = `
    <div class="probe-title">
      <b>R${String(sample.ring).padStart(2, '0')} / S${String(sample.segment).padStart(3, '0')}</b>
      <span>${escapeHtml(hit.material.replace(/^M_/, ''))}</span>
    </div>
    <dl>
      <div><dt>Height</dt><dd>${sample.heightM.toFixed(2)}m</dd></div>
      <div class="${selectedMaskView === 'slope' ? 'active' : ''}"><dt>Slope</dt><dd>${maskPercent(sample.masks.slope)}</dd></div>
      <div class="${selectedMaskView === 'talus' ? 'active' : ''}"><dt>Talus</dt><dd>${maskPercent(sample.masks.talus)}</dd></div>
      <div class="${selectedMaskView === 'lavaFlow' ? 'active' : ''}"><dt>Lava flow</dt><dd>${maskPercent(sample.masks.lavaFlow)}</dd></div>
    </dl>
    ${advisor ? `
      <div class="probe-advisor ${escapeHtml(advisor.severity)}">
        <div class="advisor-head">
          <b>${escapeHtml(advisor.title)}</b>
          <span>${escapeHtml(advisor.severityLabel)} · ${maskPercent(advisor.risk?.score || 0)}</span>
        </div>
        <p>${escapeHtml(advisor.reasons[0] || advisor.summary)}</p>
        <div class="advisor-controls">${renderAdvisorControls(advisor.controls)}</div>
        ${renderAdvisorLayers(advisor.layers)}
        <small>${escapeHtml(advisor.suggestion)}</small>
      </div>
    ` : ''}
  `;
  mapProbeHud.classList.remove('hidden');
}

function updateMapProbeAtPointer(event) {
  if (!currentField || !mapHitRegions.length) {
    hideMapProbe();
    return;
  }
  const rect = layoutCanvas.getBoundingClientRect();
  const point = {
    x: (event.clientX - rect.left) * (layoutCanvas.width / rect.width),
    y: (event.clientY - rect.top) * (layoutCanvas.height / rect.height),
  };
  renderMapProbe(faceHitAtPoint(mapHitRegions, point), event);
}

function drawMapBadge(code, x, y, tone = '#dfe7f7') {
  layoutContext.save();
  layoutContext.beginPath();
  layoutContext.arc(x, y, 14, 0, Math.PI * 2);
  layoutContext.fillStyle = 'rgba(9, 11, 15, 0.82)';
  layoutContext.fill();
  layoutContext.lineWidth = 2;
  layoutContext.strokeStyle = tone;
  layoutContext.stroke();
  layoutContext.fillStyle = '#f4f7fb';
  layoutContext.font = '900 10px Inter, system-ui, sans-serif';
  layoutContext.textAlign = 'center';
  layoutContext.textBaseline = 'middle';
  layoutContext.fillText(code, x, y + 0.5);
  layoutContext.restore();
}

function renderLayoutLegend(layout) {
  if (selectedMaskView === 'quality') {
    const metrics = qualityMetricsForMesh(previewMesh, currentField);
    layoutLegend.innerHTML = [
      { code: 'RT', label: `Route ${metrics.routeHealthLabel}`, color: '#ff5a3e', description: 'walkable path stability' },
      { code: 'DT', label: `Detail ${metrics.overDetailLabel}`, color: '#ece49c', description: 'surface noise risk' },
      { code: 'ED', label: `Edge ${metrics.thinEdgeLabel}`, color: '#76cdff', description: 'thin silhouette risk' },
    ].map((entry) => `
      <div class="map-legend-item process-legend-item">
        <i style="border-color:${entry.color}; color:${entry.color}">${entry.code}</i>
        <div>
          <b>${escapeHtml(entry.label)}</b>
          <span>${escapeHtml(entry.description)}</span>
        </div>
      </div>
    `).join('');
    semanticSummary.textContent = `Diagnostics: ${metrics.summary}. Red marks route damage, pale marks over-detail, blue marks thin edge risk.`;
    return [];
  }

  if (selectedMaskView !== 'material') {
    const activeLayer = processLayerStack(currentField, activeProcessLayerId).find((layer) => layer.active);
    const meta = {
      slope: { title: 'Slope mask', low: 'gentle shelves', high: 'steep faces' },
      talus: { title: 'Talus mask', low: 'stable rock', high: 'deposition band' },
      lavaFlow: { title: 'Lava flow mask', low: 'cold basalt', high: 'active channels' },
    }[selectedMaskView] || { title: 'Process mask', low: 'low influence', high: 'high influence' };
    const title = activeLayer?.traceKind ? `${activeLayer.label} layer` : meta.title;
    layoutLegend.innerHTML = [
      { code: 'LO', label: meta.low, color: maskColorForValue(selectedMaskView, 0.08), description: 'low process influence' },
      { code: 'MID', label: title, color: maskColorForValue(selectedMaskView, 0.52), description: 'latest server preview field' },
      { code: 'HI', label: meta.high, color: maskColorForValue(selectedMaskView, 1), description: 'high process influence' },
    ].map((entry) => `
      <div class="map-legend-item process-legend-item">
        <i style="border-color:${entry.color}; color:${entry.color}">${entry.code}</i>
        <div>
          <b>${escapeHtml(entry.label)}</b>
          <span>${escapeHtml(entry.description)}</span>
        </div>
      </div>
    `).join('');
    semanticSummary.textContent = `${title} over the current OBJ footprint. Bright faces carry stronger baker influence.`;
    return [];
  }

  const badges = semanticBadgesForLayout(layout);
  const legend = semanticLegendForLayout(layout).map((entry) => {
    const directBadge = badges.find((item) => item.id === entry.id);
    const badge = directBadge || badges.find((item) => {
      if (entry.id === 'arena') return item.code === 'AR';
      if (entry.id === 'hazard') return item.code === 'HZ';
      if (entry.id === 'pcg') return item.code === 'PC';
      if (entry.id === 'route') return item.code === 'RT';
      if (entry.id === 'landmark' || entry.id === 'attachment') return item.code === 'LM';
      return false;
    });
    return { ...entry, code: entry.code || badge?.code || '' };
  });
  layoutLegend.innerHTML = legend.map((entry) => `
    <div class="map-legend-item">
      <i style="border-color:${entry.color}; color:${entry.color}">${entry.code}</i>
      <div>
        <b>${escapeHtml(entry.label)}</b>
        <span>${escapeHtml(entry.description)}</span>
      </div>
    </div>
  `).join('');
  semanticSummary.textContent = `${legend.length} editable sources over the OBJ footprint. Dragging highlights likely movement; release the slider to fit the server preview.`;
  return badges;
}

function materialCentroid(mesh, projected, materials) {
  const materialSet = new Set(materials);
  let x = 0;
  let y = 0;
  let z = 0;
  let count = 0;
  for (const face of mesh.faces) {
    if (!materialSet.has(face.material)) continue;
    for (const index of face.indices) {
      x += projected[index].x;
      y += projected[index].y;
      z += mesh.vertices[index][2];
      count += 1;
    }
  }
  return count ? { x: x / count, y: y / count, z: z / count } : null;
}

function highestProjectedPoint(mesh, projected) {
  let bestIndex = 0;
  for (let index = 1; index < mesh.vertices.length; index += 1) {
    if (mesh.vertices[index][2] > mesh.vertices[bestIndex][2]) bestIndex = index;
  }
  return projected[bestIndex];
}

function landmarkById(layout, id) {
  return (layout?.landmarks || []).find((item) => item.id === id) || null;
}

function pathById(layout, id) {
  return (layout?.paths || []).find((item) => item.id === id) || null;
}

function zoneById(layout, id) {
  return (layout?.zones || []).find((item) => item.id === id) || null;
}

function layoutAnchorPoint(point, frame, footprintRadius, color, offset = [0, 0]) {
  const projected = livePoint(point, frame, footprintRadius);
  return { x: projected.x + offset[0], y: projected.y + offset[1], color };
}

function badgeAnchor(badge, layout, mesh, projected, frame, footprintRadius) {
  if (badge.code === 'CV') {
    const point = highestProjectedPoint(mesh, projected);
    return { x: point.x, y: point.y + 18, color: '#ff6a38' };
  }
  if (badge.code === 'AP') {
    const centroid = materialCentroid(mesh, projected, ['M_PathDirt']);
    if (centroid) return { x: centroid.x + 18, y: centroid.y, color: '#d6a15a' };
  }
  if (badge.code === 'CL') {
    const point = projectTopDownVertex([0.34, 0.26, 0], frame);
    return { x: point.x, y: point.y, color: '#ffcd7c' };
  }
  if (badge.code === 'LC') {
    const centroid = materialCentroid(mesh, projected, ['M_ElementCrack']);
    if (centroid) return { x: centroid.x + 16, y: centroid.y - 10, color: '#ff6438' };
  }
  if (badge.code === 'IW') {
    const wall = landmarkById(layout, 'primary_crystal_wall') || {};
    const radius = Number(wall.radius ?? 0.54);
    const angle = 1.18;
    return layoutAnchorPoint([Math.cos(angle) * radius, Math.sin(angle) * radius], frame, footprintRadius, '#8eefff', [0, -16]);
  }
  if (badge.code === 'CS') {
    return layoutAnchorPoint([0, 0], frame, footprintRadius, '#e7fbff', [0, 18]);
  }
  if (badge.code === 'BP') {
    const plate = pathById(layout, 'broken_ice_ring') || {};
    const radius = Array.isArray(plate.points?.[0]) ? Number(plate.points[0][0] || 0.62) : 0.62;
    return layoutAnchorPoint([radius, 0], frame, footprintRadius, '#b9e8ff', [18, -2]);
  }
  if (badge.code === 'CR') {
    const centroid = materialCentroid(mesh, projected, ['M_ElementCrack']);
    if (centroid) return { x: centroid.x + 16, y: centroid.y - 10, color: '#47bce9' };
  }
  if (badge.code === 'RC') {
    const crystals = landmarkById(layout, 'secondary_spire_clusters') || {};
    const radius = Number(crystals.radius ?? 0.48);
    const angle = 0.28;
    return layoutAnchorPoint([Math.cos(angle) * radius, Math.sin(angle) * radius], frame, footprintRadius, '#d7fbff', [12, -16]);
  }
  if (badge.code === 'CP') {
    const canopy = zoneById(layout, 'canopy_platform') || {};
    return layoutAnchorPoint(canopy.center || [0, 0], frame, footprintRadius, '#73d66f', [0, 18]);
  }
  if (badge.code === 'RA') {
    const root = landmarkById(layout, 'root_arch') || {};
    return layoutAnchorPoint(root.center || [0.35, -0.1], frame, footprintRadius, '#a7d76b', [8, -16]);
  }
  if (badge.code === 'SC') {
    const stump = landmarkById(layout, 'tree_stump_cave') || {};
    return layoutAnchorPoint(stump.center || [-0.25, 0.25], frame, footprintRadius, '#9b7a52', [-10, 16]);
  }
  if (badge.code === 'MP') {
    const mushroom = zoneById(layout, 'mushroom_pocket') || {};
    return layoutAnchorPoint(mushroom.center || [0.28, 0.34], frame, footprintRadius, '#b87dff', [14, -16]);
  }
  if (badge.code === 'VB') {
    const vine = pathById(layout, 'vine_bridge') || {};
    const points = Array.isArray(vine.points) && vine.points.length >= 2 ? vine.points : [[0.62, 0.18], [0.2, 0.42]];
    const first = points[0];
    const last = points[points.length - 1];
    return layoutAnchorPoint([(first[0] + last[0]) * 0.5, (first[1] + last[1]) * 0.5], frame, footprintRadius, '#65d4a0', [0, -18]);
  }
  if (badge.code === 'HZ') {
    const centroid = materialCentroid(mesh, projected, ['M_ElementCrack']);
    if (centroid) return { x: centroid.x + 16, y: centroid.y - 10, color: '#ff6438' };
  }
  if (badge.code === 'RT') {
    const centroid = materialCentroid(mesh, projected, ['M_PathDirt']);
    if (centroid) return { x: centroid.x + 18, y: centroid.y, color: '#d6a15a' };
  }
  if (badge.code === 'LM') {
    const point = highestProjectedPoint(mesh, projected);
    return { x: point.x, y: point.y + 20, color: '#ff5a2d' };
  }
  if (badge.code === 'PC') {
    const topMaterials = layout?.biome === 'fire' ? ['M_AshPlateau', 'M_TopGrass'] : ['M_TopGrass'];
    const centroid = materialCentroid(mesh, projected, topMaterials);
    if (centroid) return { x: centroid.x - 28, y: centroid.y - 24, color: '#68d391' };
  }
  return { x: frame.width * 0.5 - 34, y: frame.height * 0.5 - 34, color: '#8d94a3' };
}

function livePoint(point, frame, footprintRadius) {
  return layoutPointToTopDown(point, frame, footprintRadius);
}

function distanceBetween(a, b) {
  return Math.hypot(a.x - b.x, a.y - b.y);
}

function layoutUnitScale(frame, footprintRadius) {
  return distanceBetween(livePoint([0, 0], frame, footprintRadius), livePoint([1, 0], frame, footprintRadius));
}

function drawLayoutCircle(frame, footprintRadius, centerPoint, radius, options = {}) {
  const center = livePoint(centerPoint, frame, footprintRadius);
  const edge = livePoint([centerPoint[0] + radius, centerPoint[1]], frame, footprintRadius);
  const pixelRadius = distanceBetween(center, edge);

  layoutContext.beginPath();
  if (options.dash) layoutContext.setLineDash(options.dash);
  layoutContext.arc(center.x, center.y, pixelRadius, 0, Math.PI * 2);
  if (options.fillStyle) {
    layoutContext.fillStyle = options.fillStyle;
    layoutContext.fill();
  }
  if (options.strokeStyle) {
    layoutContext.lineWidth = options.lineWidth || 2;
    layoutContext.strokeStyle = options.strokeStyle;
    layoutContext.stroke();
  }
  layoutContext.setLineDash([]);
  return { center, radius: pixelRadius };
}

function drawLayoutPolyline(frame, footprintRadius, points, options = {}) {
  if (!Array.isArray(points) || points.length < 2) return;
  layoutContext.beginPath();
  points.map((point) => livePoint(point, frame, footprintRadius)).forEach((point, index) => {
    if (index === 0) layoutContext.moveTo(point.x, point.y);
    else layoutContext.lineTo(point.x, point.y);
  });
  layoutContext.lineCap = options.lineCap || 'round';
  layoutContext.lineJoin = options.lineJoin || 'round';
  layoutContext.lineWidth = options.lineWidth || 4;
  layoutContext.strokeStyle = options.strokeStyle || 'rgba(255, 255, 255, 0.5)';
  if (options.dash) layoutContext.setLineDash(options.dash);
  layoutContext.stroke();
  layoutContext.setLineDash([]);
}

function drawLayoutRay(frame, footprintRadius, angle, innerRadius, outerRadius, options = {}) {
  drawLayoutPolyline(
    frame,
    footprintRadius,
    [
      [Math.cos(angle) * innerRadius, Math.sin(angle) * innerRadius],
      [Math.cos(angle) * outerRadius, Math.sin(angle) * outerRadius],
    ],
    options,
  );
}

function drawShardMarker(frame, footprintRadius, angle, radius, options = {}) {
  const tip = livePoint([Math.cos(angle) * (radius + 0.055), Math.sin(angle) * (radius + 0.055)], frame, footprintRadius);
  const left = livePoint([Math.cos(angle - 0.045) * (radius - 0.035), Math.sin(angle - 0.045) * (radius - 0.035)], frame, footprintRadius);
  const right = livePoint([Math.cos(angle + 0.045) * (radius - 0.035), Math.sin(angle + 0.045) * (radius - 0.035)], frame, footprintRadius);
  layoutContext.beginPath();
  layoutContext.moveTo(tip.x, tip.y);
  layoutContext.lineTo(left.x, left.y);
  layoutContext.lineTo(right.x, right.y);
  layoutContext.closePath();
  layoutContext.fillStyle = options.fillStyle || 'rgba(215, 251, 255, 0.58)';
  layoutContext.strokeStyle = options.strokeStyle || 'rgba(104, 221, 255, 0.86)';
  layoutContext.lineWidth = options.lineWidth || 1.5;
  layoutContext.fill();
  layoutContext.stroke();
}

function drawOverlayHud(label, strokeStyle, textStyle) {
  layoutContext.fillStyle = 'rgba(8, 10, 14, 0.74)';
  layoutContext.strokeStyle = strokeStyle;
  layoutContext.lineWidth = 1;
  layoutContext.beginPath();
  if (typeof layoutContext.roundRect === 'function') {
    layoutContext.roundRect(12, 12, 150, 26, 7);
  } else {
    layoutContext.rect(12, 12, 150, 26);
  }
  layoutContext.fill();
  layoutContext.stroke();
  layoutContext.fillStyle = textStyle;
  layoutContext.font = '800 11px Inter, system-ui, sans-serif';
  layoutContext.textBaseline = 'middle';
  layoutContext.fillText(label, 24, 25);
}

function drawFireLiveOverlay(spec, frame, footprintRadius) {
  if (!spec.enabled) return;

  const center = livePoint([0, 0], frame, footprintRadius);
  const edge = livePoint([0.92, 0], frame, footprintRadius);
  const throat = livePoint([Math.max(0.24, spec.craterRadius * 0.72), 0], frame, footprintRadius);
  const unitScale = layoutUnitScale(frame, footprintRadius);
  const craterRadius = distanceBetween(center, livePoint([spec.craterRadius, 0], frame, footprintRadius));
  const liftAlpha = clamp(0.24 + spec.craterLift * 0.18, 0.28, 0.5);

  layoutContext.save();
  layoutContext.setLineDash([8, 7]);
  layoutContext.beginPath();
  layoutContext.arc(center.x, center.y, craterRadius, 0, Math.PI * 2);
  layoutContext.fillStyle = `rgba(255, 90, 45, ${liftAlpha * 0.38})`;
  layoutContext.fill();
  layoutContext.lineWidth = 2;
  layoutContext.strokeStyle = `rgba(255, 138, 80, ${liftAlpha + 0.22})`;
  layoutContext.stroke();

  layoutContext.beginPath();
  layoutContext.moveTo(edge.x, edge.y);
  layoutContext.lineTo(throat.x, throat.y);
  layoutContext.setLineDash([]);
  layoutContext.lineCap = 'round';
  layoutContext.lineWidth = Math.max(8, spec.pathWidth * unitScale);
  layoutContext.strokeStyle = 'rgba(255, 189, 96, 0.62)';
  layoutContext.stroke();

  const loopRadius = craterRadius;
  layoutContext.beginPath();
  layoutContext.setLineDash([10, 8]);
  layoutContext.lineWidth = Math.max(5, spec.loopWidth * unitScale);
  layoutContext.strokeStyle = 'rgba(255, 205, 124, 0.46)';
  layoutContext.arc(center.x, center.y, loopRadius, -Math.PI * spec.loopCoverage, Math.PI * spec.loopCoverage);
  layoutContext.stroke();

  layoutContext.setLineDash([]);
  for (const angle of spec.lavaAngles) {
    const inner = livePoint([Math.cos(angle) * 0.28, Math.sin(angle) * 0.28], frame, footprintRadius);
    const outerRadius = Math.max(0.95, spec.lavaRadius);
    const outer = livePoint([Math.cos(angle) * outerRadius, Math.sin(angle) * outerRadius], frame, footprintRadius);
    layoutContext.beginPath();
    layoutContext.moveTo(inner.x, inner.y);
    layoutContext.lineTo(outer.x, outer.y);
    layoutContext.lineWidth = 5;
    layoutContext.strokeStyle = 'rgba(255, 90, 45, 0.42)';
    layoutContext.stroke();
  }

  drawOverlayHud('Fire ranges', 'rgba(255, 189, 96, 0.58)', '#ffd8ba');
  layoutContext.restore();
}

function drawIceLiveOverlay(spec, frame, footprintRadius) {
  if (!spec.enabled) return;
  const unitScale = layoutUnitScale(frame, footprintRadius);

  layoutContext.save();
  drawLayoutCircle(frame, footprintRadius, [0, 0], spec.centralShelfRadius, {
    fillStyle: 'rgba(230, 251, 255, 0.14)',
    strokeStyle: 'rgba(231, 251, 255, 0.74)',
    lineWidth: 2,
  });
  drawLayoutCircle(frame, footprintRadius, [0, 0], spec.wallRadius, {
    fillStyle: 'rgba(77, 201, 255, 0.08)',
    strokeStyle: 'rgba(130, 238, 255, 0.84)',
    lineWidth: 2.2,
    dash: [5, 5],
  });
  drawLayoutCircle(frame, footprintRadius, [0, 0], spec.plateRadius, {
    strokeStyle: 'rgba(185, 232, 255, 0.72)',
    lineWidth: Math.max(4, spec.plateWidth * unitScale),
    dash: [12, 7, 3, 7],
  });

  for (const angle of spec.crackAngles) {
    drawLayoutRay(frame, footprintRadius, angle, spec.crackInnerRadius, spec.crackOuterRadius, {
      lineWidth: 6,
      strokeStyle: 'rgba(20, 118, 181, 0.52)',
    });
    drawLayoutRay(frame, footprintRadius, angle, spec.crackInnerRadius + 0.03, spec.crackOuterRadius - 0.04, {
      lineWidth: 2,
      strokeStyle: 'rgba(173, 239, 255, 0.64)',
    });
  }

  for (const angle of spec.wallAngles) {
    drawShardMarker(frame, footprintRadius, angle, spec.wallRadius, {
      fillStyle: 'rgba(142, 239, 255, 0.52)',
      strokeStyle: 'rgba(226, 253, 255, 0.92)',
      lineWidth: 2,
    });
  }
  for (const angle of spec.resourceAngles) {
    drawShardMarker(frame, footprintRadius, angle, spec.resourceRadius, {
      fillStyle: 'rgba(215, 251, 255, 0.42)',
      strokeStyle: 'rgba(89, 210, 255, 0.78)',
      lineWidth: 1.3,
    });
  }

  drawOverlayHud('Ice ranges', 'rgba(142, 239, 255, 0.62)', '#dffaff');
  layoutContext.restore();
}

function drawForestLiveOverlay(spec, frame, footprintRadius) {
  if (!spec.enabled) return;
  const unitScale = layoutUnitScale(frame, footprintRadius);

  layoutContext.save();
  drawLayoutCircle(frame, footprintRadius, spec.canopyCenter, spec.canopyRadius, {
    fillStyle: 'rgba(91, 190, 83, 0.15)',
    strokeStyle: 'rgba(115, 214, 111, 0.78)',
    lineWidth: 2,
  });
  drawLayoutPolyline(frame, footprintRadius, spec.mainPathPoints, {
    lineWidth: Math.max(8, spec.mainPathWidth * unitScale),
    strokeStyle: 'rgba(197, 161, 98, 0.45)',
  });
  drawLayoutPolyline(frame, footprintRadius, spec.vineBridgePoints, {
    lineWidth: Math.max(4, spec.vineBridgeWidth * unitScale),
    strokeStyle: 'rgba(101, 212, 160, 0.68)',
    dash: [6, 5],
  });
  drawLayoutCircle(frame, footprintRadius, spec.rootCenter, spec.rootRadius, {
    fillStyle: 'rgba(167, 215, 107, 0.13)',
    strokeStyle: 'rgba(167, 215, 107, 0.78)',
    lineWidth: 2,
  });
  drawLayoutCircle(frame, footprintRadius, spec.stumpCenter, spec.stumpRadius, {
    fillStyle: 'rgba(42, 24, 14, 0.28)',
    strokeStyle: 'rgba(155, 122, 82, 0.84)',
    lineWidth: 2.2,
  });
  drawLayoutCircle(frame, footprintRadius, spec.mushroomCenter, spec.mushroomOuterRadius, {
    fillStyle: 'rgba(184, 125, 255, 0.12)',
    strokeStyle: 'rgba(184, 125, 255, 0.78)',
    lineWidth: 2,
    dash: [7, 5],
  });
  drawLayoutCircle(frame, footprintRadius, spec.mushroomCenter, spec.mushroomInnerRadius, {
    fillStyle: 'rgba(78, 214, 190, 0.12)',
    strokeStyle: 'rgba(78, 214, 190, 0.62)',
    lineWidth: 1.4,
  });

  drawOverlayHud('Forest ranges', 'rgba(115, 214, 111, 0.58)', '#d8ffd4');
  layoutContext.restore();
}

function drawLiveOverlay(layout, frame, footprintRadius) {
  const spec = biomeLiveOverlaySpec(layout);
  if (!spec.enabled) return;
  if (spec.biome === 'ice') {
    drawIceLiveOverlay(spec, frame, footprintRadius);
    return;
  }
  if (spec.biome === 'forest') {
    drawForestLiveOverlay(spec, frame, footprintRadius);
    return;
  }
  drawFireLiveOverlay(spec, frame, footprintRadius);
}

function drawTopDownMesh(layout, mesh) {
  const width = layoutCanvas.width;
  const height = layoutCanvas.height;
  const frame = stableTopDownFrameForMesh(mesh.vertices, width, height, 34, meshCamera.yaw);
  const footprintRadius = footprintRadiusForMesh(mesh.vertices);
  const projected = mesh.vertices.map((vertex) => projectTopDownVertex(vertex, frame));
  mapHitRegions = [];

  const renderFaces = mesh.faces.map((face) => {
    const averageZ = face.indices.reduce((sum, index) => sum + mesh.vertices[index][2], 0) / face.indices.length;
    return { ...face, averageZ };
  }).sort((a, b) => a.averageZ - b.averageZ);

  layoutContext.save();
  layoutContext.shadowColor = 'rgba(0, 0, 0, 0.38)';
  layoutContext.shadowBlur = 18;
  layoutContext.shadowOffsetY = 14;
  let activeIssuePoints = null;
  const issueFaceOrder = activeQualityFaceOrder();
  for (const face of renderFaces) {
    const points = face.indices.map((index) => projected[index]);
    if (issueFaceOrder !== null && Number(face.order) === issueFaceOrder) activeIssuePoints = points;
    const light = clamp(0.7 + face.averageZ * 0.6, 0.42, 1.08);
    const alpha = face.material === 'M_UndersideRock' ? 0.2 : face.material === 'M_CliffRock' ? 0.42 : 0.9;
    const risk = selectedMaskView === 'quality'
      ? qualityRiskForFace(mesh, currentField, face)
      : null;
    const maskValue = selectedMaskView !== 'material' && selectedMaskView !== 'quality'
      ? maskValueForFaceOrder(currentField, face.order, selectedMaskView)
      : null;
    const sample = fieldFaceSampleForOrder(currentField, face.order);
    if (sample) {
      mapHitRegions.push({
        faceOrder: face.order,
        material: face.material,
        sample,
        face,
        mesh,
        points,
      });
    }
    layoutContext.beginPath();
    layoutContext.moveTo(points[0].x, points[0].y);
    for (const point of points.slice(1)) layoutContext.lineTo(point.x, point.y);
    layoutContext.closePath();
    layoutContext.fillStyle = risk?.score > 0.02
      ? qualityRiskColorForFace(risk, 0.92)
      : (maskValue === null
        ? materialColorWithAlpha(face.material, light, alpha)
        : maskColorForValue(selectedMaskView, maskValue));
    layoutContext.fill();
    layoutContext.shadowColor = 'transparent';
    layoutContext.strokeStyle = maskValue === null && !(risk?.score > 0.02)
      ? (face.material === 'M_UndersideRock' ? 'rgba(255,255,255,0.025)' : 'rgba(255,255,255,0.05)')
      : 'rgba(255,255,255,0.035)';
    layoutContext.lineWidth = 1;
    layoutContext.stroke();
  }
  layoutContext.restore();
  drawQualityIssueHighlight(layoutContext, activeIssuePoints, { lineWidth: 2.4, glow: 12 });

  if (selectedMaskView === 'material') {
    drawLiveOverlay(layout, frame, footprintRadius);
    const badges = semanticBadgesForLayout(layout);
    for (const badge of badges) {
      const anchor = badgeAnchor(badge, layout, mesh, projected, frame, footprintRadius);
      drawMapBadge(badge.code, anchor.x, anchor.y, anchor.color);
    }
  }
}

function drawLayoutPreview(layout, meshOverride = null, { refreshLegend = true } = {}) {
  const width = layoutCanvas.width;
  const height = layoutCanvas.height;
  layoutContext.clearRect(0, 0, width, height);
  layoutContext.fillStyle = '#0f1116';
  layoutContext.fillRect(0, 0, width, height);

  if (refreshLegend) renderLayoutLegend(layout);
  const footprintMesh = meshOverride || meshAtTransitionFrame(meshTransition, previewMesh, performance.now(), easeInOut);
  if (!footprintMesh) {
    mapHitRegions = [];
    hideMapProbe();
    layoutContext.fillStyle = '#aeb5c2';
    layoutContext.font = '700 13px Inter, system-ui, sans-serif';
    layoutContext.textAlign = 'center';
    layoutContext.fillText('Loading generated OBJ footprint...', width * 0.5, height * 0.5);
    return;
  }
  drawTopDownMesh(layout, footprintMesh);
}

async function loadMeshPreview() {
  setGpuInspectActive(false);
  meshStatus.textContent = 'Loading OBJ preview...';
  try {
    const response = await fetch(`/api/mesh/${currentBiome}?ts=${Date.now()}`);
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const text = await response.text();
    authoritativeMesh = parseObj(text);
    setPreviewMesh(authoritativeMesh, 'baked');
    previewStartTime = performance.now();
    renderProcessLayerStack();
    meshStatus.textContent = `${previewMesh.vertices.length} vertices · ${previewMesh.faces.length} faces · baked ${currentBiome} OBJ`;
    if (currentLayout) drawLayoutPreview(currentLayout);
  } catch (error) {
    authoritativeMesh = null;
    setPreviewMesh(null, 'baked');
    renderProcessLayerStack();
    meshStatus.textContent = `OBJ preview unavailable: ${error.message}`;
    if (currentLayout) drawLayoutPreview(currentLayout);
  }
  updateBakeUi();
}

async function warmProcessFieldPreview() {
  if (!currentLayout || currentField || generating) return;
  const biome = currentBiome;
  const qualityStatus = previewQualityStatusForBakeQuality(selectedBakeQuality);
  const requestId = previewRequestId + 1;
  previewRequestId = requestId;
  previewAbortController = new AbortController();
  previewing = true;
  updateBakeUi();
  meshStatus.textContent = `Preparing ${biomeLabel(biome)} realtime ${qualityStatus.realtimeLabel} masks for final ${qualityStatus.finalLabel}...`;
  const previewQuality = previewQualityForBakeQuality(selectedBakeQuality);

  try {
    const response = await fetch(`/api/preview/${biome}?quality=${encodeURIComponent(previewQuality)}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(currentLayout),
      signal: previewAbortController.signal,
    });
    const payload = await response.json();
    if (!payload.ok) throw new Error(payload.error || 'Process field bake failed');
    if (requestId !== previewRequestId || biome !== currentBiome) return;

    authoritativeMesh = parseObj(payload.mesh);
    currentField = payload.field || null;
    setPreviewMesh(authoritativeMesh, 'baked');
    lastPreviewSignature = currentPreviewSignature();
    const topology = payload.topology
      ? `${payload.topology.segments}x${payload.topology.rings}`
      : `${previewMesh.vertices.length} vertices`;
    updateNudgeReviewWithReport(payload.qualityReport || null);
    renderQualityRepairQueue(payload.qualityReport || null);
    meshStatus.textContent = `${previewMesh.vertices.length} vertices · ${previewMesh.faces.length} faces · realtime ${qualityStatus.realtimeLabel} for final ${qualityStatus.finalLabel} · ${topology} in ${payload.elapsed_ms}ms`;
    renderProcessLayerStack();
    drawLayoutPreview(currentLayout);
  } catch (error) {
    if (error.name !== 'AbortError') {
      meshStatus.textContent = `Process masks unavailable: ${error.message}`;
    }
  } finally {
    if (requestId === previewRequestId) {
      previewing = false;
      previewAbortController = null;
      updateBakeUi();
    }
  }
}

function schedulePreviewBake(delay = PREVIEW_BAKE_DELAY_MS) {
  if (!currentLayout || generating) return;
  if (controlInteractionActive) {
    pendingPreviewAfterInteraction = true;
    return;
  }
  const signature = currentPreviewSignature();
  if (signature === lastPreviewSignature) {
    pendingPreviewAfterInteraction = false;
    return;
  }
  if (previewing) return;
  pendingPreviewAfterInteraction = false;
  if (previewTimer) clearTimeout(previewTimer);
  previewTimer = setTimeout(() => {
    previewTimer = null;
    runPreviewBake();
  }, delay);
}

async function runPreviewBake() {
  if (!currentLayout || generating || !layoutDirty) return;
  const biome = currentBiome;
  const qualityStatus = previewQualityStatusForBakeQuality(selectedBakeQuality);
  const signature = currentPreviewSignature();
  if (signature === lastPreviewSignature) return;
  const body = JSON.stringify(currentLayout);
  const beforeMesh = meshAtTransitionFrame(meshTransition, previewMesh, performance.now(), easeInOut);
  const requestId = previewRequestId + 1;
  previewRequestId = requestId;
  previewAbortController = new AbortController();
  previewing = true;
  updateBakeUi();
  meshStatus.textContent = `Preview baking ${biomeLabel(biome)} at realtime ${qualityStatus.realtimeLabel} for final ${qualityStatus.finalLabel}...`;
  const previewQuality = previewQualityForBakeQuality(selectedBakeQuality);

  try {
    const response = await fetch(`/api/preview/${biome}?quality=${encodeURIComponent(previewQuality)}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body,
      signal: previewAbortController.signal,
    });
    const payload = await response.json();
    if (!payload.ok) throw new Error(payload.error || 'Preview bake failed');
    if (requestId !== previewRequestId || biome !== currentBiome || signature !== currentPreviewSignature()) return;

    authoritativeMesh = parseObj(payload.mesh);
    currentField = payload.field || null;
    if (currentField) triggerProcessTracePulse();
    const targetMesh = authoritativeMesh;
    triggerMeshDeltaPulse(beforeMesh, targetMesh);
    setPreviewMesh(
      targetMesh,
      'preview',
      { transition: true },
    );
    lastPreviewSignature = signature;
    activeHighlightControlId = null;
    const topology = payload.topology
      ? `${payload.topology.segments}x${payload.topology.rings}`
      : `${previewMesh.vertices.length} vertices`;
    updateNudgeReviewWithReport(payload.qualityReport || null);
    renderQualityRepairQueue(payload.qualityReport || null);
    meshStatus.textContent = `${previewMesh.vertices.length} vertices · ${previewMesh.faces.length} faces · realtime ${qualityStatus.realtimeLabel} for final ${qualityStatus.finalLabel} · ${topology} in ${payload.elapsed_ms}ms`;
    renderProcessLayerStack();
    drawLayoutPreview(currentLayout);
  } catch (error) {
    if (error.name !== 'AbortError') {
      meshStatus.textContent = `Preview bake unavailable: ${error.message}`;
    }
  } finally {
    if (requestId === previewRequestId) {
      previewing = false;
      previewAbortController = null;
      updateBakeUi();
      if (layoutDirty && !generating && !controlInteractionActive && currentPreviewSignature() !== lastPreviewSignature) {
        schedulePreviewBake();
      }
    }
  }
}

async function runHighResInspect() {
  if (!currentLayout || generating || previewing || inspecting) return;
  cancelPreviewBake();
  previewRequestId += 1;
  const biome = currentBiome;
  const qualityStatus = previewQualityStatusForBakeQuality(selectedBakeQuality);
  const signature = currentInspectSignature();
  const requestId = inspectRequestId + 1;
  inspectRequestId = requestId;
  inspecting = true;
  controlInteractionActive = false;
  pendingPreviewAfterInteraction = false;
  activeHighlightControlId = null;
  processTracePulse = null;
  meshDeltaPulse = null;
  requestMeshRender();
  updateBakeUi();
  meshStatus.textContent = `Inspect baking ${biomeLabel(biome)} at final ${qualityStatus.finalLabel} topology...`;

  try {
    const response = await fetch(`/api/inspect/${biome}?quality=${encodeURIComponent(selectedBakeQuality)}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(currentLayout),
    });
    const payload = await response.json();
    if (!payload.ok) throw new Error(payload.error || 'High-res inspect failed');
    if (requestId !== inspectRequestId || biome !== currentBiome || signature !== currentInspectSignature()) return;

    const inspectMesh = parseObj(payload.mesh);
    gpuInspectField = payload.field || null;
    const gpuReady = setGpuInspectActive(true, inspectMesh);
    lastInspectSignature = signature;
    const topology = payload.topology
      ? `${payload.topology.segments}x${payload.topology.rings}`
      : `${inspectMesh.vertices.length} vertices`;
    updateNudgeReviewWithReport(payload.qualityReport || null);
    renderQualityRepairQueue(payload.qualityReport || null);
    meshStatus.textContent = `${inspectMesh.vertices.length} vertices · ${inspectMesh.faces.length} faces · final ${qualityStatus.finalLabel} ${gpuReady ? 'GPU inspect' : 'inspect snapshot'} · ${topology} in ${payload.elapsed_ms}ms`;
    renderProcessLayerStack();
  } catch (error) {
    meshStatus.textContent = `High-res inspect unavailable: ${error.message}`;
  } finally {
    if (requestId === inspectRequestId) {
      inspecting = false;
      updateBakeUi();
    }
  }
}

async function loadManifest({ syncBakeQuality = false } = {}) {
  try {
    const response = await fetch(`/api/manifest/${currentBiome}?ts=${Date.now()}`);
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const manifest = await response.json();
    if (syncBakeQuality) syncBakeQualityFromManifest(manifest);
    manifestStatus.textContent = 'sidecar ready';
    manifestPreview.textContent = JSON.stringify(manifest, null, 2);
  } catch {
    manifestStatus.textContent = 'not generated';
    manifestPreview.textContent = 'Generate this biome to export the UE / PCG sidecar manifest.';
  }
}

async function loadQualityReport() {
  try {
    const response = await fetch(`/api/quality-report/${currentBiome}?ts=${Date.now()}`);
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    renderQualityRepairQueue(await response.json());
  } catch {
    renderQualityRepairQueue(null);
  }
}

function formatControlValue(control, value) {
  if (control.id === 'lavaCount') return `${Math.round(value)} branches`;
  if (control.id === 'resourceClusterCount') return `${Math.round(value)} clusters`;
  if (control.id === 'loopCoverage') return `${Math.round(value * 100)}% ring`;
  if (
    control.id === 'volcanoDominance'
    || control.id === 'rootDominance'
    || control.id === 'stumpCaveDominance'
    || control.id === 'vineAnchorDominance'
    || control.id === 'crystalWallDominance'
  ) return `${Number(value).toFixed(2)}x`;
  if (control.id === 'detailEnergy') return `${Number(value).toFixed(2)} energy`;
  if (control.id === 'erosionAge') return `${Math.round(value * 100)}% aged`;
  if (control.id === 'depositionWeight') return `${Math.round(value * 100)}% talus`;
  if (
    control.id === 'mainPathWidth'
    || control.id === 'vineBridgeWidth'
    || control.id === 'centralShelfWidth'
  ) return `${Math.round(value * 100)}% width`;
  return `${Math.round(value * 100)}% radius`;
}

function handleLayoutEdited(layout, { queuePreview = true } = {}) {
  jsonPreview.textContent = JSON.stringify(layout, null, 2);
  markLayoutDirty();
  drawLayoutPreview(layout);
  updateDesignHealth(layout);
  if (queuePreview) requestPreviewAfterEdit();
}

function renderBiomeControls(layout) {
  const controls = controlSpec(layout);
  const controlPage = controlsForActiveGroup(controls, activeControlGroup);
  activeControlGroup = controlPage.activeGroup;
  controlCards.innerHTML = `
    <div class="control-group-tabs" role="tablist" aria-label="${escapeHtml(titleCase(layout.biome))} control groups">
      ${controlPage.tabs.map((tab) => `
        <button class="control-group-tab ${tab.id === activeControlGroup ? 'active' : ''}" data-control-group="${tab.id}" type="button" role="tab" aria-selected="${tab.id === activeControlGroup}">
          <span>${tab.label}</span>
          <b>${tab.count}</b>
        </button>
      `).join('')}
    </div>
    <div class="control-group control-count-${controlPage.controls.length}">
      <div class="control-group-title">
        <span>${activeControlGroup}</span>
        <div class="control-group-tools">
          ${activeControlGroup === 'Process' ? `
            <label class="process-trace-toggle compact">
              <input id="processTraceToggle" type="checkbox" ${processTracesEnabled ? 'checked' : ''}>
              <span>3D process traces</span>
            </label>
          ` : ''}
        </div>
      </div>
      ${controlPage.controls.map((control) => `
        <div class="control-card compact-control ${activeAdvisorControlIds.has(control.id) ? 'advisor-linked' : ''}" data-control-id="${escapeHtml(control.id)}">
          <div class="control-card-head">
            <div>
              <b>${control.title}</b>
              <small>${control.metric}</small>
            </div>
            <output id="${control.id}Value">${formatControlValue(control, control.value)}</output>
          </div>
          <span>${control.note}</span>
          <div class="control-row">
            <input id="${control.id}Range" type="range" min="${control.min}" max="${control.max}" step="${control.step}" value="${control.value}">
            <input id="${control.id}Number" type="number" min="${control.min}" max="${control.max}" step="${control.step}" value="${control.value}">
          </div>
        </div>
      `).join('')}
    </div>
  `;

  controlCards.querySelectorAll('[data-control-group]').forEach((button) => {
    button.addEventListener('click', () => {
      activeControlGroup = button.dataset.controlGroup;
      activeHighlightControlId = null;
      renderBiomeControls(layout);
      requestMeshRender();
    });
  });
  const processTraceToggle = controlCards.querySelector('#processTraceToggle');
  if (processTraceToggle) {
    processTraceToggle.addEventListener('change', () => {
      processTracesEnabled = processTraceToggle.checked;
      if (processTracesEnabled) triggerProcessTracePulse();
      requestMeshRender();
    });
  }

  controlPage.controls.forEach((control) => {
    const range = document.querySelector(`#${control.id}Range`);
    const number = document.querySelector(`#${control.id}Number`);
    const output = document.querySelector(`#${control.id}Value`);
    const onInput = (rawValue) => {
      const numericValue = Number(rawValue);
      if (!Number.isFinite(numericValue)) return;
      activeHighlightControlId = control.id;
      const processLayer = processLayerForControl(control.id);
      if (processLayer) {
        activeProcessLayerId = processLayer.layerId;
        selectedMaskView = processLayer.maskView;
        renderProcessLayerStack();
      }
      const value = Number(clamp(roundTo(numericValue, control.step), control.min, control.max).toFixed(4));
      range.value = value;
      number.value = value;
      output.textContent = formatControlValue(control, value);
      control.update(value);
      if (autoLinkToggle.checked && control.id === 'volcanoDominance') {
        applyVolcanicCoherence(layout);
        renderControls(layout);
        handleLayoutEdited(layout);
        return;
      }
      handleLayoutEdited(layout);
    };
    range.addEventListener('pointerdown', () => beginControlInteraction(control.id));
    range.addEventListener('change', finishControlInteraction);
    range.addEventListener('input', (event) => onInput(event.target.value));
    number.addEventListener('input', (event) => onInput(event.target.value));
    number.addEventListener('change', () => schedulePreviewBake(0));
  });
}

function renderReadOnlySemanticCards(layout) {
  const sections = [
    ['Landmarks', layout.landmarks.map((item) => `${item.id} · ${item.kind} · ${item.bake_mode}`)],
    ['Paths', layout.paths.map((item) => `${item.id} · ${item.kind} · width ${item.width}`)],
    ['Zones', layout.zones.map((item) => `${item.id} · ${item.kind} · ${item.walkable ? 'walkable' : 'blocked'}`)],
  ];
  controlCards.innerHTML = sections.map(([title, rows]) => `
    <div class="control-card semantic-card">
      <b>${title}</b>
      ${rows.map((row) => `<span>${row}</span>`).join('')}
    </div>
  `).join('');
}

function renderControls(layout) {
  controlTitle.textContent = `${titleCase(layout.biome)} Controls`;
  coherenceToggle.classList.toggle('hidden', layout.biome !== 'fire');
  autoLinkToggle.disabled = layout.biome !== 'fire';
  renderBiomeControls(layout);
  updateDesignHealth(layout);
}

function renderBiomeChips() {
  biomeChips.innerHTML = availableBiomes.map((item) => `
    <button class="biome-chip ${item.biome === currentBiome ? 'active' : ''}" data-biome="${item.biome}" type="button">
      ${item.label}
    </button>
  `).join('');
  biomeChips.querySelectorAll('button').forEach((button) => {
    button.addEventListener('click', () => {
      cancelPreviewBake();
      previewRequestId += 1;
      currentBiome = button.dataset.biome;
      renderBiomeChips();
      loadLayout();
    });
  });
}

function renderBakeQualityOptions() {
  const profiles = activeBakeQualityProfiles();
  if (!profiles.some((profile) => profile.id === selectedBakeQuality)) selectedBakeQuality = 'production';
  bakeQualitySelect.innerHTML = profiles.map((profile) => `
    <option value="${profile.id}" ${profile.id === selectedBakeQuality ? 'selected' : ''}>
      ${profile.label} · ${profile.segments}x${profile.rings}
    </option>
  `).join('');
  const selected = profiles.find((profile) => profile.id === selectedBakeQuality);
  bakeQualitySelect.title = selected?.description || 'Final bake quality';
}

async function loadBakeProfiles() {
  try {
    const response = await fetch('/api/bake-profiles');
    bakeQualityProfiles = response.ok ? await response.json() : fallbackBakeQualityProfiles;
  } catch {
    bakeQualityProfiles = fallbackBakeQualityProfiles;
  }
  renderBakeQualityOptions();
}

async function loadBiomes() {
  try {
    const response = await fetch('/api/biomes');
    availableBiomes = response.ok ? await response.json() : fallbackBiomes;
  } catch {
    availableBiomes = fallbackBiomes;
  }
  renderBiomeChips();
}

async function loadLayout() {
  cancelPreviewBake();
  previewRequestId += 1;
  previewing = false;
  generating = false;
  inspecting = false;
  inspectRequestId += 1;
  lastInspectSignature = '';
  setGpuInspectActive(false);
  layoutDirty = false;
  previewMeshMode = 'baked';
  currentField = null;
  processTracePulse = null;
  meshDeltaPulse = null;
  selectedMaskView = 'material';
  activeProcessLayerId = 'finalMesh';
  controlInteractionActive = false;
  pendingPreviewAfterInteraction = false;
  activeHighlightControlId = null;
  activeAdvisorControlIds = new Set();
  currentQualityReport = null;
  activeQualityIssue = null;
  activeNudgeReview = null;
  activeControlGroup = 'Form';
  layoutEditVersion += 1;
  invalidatePendingMovementHighlightCache();
  updateBakeUi();
  renderQualityRepairQueue(null);
  generationStatus.textContent = `Loading ${biomeLabel(currentBiome)}...`;
  const response = await fetch(`/api/layout/${currentBiome}`);
  const layout = await response.json();
  ensureProcessControls(layout);
  currentLayout = layout;
  lastPreviewSignature = currentPreviewSignature(layout);
  document.body.dataset.biome = layout.biome;
  diameterMetric.textContent = `${layout.radius_m * 2}m`;
  seedMetric.textContent = layout.seed;
  updateViewportHud();
  renderProcessLayerStack();
  updateBakeUi();
  renderControls(layout);
  jsonPreview.textContent = JSON.stringify(layout, null, 2);
  await loadManifest({ syncBakeQuality: true });
  await loadMeshPreview();
  await loadQualityReport();
  await warmProcessFieldPreview();
  generationStatus.textContent = 'Ready to generate.';
  updateBakeUi();
}

rendererToggle?.querySelectorAll('button[data-renderer-mode]').forEach((button) => {
  button.addEventListener('click', () => setMeshRendererMode(button.dataset.rendererMode));
});
updateRendererToggleUi();

inspectButton?.addEventListener('click', runHighResInspect);

generateButton.addEventListener('click', async () => {
  cancelPreviewBake();
  previewRequestId += 1;
  inspectRequestId += 1;
  previewing = false;
  generating = true;
  controlInteractionActive = false;
  pendingPreviewAfterInteraction = false;
  activeHighlightControlId = null;
  processTracePulse = null;
  meshDeltaPulse = null;
  requestMeshRender();
  updateBakeUi();
  generationStatus.textContent = `Baking ${biomeLabel(currentBiome)}...`;
  try {
    const response = await fetch(`/api/generate/${currentBiome}?quality=${encodeURIComponent(selectedBakeQuality)}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(currentLayout),
    });
    const payload = await response.json();
    if (!payload.ok) throw new Error(payload.error || 'Generation failed');
    const topology = payload.topology ? `${payload.topology.segments} segments / ${payload.topology.rings} rings` : 'topology unavailable';
    const qualityLines = [
      `Quality: ${payload.quality || selectedBakeQuality} (${topology})`,
      payload.qualitySummary ? `Report summary: ${payload.qualitySummary}` : '',
      payload.qualityReport ? `Quality report: ${payload.qualityReport}` : '',
    ].filter(Boolean);
    generationStatus.textContent = `${payload.stdout}\n\n${qualityLines.join('\n')}\nPython: ${payload.python}\nOutput: ${payload.output}\nManifest: ${payload.manifest}`;
    currentField = payload.fieldData || currentField;
    updateNudgeReviewWithReport(payload.qualityReportData || null);
    renderQualityRepairQueue(payload.qualityReportData || null);
    layoutDirty = false;
    previewMeshMode = 'baked';
    lastPreviewSignature = currentPreviewSignature();
    lastInspectSignature = currentInspectSignature();
    await loadMeshPreview();
    await loadManifest();
  } catch (error) {
    generationStatus.textContent = `Bake failed: ${error.message}`;
  } finally {
    generating = false;
    updateBakeUi();
  }
});

resetButton.addEventListener('click', () => {
  cancelPreviewBake();
  previewRequestId += 1;
  controlInteractionActive = false;
  pendingPreviewAfterInteraction = false;
  activeHighlightControlId = null;
  generationStatus.textContent = 'Discarding live edits...';
  loadLayout().then(() => {
    generationStatus.textContent = 'Edits discarded.';
  }).catch((error) => {
    generationStatus.textContent = `Discard failed: ${error.message}`;
  });
});

autoLinkToggle.addEventListener('change', () => {
  if (!currentLayout || currentLayout.biome !== 'fire') return;
  if (autoLinkToggle.checked) {
    applyVolcanicCoherence(currentLayout);
    activeHighlightControlId = 'volcanoDominance';
    renderControls(currentLayout);
    drawLayoutPreview(currentLayout);
    jsonPreview.textContent = JSON.stringify(currentLayout, null, 2);
    markLayoutDirty();
    requestPreviewAfterEdit();
  } else {
    updateDesignHealth(currentLayout);
  }
});

bakeQualitySelect.addEventListener('change', () => {
  const nextQuality = bakeQualitySelect.value || 'production';
  if (nextQuality === selectedBakeQuality) return;
  selectedBakeQuality = nextQuality;
  renderBakeQualityOptions();
  if (!currentLayout) return;
  cancelPreviewBake();
  previewRequestId += 1;
  previewing = false;
  controlInteractionActive = false;
  pendingPreviewAfterInteraction = false;
  activeHighlightControlId = null;
  currentField = null;
  processTracePulse = null;
  meshDeltaPulse = null;
  renderProcessLayerStack();
  markLayoutDirty();
  drawLayoutPreview(currentLayout);
  schedulePreviewBake(0);
});

loadBiomes()
  .then(loadBakeProfiles)
  .then(loadLayout)
  .catch((error) => {
    jsonPreview.textContent = `Failed to load layout: ${error.message}`;
  });
requestMeshRender();
