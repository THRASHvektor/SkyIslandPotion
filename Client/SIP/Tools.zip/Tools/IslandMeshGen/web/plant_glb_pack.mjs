import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { basename, dirname, extname, resolve } from 'node:path';

const GLB_MAGIC = 0x46546c67;
const GLB_VERSION = 2;
const CHUNK_JSON = 0x4e4f534a;
const CHUNK_BIN = 0x004e4942;

export async function packGltfToGlb({ gltfPath, outputPath }) {
  if (!gltfPath) throw new Error('packGltfToGlb requires gltfPath.');
  if (!outputPath) throw new Error('packGltfToGlb requires outputPath.');

  const absoluteGltfPath = resolve(gltfPath);
  const absoluteOutputPath = resolve(outputPath);
  const gltfDir = dirname(absoluteGltfPath);
  const gltf = JSON.parse(await readFile(absoluteGltfPath, 'utf8'));
  const binBuilder = new BinaryChunkBuilder();
  const bufferOffsets = new Map();

  for (let index = 0; index < (gltf.buffers || []).length; index += 1) {
    const sourceBuffer = gltf.buffers[index];
    const bytes = await readUriBytes(sourceBuffer.uri, gltfDir);
    const byteOffset = binBuilder.append(bytes);
    bufferOffsets.set(index, byteOffset);
  }

  for (const bufferView of gltf.bufferViews || []) {
    const sourceBufferIndex = bufferView.buffer ?? 0;
    if (!bufferOffsets.has(sourceBufferIndex)) {
      throw new Error(`Missing source buffer ${sourceBufferIndex} for bufferView.`);
    }
    bufferView.byteOffset = bufferOffsets.get(sourceBufferIndex) + (bufferView.byteOffset || 0);
    bufferView.buffer = 0;
  }

  for (const image of gltf.images || []) {
    if (!image.uri) continue;
    const bytes = await readUriBytes(image.uri, gltfDir);
    const byteOffset = binBuilder.append(bytes);
    const bufferView = {
      buffer: 0,
      byteOffset,
      byteLength: bytes.byteLength,
    };
    gltf.bufferViews = gltf.bufferViews || [];
    image.bufferView = gltf.bufferViews.push(bufferView) - 1;
    image.mimeType = image.mimeType || mimeTypeForUri(image.uri);
    delete image.uri;
  }

  const binChunk = binBuilder.toBuffer();
  gltf.buffers = [{ byteLength: binChunk.byteLength }];
  const jsonChunk = paddedJsonBuffer(gltf);
  const glb = writeGlb({ jsonChunk, binChunk });

  await mkdir(dirname(absoluteOutputPath), { recursive: true });
  await writeFile(absoluteOutputPath, glb);
  return {
    fileName: basename(absoluteOutputPath),
    absolutePath: absoluteOutputPath,
    bytes: glb.byteLength,
  };
}

async function readUriBytes(uri, baseDir) {
  if (!uri) throw new Error('Only external or data URI glTF resources can be packed.');
  if (uri.startsWith('data:')) return readDataUri(uri);
  const filePath = resolve(baseDir, decodeUriPath(uri));
  return readFile(filePath);
}

function decodeUriPath(uri) {
  const pathPart = String(uri).split(/[?#]/, 1)[0];
  try {
    return decodeURIComponent(pathPart);
  } catch {
    return pathPart;
  }
}

function readDataUri(uri) {
  const match = /^data:([^,]*?),(.*)$/s.exec(uri);
  if (!match) throw new Error('Invalid data URI in glTF resource.');
  const meta = match[1] || '';
  const payload = match[2] || '';
  if (meta.split(';').includes('base64')) return Buffer.from(payload, 'base64');
  return Buffer.from(decodeURIComponent(payload), 'utf8');
}

function mimeTypeForUri(uri) {
  const extension = extname(decodeUriPath(uri)).toLowerCase();
  if (extension === '.jpg' || extension === '.jpeg') return 'image/jpeg';
  if (extension === '.png') return 'image/png';
  if (extension === '.webp') return 'image/webp';
  return 'application/octet-stream';
}

function paddedJsonBuffer(gltf) {
  const json = Buffer.from(JSON.stringify(gltf), 'utf8');
  const padding = Buffer.alloc(alignmentPadding(json.byteLength), 0x20);
  return Buffer.concat([json, padding]);
}

function writeGlb({ jsonChunk, binChunk }) {
  const hasBinChunk = binChunk.byteLength > 0;
  const totalLength = 12 + 8 + jsonChunk.byteLength + (hasBinChunk ? 8 + binChunk.byteLength : 0);
  const header = Buffer.alloc(12);
  header.writeUInt32LE(GLB_MAGIC, 0);
  header.writeUInt32LE(GLB_VERSION, 4);
  header.writeUInt32LE(totalLength, 8);

  const jsonHeader = Buffer.alloc(8);
  jsonHeader.writeUInt32LE(jsonChunk.byteLength, 0);
  jsonHeader.writeUInt32LE(CHUNK_JSON, 4);

  if (!hasBinChunk) return Buffer.concat([header, jsonHeader, jsonChunk]);

  const binHeader = Buffer.alloc(8);
  binHeader.writeUInt32LE(binChunk.byteLength, 0);
  binHeader.writeUInt32LE(CHUNK_BIN, 4);
  return Buffer.concat([header, jsonHeader, jsonChunk, binHeader, binChunk]);
}

function alignmentPadding(length) {
  return (4 - (length % 4)) % 4;
}

class BinaryChunkBuilder {
  constructor() {
    this.chunks = [];
    this.length = 0;
  }

  append(bytes) {
    const buffer = Buffer.from(bytes);
    const paddingLength = alignmentPadding(this.length);
    if (paddingLength) {
      this.chunks.push(Buffer.alloc(paddingLength));
      this.length += paddingLength;
    }
    const byteOffset = this.length;
    this.chunks.push(buffer);
    this.length += buffer.byteLength;
    return byteOffset;
  }

  toBuffer() {
    const paddingLength = alignmentPadding(this.length);
    if (paddingLength) {
      this.chunks.push(Buffer.alloc(paddingLength));
      this.length += paddingLength;
    }
    return Buffer.concat(this.chunks, this.length);
  }
}
