from collections import Counter


STATUS_ORDER = {
    "pass": 0,
    "review": 1,
    "critical": 2,
}


ISSUE_WEIGHTS = {
    "RootPrimaryDetach": 100,
    "CoreTooSmall": 80,
    "CoreTooLarge": 80,
    "CoreDrift": 60,
    "HighDispersionMix": 40,
    "LowReadability": 30,
}


def issue_slug(issues):
    if not issues:
        return "Pass"
    return "_".join(str(issue) for issue in issues)


def _float(payload, key, default=0.0):
    try:
        return float(payload.get(key, default))
    except (TypeError, ValueError):
        return float(default)


def _max_vector_delta(vector):
    values = [int(vector.get(slot, 0)) for slot in ("BodyShell", "PrimarySilhouette", "Core", "OrbitSet")]
    return max(values) - min(values)


def classify_assembly_row(row, thresholds=None):
    thresholds = {
        "root_primary_detach_gap_cm": 20.0,
        "core_too_small_ratio": 0.07,
        "core_too_large_ratio": 0.75,
        "core_drift_cm": 34.0,
        "high_dispersion": 0.62,
        "low_readability_height_cm": 45.0,
        **(thresholds or {}),
    }

    vector = row.get("collapse_vector", {})
    metrics = row.get("metrics", {})
    measurements = row.get("measurements", {})
    severity = _float(metrics, "severity")
    dispersion = _float(metrics, "dispersion")
    gap = _float(measurements, "body_primary_gap_cm")
    core_to_primary = _float(measurements, "core_to_primary_height_ratio")
    core_drift = _float(measurements, "core_primary_center_distance_cm")
    plant_height = _float(measurements, "plant_height_cm")

    issues = []

    if gap > thresholds["root_primary_detach_gap_cm"]:
        issues.append("RootPrimaryDetach")
    if 0.0 < core_to_primary < thresholds["core_too_small_ratio"]:
        issues.append("CoreTooSmall")
    if core_to_primary > thresholds["core_too_large_ratio"]:
        issues.append("CoreTooLarge")
    if core_drift > thresholds["core_drift_cm"]:
        issues.append("CoreDrift")
    if severity >= 2.2 and dispersion > thresholds["high_dispersion"] and _max_vector_delta(vector) >= 3:
        issues.append("HighDispersionMix")
    if 0.0 < plant_height < thresholds["low_readability_height_cm"]:
        issues.append("LowReadability")

    if any(issue in issues for issue in ("RootPrimaryDetach", "CoreTooSmall", "CoreTooLarge")):
        status = "critical"
    elif issues:
        status = "review"
    else:
        status = "pass"

    score = sum(ISSUE_WEIGHTS.get(issue, 10) for issue in issues)
    return {
        "status": status,
        "score": score,
        "issues": issues,
        "issue_slug": issue_slug(issues),
    }


def summarize_assembly_audit(rows, thresholds=None):
    enriched = []
    status_counts = Counter()
    family_counts = Counter()
    issue_counts = Counter()

    for row in rows:
        audit = classify_assembly_row(row, thresholds=thresholds)
        enriched_row = {**row, "audit": audit}
        enriched.append(enriched_row)
        status_counts[audit["status"]] += 1
        family_counts[row.get("family", "Unknown")] += 1
        for issue in audit["issues"]:
            issue_counts[issue] += 1

    enriched.sort(
        key=lambda row: (
            -STATUS_ORDER.get(row["audit"]["status"], 0),
            -row["audit"]["score"],
            row.get("family", ""),
            row.get("label", ""),
        )
    )

    return {
        "schema": "SkyIslandPotion.AIGCPlantAssemblyAudit.v0",
        "total_count": len(enriched),
        "status_counts": dict(status_counts),
        "family_counts": dict(family_counts),
        "issue_counts": dict(issue_counts),
        "rows": enriched,
    }
