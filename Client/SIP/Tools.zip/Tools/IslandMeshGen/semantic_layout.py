from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field
from typing import Any


MATERIAL_SLOTS = ("M_TopGrass", "M_PathDirt", "M_CliffRock", "M_UndersideRock", "M_ElementCrack")
FIRE_MATERIAL_SLOTS = ("M_AshPlateau", "M_PathDirt", "M_CliffRock", "M_UndersideRock", "M_ElementCrack")
ALL_MATERIAL_SLOTS = tuple(dict.fromkeys(MATERIAL_SLOTS + FIRE_MATERIAL_SLOTS))


def material_slots_for_biome(biome: str) -> tuple[str, ...]:
    return FIRE_MATERIAL_SLOTS if biome == "fire" else MATERIAL_SLOTS


@dataclass(frozen=True)
class Zone:
    id: str
    kind: str
    center: tuple[float, float] = (0.0, 0.0)
    radius_range: tuple[float, float] = (0.0, 1.0)
    walkable: bool = True
    height_role: str = "neutral"


@dataclass(frozen=True)
class Landmark:
    id: str
    kind: str
    center: tuple[float, float] = (0.0, 0.0)
    radius: float = 0.25
    dominance: float = 0.5
    bake_mode: str = "terrain"
    count: int = 1


@dataclass(frozen=True)
class PathRoute:
    id: str
    kind: str
    points: tuple[tuple[float, float], ...] = field(default_factory=tuple)
    width: float = 0.1
    max_slope_m: float = 4.0
    material: str = "M_PathDirt"
    coverage: float = 1.0


@dataclass(frozen=True)
class MaterialMask:
    slot: str
    source: str
    meaning: str


@dataclass(frozen=True)
class IslandLayout:
    biome: str
    radius_m: float = 100.0
    seed: int = 42
    zones: tuple[Zone, ...] = field(default_factory=tuple)
    landmarks: tuple[Landmark, ...] = field(default_factory=tuple)
    paths: tuple[PathRoute, ...] = field(default_factory=tuple)
    material_masks: tuple[MaterialMask, ...] = field(default_factory=tuple)
    process: dict[str, float] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), indent=2, sort_keys=True)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "IslandLayout":
        return cls(
            biome=data["biome"],
            radius_m=float(data.get("radius_m", 100.0)),
            seed=int(data.get("seed", 42)),
            zones=tuple(_zone_from_dict(item) for item in data.get("zones", ())),
            landmarks=tuple(_landmark_from_dict(item) for item in data.get("landmarks", ())),
            paths=tuple(_path_from_dict(item) for item in data.get("paths", ())),
            material_masks=tuple(_material_mask_from_dict(item) for item in data.get("material_masks", ())),
            process={key: float(value) for key, value in data.get("process", {}).items()},
        )

    @classmethod
    def from_json(cls, text: str) -> "IslandLayout":
        return cls.from_dict(json.loads(text))


def default_layout(biome: str, radius_m: float = 100.0, seed: int = 42) -> IslandLayout:
    biome = biome.lower()
    if biome == "fire":
        return _fire_layout(radius_m, seed)
    if biome == "ice":
        return _ice_layout(radius_m, seed)
    if biome == "forest":
        return _forest_layout(radius_m, seed)
    raise ValueError(f"Unknown island biome: {biome}")


def _fire_layout(radius_m: float, seed: int) -> IslandLayout:
    return IslandLayout(
        biome="fire",
        radius_m=radius_m,
        seed=seed,
        landmarks=(
            Landmark("central_volcano", "volcano", radius=0.42, dominance=0.85, bake_mode="terrain"),
            Landmark("lava_channels", "lava_channel", radius=0.82, dominance=0.65, bake_mode="terrain", count=3),
        ),
        paths=(
            PathRoute("main_approach", "main_path", points=((0.92, 0.0), (0.62, 0.0), (0.38, 0.0)), width=0.12, max_slope_m=4.0),
            PathRoute("partial_crater_loop", "loop_path", points=((0.42, 0.0),), width=0.08, max_slope_m=3.0, coverage=0.55),
        ),
        zones=(
            Zone("crater_arena", "arena", radius_range=(0.24, 0.48), walkable=True, height_role="elevated_ring"),
            Zone("lava_hazard", "hazard", radius_range=(0.28, 0.95), walkable=False, height_role="cut"),
            Zone("outer_blackrock_shelves", "arena", radius_range=(0.55, 0.9), walkable=True, height_role="stepped"),
        ),
        material_masks=(
            MaterialMask("M_AshPlateau", "volcanic_ash_plateau", "ash_plateau_and_settled_talus"),
            MaterialMask("M_ElementCrack", "lava_channels", "elemental_reaction_surface"),
            MaterialMask("M_PathDirt", "main_approach", "walkable_route"),
        ),
        process={
            "detail_energy": 1.0,
            "erosion_age": 0.45,
            "deposition_weight": 0.55,
        },
    )


def _ice_layout(radius_m: float, seed: int) -> IslandLayout:
    return IslandLayout(
        biome="ice",
        radius_m=radius_m,
        seed=seed,
        landmarks=(
            Landmark("primary_crystal_wall", "ice_wall", radius=0.54, dominance=0.86, bake_mode="terrain", count=4),
            Landmark("secondary_spire_clusters", "ice_crystal_cluster", radius=0.48, dominance=0.72, bake_mode="terrain", count=6),
        ),
        paths=(
            PathRoute("central_shelf", "open_area", points=((0.0, 0.0),), width=0.34, max_slope_m=2.0),
            PathRoute("broken_ice_ring", "loop_path", points=((0.62, 0.0),), width=0.1, max_slope_m=3.0),
        ),
        zones=(
            Zone("resource_crystals", "resource", radius_range=(0.38, 0.76), walkable=True, height_role="clustered"),
            Zone("deep_cracks", "hazard", radius_range=(0.42, 0.92), walkable=False, height_role="cut"),
            Zone("central_ice_shelf", "arena", radius_range=(0.0, 0.34), walkable=True, height_role="flat"),
        ),
        material_masks=(
            MaterialMask("M_ElementCrack", "deep_cracks", "deep_blue_ice_crack"),
            MaterialMask("M_PathDirt", "central_shelf", "walkable_ice"),
        ),
        process={
            "detail_energy": 1.0,
            "erosion_age": 0.45,
            "deposition_weight": 0.55,
        },
    )


def _forest_layout(radius_m: float, seed: int) -> IslandLayout:
    return IslandLayout(
        biome="forest",
        radius_m=radius_m,
        seed=seed,
        landmarks=(
            Landmark("root_arch", "root_arch", center=(0.35, -0.1), radius=0.22, dominance=0.7, bake_mode="attachment"),
            Landmark("tree_stump_cave", "tree_stump_cave", center=(-0.25, 0.25), radius=0.2, dominance=0.72, bake_mode="attachment"),
            Landmark("vine_bridge_anchor", "vine_bridge_anchor", center=(0.62, 0.18), radius=0.12, dominance=0.38, bake_mode="mask_only"),
        ),
        paths=(
            PathRoute("forest_main_path", "main_path", points=((0.9, 0.0), (0.35, -0.1), (-0.25, 0.25)), width=0.14, max_slope_m=3.0),
            PathRoute("vine_bridge", "bridge_anchor", points=((0.62, 0.18), (0.2, 0.42)), width=0.08, max_slope_m=4.0),
        ),
        zones=(
            Zone("mushroom_pocket", "pcg", center=(0.28, 0.34), radius_range=(0.18, 0.42), walkable=True, height_role="shelf"),
            Zone("glowing_root_cave", "pcg", center=(-0.25, 0.25), radius_range=(0.14, 0.34), walkable=True, height_role="attachment_anchor"),
            Zone("canopy_platform", "arena", center=(0.0, 0.0), radius_range=(0.0, 0.44), walkable=True, height_role="soft_plateau"),
        ),
        material_masks=(
            MaterialMask("M_TopGrass", "pcg_zones", "moss_and_grass"),
            MaterialMask("M_PathDirt", "forest_main_path", "walkable_route"),
            MaterialMask("M_ElementCrack", "glowing_root_cave", "glow_cave_marker"),
        ),
        process={
            "detail_energy": 1.0,
            "erosion_age": 0.45,
            "deposition_weight": 0.55,
        },
    )


def _zone_from_dict(data: dict[str, Any]) -> Zone:
    return Zone(
        id=data["id"],
        kind=data["kind"],
        center=tuple(data.get("center", (0.0, 0.0))),
        radius_range=tuple(data.get("radius_range", (0.0, 1.0))),
        walkable=bool(data.get("walkable", True)),
        height_role=data.get("height_role", "neutral"),
    )


def _landmark_from_dict(data: dict[str, Any]) -> Landmark:
    return Landmark(
        id=data["id"],
        kind=data["kind"],
        center=tuple(data.get("center", (0.0, 0.0))),
        radius=float(data.get("radius", 0.25)),
        dominance=float(data.get("dominance", 0.5)),
        bake_mode=data.get("bake_mode", "terrain"),
        count=int(data.get("count", 1)),
    )


def _path_from_dict(data: dict[str, Any]) -> PathRoute:
    return PathRoute(
        id=data["id"],
        kind=data["kind"],
        points=tuple(tuple(point) for point in data.get("points", ())),
        width=float(data.get("width", 0.1)),
        max_slope_m=float(data.get("max_slope_m", 4.0)),
        material=data.get("material", "M_PathDirt"),
        coverage=float(data.get("coverage", 1.0)),
    )


def _material_mask_from_dict(data: dict[str, Any]) -> MaterialMask:
    slot = data["slot"]
    if slot not in ALL_MATERIAL_SLOTS:
        raise ValueError(f"Unknown material slot: {slot}")
    return MaterialMask(slot=slot, source=data["source"], meaning=data["meaning"])
