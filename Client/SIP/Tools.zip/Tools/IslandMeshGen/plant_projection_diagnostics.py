#!/usr/bin/env python3
"""Estimate how a Meshy PBR GLB would project onto regrouped Auto Split parts.

This is a diagnostic bridge, not the final cutter. It answers the practical
question: "If we use the regroup manifest as semantic surfaces, how many PBR
triangles would land in each group, and how noisy is the projection?"
"""

from __future__ import annotations

import argparse
import itertools
import json
import math
import struct
import time
from collections import defaultdict
from pathlib import Path

import numpy as np


COMPONENT_DTYPE = {
    5120: np.int8,
    5121: np.uint8,
    5122: np.int16,
    5123: np.uint16,
    5125: np.uint32,
    5126: np.float32,
}

ACCESSOR_WIDTH = {
    "SCALAR": 1,
    "VEC2": 2,
    "VEC3": 3,
    "VEC4": 4,
    "MAT4": 16,
}

GROUP_ORDER = [
    "Core",
    "PrimarySilhouette",
    "OrbitSet",
    "BodyShell",
]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", required=True, help="Regroup manifest JSON.")
    split_source = parser.add_mutually_exclusive_group(required=True)
    split_source.add_argument("--split-obj", help="Meshy Auto Split OBJ.")
    split_source.add_argument("--split-glb", help="Meshy Auto Split/part-segmentation GLB.")
    parser.add_argument("--pbr-glb", required=True, help="Full PBR GLB.")
    parser.add_argument("--output", help="Optional output report JSON.")
    parser.add_argument(
        "--sample-faces",
        type=int,
        default=140_000,
        help="Number of PBR faces to sample for diagnostics. Use 0 for all faces.",
    )
    parser.add_argument(
        "--split-sample-faces",
        type=int,
        default=220_000,
        help="Number of split faces to sample for projection surface. Use 0 for all faces.",
    )
    parser.add_argument("--cell-size", type=float, default=0.055, help="Spatial hash cell size in normalized units.")
    parser.add_argument("--seed", type=int, default=23, help="Deterministic sampling seed.")
    return parser.parse_args()


def load_manifest(path: Path) -> tuple[dict[str, str], dict[str, str], dict]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    name_to_group: dict[str, str] = {}
    material_to_group: dict[str, str] = {}
    for group, parts in payload.get("semantic_groups", {}).items():
        for part in parts:
            if part.get("name"):
                name_to_group[str(part["name"])] = group
            if part.get("material"):
                material_to_group[str(part["material"])] = group
    return name_to_group, material_to_group, payload


def parse_obj_tri_centers(path: Path, name_to_group: dict[str, str], material_to_group: dict[str, str]):
    vertices: list[tuple[float, float, float]] = []
    centers: list[tuple[float, float, float]] = []
    group_ids: list[int] = []
    group_names: list[str] = []
    current_name = "mesh_0"
    current_material = "model_part0"

    def group_index(name: str) -> int:
        if name not in group_names:
            group_names.append(name)
        return group_names.index(name)

    def active_group() -> str:
        return name_to_group.get(current_name) or material_to_group.get(current_material) or "Unassigned"

    with path.open("r", encoding="utf-8", errors="ignore") as handle:
        for raw_line in handle:
            if not raw_line:
                continue
            if raw_line.startswith("v "):
                values = raw_line.split()
                if len(values) >= 4:
                    vertices.append((float(values[1]), float(values[2]), float(values[3])))
                continue
            if raw_line.startswith("o ") or raw_line.startswith("g "):
                name = raw_line[2:].strip()
                if name:
                    current_name = name
                continue
            if raw_line.startswith("usemtl "):
                current_material = raw_line[7:].strip() or current_material
                continue
            if raw_line.startswith("f "):
                tokens = raw_line.split()[1:]
                indices = [parse_obj_index(token, len(vertices)) for token in tokens]
                if len(indices) < 3:
                    continue
                group_id = group_index(active_group())
                for i in range(1, len(indices) - 1):
                    a = vertices[indices[0]]
                    b = vertices[indices[i]]
                    c = vertices[indices[i + 1]]
                    centers.append(((a[0] + b[0] + c[0]) / 3.0, (a[1] + b[1] + c[1]) / 3.0, (a[2] + b[2] + c[2]) / 3.0))
                    group_ids.append(group_id)

    return np.asarray(centers, dtype=np.float32), np.asarray(group_ids, dtype=np.int16), group_names, len(vertices)


def parse_obj_index(token: str, vertex_count: int) -> int:
    raw = int(token.split("/")[0])
    return vertex_count + raw if raw < 0 else raw - 1


def node_matrix(node: dict) -> np.ndarray:
    if "matrix" in node:
        return np.asarray(node["matrix"], dtype=np.float32).reshape((4, 4)).T
    translation = np.asarray(node.get("translation", [0, 0, 0]), dtype=np.float32)
    scale = np.asarray(node.get("scale", [1, 1, 1]), dtype=np.float32)
    rotation = np.asarray(node.get("rotation", [0, 0, 0, 1]), dtype=np.float32)
    matrix = quat_matrix(rotation)
    matrix[:3, :3] *= scale.reshape((1, 3))
    matrix[:3, 3] = translation
    return matrix


def quat_matrix(q: np.ndarray) -> np.ndarray:
    x, y, z, w = q
    xx, yy, zz = x * x, y * y, z * z
    xy, xz, yz = x * y, x * z, y * z
    wx, wy, wz = w * x, w * y, w * z
    return np.asarray([
        [1 - 2 * (yy + zz), 2 * (xy - wz), 2 * (xz + wy), 0],
        [2 * (xy + wz), 1 - 2 * (xx + zz), 2 * (yz - wx), 0],
        [2 * (xz - wy), 2 * (yz + wx), 1 - 2 * (xx + yy), 0],
        [0, 0, 0, 1],
    ], dtype=np.float32)


def scene_node_indices(doc: dict) -> list[int]:
    if doc.get("scenes"):
        scene_index = int(doc.get("scene", 0))
        nodes = doc["scenes"][scene_index].get("nodes", [])
        return [int(node) for node in nodes]
    return list(range(len(doc.get("nodes", []))))


def world_matrices(doc: dict) -> dict[int, np.ndarray]:
    nodes = doc.get("nodes", [])
    matrices: dict[int, np.ndarray] = {}

    def visit(index: int, parent: np.ndarray) -> None:
        local = node_matrix(nodes[index])
        world = parent @ local
        matrices[index] = world
        for child in nodes[index].get("children", []):
            visit(int(child), world)

    for root in scene_node_indices(doc):
        if 0 <= root < len(nodes):
            visit(root, np.eye(4, dtype=np.float32))
    for index in range(len(nodes)):
        matrices.setdefault(index, node_matrix(nodes[index]))
    return matrices


def transform_points(points: np.ndarray, matrix: np.ndarray) -> np.ndarray:
    ones = np.ones((len(points), 1), dtype=np.float32)
    hom = np.hstack([points.astype(np.float32), ones])
    return (hom @ matrix.T)[:, :3]


def transform_normals(normals: np.ndarray, matrix: np.ndarray) -> np.ndarray:
    try:
        normal_matrix = np.linalg.inv(matrix[:3, :3]).T
    except np.linalg.LinAlgError:
        normal_matrix = matrix[:3, :3]
    transformed_normals = normals.astype(np.float32) @ normal_matrix.T
    lengths = np.linalg.norm(transformed_normals, axis=1, keepdims=True)
    lengths = np.maximum(lengths, 1e-8)
    return (transformed_normals / lengths).astype(np.float32)


def read_glb(path: Path) -> tuple[dict, bytes]:
    data = path.read_bytes()
    if len(data) < 20:
        raise ValueError(f"{path} is too small to be a GLB.")
    magic, version, total_length = struct.unpack_from("<III", data, 0)
    if magic != 0x46546C67 or version != 2:
        raise ValueError(f"{path} is not a GLB 2.0 file.")
    offset = 12
    json_doc = None
    bin_chunk = None
    while offset < total_length:
        chunk_length, chunk_type = struct.unpack_from("<II", data, offset)
        offset += 8
        chunk = data[offset : offset + chunk_length]
        offset += chunk_length
        if chunk_type == 0x4E4F534A:
            json_doc = json.loads(chunk.decode("utf-8"))
        elif chunk_type == 0x004E4942:
            bin_chunk = chunk
    if json_doc is None or bin_chunk is None:
        raise ValueError("GLB must contain JSON and BIN chunks.")
    return json_doc, bin_chunk


def accessor_array(doc: dict, bin_chunk: bytes, accessor_index: int) -> np.ndarray:
    accessor = doc["accessors"][accessor_index]
    buffer_view = doc["bufferViews"][accessor["bufferView"]]
    dtype = np.dtype(COMPONENT_DTYPE[accessor["componentType"]]).newbyteorder("<")
    width = ACCESSOR_WIDTH[accessor["type"]]
    count = int(accessor["count"])
    byte_offset = int(buffer_view.get("byteOffset", 0)) + int(accessor.get("byteOffset", 0))
    byte_stride = buffer_view.get("byteStride")
    if accessor.get("sparse"):
        raise ValueError("Sparse accessors are not supported by this diagnostic script.")
    if byte_stride and byte_stride != dtype.itemsize * width:
        rows = []
        for i in range(count):
            start = byte_offset + i * byte_stride
            rows.append(np.frombuffer(bin_chunk, dtype=dtype, count=width, offset=start))
        array = np.vstack(rows)
    else:
        array = np.frombuffer(bin_chunk, dtype=dtype, count=count * width, offset=byte_offset)
        array = array.reshape((count, width))
    if accessor.get("normalized"):
        array = normalize_integer_accessor(array, accessor["componentType"])
    return np.asarray(array)


def normalize_integer_accessor(array: np.ndarray, component_type: int) -> np.ndarray:
    array = array.astype(np.float32)
    if component_type == 5120:
        return np.maximum(array / 127.0, -1.0)
    if component_type == 5121:
        return array / 255.0
    if component_type == 5122:
        return np.maximum(array / 32767.0, -1.0)
    if component_type == 5123:
        return array / 65535.0
    return array


def parse_glb_tri_centers(path: Path, name_to_group: dict[str, str], material_to_group: dict[str, str]):
    doc, bin_chunk = read_glb(path)
    centers: list[np.ndarray] = []
    group_ids: list[int] = []
    group_names: list[str] = []
    vertex_count = 0
    matrices = world_matrices(doc)
    nodes = doc.get("nodes", [])
    meshes = doc.get("meshes", [])
    materials = doc.get("materials", [])

    def group_index(name: str) -> int:
        if name not in group_names:
            group_names.append(name)
        return group_names.index(name)

    def material_name(material_index: int) -> str:
        if 0 <= material_index < len(materials):
            return materials[material_index].get("name") or f"model_part{material_index}"
        return ""

    def active_group(node_name: str, mesh_name: str, material_index: int) -> str:
        mat_name = material_name(material_index)
        for candidate in (
            node_name,
            mesh_name,
            mat_name,
            f"model_part{material_index}",
            str(material_index),
        ):
            if candidate and candidate in name_to_group:
                return name_to_group[candidate]
            if candidate and candidate in material_to_group:
                return material_to_group[candidate]
        return "Unassigned"

    def append_primitive(node_name: str, mesh_name: str, primitive: dict, world: np.ndarray) -> None:
        nonlocal vertex_count
        attributes = primitive.get("attributes", {})
        if primitive.get("mode", 4) != 4 or "POSITION" not in attributes:
            return
        positions = accessor_array(doc, bin_chunk, attributes["POSITION"]).astype(np.float32)
        positions = transform_points(positions, world)
        vertex_count += len(positions)
        if "indices" in primitive:
            indices = accessor_array(doc, bin_chunk, primitive["indices"]).astype(np.int64).reshape(-1)
            face_count = len(indices) // 3
            triangles = positions[indices[: face_count * 3]].reshape((-1, 3, 3))
        else:
            face_count = len(positions) // 3
            triangles = positions[: face_count * 3].reshape((-1, 3, 3))
        if face_count == 0:
            return
        material_index = int(primitive.get("material", -1))
        group_id = group_index(active_group(node_name, mesh_name, material_index))
        centers.append(triangles.mean(axis=1))
        group_ids.extend([group_id] * face_count)

    if nodes:
        for node_index, node in enumerate(nodes):
            if "mesh" not in node:
                continue
            mesh_index = int(node["mesh"])
            if not (0 <= mesh_index < len(meshes)):
                continue
            mesh = meshes[mesh_index]
            node_name = node.get("name") or mesh.get("name") or f"mesh_{mesh_index}"
            mesh_name = mesh.get("name") or node_name
            world = matrices.get(node_index, np.eye(4, dtype=np.float32))
            for primitive in mesh.get("primitives", []):
                append_primitive(node_name, mesh_name, primitive, world)
    else:
        for mesh_index, mesh in enumerate(meshes):
            mesh_name = mesh.get("name") or f"mesh_{mesh_index}"
            for primitive in mesh.get("primitives", []):
                append_primitive(mesh_name, mesh_name, primitive, np.eye(4, dtype=np.float32))

    if not centers:
        raise ValueError("No triangle primitives with POSITION were found in split GLB.")
    return np.vstack(centers).astype(np.float32), np.asarray(group_ids, dtype=np.int16), group_names, vertex_count


def glb_tri_centers(path: Path):
    doc, bin_chunk = read_glb(path)
    centers = []
    primitive_count = 0
    material_indices = []
    matrices = world_matrices(doc)
    nodes = doc.get("nodes", [])
    meshes = doc.get("meshes", [])

    def append_primitive(primitive: dict, world: np.ndarray) -> None:
        nonlocal primitive_count
        attributes = primitive.get("attributes", {})
        if primitive.get("mode", 4) != 4 or "POSITION" not in attributes:
            return
        positions = accessor_array(doc, bin_chunk, attributes["POSITION"]).astype(np.float32)
        positions = transform_points(positions, world)
        if "indices" in primitive:
            indices = accessor_array(doc, bin_chunk, primitive["indices"]).astype(np.int64).reshape(-1)
            face_count = len(indices) // 3
            triangles = positions[indices[: face_count * 3]].reshape((-1, 3, 3))
        else:
            face_count = len(positions) // 3
            triangles = positions[: face_count * 3].reshape((-1, 3, 3))
        primitive_centers = triangles.mean(axis=1)
        centers.append(primitive_centers)
        material_indices.extend([int(primitive.get("material", -1))] * len(primitive_centers))
        primitive_count += 1

    if nodes:
        for node_index, node in enumerate(nodes):
            if "mesh" not in node:
                continue
            mesh_index = int(node["mesh"])
            if not (0 <= mesh_index < len(meshes)):
                continue
            mesh = meshes[mesh_index]
            world = matrices.get(node_index, np.eye(4, dtype=np.float32))
            for primitive in mesh.get("primitives", []):
                append_primitive(primitive, world)
    else:
        for mesh in meshes:
            for primitive in mesh.get("primitives", []):
                append_primitive(primitive, np.eye(4, dtype=np.float32))

    if not centers:
        raise ValueError("No triangle primitives with POSITION were found in PBR GLB.")
    return np.vstack(centers).astype(np.float32), np.asarray(material_indices, dtype=np.int16), doc, primitive_count


def deterministic_sample(count: int, limit: int, seed: int) -> np.ndarray:
    if limit <= 0 or count <= limit:
        return np.arange(count, dtype=np.int64)
    rng = np.random.default_rng(seed)
    sample = rng.choice(count, size=limit, replace=False)
    return np.sort(sample)


def canonicalize(points: np.ndarray) -> tuple[np.ndarray, dict]:
    mins = points.min(axis=0)
    maxs = points.max(axis=0)
    center = (mins + maxs) * 0.5
    extents = maxs - mins
    scale = float(max(extents.max(), 1e-8))
    normalized = (points - center) / scale
    return normalized.astype(np.float32), {
        "min": mins.tolist(),
        "max": maxs.tolist(),
        "center": center.tolist(),
        "extents": extents.tolist(),
        "scale": scale,
    }


def transformed(points: np.ndarray, permutation: tuple[int, int, int], signs: tuple[int, int, int]) -> np.ndarray:
    sign_array = np.asarray(signs, dtype=np.float32)
    return points[:, permutation] * sign_array


def build_grid(points: np.ndarray, cell_size: float) -> dict[tuple[int, int, int], np.ndarray]:
    cells = np.floor(points / cell_size).astype(np.int32)
    buckets: dict[tuple[int, int, int], list[int]] = defaultdict(list)
    for idx, cell in enumerate(cells):
        buckets[(int(cell[0]), int(cell[1]), int(cell[2]))].append(idx)
    return {key: np.asarray(value, dtype=np.int64) for key, value in buckets.items()}


def query_grid(points: np.ndarray, split_points: np.ndarray, split_group_ids: np.ndarray, grid, cell_size: float):
    distances = np.empty(len(points), dtype=np.float32)
    groups = np.empty(len(points), dtype=np.int16)
    neighbor_offsets = [
        (dx, dy, dz)
        for dx in (-1, 0, 1)
        for dy in (-1, 0, 1)
        for dz in (-1, 0, 1)
    ]
    fallback_offsets = [
        (dx, dy, dz)
        for dx in (-2, -1, 0, 1, 2)
        for dy in (-2, -1, 0, 1, 2)
        for dz in (-2, -1, 0, 1, 2)
    ]
    for i, point in enumerate(points):
        base = tuple(np.floor(point / cell_size).astype(np.int32).tolist())
        candidates = collect_candidates(grid, base, neighbor_offsets)
        if candidates.size == 0:
            candidates = collect_candidates(grid, base, fallback_offsets)
        if candidates.size == 0:
            candidates = np.arange(len(split_points), dtype=np.int64)
        deltas = split_points[candidates] - point
        dist2 = np.einsum("ij,ij->i", deltas, deltas)
        local = int(np.argmin(dist2))
        split_index = int(candidates[local])
        distances[i] = math.sqrt(float(dist2[local]))
        groups[i] = split_group_ids[split_index]
    return groups, distances


def collect_candidates(grid, base, offsets) -> np.ndarray:
    chunks = []
    bx, by, bz = base
    for dx, dy, dz in offsets:
        chunk = grid.get((bx + dx, by + dy, bz + dz))
        if chunk is not None:
            chunks.append(chunk)
    if not chunks:
        return np.empty(0, dtype=np.int64)
    return np.concatenate(chunks)


def choose_axis_transform(split_points: np.ndarray, pbr_points: np.ndarray, split_group_ids: np.ndarray, cell_size: float, seed: int):
    # Axis/sign search is only an alignment bootstrap. Keep it deliberately
    # small; the full diagnostic query below uses the larger requested samples.
    split_idx = deterministic_sample(len(split_points), min(18_000, len(split_points)), seed + 101)
    pbr_idx = deterministic_sample(len(pbr_points), min(2_500, len(pbr_points)), seed + 211)
    split_sample = split_points[split_idx]
    split_groups = split_group_ids[split_idx]
    pbr_sample = pbr_points[pbr_idx]
    best = None
    for permutation in itertools.permutations((0, 1, 2)):
        for signs in itertools.product((-1, 1), repeat=3):
            candidate_split = transformed(split_sample, permutation, signs)
            grid = build_grid(candidate_split, cell_size)
            _, distances = query_grid(pbr_sample, candidate_split, split_groups, grid, cell_size)
            score = float(np.percentile(distances, 75) + distances.mean())
            if best is None or score < best["score"]:
                best = {
                    "score": score,
                    "permutation": permutation,
                    "signs": signs,
                    "mean_distance": float(distances.mean()),
                    "p75_distance": float(np.percentile(distances, 75)),
                    "p95_distance": float(np.percentile(distances, 95)),
                }
    assert best is not None
    return best


def summarize_projection(groups, distances, group_names, total_face_count, sample_count):
    scale_factor = total_face_count / max(sample_count, 1)
    summaries = {name: {"sample_faces": 0, "estimated_faces": 0, "coverage": 0.0} for name in GROUP_ORDER}
    for group_id in groups:
        name = group_names[int(group_id)] if int(group_id) < len(group_names) else "Ignore"
        if name not in summaries:
            summaries[name] = {"sample_faces": 0, "estimated_faces": 0, "coverage": 0.0}
        summaries[name]["sample_faces"] += 1
    for summary in summaries.values():
        summary["estimated_faces"] = int(round(summary["sample_faces"] * scale_factor))
        summary["coverage"] = round(summary["sample_faces"] / max(sample_count, 1), 6)
    return {
        "groups": summaries,
        "distance": {
            "mean": round(float(distances.mean()), 6),
            "median": round(float(np.median(distances)), 6),
            "p75": round(float(np.percentile(distances, 75)), 6),
            "p90": round(float(np.percentile(distances, 90)), 6),
            "p95": round(float(np.percentile(distances, 95)), 6),
            "max": round(float(distances.max()), 6),
        },
    }


def verdict(distance_summary: dict) -> dict:
    p90 = distance_summary["p90"]
    p95 = distance_summary["p95"]
    if p90 < 0.035 and p95 < 0.06:
        return {
            "level": "good",
            "message": "Projection is tight enough to attempt a first PBR part export.",
        }
    if p90 < 0.07 and p95 < 0.11:
        return {
            "level": "usable_with_cleanup",
            "message": "Projection is usable for a draft cut, but boundary cleanup or group locking will matter.",
        }
    return {
        "level": "risky",
        "message": "Projection distance is high. Recheck axis alignment, Meshy topology changes, or semantic grouping before cutting PBR parts.",
    }


def main() -> None:
    args = parse_args()
    started_at = time.perf_counter()
    manifest_path = Path(args.manifest)
    split_obj_path = Path(args.split_obj) if args.split_obj else None
    split_glb_path = Path(args.split_glb) if args.split_glb else None
    pbr_glb_path = Path(args.pbr_glb)

    name_to_group, material_to_group, manifest = load_manifest(manifest_path)
    if split_glb_path:
        split_centers, split_group_ids, group_names, split_vertex_count = parse_glb_tri_centers(
            split_glb_path,
            name_to_group,
            material_to_group,
        )
        split_source_kind = "glb"
    elif split_obj_path:
        split_centers, split_group_ids, group_names, split_vertex_count = parse_obj_tri_centers(
            split_obj_path,
            name_to_group,
            material_to_group,
        )
        split_source_kind = "obj"
    else:
        raise ValueError("Provide either --split-obj or --split-glb.")
    pbr_centers, pbr_materials, pbr_doc, primitive_count = glb_tri_centers(pbr_glb_path)

    split_normalized, split_bounds = canonicalize(split_centers)
    pbr_normalized, pbr_bounds = canonicalize(pbr_centers)
    split_sample_idx = deterministic_sample(len(split_normalized), args.split_sample_faces, args.seed + 5)
    pbr_sample_idx = deterministic_sample(len(pbr_normalized), args.sample_faces, args.seed + 7)
    split_surface = split_normalized[split_sample_idx]
    split_surface_groups = split_group_ids[split_sample_idx]
    pbr_sample = pbr_normalized[pbr_sample_idx]

    axis_transform = choose_axis_transform(
        split_surface,
        pbr_sample,
        split_surface_groups,
        args.cell_size,
        args.seed,
    )
    split_projected = transformed(split_surface, tuple(axis_transform["permutation"]), tuple(axis_transform["signs"]))
    grid = build_grid(split_projected, args.cell_size)
    projected_groups, distances = query_grid(
        pbr_sample,
        split_projected,
        split_surface_groups,
        grid,
        args.cell_size,
    )
    summary = summarize_projection(projected_groups, distances, group_names, len(pbr_normalized), len(pbr_sample))
    report = {
        "schema": "SkyIslandPotion.PlantProjectionDiagnostics.v1",
        "source": {
            "manifest": str(manifest_path),
            "split_obj": str(split_obj_path) if split_obj_path else None,
            "split_glb": str(split_glb_path) if split_glb_path else None,
            "split_source_kind": split_source_kind,
            "pbr_glb": str(pbr_glb_path),
            "manifest_source": manifest.get("source", {}),
        },
        "counts": {
            "split_vertices": split_vertex_count,
            "split_faces": int(len(split_centers)),
            "split_surface_sample_faces": int(len(split_surface)),
            "pbr_faces": int(len(pbr_normalized)),
            "pbr_sample_faces": int(len(pbr_sample)),
            "pbr_primitives": int(primitive_count),
            "pbr_material_slots": int(len(pbr_doc.get("materials", []))),
            "pbr_images": int(len(pbr_doc.get("images", []))),
        },
        "bounds": {
            "split": split_bounds,
            "pbr": pbr_bounds,
        },
        "axis_transform": {
            "split_axis_permutation_to_pbr": list(axis_transform["permutation"]),
            "split_axis_signs": list(axis_transform["signs"]),
            "selection_score": round(axis_transform["score"], 6),
            "search_mean_distance": round(axis_transform["mean_distance"], 6),
            "search_p75_distance": round(axis_transform["p75_distance"], 6),
            "search_p95_distance": round(axis_transform["p95_distance"], 6),
        },
        "projection": summary,
        "verdict": verdict(summary["distance"]),
        "elapsed_ms": int(round((time.perf_counter() - started_at) * 1000)),
    }
    if args.output:
        output_path = Path(args.output)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
