import csv
import json
import re
import sys
from datetime import datetime
from pathlib import Path

import unreal


def _tool_script_dir():
    script_path = globals().get("__file__")
    if script_path:
        return Path(script_path).resolve().parent

    project_dir = Path(unreal.Paths.project_dir()).resolve()
    candidates = [
        project_dir.parents[1] / "Tools" / "IslandMeshGen",
        project_dir.parent / "Tools" / "IslandMeshGen",
        Path.cwd(),
    ]
    for candidate in candidates:
        if (candidate / "plant_assembly_audit.py").exists():
            return candidate
    return candidates[0]


TOOL_DIR = _tool_script_dir()
sys.path.insert(0, str(TOOL_DIR))
sys.modules.pop("plant_assembly_audit", None)

from plant_assembly_audit import summarize_assembly_audit


PLANT_LABEL_PREFIX = "SIP_AIGC_AllCombPlant"
AUDIT_LABEL_PREFIX = "SIP_AIGC_AuditLabel"
AUDIT_TAG = "AIGCResourcePlantAssemblyAudit"

SLOT_COMPONENT_PROPERTY = {
    "BodyShell": "body_shell_root_slot",
    "PrimarySilhouette": "primary_silhouette_slot",
    "Core": "core_slot",
    "OrbitSet": "orbit_node_a_slot",
}

LABEL_PATTERN = re.compile(
    r"^SIP_AIGC_AllCombPlant_(?P<family>[A-Za-z0-9]+)_I(?P<index>\d+)_"
    r"B(?P<body>\d)_P(?P<primary>\d)_C(?P<core>\d)_O(?P<orbit>\d)$"
)

OUTPUT_DIR = TOOL_DIR / "output" / "plant_assembly_audits"

DEFAULT_ARGS = {
    "spawn_labels": True,
    "clear_previous_labels": True,
    "max_labels": 48,
    "label_statuses": ["critical", "review"],
}


def _get_args():
    args = dict(DEFAULT_ARGS)
    if hasattr(unreal, "get_mcp_args"):
        supplied = unreal.get_mcp_args()
        if isinstance(supplied, dict):
            args.update(supplied)
    args["spawn_labels"] = bool(args["spawn_labels"])
    args["clear_previous_labels"] = bool(args["clear_previous_labels"])
    args["max_labels"] = max(0, int(args["max_labels"]))
    args["label_statuses"] = [str(value) for value in args.get("label_statuses", [])]
    return args


def _vector_to_tuple(vector):
    return (
        int(vector.get("BodyShell", 0)),
        int(vector.get("PrimarySilhouette", 0)),
        int(vector.get("Core", 0)),
        int(vector.get("OrbitSet", 0)),
    )


def _calculate_metrics(vector):
    weights = {
        "BodyShell": 0.20,
        "PrimarySilhouette": 0.35,
        "Core": 0.25,
        "OrbitSet": 0.20,
    }
    severity = sum(weights[slot] * int(vector.get(slot, 0)) for slot in weights)
    dispersion = sum(weights[slot] * (int(vector.get(slot, 0)) - severity) ** 2 for slot in weights)
    return {
        "severity": severity,
        "dispersion": dispersion,
    }


def _parse_actor_label(actor):
    label = actor.get_actor_label()
    match = LABEL_PATTERN.match(label)
    if not match:
        return None

    vector = {
        "BodyShell": int(match.group("body")),
        "PrimarySilhouette": int(match.group("primary")),
        "Core": int(match.group("core")),
        "OrbitSet": int(match.group("orbit")),
    }
    return {
        "label": label,
        "family": match.group("family"),
        "vector_index": int(match.group("index")),
        "collapse_vector": vector,
        "vector_slug": "B{}_P{}_C{}_O{}".format(*_vector_to_tuple(vector)),
        "metrics": _calculate_metrics(vector),
    }


def _component_z_bounds(component):
    local_min, local_max = component.get_local_bounds()
    location = component.get_editor_property("relative_location")
    scale = component.get_editor_property("relative_scale3d")
    actor_z = component.get_owner().get_actor_location().z
    z0 = actor_z + location.z + local_min.z * scale.z
    z1 = actor_z + location.z + local_max.z * scale.z
    return [min(z0, z1), max(z0, z1)]


def _component_center(component):
    local_min, local_max = component.get_local_bounds()
    location = component.get_editor_property("relative_location")
    scale = component.get_editor_property("relative_scale3d")
    actor_location = component.get_owner().get_actor_location()
    return [
        actor_location.x + location.x + ((local_min.x + local_max.x) * 0.5) * scale.x,
        actor_location.y + location.y + ((local_min.y + local_max.y) * 0.5) * scale.y,
        actor_location.z + location.z + ((local_min.z + local_max.z) * 0.5) * scale.z,
    ]


def _distance(a, b):
    return sum((float(a[index]) - float(b[index])) ** 2 for index in range(3)) ** 0.5


def _height(z_bounds):
    return max(0.0, float(z_bounds[1]) - float(z_bounds[0]))


def _safe_ratio(numerator, denominator):
    denominator = float(denominator)
    if abs(denominator) <= 1e-6:
        return 0.0
    return float(numerator) / denominator


def _measure_actor(actor):
    components = {
        slot: actor.get_editor_property(component_property)
        for slot, component_property in SLOT_COMPONENT_PROPERTY.items()
    }
    z_bounds = {slot: _component_z_bounds(component) for slot, component in components.items()}
    centers = {slot: _component_center(component) for slot, component in components.items()}
    heights = {slot: _height(bounds) for slot, bounds in z_bounds.items()}

    min_z = min(bounds[0] for bounds in z_bounds.values())
    max_z = max(bounds[1] for bounds in z_bounds.values())
    return {
        "slot_z_bounds": z_bounds,
        "slot_centers": centers,
        "slot_heights": heights,
        "body_primary_gap_cm": z_bounds["PrimarySilhouette"][0] - z_bounds["BodyShell"][1],
        "core_to_primary_height_ratio": _safe_ratio(heights["Core"], heights["PrimarySilhouette"]),
        "core_to_body_height_ratio": _safe_ratio(heights["Core"], heights["BodyShell"]),
        "core_primary_center_distance_cm": _distance(centers["Core"], centers["PrimarySilhouette"]),
        "plant_height_cm": max_z - min_z,
    }


def _clear_previous_labels():
    subsystem = unreal.get_editor_subsystem(unreal.EditorActorSubsystem)
    removed = 0
    for actor in list(subsystem.get_all_level_actors()):
        label = actor.get_actor_label()
        has_tag = any(str(tag) == AUDIT_TAG for tag in actor.tags)
        if has_tag or label.startswith(AUDIT_LABEL_PREFIX):
            subsystem.destroy_actor(actor)
            removed += 1
    return removed


def _spawn_label(label, location, text, status):
    text_actor_class = getattr(unreal, "TextRenderActor", None)
    if text_actor_class is None:
        return None

    subsystem = unreal.get_editor_subsystem(unreal.EditorActorSubsystem)
    actor = subsystem.spawn_actor_from_class(
        text_actor_class,
        unreal.Vector(float(location[0]), float(location[1]), float(location[2])),
        unreal.Rotator(66.0, 90.0, 0.0),
    )
    actor.set_actor_label(label)
    actor.tags = [unreal.Name(AUDIT_TAG)]

    component = actor.get_editor_property("text_render")
    component.set_text(text)
    component.set_world_size(55.0 if status == "critical" else 44.0)
    component.set_horizontal_alignment(unreal.HorizTextAligment.EHTA_CENTER)
    if status == "critical":
        component.set_text_render_color(unreal.Color(255, 74, 40, 255))
    else:
        component.set_text_render_color(unreal.Color(255, 210, 64, 255))
    return actor


def _spawn_audit_labels(rows, max_labels, label_statuses):
    spawned = []
    for row in rows:
        audit = row["audit"]
        if len(spawned) >= max_labels:
            break
        if audit["status"] not in label_statuses:
            continue
        actor_location = row["actor_location"]
        location = [actor_location[0], actor_location[1], actor_location[2] + row["measurements"]["plant_height_cm"] + 110.0]
        text = "{}\n{}".format(row["vector_slug"], audit["issue_slug"])
        actor = _spawn_label(
            "{}_{}_{}".format(AUDIT_LABEL_PREFIX, row["family"], row["vector_slug"]),
            location,
            text,
            audit["status"],
        )
        if actor:
            spawned.append(actor)
    return spawned


def _write_outputs(summary):
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    json_path = OUTPUT_DIR / "plant_assembly_audit_{}.json".format(stamp)
    csv_path = OUTPUT_DIR / "plant_assembly_audit_{}.csv".format(stamp)

    json_path.write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")
    with csv_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=[
                "label",
                "family",
                "vector_slug",
                "status",
                "issues",
                "score",
                "severity",
                "dispersion",
                "body_primary_gap_cm",
                "core_to_primary_height_ratio",
                "core_primary_center_distance_cm",
                "plant_height_cm",
            ],
        )
        writer.writeheader()
        for row in summary["rows"]:
            measurements = row["measurements"]
            audit = row["audit"]
            metrics = row["metrics"]
            writer.writerow(
                {
                    "label": row["label"],
                    "family": row["family"],
                    "vector_slug": row["vector_slug"],
                    "status": audit["status"],
                    "issues": "|".join(audit["issues"]),
                    "score": audit["score"],
                    "severity": metrics["severity"],
                    "dispersion": metrics["dispersion"],
                    "body_primary_gap_cm": measurements["body_primary_gap_cm"],
                    "core_to_primary_height_ratio": measurements["core_to_primary_height_ratio"],
                    "core_primary_center_distance_cm": measurements["core_primary_center_distance_cm"],
                    "plant_height_cm": measurements["plant_height_cm"],
                }
            )

    return str(json_path), str(csv_path)


def main():
    args = _get_args()
    subsystem = unreal.get_editor_subsystem(unreal.EditorActorSubsystem)
    rows = []

    for actor in subsystem.get_all_level_actors():
        parsed = _parse_actor_label(actor)
        if not parsed:
            continue
        actor_location = actor.get_actor_location()
        parsed["actor_location"] = [actor_location.x, actor_location.y, actor_location.z]
        parsed["measurements"] = _measure_actor(actor)
        rows.append(parsed)

    summary = summarize_assembly_audit(rows)
    json_path, csv_path = _write_outputs(summary)
    removed_labels = _clear_previous_labels() if args["clear_previous_labels"] else 0
    spawned_labels = []
    if args["spawn_labels"]:
        spawned_labels = _spawn_audit_labels(summary["rows"], args["max_labels"], set(args["label_statuses"]))

    print(
        json.dumps(
            {
                "schema": "SkyIslandPotion.AIGCPlantAssemblyAuditRun.v0",
                "scanned_actor_count": len(rows),
                "removed_previous_labels": removed_labels,
                "spawned_label_count": len(spawned_labels),
                "json_path": json_path,
                "csv_path": csv_path,
                "status_counts": summary["status_counts"],
                "family_counts": summary["family_counts"],
                "issue_counts": summary["issue_counts"],
                "top_rows": [
                    {
                        "label": row["label"],
                        "family": row["family"],
                        "vector_slug": row["vector_slug"],
                        "audit": row["audit"],
                        "measurements": {
                            "body_primary_gap_cm": row["measurements"]["body_primary_gap_cm"],
                            "core_to_primary_height_ratio": row["measurements"]["core_to_primary_height_ratio"],
                            "core_primary_center_distance_cm": row["measurements"]["core_primary_center_distance_cm"],
                            "plant_height_cm": row["measurements"]["plant_height_cm"],
                        },
                    }
                    for row in summary["rows"][:18]
                ],
            },
            indent=2,
            ensure_ascii=False,
        )
    )


main()
