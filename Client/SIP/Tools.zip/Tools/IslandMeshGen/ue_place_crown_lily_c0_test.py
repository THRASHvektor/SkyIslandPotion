import json
from pathlib import Path

import unreal


ASSEMBLY_MANIFEST = Path(
    r"C:\Users\12542\Documents\Unreal Projects\SkyIslandPotion\Tools\IslandMeshGen\output\plant_regroup\CrownLily_local-upload-mr9cc1z8-Meshy_AI_Flamebound_Scepter_1783275149_part-segm-Meshy_AI_Fl\07_ue_test\assembly_manifest.json"
)

DESTINATION_PATH = "/Game/AIGC/Plants/CrownLily/C0_EndToEnd"
ACTOR_TAG = "AIGCPlantC0EndToEndTest"
LABEL_PREFIX = "SIP_AIGC_CrownLily_C0_EndToEndTest"
SPAWN_LOCATION = unreal.Vector(-1040.0, -520.0, 220.0)
SPAWN_ROTATION = unreal.Rotator(0.0, -18.0, 0.0)


def _load_static_mesh(asset_path: str) -> unreal.StaticMesh | None:
    asset = unreal.EditorAssetLibrary.load_asset(asset_path)
    if isinstance(asset, unreal.StaticMesh):
        return asset
    return None


def _import_glb(slot: str, glb_path: str) -> unreal.StaticMesh:
    asset_tools = unreal.AssetToolsHelpers.get_asset_tools()
    task = unreal.AssetImportTask()
    task.set_editor_property("filename", glb_path)
    task.set_editor_property("destination_path", DESTINATION_PATH)
    task.set_editor_property("destination_name", f"SM_CrownLily_C0_{slot}")
    task.set_editor_property("automated", True)
    task.set_editor_property("replace_existing", True)
    task.set_editor_property("save", True)

    asset_tools.import_asset_tasks([task])

    imported_paths = list(task.get_editor_property("imported_object_paths") or [])
    static_mesh_paths = []
    for path in imported_paths:
        mesh = _load_static_mesh(path)
        if mesh:
            static_mesh_paths.append(path)

    if not static_mesh_paths:
        # Some glTF importers create nested material/texture assets first; scan the folder as a fallback.
        for path in unreal.EditorAssetLibrary.list_assets(DESTINATION_PATH, recursive=True, include_folder=False):
            if f"SM_CrownLily_C0_{slot}" in path:
                mesh = _load_static_mesh(path)
                if mesh:
                    static_mesh_paths.append(path)

    if not static_mesh_paths:
        raise RuntimeError(f"GLB import did not produce a StaticMesh for {slot}: {glb_path}")

    mesh = _load_static_mesh(static_mesh_paths[0])
    if mesh is None:
        raise RuntimeError(f"Imported asset is not a StaticMesh for {slot}: {static_mesh_paths[0]}")
    return mesh


def _clear_previous_test_actors() -> int:
    subsystem = unreal.get_editor_subsystem(unreal.EditorActorSubsystem)
    removed = 0
    for actor in subsystem.get_all_level_actors():
        labels_match = actor.get_actor_label().startswith(LABEL_PREFIX)
        tags_match = any(str(tag) == ACTOR_TAG for tag in actor.tags)
        if labels_match or tags_match:
            subsystem.destroy_actor(actor)
            removed += 1
    return removed


def _spawn_slot_actor(slot: str, mesh: unreal.StaticMesh) -> unreal.Actor:
    subsystem = unreal.get_editor_subsystem(unreal.EditorActorSubsystem)
    actor = subsystem.spawn_actor_from_class(unreal.StaticMeshActor, SPAWN_LOCATION, SPAWN_ROTATION)
    actor.set_actor_label(f"{LABEL_PREFIX}_{slot}")
    actor.tags = [ACTOR_TAG, "AIGCPreview", "AIGCPreview.CrownLily", "AIGCPreview.C0", f"AIGCSlot.{slot}"]

    component = actor.static_mesh_component
    component.set_static_mesh(mesh)
    component.set_mobility(unreal.ComponentMobility.STATIC)
    return actor


def main() -> None:
    if not ASSEMBLY_MANIFEST.exists():
        raise RuntimeError(f"Assembly manifest not found: {ASSEMBLY_MANIFEST}")

    hint = json.loads(ASSEMBLY_MANIFEST.read_text(encoding="utf-8"))
    slots = hint["slots"]
    removed = _clear_previous_test_actors()

    imported = {}
    spawned = []
    for slot in ("BodyShell", "PrimarySilhouette", "Core", "OrbitSet"):
        glb_path = slots[slot]["glb_path"]
        if not Path(glb_path).exists():
            raise RuntimeError(f"Missing GLB for {slot}: {glb_path}")
        mesh = _import_glb(slot, glb_path)
        imported[slot] = mesh.get_path_name()
        spawned.append(_spawn_slot_actor(slot, mesh).get_actor_label())

    unreal.EditorLevelLibrary.set_selected_level_actors(
        [actor for actor in unreal.get_editor_subsystem(unreal.EditorActorSubsystem).get_all_level_actors() if actor.get_actor_label() in spawned]
    )

    print(
        json.dumps(
            {
                "removed_previous_test_actors": removed,
                "destination_path": DESTINATION_PATH,
                "spawn_location": [SPAWN_LOCATION.x, SPAWN_LOCATION.y, SPAWN_LOCATION.z],
                "placement_mode": "shared_origin_from_semantic_glb_parts",
                "imported_static_meshes": imported,
                "spawned_actors": spawned,
            },
            indent=2,
            ensure_ascii=False,
        )
    )


main()
