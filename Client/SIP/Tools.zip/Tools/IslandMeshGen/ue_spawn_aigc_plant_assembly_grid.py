import json
import sys
from pathlib import Path

import unreal


def _tool_script_dir():
    script_path = globals().get("__file__")
    if script_path:
        return Path(script_path).resolve().parent

    project_dir = Path(unreal.Paths.project_dir()).resolve()
    candidates = [
        project_dir.parents[1] / "Tools" / "IslandMeshGen",
        project_dir.parent / "Tools" / "IslandMeshGen",
        Path.cwd(),
    ]
    for candidate in candidates:
        if (candidate / "plant_collapse_sampler.py").exists():
            return candidate
    return candidates[0]


sys.path.insert(0, str(_tool_script_dir()))

from plant_collapse_sampler import BANDS, FAMILIES, SLOTS, sample_collapse_vector, vector_slug


TEST_TAG = "AIGCPlantAssemblyRandomTest"
LABEL_PREFIX = "SIP_AIGC_RandomPlant"

DEFAULT_ARGS = {
    "samples_per_band": 2,
    "seed": 7307,
    "origin": [-2100.0, -1200.0, 120.0],
    "family_spacing_y": 1450.0,
    "band_spacing_x": 920.0,
    "sample_spacing_y": 470.0,
    "scale": 1.0,
    "clear_previous": True,
    "spawn_labels": True,
}


def _get_args():
    args = dict(DEFAULT_ARGS)
    if hasattr(unreal, "get_mcp_args"):
        supplied = unreal.get_mcp_args()
        if isinstance(supplied, dict):
            args.update(supplied)
    args["samples_per_band"] = max(1, int(args["samples_per_band"]))
    args["seed"] = int(args["seed"])
    args["origin"] = [float(value) for value in args["origin"]]
    args["scale"] = max(0.01, float(args["scale"]))
    return args


def _load_static_mesh(asset_path):
    asset = unreal.EditorAssetLibrary.load_asset(asset_path)
    if isinstance(asset, unreal.StaticMesh):
        return asset
    return None


def _mesh_path(family, slot, level):
    return "/Game/AIGC/Plants/{}/C{}/{}".format(family, level, slot)


def _clear_previous():
    subsystem = unreal.get_editor_subsystem(unreal.EditorActorSubsystem)
    removed = 0
    for actor in list(subsystem.get_all_level_actors()):
        label = actor.get_actor_label()
        has_test_tag = any(str(tag) == TEST_TAG for tag in actor.tags)
        if has_test_tag or label.startswith(LABEL_PREFIX):
            subsystem.destroy_actor(actor)
            removed += 1
    return removed


def _spawn_static_mesh_actor(label, tags, mesh, location, rotation, scale):
    subsystem = unreal.get_editor_subsystem(unreal.EditorActorSubsystem)
    actor = subsystem.spawn_actor_from_class(unreal.StaticMeshActor, location, rotation)
    actor.set_actor_label(label)
    actor.tags = [unreal.Name(tag) for tag in tags]
    actor.set_actor_scale3d(unreal.Vector(scale, scale, scale))

    component = actor.static_mesh_component
    component.set_static_mesh(mesh)
    component.set_mobility(unreal.ComponentMobility.STATIC)
    component.component_tags = [unreal.Name(tag) for tag in tags]
    return actor


def _spawn_label(label, tags, text, location):
    if not hasattr(unreal, "TextRenderActor"):
        return None

    subsystem = unreal.get_editor_subsystem(unreal.EditorActorSubsystem)
    actor = subsystem.spawn_actor_from_class(unreal.TextRenderActor, location, unreal.Rotator(0.0, 0.0, 0.0))
    actor.set_actor_label(label)
    actor.tags = [unreal.Name(tag) for tag in tags]

    component = actor.get_component_by_class(unreal.TextRenderComponent)
    if component:
        component.set_text(text)
        component.set_world_size(42.0)
        component.set_horizontal_alignment(unreal.HorizTextAligment.EHTA_CENTER)
        component.set_vertical_alignment(unreal.VerticalTextAligment.EVRTA_TEXT_CENTER)
    return actor


def _slot_level(vector, slot):
    return int(vector[slot])


def _spawn_assembly(family, band, sample_index, vector, metrics, energy, location, scale, spawn_labels):
    group_id = "{}_{}_S{}_{}".format(family, band, sample_index, vector_slug(vector))
    base_tags = [
        TEST_TAG,
        "AIGCPlantAssemblyRandomTest.{}".format(family),
        "AIGCPlantAssemblyRandomTest.Band.{}".format(band),
        "AIGCPlantAssemblyRandomTest.Group.{}".format(group_id),
        "AIGCPlantAssemblyRandomTest.Vector.{}".format(vector_slug(vector)),
    ]

    spawned = []
    missing = []
    mesh_paths = {}

    for slot in SLOTS:
        level = _slot_level(vector, slot)
        asset_path = _mesh_path(family, slot, level)
        mesh = _load_static_mesh(asset_path)
        mesh_paths[slot] = asset_path
        if not mesh:
            missing.append(asset_path)
            continue

        label = "{}_{}_{}_S{}_{}_C{}".format(LABEL_PREFIX, family, band, sample_index, slot, level)
        tags = list(base_tags)
        tags.append("AIGCPlantAssemblyRandomTest.Slot.{}".format(slot))
        tags.append("AIGCPlantAssemblyRandomTest.C{}".format(level))
        actor = _spawn_static_mesh_actor(label, tags, mesh, location, unreal.Rotator(0.0, 0.0, 0.0), scale)
        spawned.append(actor)

    if spawn_labels:
        text = "{}\n{}\n{}\nS={:.2f} D={:.2f}".format(
            family,
            band.replace("_", " "),
            vector_slug(vector),
            metrics["severity"],
            metrics["dispersion"],
        )
        label_actor = _spawn_label(
            "{}_{}_{}_S{}_Label".format(LABEL_PREFIX, family, band, sample_index),
            base_tags + ["AIGCPlantAssemblyRandomTest.Label"],
            text,
            unreal.Vector(location.x, location.y, location.z + 260.0 * scale),
        )
        if label_actor:
            spawned.append(label_actor)

    return {
        "family": family,
        "band": band,
        "sample_index": sample_index,
        "group_id": group_id,
        "location": [location.x, location.y, location.z],
        "vector": vector,
        "metrics": metrics,
        "energy": energy,
        "mesh_paths": mesh_paths,
        "missing_assets": missing,
        "spawned_actor_labels": [actor.get_actor_label() for actor in spawned],
    }


def _select_test_actors():
    subsystem = unreal.get_editor_subsystem(unreal.EditorActorSubsystem)
    actors = [
        actor
        for actor in subsystem.get_all_level_actors()
        if any(str(tag) == TEST_TAG for tag in actor.tags)
    ]
    unreal.EditorLevelLibrary.set_selected_level_actors(actors)
    return len(actors)


def main():
    args = _get_args()
    removed = _clear_previous() if args["clear_previous"] else 0
    origin = unreal.Vector(args["origin"][0], args["origin"][1], args["origin"][2])
    scale = args["scale"]
    samples_per_band = args["samples_per_band"]
    base_seed = args["seed"]

    results = []
    for family_index, family in enumerate(FAMILIES):
        for band_index, band in enumerate(BANDS):
            for sample_index in range(samples_per_band):
                seed = base_seed + family_index * 1000 + band_index * 100 + sample_index * 17
                sample = sample_collapse_vector(seed=seed, band=band, family=family)
                vector = sample.vector
                metrics = sample.metrics
                energy = sample.energy
                location = unreal.Vector(
                    origin.x + band_index * float(args["band_spacing_x"]),
                    origin.y + family_index * float(args["family_spacing_y"]) + sample_index * float(args["sample_spacing_y"]),
                    origin.z,
                )
                result = _spawn_assembly(
                    family,
                    band,
                    sample_index,
                    vector,
                    metrics,
                    energy,
                    location,
                    scale,
                    bool(args["spawn_labels"]),
                )
                result["seed"] = seed
                results.append(result)

    selected_count = _select_test_actors()
    missing_assets = sorted({path for result in results for path in result["missing_assets"]})
    spawned_slot_actor_count = sum(
        1
        for result in results
        for label in result["spawned_actor_labels"]
        if not label.endswith("_Label")
    )

    print(
        json.dumps(
            {
                "removed_previous_test_actors": removed,
                "placement_mode": "four_static_mesh_actors_per_plant_shared_origin_readonly_aigc_assets",
                "asset_root": "/Game/AIGC/Plants/{Family}/C{Level}/{Slot}",
                "families": list(FAMILIES),
                "bands": list(BANDS),
                "samples_per_band": samples_per_band,
                "assemblies_spawned": len(results),
                "slot_actors_spawned": spawned_slot_actor_count,
                "selected_test_actors": selected_count,
                "missing_assets": missing_assets,
                "results": results,
            },
            indent=2,
            ensure_ascii=False,
        )
    )


main()
