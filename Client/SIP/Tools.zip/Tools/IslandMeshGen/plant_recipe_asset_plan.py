from plant_collapse_sampler import SLOTS


RECIPE_ASSET_ROOT = "/Game/AIGC/Plants/Recipes"


def _asset_name(recipe_id):
    return "DA_{}".format(recipe_id)


def _is_recipe_complete(recipe):
    mesh_slots = recipe.get("mesh_slots", {})
    for slot in SLOTS:
        slot_recipe = mesh_slots.get(slot)
        if not slot_recipe:
            return False
        if not slot_recipe.get("default_mesh"):
            return False
        variants = slot_recipe.get("variants", {})
        for level in range(4):
            if not variants.get("C{}".format(level)):
                return False
    return True


def build_recipe_asset_plan(recipe_plan, package_path=RECIPE_ASSET_ROOT, allow_partial=False):
    assets = []
    partial_recipes = []

    for recipe in recipe_plan.get("recipes", []):
        if not _is_recipe_complete(recipe):
            partial_recipes.append(recipe.get("recipe_id", "<unknown>"))
            if not allow_partial:
                raise ValueError("Refusing to create incomplete recipe assets: {}".format(partial_recipes))

        asset_name = _asset_name(recipe["recipe_id"])
        assets.append(
            {
                "asset_name": asset_name,
                "package_path": package_path,
                "object_path": "{}/{}".format(package_path, asset_name),
                "recipe": recipe,
                "is_complete": _is_recipe_complete(recipe),
            }
        )

    return {
        "schema": "SkyIslandPotion.AIGCPlantRecipeAssetPlan.v0",
        "package_path": package_path,
        "assets": assets,
        "partial_recipes": partial_recipes,
    }
