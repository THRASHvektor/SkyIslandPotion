import json
import sys
from pathlib import Path

import unreal


def _tool_script_dir():
    script_path = globals().get("__file__")
    if script_path:
        return Path(script_path).resolve().parent

    project_dir = Path(unreal.Paths.project_dir()).resolve()
    candidates = [
        project_dir.parents[1] / "Tools" / "IslandMeshGen",
        project_dir.parent / "Tools" / "IslandMeshGen",
        Path.cwd(),
    ]
    for candidate in candidates:
        if (candidate / "plant_all_combinations_layout.py").exists():
            return candidate
    return candidates[0]


TOOL_DIR = _tool_script_dir()
sys.path.insert(0, str(TOOL_DIR))

for module_name in (
    "plant_aigc_asset_catalog",
    "plant_all_combinations_layout",
    "plant_collapse_sampler",
    "plant_recipe_asset_plan",
):
    sys.modules.pop(module_name, None)

from plant_aigc_asset_catalog import build_asset_audit
from plant_all_combinations_layout import DEFAULT_ALL_COMBINATIONS_PRESET, build_all_combinations_layout
from plant_collapse_sampler import BANDS, FAMILIES, SLOTS
from plant_recipe_asset_plan import RECIPE_ASSET_ROOT


TEST_TAG = "AIGCResourcePlantAllCombinations"
PANORAMA_TEST_TAG = "AIGCResourcePlantPanorama"
LABEL_PREFIX = "SIP_AIGC_AllCombPlant"
STAGE_LABEL_PREFIX = "SIP_AIGC_AllCombStage"
PANORAMA_LABEL_PREFIX = "SIP_AIGC_PanoramaPlant"
PANORAMA_STAGE_LABEL_PREFIX = "SIP_AIGC_PanoramaStage"

SLOT_COMPONENT_PROPERTY = {
    "BodyShell": "body_shell_root_slot",
    "PrimarySilhouette": "primary_silhouette_slot",
    "Core": "core_slot",
    "OrbitSet": "orbit_node_a_slot",
}

DEFAULT_ARGS = {
    "families": list(FAMILIES),
    "bands": list(BANDS),
    "origin": list(DEFAULT_ALL_COMBINATIONS_PRESET["origin"]),
    "columns": DEFAULT_ALL_COMBINATIONS_PRESET["columns"],
    "spacing_x": DEFAULT_ALL_COMBINATIONS_PRESET["spacing_x"],
    "spacing_y": DEFAULT_ALL_COMBINATIONS_PRESET["spacing_y"],
    "family_spacing_y": DEFAULT_ALL_COMBINATIONS_PRESET["family_spacing_y"],
    "scale": DEFAULT_ALL_COMBINATIONS_PRESET["scale"],
    "recipe_asset_package_path": RECIPE_ASSET_ROOT,
    "clear_previous": True,
    "clear_panorama": True,
    "select_spawned": False,
    "spawn_stage": True,
    "spawn_lights": False,
    "spawn_labels": False,
}


def _get_args():
    args = dict(DEFAULT_ARGS)
    if hasattr(unreal, "get_mcp_args"):
        supplied = unreal.get_mcp_args()
        if isinstance(supplied, dict):
            args.update(supplied)
    args["families"] = [str(value) for value in args["families"]]
    args["bands"] = [str(value) for value in args["bands"]]
    args["origin"] = [float(value) for value in args["origin"]]
    args["columns"] = max(1, int(args["columns"]))
    args["spacing_x"] = float(args["spacing_x"])
    args["spacing_y"] = float(args["spacing_y"])
    args["family_spacing_y"] = float(args["family_spacing_y"])
    args["scale"] = max(0.1, float(args["scale"]))
    args["recipe_asset_package_path"] = str(args["recipe_asset_package_path"])
    return args


def _normalize_name(value):
    return "".join(ch for ch in str(value).lower() if ch.isalnum())


def _get_unreal_type(*names):
    for name in names:
        value = getattr(unreal, name, None)
        if value is not None:
            return value
    return None


def _enum_value(type_name, value):
    enum_type = _get_unreal_type(type_name, type_name[1:] if type_name.startswith("E") else type_name)
    if enum_type is None:
        raise RuntimeError("Missing reflected enum type {}".format(type_name))

    wanted = _normalize_name(value)
    for attr in dir(enum_type):
        if attr.startswith("_"):
            continue
        if _normalize_name(attr) == wanted:
            return getattr(enum_type, attr)

    for attr in dir(enum_type):
        if attr.startswith("_"):
            continue
        normalized = _normalize_name(attr)
        if wanted in normalized or normalized in wanted:
            return getattr(enum_type, attr)

    raise RuntimeError("Cannot resolve enum {}.{}".format(type_name, value))


def _get_editor_property(obj, names):
    errors = []
    for name in names:
        try:
            return obj.get_editor_property(name)
        except Exception as exc:
            errors.append("{}: {}".format(name, exc))
    raise RuntimeError("Could not get property on {}. Tried {}. Errors: {}".format(obj, names, errors))


def _set_editor_property(obj, names, value):
    errors = []
    for name in names:
        try:
            obj.set_editor_property(name, value)
            return name
        except Exception as exc:
            errors.append("{}: {}".format(name, exc))
    raise RuntimeError("Could not set property on {}. Tried {}. Errors: {}".format(obj, names, errors))


def _package_path(asset):
    if asset is None:
        return None
    return str(asset.get_path_name()).split(".")[0]


def _recipe_id_for_family(family):
    return "AIGC_{}".format(family)


def _recipe_asset_path(package_path, family):
    return "{}/DA_{}".format(package_path, _recipe_id_for_family(family))


def _expected_mesh_paths(families):
    return [
        "/Game/AIGC/Plants/{}/C{}/{}".format(family, level, slot)
        for family in families
        for level in range(4)
        for slot in SLOTS
    ]


def _load_recipe_assets(families, package_path):
    recipe_type = _get_unreal_type("SIPResourcePlantRecipe")
    if recipe_type is None:
        raise RuntimeError("Missing reflected USIPResourcePlantRecipe class. Rebuild the SIP editor module first.")

    loaded = {}
    missing = []
    for family in families:
        object_path = _recipe_asset_path(package_path, family)
        asset = unreal.EditorAssetLibrary.load_asset(object_path)
        if isinstance(asset, recipe_type):
            loaded[family] = asset
        else:
            missing.append(object_path)
    return loaded, missing


def _clear_previous(clear_panorama=False):
    subsystem = unreal.get_editor_subsystem(unreal.EditorActorSubsystem)
    removed = 0
    for actor in list(subsystem.get_all_level_actors()):
        label = actor.get_actor_label()
        tags = {str(tag) for tag in actor.tags}
        has_all_comb_tag = TEST_TAG in tags
        has_panorama_tag = PANORAMA_TEST_TAG in tags
        has_all_comb_label = label.startswith(LABEL_PREFIX) or label.startswith(STAGE_LABEL_PREFIX)
        has_panorama_label = label.startswith(PANORAMA_LABEL_PREFIX) or label.startswith(PANORAMA_STAGE_LABEL_PREFIX)
        if has_all_comb_tag or has_all_comb_label or (clear_panorama and (has_panorama_tag or has_panorama_label)):
            subsystem.destroy_actor(actor)
            removed += 1
    return removed


def _spawn_actor(actor_class, label, location, rotation=None):
    subsystem = unreal.get_editor_subsystem(unreal.EditorActorSubsystem)
    rotator = rotation or unreal.Rotator(0.0, 0.0, 0.0)
    actor = subsystem.spawn_actor_from_class(actor_class, unreal.Vector(*location), rotator)
    actor.set_actor_label(label)
    actor.tags = [unreal.Name(TEST_TAG)]
    return actor


def _collapse_vector_to_dict(vector):
    return {
        "BodyShell": int(_get_editor_property(vector, ("body_shell", "BodyShell"))),
        "PrimarySilhouette": int(_get_editor_property(vector, ("primary_silhouette", "PrimarySilhouette"))),
        "Core": int(_get_editor_property(vector, ("core", "Core"))),
        "OrbitSet": int(_get_editor_property(vector, ("orbit_set", "OrbitSet"))),
    }


def _make_collapse_vector(vector):
    vector_type = _get_unreal_type("SIPResourcePlantCollapseVector")
    if vector_type is None:
        raise RuntimeError("Missing reflected FSIPResourcePlantCollapseVector struct. Rebuild the SIP editor module first.")

    payload = vector_type()
    _set_editor_property(payload, ("body_shell", "BodyShell"), int(vector["BodyShell"]))
    _set_editor_property(payload, ("primary_silhouette", "PrimarySilhouette"), int(vector["PrimarySilhouette"]))
    _set_editor_property(payload, ("core", "Core"), int(vector["Core"]))
    _set_editor_property(payload, ("orbit_set", "OrbitSet"), int(vector["OrbitSet"]))
    return payload


def _configure_actor_with_explicit_vector(actor, recipe, family, band, vector, scale):
    if not hasattr(actor, "rebuild_plant_preview"):
        raise RuntimeError(
            "ASIPResourcePlantActor.rebuild_plant_preview is not reflected. "
            "Rebuild/relaunch the SIP editor module before spawning all combinations."
        )

    _set_editor_property(actor, ("configure_from_pcg_properties", "b_configure_from_pcg_properties", "bConfigureFromPCGProperties"), False)
    _set_editor_property(actor, ("plant_recipe", "PlantRecipe"), recipe)
    _set_editor_property(actor, ("preview_family", "PreviewFamily"), _enum_value("SIPResourcePlantPreviewFamily", family))
    _set_editor_property(actor, ("collapse_band", "CollapseBand"), _enum_value("SIPResourcePlantCollapseBand", band))
    _set_editor_property(actor, ("plant_scale", "PlantScale"), float(scale))
    _set_editor_property(actor, ("use_recipe_default_collapse_band", "b_use_recipe_default_collapse_band", "bUseRecipeDefaultCollapseBand"), False)
    _set_editor_property(actor, ("show_collapse_proxy_ring", "b_show_collapse_proxy_ring", "bShowCollapseProxyRing"), False)
    _set_editor_property(actor, ("use_explicit_collapse_vector", "b_use_explicit_collapse_vector", "bUseExplicitCollapseVector"), True)
    _set_editor_property(actor, ("explicit_collapse_vector", "ExplicitCollapseVector"), _make_collapse_vector(vector))

    actor.rebuild_plant_preview()
    resolved = _get_editor_property(actor, ("resolved_collapse_vector", "ResolvedCollapseVector"))
    return _collapse_vector_to_dict(resolved)


def _component_material_overrides(component):
    try:
        overrides = component.get_editor_property("override_materials")
    except Exception:
        try:
            overrides = component.get_editor_property("OverrideMaterials")
        except Exception:
            return []

    return [
        str(material.get_path_name())
        for material in list(overrides)
        if material is not None
    ]


def _verify_actor(actor, family, vector):
    slot_results = {}
    mesh_mismatches = []
    material_overrides = []

    for slot, component_property in SLOT_COMPONENT_PROPERTY.items():
        component = _get_editor_property(actor, (component_property,))
        mesh = _get_editor_property(component, ("static_mesh", "StaticMesh"))
        actual = _package_path(mesh)
        level = int(vector[slot])
        expected = "/Game/AIGC/Plants/{}/C{}/{}".format(family, level, slot)
        overrides = _component_material_overrides(component)
        ok = actual == expected

        slot_results[slot] = {
            "expected": expected,
            "actual": actual,
            "collapse_level": level,
            "material_override_count": len(overrides),
            "ok": ok and not overrides,
        }

        if not ok:
            mesh_mismatches.append({"slot": slot, "expected": expected, "actual": actual})
        for override in overrides:
            material_overrides.append({"slot": slot, "override": override})

    return slot_results, mesh_mismatches, material_overrides


def _spawn_stage(layout):
    bounds = layout["bounds"]
    center = bounds["center"]
    width = max(1200.0, bounds["max"][0] - bounds["min"][0] + 900.0)
    depth = max(900.0, bounds["max"][1] - bounds["min"][1] + 950.0)
    height = 26.0
    cube_mesh = unreal.EditorAssetLibrary.load_asset("/Engine/BasicShapes/Cube.Cube")

    static_mesh_actor_class = _get_unreal_type("StaticMeshActor")
    if static_mesh_actor_class is None:
        return []

    stage = _spawn_actor(
        static_mesh_actor_class,
        "{}_Base".format(STAGE_LABEL_PREFIX),
        [center[0], center[1], bounds["min"][2] - height * 0.62],
    )
    component = stage.get_editor_property("static_mesh_component")
    component.set_static_mesh(cube_mesh)
    component.set_relative_scale3d(unreal.Vector(width / 100.0, depth / 100.0, height / 100.0))
    component.set_collision_enabled(unreal.CollisionEnabled.NO_COLLISION)
    return [stage]


def _spawn_label(label, location, text, size=70.0):
    text_actor_class = _get_unreal_type("TextRenderActor")
    if text_actor_class is None:
        return None

    actor = _spawn_actor(text_actor_class, label, location, unreal.Rotator(64.0, 90.0, 0.0))
    component = actor.get_editor_property("text_render")
    component.set_text(text)
    component.set_world_size(size)
    component.set_horizontal_alignment(unreal.HorizTextAligment.EHTA_CENTER)
    component.set_text_render_color(unreal.Color(255, 232, 170, 255))
    return actor


def _spawn_labels(layout):
    actors = []
    bounds = layout["bounds"]
    family_label_x = bounds["min"][0] - 520.0
    label_z = bounds["min"][2] + 45.0

    for lane in layout["family_lanes"]:
        actor = _spawn_label(
            "{}_Family_{}".format(STAGE_LABEL_PREFIX, lane["family"]),
            [family_label_x, lane["center_y"], label_z],
            "{} / {} forms".format(lane["family"], lane["vector_count"]),
            64.0,
        )
        if actor:
            actors.append(actor)

    return actors


def _spawn_lights(layout):
    actors = []
    center = layout["bounds"]["center"]
    point_class = _get_unreal_type("PointLight")

    if point_class is not None:
        for index, offset in enumerate(([-2100.0, -1200.0, 900.0], [2600.0, 1800.0, 840.0])):
            light = _spawn_actor(
                point_class,
                "{}_AccentLight_{}".format(STAGE_LABEL_PREFIX, index),
                [center[0] + offset[0], center[1] + offset[1], center[2] + offset[2]],
            )
            component = light.get_editor_property("light_component")
            component.set_editor_property("intensity", 980.0)
            component.set_editor_property("attenuation_radius", 3300.0)
            actors.append(light)

    return actors


def _select_spawned(actors):
    unreal.EditorLevelLibrary.set_selected_level_actors(actors)


def _validate_reflection_ready():
    required_types = [
        "SIPResourcePlantActor",
        "SIPResourcePlantRecipe",
        "SIPResourcePlantCollapseVector",
        "SIPResourcePlantPreviewFamily",
        "SIPResourcePlantCollapseBand",
    ]
    missing = [type_name for type_name in required_types if _get_unreal_type(type_name) is None]
    if missing:
        raise RuntimeError(
            "SIP plant reflection is stale or incomplete. Missing {}. "
            "Run a SIP editor rebuild/relaunch before the all-combinations smoke test.".format(missing)
        )


def main():
    args = _get_args()
    _validate_reflection_ready()

    actor_class = _get_unreal_type("SIPResourcePlantActor")
    recipes, missing_recipes = _load_recipe_assets(args["families"], args["recipe_asset_package_path"])
    audit = build_asset_audit(_expected_mesh_paths(args["families"]), families=args["families"])
    layout = build_all_combinations_layout(
        families=args["families"],
        bands=args["bands"],
        origin=args["origin"],
        columns=args["columns"],
        spacing_x=args["spacing_x"],
        spacing_y=args["spacing_y"],
        family_spacing_y=args["family_spacing_y"],
        scale=args["scale"],
    )
    removed = _clear_previous(clear_panorama=bool(args.get("clear_panorama", False))) if bool(args["clear_previous"]) else 0

    spawned = []
    stage_actors = []
    results = []
    all_mesh_mismatches = []
    all_material_overrides = []
    explicit_vector_mismatches = []

    if bool(args["spawn_stage"]):
        stage_actors.extend(_spawn_stage(layout))

    if bool(args.get("spawn_lights", False)):
        stage_actors.extend(_spawn_lights(layout))

    if bool(args["spawn_labels"]):
        stage_actors.extend(_spawn_labels(layout))

    for actor_plan in layout["actors"]:
        family = actor_plan["family"]
        recipe = recipes.get(family)
        if recipe is None:
            continue

        vector = actor_plan["collapse_vector"]
        band = actor_plan["bands"][0] if actor_plan["bands"] else "Weathered_C1"
        location = list(actor_plan["location"])
        vector_slug = actor_plan["vector_slug"]
        yaw = -8.0 + (int(actor_plan["vector_index"]) % 17)
        label = "{}_{}_I{:03d}_{}".format(LABEL_PREFIX, family, int(actor_plan["vector_index"]), vector_slug)
        actor = _spawn_actor(actor_class, label, location, unreal.Rotator(0.0, yaw, 0.0))
        actor.tags = [
            unreal.Name(TEST_TAG),
            unreal.Name("{}.{}".format(TEST_TAG, family)),
            unreal.Name("{}.Vector.{}".format(TEST_TAG, vector_slug)),
        ]

        resolved_vector = _configure_actor_with_explicit_vector(
            actor,
            recipe,
            family,
            band,
            vector,
            actor_plan["plant_scale"],
        )
        if resolved_vector != vector:
            explicit_vector_mismatches.append(
                {
                    "actor_label": actor.get_actor_label(),
                    "expected": vector,
                    "resolved": resolved_vector,
                }
            )

        slot_results, mesh_mismatches, material_overrides = _verify_actor(actor, family, vector)
        spawned.append(actor)
        all_mesh_mismatches.extend(
            [
                {
                    "actor_label": actor.get_actor_label(),
                    **mismatch,
                }
                for mismatch in mesh_mismatches
            ]
        )
        all_material_overrides.extend(
            [
                {
                    "actor_label": actor.get_actor_label(),
                    **override,
                }
                for override in material_overrides
            ]
        )
        results.append(
            {
                "label": actor.get_actor_label(),
                "family": family,
                "vector_index": actor_plan["vector_index"],
                "location": location,
                "collapse_vector": vector,
                "bands": actor_plan["bands"],
                "metrics": actor_plan["metrics"],
                "slot_verification": slot_results,
            }
        )

    if args["select_spawned"]:
        _select_spawned(spawned)

    print(
        json.dumps(
            {
                "schema": "SkyIslandPotion.AIGCPlantAllCombinationsSmoke.v0",
                "removed_previous_test_actors": removed,
                "spawned_actor_count": len(spawned),
                "stage_actor_count": len(stage_actors),
                "selected_spawned": bool(args["select_spawned"]),
                "missing_recipe_count": len(missing_recipes),
                "missing_recipes": missing_recipes,
                "complete_families": audit["summary"]["complete_families"],
                "mesh_mismatch_count": len(all_mesh_mismatches),
                "mesh_mismatches": all_mesh_mismatches,
                "material_override_count": len(all_material_overrides),
                "material_overrides": all_material_overrides,
                "explicit_vector_mismatch_count": len(explicit_vector_mismatches),
                "explicit_vector_mismatches": explicit_vector_mismatches,
                "camera": layout["camera"],
                "bounds": layout["bounds"],
                "family_lanes": layout["family_lanes"],
                "results": results,
            },
            indent=2,
            ensure_ascii=False,
        )
    )


main()
