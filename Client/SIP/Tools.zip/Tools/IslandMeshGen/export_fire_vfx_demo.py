from __future__ import annotations

import json
from pathlib import Path

from semantic_vfx_manifest import build_fire_vfx_manifest, write_vfx_manifest


DEFAULT_INPUT = Path("output/SM_ProcIsland_Fire_VolcanoLayout_200m.manifest.json")
DEFAULT_OUTPUT = Path("output/SM_ProcIsland_Fire_VolcanoLayout_200m.vfx_manifest.json")


def main() -> None:
    island_manifest = json.loads(DEFAULT_INPUT.read_text(encoding="utf-8"))
    vfx_manifest = build_fire_vfx_manifest(island_manifest)
    write_vfx_manifest(vfx_manifest, DEFAULT_OUTPUT)
    print(f"wrote {DEFAULT_OUTPUT}")


if __name__ == "__main__":
    main()
