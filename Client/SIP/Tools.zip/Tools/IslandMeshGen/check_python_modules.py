import importlib.util

for name in ["numpy", "PIL", "trimesh", "pygltflib"]:
    print(name, importlib.util.find_spec(name) is not None)
