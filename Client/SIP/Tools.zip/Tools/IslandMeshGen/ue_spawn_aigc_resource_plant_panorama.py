import json
import sys
from pathlib import Path

import unreal


def _tool_script_dir():
    script_path = globals().get("__file__")
    if script_path:
        return Path(script_path).resolve().parent

    project_dir = Path(unreal.Paths.project_dir()).resolve()
    candidates = [
        project_dir.parents[1] / "Tools" / "IslandMeshGen",
        project_dir.parent / "Tools" / "IslandMeshGen",
        Path.cwd(),
    ]
    for candidate in candidates:
        if (candidate / "plant_panorama_layout.py").exists():
            return candidate
    return candidates[0]


TOOL_DIR = _tool_script_dir()
sys.path.insert(0, str(TOOL_DIR))

for module_name in (
    "plant_actor_spawn_plan",
    "plant_aigc_asset_catalog",
    "plant_collapse_sampler",
    "plant_panorama_layout",
    "plant_recipe_asset_plan",
):
    sys.modules.pop(module_name, None)

from plant_aigc_asset_catalog import build_asset_audit, build_recipe_plan
from plant_collapse_sampler import BANDS, FAMILIES, SLOTS, vector_slug
from plant_panorama_layout import build_panorama_layout, load_panorama_preset
from plant_recipe_asset_plan import RECIPE_ASSET_ROOT


TEST_TAG = "AIGCResourcePlantPanorama"
LABEL_PREFIX = "SIP_AIGC_PanoramaPlant"
STAGE_LABEL_PREFIX = "SIP_AIGC_PanoramaStage"

SLOT_COMPONENT_PROPERTY = {
    "BodyShell": "body_shell_root_slot",
    "PrimarySilhouette": "primary_silhouette_slot",
    "Core": "core_slot",
    "OrbitSet": "orbit_node_a_slot",
}

DEFAULT_PANORAMA_PRESET = load_panorama_preset()

DEFAULT_ARGS = {
    "families": list(FAMILIES),
    "bands": list(BANDS),
    "samples_per_band": 3,
    "seed": 9103,
    "origin": list(DEFAULT_PANORAMA_PRESET["origin"]),
    "band_spacing_x": DEFAULT_PANORAMA_PRESET["band_spacing_x"],
    "family_spacing_y": DEFAULT_PANORAMA_PRESET["family_spacing_y"],
    "sample_spacing_y": DEFAULT_PANORAMA_PRESET["sample_spacing_y"],
    "scale": DEFAULT_PANORAMA_PRESET["scale"],
    "temperature_scale": DEFAULT_PANORAMA_PRESET["temperature_scale"],
    "recipe_asset_package_path": RECIPE_ASSET_ROOT,
    "clear_previous": True,
    "select_spawned": True,
    "spawn_stage": True,
    "spawn_lights": False,
    "spawn_labels": False,
}


def _get_args():
    args = dict(DEFAULT_ARGS)
    if hasattr(unreal, "get_mcp_args"):
        supplied = unreal.get_mcp_args()
        if isinstance(supplied, dict):
            args.update(supplied)
    args["families"] = [str(value) for value in args["families"]]
    args["bands"] = [str(value) for value in args["bands"]]
    args["samples_per_band"] = max(1, int(args["samples_per_band"]))
    args["seed"] = int(args["seed"])
    args["origin"] = [float(value) for value in args["origin"]]
    args["band_spacing_x"] = float(args["band_spacing_x"])
    args["family_spacing_y"] = float(args["family_spacing_y"])
    args["sample_spacing_y"] = float(args["sample_spacing_y"])
    args["scale"] = max(0.1, float(args["scale"]))
    args["temperature_scale"] = float(args["temperature_scale"])
    args["recipe_asset_package_path"] = str(args["recipe_asset_package_path"])
    return args


def _normalize_name(value):
    return "".join(ch for ch in str(value).lower() if ch.isalnum())


def _get_unreal_type(*names):
    for name in names:
        value = getattr(unreal, name, None)
        if value is not None:
            return value
    return None


def _enum_value(type_name, value):
    enum_type = _get_unreal_type(type_name, type_name[1:] if type_name.startswith("E") else type_name)
    if enum_type is None:
        raise RuntimeError("Missing reflected enum type {}".format(type_name))

    wanted = _normalize_name(value)
    for attr in dir(enum_type):
        if attr.startswith("_"):
            continue
        if _normalize_name(attr) == wanted:
            return getattr(enum_type, attr)

    for attr in dir(enum_type):
        if attr.startswith("_"):
            continue
        normalized = _normalize_name(attr)
        if wanted in normalized or normalized in wanted:
            return getattr(enum_type, attr)

    raise RuntimeError("Cannot resolve enum {}.{}".format(type_name, value))


def _get_editor_property(obj, names):
    errors = []
    for name in names:
        try:
            return obj.get_editor_property(name)
        except Exception as exc:
            errors.append("{}: {}".format(name, exc))
    raise RuntimeError("Could not get property on {}. Tried {}. Errors: {}".format(obj, names, errors))


def _set_editor_property(obj, names, value):
    errors = []
    for name in names:
        try:
            obj.set_editor_property(name, value)
            return name
        except Exception as exc:
            errors.append("{}: {}".format(name, exc))
    raise RuntimeError("Could not set property on {}. Tried {}. Errors: {}".format(obj, names, errors))


def _package_path(asset):
    if asset is None:
        return None
    return str(asset.get_path_name()).split(".")[0]


def _recipe_id_for_family(family):
    return "AIGC_{}".format(family)


def _recipe_asset_path(package_path, family):
    return "{}/DA_{}".format(package_path, _recipe_id_for_family(family))


def _expected_mesh_paths(families):
    return [
        "/Game/AIGC/Plants/{}/C{}/{}".format(family, level, slot)
        for family in families
        for level in range(4)
        for slot in SLOTS
    ]


def _load_recipe_assets(families, package_path):
    recipe_type = _get_unreal_type("SIPResourcePlantRecipe")
    if recipe_type is None:
        raise RuntimeError("Missing reflected USIPResourcePlantRecipe class. Rebuild the SIP editor module first.")

    loaded = {}
    missing = []
    for family in families:
        object_path = _recipe_asset_path(package_path, family)
        asset = unreal.EditorAssetLibrary.load_asset(object_path)
        if isinstance(asset, recipe_type):
            loaded[family] = asset
        else:
            missing.append(object_path)
    return loaded, missing


def _clear_previous():
    subsystem = unreal.get_editor_subsystem(unreal.EditorActorSubsystem)
    removed = 0
    for actor in list(subsystem.get_all_level_actors()):
        label = actor.get_actor_label()
        has_test_tag = any(str(tag) == TEST_TAG for tag in actor.tags)
        if has_test_tag or label.startswith(LABEL_PREFIX) or label.startswith(STAGE_LABEL_PREFIX):
            subsystem.destroy_actor(actor)
            removed += 1
    return removed


def _spawn_actor(actor_class, label, location, rotation=None):
    subsystem = unreal.get_editor_subsystem(unreal.EditorActorSubsystem)
    rotator = rotation or unreal.Rotator(0.0, 0.0, 0.0)
    actor = subsystem.spawn_actor_from_class(actor_class, unreal.Vector(*location), rotator)
    actor.set_actor_label(label)
    actor.tags = [unreal.Name(TEST_TAG)]
    return actor


def _collapse_vector_to_dict(vector):
    return {
        "BodyShell": int(_get_editor_property(vector, ("body_shell", "BodyShell"))),
        "PrimarySilhouette": int(_get_editor_property(vector, ("primary_silhouette", "PrimarySilhouette"))),
        "Core": int(_get_editor_property(vector, ("core", "Core"))),
        "OrbitSet": int(_get_editor_property(vector, ("orbit_set", "OrbitSet"))),
    }


def _configure_actor_with_properties(actor, recipe, family, band, seed, scale, temperature_scale):
    if not hasattr(actor, "apply_pcg_property_configuration"):
        raise RuntimeError(
            "ASIPResourcePlantActor.apply_pcg_property_configuration is not reflected. "
            "Rebuild/relaunch the SIP editor module after adding ApplyPCGPropertyConfiguration."
        )

    _set_editor_property(actor, ("configure_from_pcg_properties", "b_configure_from_pcg_properties", "bConfigureFromPCGProperties"), True)
    _set_editor_property(actor, ("plant_recipe", "PlantRecipe"), recipe)
    _set_editor_property(actor, ("preview_family", "PreviewFamily"), _enum_value("SIPResourcePlantPreviewFamily", family))
    _set_editor_property(actor, ("collapse_band", "CollapseBand"), _enum_value("SIPResourcePlantCollapseBand", band))
    _set_editor_property(actor, ("plant_seed", "PlantSeed"), int(seed))
    _set_editor_property(actor, ("plant_scale", "PlantScale"), float(scale))
    _set_editor_property(actor, ("collapse_temperature_scale", "CollapseTemperatureScale"), float(temperature_scale))
    _set_editor_property(actor, ("use_recipe_default_collapse_band", "b_use_recipe_default_collapse_band", "bUseRecipeDefaultCollapseBand"), False)
    _set_editor_property(actor, ("show_collapse_proxy_ring", "b_show_collapse_proxy_ring", "bShowCollapseProxyRing"), False)

    returned_vector = actor.apply_pcg_property_configuration()
    return _collapse_vector_to_dict(returned_vector)


def _component_material_overrides(component):
    try:
        overrides = component.get_editor_property("override_materials")
    except Exception:
        try:
            overrides = component.get_editor_property("OverrideMaterials")
        except Exception:
            return []

    return [
        str(material.get_path_name())
        for material in list(overrides)
        if material is not None
    ]


def _verify_actor(actor, family, vector):
    slot_results = {}
    mesh_mismatches = []
    material_overrides = []

    for slot, component_property in SLOT_COMPONENT_PROPERTY.items():
        component = _get_editor_property(actor, (component_property,))
        mesh = _get_editor_property(component, ("static_mesh", "StaticMesh"))
        actual = _package_path(mesh)
        level = int(vector[slot])
        expected = "/Game/AIGC/Plants/{}/C{}/{}".format(family, level, slot)
        overrides = _component_material_overrides(component)
        ok = actual == expected

        slot_results[slot] = {
            "expected": expected,
            "actual": actual,
            "collapse_level": level,
            "material_override_count": len(overrides),
            "ok": ok and not overrides,
        }

        if not ok:
            mesh_mismatches.append({"slot": slot, "expected": expected, "actual": actual})
        for override in overrides:
            material_overrides.append({"slot": slot, "override": override})

    return slot_results, mesh_mismatches, material_overrides


def _spawn_stage(layout):
    bounds = layout["bounds"]
    center = bounds["center"]
    width = max(1200.0, bounds["max"][0] - bounds["min"][0] + 900.0)
    depth = max(900.0, bounds["max"][1] - bounds["min"][1] + 950.0)
    height = 26.0
    cube_mesh = unreal.EditorAssetLibrary.load_asset("/Engine/BasicShapes/Cube.Cube")

    static_mesh_actor_class = _get_unreal_type("StaticMeshActor")
    if static_mesh_actor_class is None:
        return []

    stage = _spawn_actor(
        static_mesh_actor_class,
        "{}_Base".format(STAGE_LABEL_PREFIX),
        [center[0], center[1], bounds["min"][2] - height * 0.62],
    )
    component = stage.get_editor_property("static_mesh_component")
    component.set_static_mesh(cube_mesh)
    component.set_relative_scale3d(unreal.Vector(width / 100.0, depth / 100.0, height / 100.0))
    component.set_collision_enabled(unreal.CollisionEnabled.NO_COLLISION)
    return [stage]


def _spawn_label(label, location, text, size=70.0):
    text_actor_class = _get_unreal_type("TextRenderActor")
    if text_actor_class is None:
        return None

    actor = _spawn_actor(text_actor_class, label, location, unreal.Rotator(64.0, 90.0, 0.0))
    component = actor.get_editor_property("text_render")
    component.set_text(text)
    component.set_world_size(size)
    component.set_horizontal_alignment(unreal.HorizTextAligment.EHTA_CENTER)
    component.set_text_render_color(unreal.Color(255, 232, 170, 255))
    return actor


def _spawn_labels(layout):
    actors = []
    bounds = layout["bounds"]
    band_label_y = bounds["min"][1] - 360.0
    family_label_x = bounds["min"][0] - 520.0
    label_z = bounds["min"][2] + 45.0

    for zone in layout["band_zones"]:
        actor = _spawn_label(
            "{}_Band_{}".format(STAGE_LABEL_PREFIX, zone["band"]),
            [zone["center"][0], band_label_y, label_z],
            str(zone["band"]),
            58.0,
        )
        if actor:
            actors.append(actor)

    for lane in layout["family_lanes"]:
        actor = _spawn_label(
            "{}_Family_{}".format(STAGE_LABEL_PREFIX, lane["family"]),
            [family_label_x, lane["center_y"], label_z],
            str(lane["family"]),
            64.0,
        )
        if actor:
            actors.append(actor)

    return actors


def _spawn_lights(layout):
    actors = []
    center = layout["bounds"]["center"]
    point_class = _get_unreal_type("PointLight")

    if point_class is not None:
        for index, offset in enumerate(([-1450.0, -650.0, 760.0], [1450.0, 760.0, 720.0])):
            light = _spawn_actor(
                point_class,
                "{}_AccentLight_{}".format(STAGE_LABEL_PREFIX, index),
                [center[0] + offset[0], center[1] + offset[1], center[2] + offset[2]],
            )
            component = light.get_editor_property("light_component")
            component.set_editor_property("intensity", 900.0)
            component.set_editor_property("attenuation_radius", 2100.0)
            actors.append(light)

    return actors


def _select_spawned(actors):
    unreal.EditorLevelLibrary.set_selected_level_actors(actors)


def _validate_reflection_ready():
    required_types = [
        "SIPResourcePlantActor",
        "SIPResourcePlantRecipe",
        "SIPResourcePlantCollapseVector",
        "SIPResourcePlantPreviewFamily",
        "SIPResourcePlantCollapseBand",
    ]
    missing = [type_name for type_name in required_types if _get_unreal_type(type_name) is None]
    if missing:
        raise RuntimeError(
            "SIP plant reflection is stale or incomplete. Missing {}. "
            "Run a SIP editor rebuild/relaunch before the panorama smoke test.".format(missing)
        )


def main():
    args = _get_args()
    _validate_reflection_ready()

    actor_class = _get_unreal_type("SIPResourcePlantActor")
    recipes, missing_recipes = _load_recipe_assets(args["families"], args["recipe_asset_package_path"])
    audit = build_asset_audit(_expected_mesh_paths(args["families"]), families=args["families"])
    recipe_plan = build_recipe_plan(audit)
    layout = build_panorama_layout(
        recipe_plan,
        families=args["families"],
        bands=args["bands"],
        samples_per_band=args["samples_per_band"],
        seed=args["seed"],
        origin=args["origin"],
        band_spacing_x=args["band_spacing_x"],
        family_spacing_y=args["family_spacing_y"],
        sample_spacing_y=args["sample_spacing_y"],
        scale=args["scale"],
        temperature_scale=args["temperature_scale"],
    )
    removed = _clear_previous() if bool(args["clear_previous"]) else 0

    spawned = []
    stage_actors = []
    results = []
    all_mesh_mismatches = []
    all_material_overrides = []

    if bool(args["spawn_stage"]):
        stage_actors.extend(_spawn_stage(layout))

    if bool(args.get("spawn_lights", False)):
        stage_actors.extend(_spawn_lights(layout))

    if bool(args["spawn_labels"]):
        stage_actors.extend(_spawn_labels(layout))

    for actor_plan in layout["actors"]:
        family = actor_plan["family"]
        recipe = recipes.get(family)
        if recipe is None:
            continue

        seed = actor_plan["seed"]
        band = actor_plan["band"]
        location = list(actor_plan["location"])
        yaw = -8.0 + (int(seed) % 17)
        label = "{}_{}_{}_Seed{}".format(LABEL_PREFIX, family, band, seed)
        actor = _spawn_actor(actor_class, label, location, unreal.Rotator(0.0, yaw, 0.0))
        actor.tags = [
            unreal.Name(TEST_TAG),
            unreal.Name("{}.{}".format(TEST_TAG, family)),
            unreal.Name("{}.Band.{}".format(TEST_TAG, band)),
        ]

        vector = _configure_actor_with_properties(
            actor,
            recipe,
            family,
            band,
            seed,
            actor_plan["plant_scale"],
            actor_plan["temperature_scale"],
        )
        slot_results, mesh_mismatches, material_overrides = _verify_actor(actor, family, vector)
        vector_name = vector_slug(vector)
        actor.set_actor_label("{}_{}_{}_{}".format(LABEL_PREFIX, family, band, vector_name))

        spawned.append(actor)
        all_mesh_mismatches.extend(
            [
                {
                    "actor_label": actor.get_actor_label(),
                    **mismatch,
                }
                for mismatch in mesh_mismatches
            ]
        )
        all_material_overrides.extend(
            [
                {
                    "actor_label": actor.get_actor_label(),
                    **override,
                }
                for override in material_overrides
            ]
        )
        results.append(
            {
                "label": actor.get_actor_label(),
                "family": family,
                "band": band,
                "seed": seed,
                "location": location,
                "collapse_vector": vector,
                "slot_verification": slot_results,
            }
        )

    if args["select_spawned"]:
        _select_spawned(spawned)

    print(
        json.dumps(
            {
                "schema": "SkyIslandPotion.AIGCPlantPanoramaSmoke.v0",
                "removed_previous_test_actors": removed,
                "spawned_actor_count": len(spawned),
                "stage_actor_count": len(stage_actors),
                "selected_spawned": bool(args["select_spawned"]),
                "missing_recipe_count": len(missing_recipes),
                "missing_recipes": missing_recipes,
                "mesh_mismatch_count": len(all_mesh_mismatches),
                "mesh_mismatches": all_mesh_mismatches,
                "material_override_count": len(all_material_overrides),
                "material_overrides": all_material_overrides,
                "camera": layout["camera"],
                "bounds": layout["bounds"],
                "results": results,
            },
            indent=2,
            ensure_ascii=False,
        )
    )


main()
