#!/usr/bin/env python3
"""Convert a GLB mesh into a lightweight OBJ proxy for UE smoke tests.

This intentionally keeps only geometry. It is not a material/PBR exporter.
The goal is to avoid UE 5.4 Interchange GLB hangs while validating placement.
"""

from __future__ import annotations

import argparse
import json
import math
import struct
from pathlib import Path
from typing import Any

import numpy as np


COMPONENT_DTYPE = {
    5120: np.int8,
    5121: np.uint8,
    5122: np.int16,
    5123: np.uint16,
    5125: np.uint32,
    5126: np.float32,
}

TYPE_COUNTS = {
    "SCALAR": 1,
    "VEC2": 2,
    "VEC3": 3,
    "VEC4": 4,
    "MAT2": 4,
    "MAT3": 9,
    "MAT4": 16,
}


def read_glb(path: Path) -> tuple[dict[str, Any], bytes]:
    data = path.read_bytes()
    magic, version, total_length = struct.unpack_from("<III", data, 0)
    if magic != 0x46546C67 or version != 2:
        raise ValueError(f"{path} is not a glTF 2.0 GLB")
    if total_length != len(data):
        raise ValueError(f"{path} length mismatch: header={total_length}, actual={len(data)}")

    offset = 12
    json_doc: dict[str, Any] | None = None
    bin_chunk = b""
    while offset < len(data):
        chunk_length, chunk_type = struct.unpack_from("<II", data, offset)
        offset += 8
        chunk = data[offset : offset + chunk_length]
        offset += chunk_length
        if chunk_type == 0x4E4F534A:
            json_doc = json.loads(chunk.decode("utf-8"))
        elif chunk_type == 0x004E4942:
            bin_chunk = chunk

    if json_doc is None:
        raise ValueError("GLB has no JSON chunk")
    return json_doc, bin_chunk


def node_matrix(node: dict[str, Any]) -> np.ndarray:
    if "matrix" in node:
        return np.asarray(node["matrix"], dtype=np.float32).reshape((4, 4)).T

    translation = np.asarray(node.get("translation", [0.0, 0.0, 0.0]), dtype=np.float32)
    scale = np.asarray(node.get("scale", [1.0, 1.0, 1.0]), dtype=np.float32)
    rotation = np.asarray(node.get("rotation", [0.0, 0.0, 0.0, 1.0]), dtype=np.float32)
    x, y, z, w = rotation
    xx, yy, zz = x * x, y * y, z * z
    xy, xz, yz = x * y, x * z, y * z
    wx, wy, wz = w * x, w * y, w * z

    rot = np.array(
        [
            [1 - 2 * (yy + zz), 2 * (xy - wz), 2 * (xz + wy), 0],
            [2 * (xy + wz), 1 - 2 * (xx + zz), 2 * (yz - wx), 0],
            [2 * (xz - wy), 2 * (yz + wx), 1 - 2 * (xx + yy), 0],
            [0, 0, 0, 1],
        ],
        dtype=np.float32,
    )
    scl = np.diag([scale[0], scale[1], scale[2], 1.0]).astype(np.float32)
    trs = np.eye(4, dtype=np.float32)
    trs[:3, 3] = translation
    return trs @ rot @ scl


def iter_mesh_nodes(doc: dict[str, Any]) -> list[tuple[int, np.ndarray, str]]:
    nodes = doc.get("nodes", [])
    scenes = doc.get("scenes", [])
    scene_idx = int(doc.get("scene", 0))
    roots = scenes[scene_idx].get("nodes", []) if scenes else list(range(len(nodes)))
    out: list[tuple[int, np.ndarray, str]] = []

    def visit(node_idx: int, parent: np.ndarray) -> None:
        node = nodes[node_idx]
        world = parent @ node_matrix(node)
        if "mesh" in node:
            out.append((int(node["mesh"]), world, node.get("name", f"node_{node_idx}")))
        for child_idx in node.get("children", []):
            visit(int(child_idx), world)

    for root in roots:
        visit(int(root), np.eye(4, dtype=np.float32))
    return out


def accessor_array(doc: dict[str, Any], bin_chunk: bytes, accessor_idx: int) -> np.ndarray:
    accessor = doc["accessors"][accessor_idx]
    view = doc["bufferViews"][accessor["bufferView"]]
    component_type = int(accessor["componentType"])
    dtype = np.dtype(COMPONENT_DTYPE[component_type])
    count = int(accessor["count"])
    width = TYPE_COUNTS[accessor["type"]]
    item_size = dtype.itemsize * width
    offset = int(view.get("byteOffset", 0)) + int(accessor.get("byteOffset", 0))
    stride = int(view.get("byteStride", item_size))

    if stride == item_size:
        raw = bin_chunk[offset : offset + count * item_size]
        return np.frombuffer(raw, dtype=dtype).reshape((count, width)).copy()

    rows = []
    for i in range(count):
        start = offset + i * stride
        rows.append(np.frombuffer(bin_chunk[start : start + item_size], dtype=dtype, count=width))
    return np.vstack(rows).copy()


def transform_positions(positions: np.ndarray, world: np.ndarray, scale_cm: float) -> np.ndarray:
    ones = np.ones((len(positions), 1), dtype=np.float32)
    transformed = np.concatenate([positions.astype(np.float32), ones], axis=1) @ world.T
    p = transformed[:, :3]
    # glTF/Meshy convention: X right, Y up, Z forward. UE proxy OBJ: X, -Z, Y in cm.
    return np.column_stack([p[:, 0] * scale_cm, -p[:, 2] * scale_cm, p[:, 1] * scale_cm]).astype(np.float32)


def primitive_triangles(doc: dict[str, Any], bin_chunk: bytes, primitive: dict[str, Any], world: np.ndarray, scale_cm: float) -> tuple[np.ndarray, np.ndarray]:
    attributes = primitive.get("attributes", {})
    if primitive.get("mode", 4) != 4 or "POSITION" not in attributes:
        raise ValueError("Only triangle primitives with POSITION are supported")

    positions = accessor_array(doc, bin_chunk, int(attributes["POSITION"]))
    positions = transform_positions(positions, world, scale_cm)
    if "indices" in primitive:
        indices = accessor_array(doc, bin_chunk, int(primitive["indices"])).reshape(-1).astype(np.uint32)
    else:
        indices = np.arange(len(positions), dtype=np.uint32)
    face_count = len(indices) // 3
    return positions, indices[: face_count * 3].reshape((-1, 3))


def choose_faces(face_count: int, target_faces: int) -> np.ndarray:
    if target_faces <= 0 or face_count <= target_faces:
        return np.arange(face_count, dtype=np.int64)
    step = face_count / float(target_faces)
    return np.asarray([min(face_count - 1, int(math.floor(i * step))) for i in range(target_faces)], dtype=np.int64)


def export_obj(input_path: Path, output_path: Path, target_faces: int, scale_cm: float) -> dict[str, Any]:
    doc, bin_chunk = read_glb(input_path)
    meshes = doc.get("meshes", [])
    all_vertices: list[np.ndarray] = []
    all_faces: list[np.ndarray] = []
    groups: list[tuple[str, int, int]] = []
    vertex_cursor = 0
    original_faces = 0

    for mesh_idx, world, node_name in iter_mesh_nodes(doc):
        mesh = meshes[mesh_idx]
        for prim_idx, primitive in enumerate(mesh.get("primitives", [])):
            try:
                positions, faces = primitive_triangles(doc, bin_chunk, primitive, world, scale_cm)
            except ValueError:
                continue
            original_faces += len(faces)
            all_vertices.append(positions)
            all_faces.append(faces + vertex_cursor)
            groups.append((f"{node_name}_{mesh.get('name', mesh_idx)}_{prim_idx}", vertex_cursor, vertex_cursor + len(positions)))
            vertex_cursor += len(positions)

    if not all_vertices or not all_faces:
        raise ValueError(f"No triangle geometry found in {input_path}")

    vertices = np.vstack(all_vertices)
    faces = np.vstack(all_faces)
    selected = choose_faces(len(faces), target_faces)
    faces = faces[selected]

    used, inverse = np.unique(faces.reshape(-1), return_inverse=True)
    compact_vertices = vertices[used]
    compact_faces = inverse.reshape((-1, 3)) + 1

    output_path.parent.mkdir(parents=True, exist_ok=True)
    with output_path.open("w", encoding="utf-8", newline="\n") as f:
        f.write(f"# Generated from {input_path.name}\n")
        f.write(f"# Original faces: {original_faces}; exported faces: {len(compact_faces)}\n")
        f.write("o CrownLily_C0_LightweightProxy\n")
        for v in compact_vertices:
            f.write(f"v {v[0]:.6f} {v[1]:.6f} {v[2]:.6f}\n")
        f.write("g CrownLily_C0_LightweightProxy\n")
        for tri in compact_faces:
            f.write(f"f {tri[0]} {tri[1]} {tri[2]}\n")

    mins = compact_vertices.min(axis=0).tolist()
    maxs = compact_vertices.max(axis=0).tolist()
    return {
        "input": str(input_path),
        "output": str(output_path),
        "original_faces": int(original_faces),
        "exported_faces": int(len(compact_faces)),
        "exported_vertices": int(len(compact_vertices)),
        "bounds_min_cm": mins,
        "bounds_max_cm": maxs,
        "scale_cm": scale_cm,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--target-faces", type=int, default=25000)
    parser.add_argument("--scale-cm", type=float, default=2200.0)
    args = parser.parse_args()

    result = export_obj(args.input.resolve(), args.output.resolve(), args.target_faces, args.scale_cm)
    report_path = args.output.with_suffix(".report.json")
    report_path.write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps({**result, "report": str(report_path)}, indent=2, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
