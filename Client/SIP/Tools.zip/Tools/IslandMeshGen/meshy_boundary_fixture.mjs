#!/usr/bin/env node

import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { existsSync } from 'node:fs';
import path from 'node:path';

const EXPECTED_MATERIAL_SLOTS = [
  'M_TopGrass',
  'M_PathDirt',
  'M_CliffRock',
  'M_UndersideRock',
  'M_ElementCrack',
];

const DEFAULTS = {
  mesh: 'Tools/IslandMeshGen/output/SM_ProcIsland_Fire_VolcanoLayout_200m.obj',
  manifest: 'Tools/IslandMeshGen/output/SM_ProcIsland_Fire_VolcanoLayout_200m.manifest.json',
  fieldJson: 'Tools/IslandMeshGen/output/SM_ProcIsland_Fire_VolcanoLayout_200m.field.json',
  qualityReport: 'Tools/IslandMeshGen/output/SM_ProcIsland_Fire_VolcanoLayout_200m.quality_report.json',
  outputDir: 'Tools/IslandMeshGen/output/meshy-boundary-fixture',
  inputFormat: 'obj',
  job: 'all',
};

const JOBS = ['retexture-material-slots', 'retexture-colored-mask', 'remesh-visible-skin'];

function usage() {
  return `Meshy boundary fixture (dry-run by default)

Usage:
  node Tools/IslandMeshGen/meshy_boundary_fixture.mjs [options]

Default local dry-run:
  node Tools/IslandMeshGen/meshy_boundary_fixture.mjs

Useful options:
  --mesh <path>                 Source semantic OBJ. Default: ${DEFAULTS.mesh}
  --manifest <path>             Source manifest JSON. Default: ${DEFAULTS.manifest}
  --field-json <path>           Source field JSON. Default: ${DEFAULTS.fieldJson}
  --quality-report <path>       Source quality report JSON. Default: ${DEFAULTS.qualityReport}
  --output-dir <path>           Fixture output directory. Default: ${DEFAULTS.outputDir}
  --input-format <obj|glb|fbx>  Planned Meshy input format label. Default: obj
  --model-url <url>             Uploaded model URL for payload/curl templates.
  --job <name|all>              ${JOBS.join(', ')}. Default: all
  --compare-result <path>       Optional OBJ result to compare against source bbox/materials.
  --write-masked-obj            Also writes an OBJ copy with an mtllib reference.
  --call-api                    Explicitly POST one payload to MESHY_ENDPOINT.
  --endpoint <url>              Override MESHY_ENDPOINT for --call-api.
  --help                        Show this help.

Network safety:
  --call-api requires MESHY_API_KEY, MESHY_ENDPOINT or --endpoint, --model-url,
  and a single --job. The API key is never printed. No network call is made
  unless --call-api is present.
`;
}

function parseArgs(argv) {
  const args = {
    ...DEFAULTS,
    dryRun: true,
    callApi: false,
    writeMaskedObj: false,
    modelUrl: '',
    endpoint: '',
    compareResult: '',
  };

  for (let index = 0; index < argv.length; index += 1) {
    const token = argv[index];
    const next = () => {
      if (index + 1 >= argv.length) {
        throw new Error(`Missing value for ${token}`);
      }
      index += 1;
      return argv[index];
    };

    if (token === '--help' || token === '-h') {
      args.help = true;
    } else if (token === '--mesh') {
      args.mesh = next();
    } else if (token === '--manifest') {
      args.manifest = next();
    } else if (token === '--field-json') {
      args.fieldJson = next();
    } else if (token === '--quality-report') {
      args.qualityReport = next();
    } else if (token === '--output-dir') {
      args.outputDir = next();
    } else if (token === '--input-format') {
      args.inputFormat = next().toLowerCase();
    } else if (token === '--model-url') {
      args.modelUrl = next();
    } else if (token === '--job') {
      args.job = next();
    } else if (token === '--compare-result') {
      args.compareResult = next();
    } else if (token === '--endpoint') {
      args.endpoint = next();
    } else if (token === '--write-masked-obj') {
      args.writeMaskedObj = true;
    } else if (token === '--call-api') {
      args.callApi = true;
      args.dryRun = false;
    } else {
      throw new Error(`Unknown option: ${token}`);
    }
  }

  if (!['obj', 'glb', 'fbx'].includes(args.inputFormat)) {
    throw new Error(`--input-format must be obj, glb, or fbx. Got ${args.inputFormat}`);
  }
  if (args.job !== 'all' && !JOBS.includes(args.job)) {
    throw new Error(`--job must be one of: all, ${JOBS.join(', ')}`);
  }
  if (args.callApi && args.job === 'all') {
    throw new Error('--call-api requires one explicit --job; it will not submit all jobs at once.');
  }

  return args;
}

function toPosixPath(rawPath) {
  return rawPath.split(path.sep).join('/');
}

async function readJsonIfExists(filePath) {
  if (!existsSync(filePath)) {
    return { exists: false, value: null };
  }
  const text = await readFile(filePath, 'utf8');
  return { exists: true, value: JSON.parse(text) };
}

function parseObj(text) {
  const bbox = {
    min: [Number.POSITIVE_INFINITY, Number.POSITIVE_INFINITY, Number.POSITIVE_INFINITY],
    max: [Number.NEGATIVE_INFINITY, Number.NEGATIVE_INFINITY, Number.NEGATIVE_INFINITY],
  };
  const materialFaceCounts = {};
  const mtllibs = [];
  let vertexCount = 0;
  let faceCount = 0;
  let currentMaterial = '__unassigned__';
  let maxXYRadius = 0;

  for (const rawLine of text.split(/\r?\n/)) {
    const line = rawLine.trim();
    if (line.startsWith('mtllib ')) {
      mtllibs.push(line.slice('mtllib '.length).trim());
      continue;
    }
    if (line.startsWith('usemtl ')) {
      currentMaterial = line.slice('usemtl '.length).trim();
      if (!materialFaceCounts[currentMaterial]) materialFaceCounts[currentMaterial] = 0;
      continue;
    }
    if (line.startsWith('v ')) {
      const parts = line.split(/\s+/).slice(1).map(Number);
      if (parts.length >= 3 && parts.every(Number.isFinite)) {
        vertexCount += 1;
        for (let axis = 0; axis < 3; axis += 1) {
          bbox.min[axis] = Math.min(bbox.min[axis], parts[axis]);
          bbox.max[axis] = Math.max(bbox.max[axis], parts[axis]);
        }
        maxXYRadius = Math.max(maxXYRadius, Math.hypot(parts[0], parts[1]));
      }
      continue;
    }
    if (line.startsWith('f ')) {
      faceCount += 1;
      materialFaceCounts[currentMaterial] = (materialFaceCounts[currentMaterial] || 0) + 1;
    }
  }

  const size = bbox.max.map((value, axis) => Number((value - bbox.min[axis]).toFixed(3)));
  const center = bbox.max.map((value, axis) => Number(((value + bbox.min[axis]) * 0.5).toFixed(3)));
  const materials = Object.keys(materialFaceCounts).filter((material) => material !== '__unassigned__');

  return {
    vertices: vertexCount,
    faces: faceCount,
    materials,
    materialFaceCounts,
    materialSlotCount: materials.length,
    missingExpectedMaterialSlots: EXPECTED_MATERIAL_SLOTS.filter((slot) => !materials.includes(slot)),
    hasMaterialLibrary: mtllibs.length > 0,
    materialLibraries: mtllibs,
    bbox: {
      min: bbox.min.map((value) => Number(value.toFixed(3))),
      max: bbox.max.map((value) => Number(value.toFixed(3))),
      size,
      center,
    },
    maxXYRadius: Number(maxXYRadius.toFixed(3)),
  };
}

function compareObjStats(source, result) {
  const ratio = (a, b) => (b === 0 ? null : Number((a / b).toFixed(4)));
  const centerDelta = result.bbox.center.map((value, axis) => Number((value - source.bbox.center[axis]).toFixed(3)));
  const sizeRatio = result.bbox.size.map((value, axis) => ratio(value, source.bbox.size[axis]));
  const maxXYRadiusRatio = ratio(result.maxXYRadius, source.maxXYRadius);
  const sourceMaterials = new Set(source.materials);
  const resultMaterials = new Set(result.materials);

  return {
    sourceMesh: {
      vertices: source.vertices,
      faces: source.faces,
      materialSlotCount: source.materialSlotCount,
      maxXYRadius: source.maxXYRadius,
    },
    resultMesh: {
      vertices: result.vertices,
      faces: result.faces,
      materialSlotCount: result.materialSlotCount,
      maxXYRadius: result.maxXYRadius,
    },
    bboxSizeRatio: {
      x: sizeRatio[0],
      y: sizeRatio[1],
      z: sizeRatio[2],
    },
    centerDelta,
    maxXYRadiusRatio,
    possibleSilhouetteShrink: maxXYRadiusRatio !== null && maxXYRadiusRatio < 0.985,
    missingMaterialsFromResult: [...sourceMaterials].filter((material) => !resultMaterials.has(material)),
    newMaterialsInResult: [...resultMaterials].filter((material) => !sourceMaterials.has(material)),
  };
}

function buildBaseline({ args, objStats, manifest, field, qualityReport }) {
  const manifestSlots = manifest?.material_slots ? Object.keys(manifest.material_slots) : [];
  const fieldMasks = field?.masks ? Object.keys(field.masks) : [];
  const artifactChecks = {
    meshExists: existsSync(args.mesh),
    manifestExists: existsSync(args.manifest),
    fieldJsonExists: existsSync(args.fieldJson),
    qualityReportExists: existsSync(args.qualityReport),
    localGlbExporterObserved: false,
    note: 'This fixture found OBJ/manifest/field/quality artifacts. It does not observe a local GLB exporter in the current IslandMeshGen files.',
  };

  return {
    schemaVersion: 1,
    generatedAt: new Date().toISOString(),
    fixtureMode: args.callApi ? 'explicit-api-call' : 'dry-run',
    sourceArtifacts: {
      mesh: toPosixPath(args.mesh),
      manifest: toPosixPath(args.manifest),
      fieldJson: toPosixPath(args.fieldJson),
      qualityReport: toPosixPath(args.qualityReport),
    },
    artifactChecks,
    mesh: objStats,
    manifest: manifest
      ? {
          schemaVersion: manifest.schema_version,
          biome: manifest.biome,
          seed: manifest.seed,
          scale: manifest.scale,
          bake: manifest.bake,
          materialSlots: manifestSlots,
          missingExpectedMaterialSlots: EXPECTED_MATERIAL_SLOTS.filter((slot) => !manifestSlots.includes(slot)),
          materialMasks: manifest.material_masks || [],
          walkableZoneIds: (manifest.walkable_zones || []).map((zone) => zone.id),
          hazardZoneIds: (manifest.hazard_zones || []).map((zone) => zone.id),
        }
      : null,
    field: field
      ? {
          radialSegments: field.radial_segments,
          rings: field.rings,
          biome: field.biome,
          maskNames: fieldMasks,
          hasPathMask: fieldMasks.includes('path'),
          hasLavaMask: fieldMasks.includes('lava'),
          hasCliffMask: fieldMasks.includes('cliff'),
          hasProcessMasks: ['slope', 'talus', 'lava_flow'].every((name) => fieldMasks.includes(name)),
        }
      : null,
    qualityReport: qualityReport
      ? {
          schemaVersion: qualityReport.schemaVersion,
          generatedAt: qualityReport.generatedAt,
          biome: qualityReport.biome,
          quality: qualityReport.quality,
          topology: qualityReport.topology,
          mesh: qualityReport.mesh,
          metrics: qualityReport.metrics,
          issueCount: qualityReport.issueCount,
          topIssueTypes: [...new Set((qualityReport.topIssues || []).map((issue) => issue.type))],
        }
      : null,
    boundaryHypotheses: {
      materialSlotRetexture: 'Retexture may follow 4-5 source regions but must be measured, not trusted.',
      coloredMaskRetexture: 'Colored semantic masks may improve region steering, but Meshy may treat colors as final appearance.',
      remesh: 'Remesh may preserve rough scale/pivot while rebuilding topology, UVs, and possibly material assignments.',
      inputFormat: 'GLB/FBX should be tested against OBJ+MTL; this repo currently has OBJ artifacts but no local GLB exporter.',
      productionUse: 'Meshy output should be evaluated as visible skin only; original semantic mesh remains collision and PCG proxy.',
    },
  };
}

function buildPrompt(jobName) {
  const common = [
    'Preserve the model shape, scale, pivot/origin, and region layout as much as possible.',
    'Do not invent a new island silhouette or route topology.',
    'No baked lighting.',
    'Stylized realistic Unreal Engine game asset.',
    'Keep lava fissures visually distinct from paths, cliffs, top terrain, and underside rock.',
  ];

  if (jobName === 'retexture-material-slots') {
    return [
      'The input terrain mesh uses five semantic material regions: M_TopGrass, M_PathDirt, M_CliffRock, M_UndersideRock, and M_ElementCrack.',
      'Use those material regions as guidance for separate PBR looks if possible.',
      'M_ElementCrack should become glowing lava fissures with emissive PBR.',
      'M_PathDirt should become compressed volcanic ash paths with fine gravel normals.',
      'M_CliffRock should become dark basalt cliffs with vertical strata.',
      'M_TopGrass should become cooled black volcanic soil with ash dust.',
      'M_UndersideRock should become porous shadow rock.',
      'Preserve material separation if possible; do not merge semantic regions.',
      ...common,
    ].join('\n');
  }

  if (jobName === 'retexture-colored-mask') {
    return [
      'The input mesh uses temporary colored material regions as semantic masks, not final colors.',
      'Red/orange regions are lava fissure masks and should become glowing emissive lava cracks.',
      'Ochre/yellow regions are path masks and should become compressed volcanic ash paths.',
      'Blue-gray regions are cliff masks and should become dark basalt cliffs with vertical strata.',
      'Neutral gray-green regions are top terrain masks and should become cooled black volcanic soil with ash dust.',
      'Dark purple/black regions are underside masks and should become porous shadow rock.',
      'Replace the mask colors with natural PBR materials; do not keep the flat mask colors as final albedo.',
      ...common,
    ].join('\n');
  }

  return [
    'Remesh this terrain only as a visual skin experiment.',
    'Smooth import noise and tiny spikes without shrinking the outer silhouette.',
    'Preserve the source scale, pivot/origin, and approximate bounding box.',
    'Preserve material assignment boundaries if possible.',
    'Do not treat the remeshed result as collision, walkability, PCG, or gameplay source of truth.',
    ...common,
  ].join('\n');
}

function buildNegativePrompt() {
  return [
    'baked lighting',
    'merged lava into path',
    'merged material regions',
    'new terrain topology',
    'changed island scale',
    'shifted pivot',
    'rounded crater away',
    'shrunken silhouette',
    'flat mask colors as final material',
    'single generic rock material',
  ].join(', ');
}

function buildPayload(jobName, args, baseline) {
  const taskType = jobName.startsWith('retexture') ? 'retexture' : 'remesh';
  const prompt = buildPrompt(jobName);
  return {
    schema: 'local_meshy_boundary_payload_draft_v1',
    apiNote: 'Draft payload for manual adaptation to the current Meshy API. This fixture intentionally does not hard-code endpoint-specific field names.',
    jobName,
    taskType,
    sourceOfTruthWarning: 'Use Meshy output as visible skin or visual reference only. Keep the original semantic mesh for collision, PCG proxy, walkability, and gameplay regions.',
    input: {
      modelUrl: args.modelUrl || '<UPLOAD_MODEL_URL>',
      plannedInputFormat: args.inputFormat,
      localMeshPath: toPosixPath(args.mesh),
      localManifestPath: toPosixPath(args.manifest),
      meshStats: {
        vertices: baseline.mesh.vertices,
        faces: baseline.mesh.faces,
        materialSlotCount: baseline.mesh.materialSlotCount,
        materials: baseline.mesh.materials,
        bbox: baseline.mesh.bbox,
        maxXYRadius: baseline.mesh.maxXYRadius,
      },
    },
    prompt,
    negativePrompt: buildNegativePrompt(),
    requestedBehavior: {
      enablePbr: taskType === 'retexture',
      preserveScale: true,
      preservePivot: true,
      preserveMaterialRegions: true,
      preserveNamedMaterialSlotsIfSupported: true,
      noBakedLighting: true,
    },
    acceptanceChecks: [
      'Count output material slots / material regions and compare with the five source regions.',
      'Check whether lava/path/cliff/top/underside remain visually separable.',
      'Measure bounding box size and origin shift against baseline.',
      'For remesh, check max XY radius ratio; values below 0.985 indicate possible silhouette shrink.',
      'Confirm the result is acceptable only as a visible skin; original semantic mesh remains collision and PCG proxy.',
    ],
  };
}

function buildMaskMtl() {
  return `# Semantic mask material library for Meshy boundary tests.
# These colors are masks, not final art direction.

newmtl M_TopGrass
Kd 0.36 0.42 0.34
Ka 0.00 0.00 0.00

newmtl M_PathDirt
Kd 0.95 0.68 0.18
Ka 0.00 0.00 0.00

newmtl M_CliffRock
Kd 0.28 0.38 0.48
Ka 0.00 0.00 0.00

newmtl M_UndersideRock
Kd 0.08 0.04 0.12
Ka 0.00 0.00 0.00

newmtl M_ElementCrack
Kd 1.00 0.18 0.02
Ke 1.00 0.18 0.02
Ka 0.00 0.00 0.00
`;
}

async function writeMaskedObjCopy(args, outputDir) {
  const sourceText = await readFile(args.mesh, 'utf8');
  const mtlName = 'meshy_semantic_mask.mtl';
  const outputName = `${path.basename(args.mesh, path.extname(args.mesh))}.semantic_mask.obj`;
  const outputPath = path.join(outputDir, outputName);
  const lines = sourceText.split(/\r?\n/);
  const hasMtllib = lines.some((line) => line.trim().startsWith('mtllib '));
  const nextText = hasMtllib
    ? sourceText.replace(/^mtllib .+$/m, `mtllib ${mtlName}`)
    : [`mtllib ${mtlName}`, sourceText].join('\n');
  await writeFile(outputPath, nextText, 'utf8');
  return outputPath;
}

function buildChecklist(args, baseline, payloadFiles, comparisonFile) {
  const modelUrlExample = args.modelUrl || '<UPLOAD_MODEL_URL>';
  return `# Meshy Boundary Fixture Checklist

Generated: ${new Date().toISOString()}

## Source Baseline

- Mesh: \`${toPosixPath(args.mesh)}\`
- Manifest: \`${toPosixPath(args.manifest)}\`
- Field JSON: \`${toPosixPath(args.fieldJson)}\`
- Quality report: \`${toPosixPath(args.qualityReport)}\`
- Mesh vertices/faces: ${baseline.mesh.vertices} / ${baseline.mesh.faces}
- OBJ material slots found: ${baseline.mesh.materialSlotCount} (${baseline.mesh.materials.join(', ')})
- Expected slot gaps: ${baseline.mesh.missingExpectedMaterialSlots.length ? baseline.mesh.missingExpectedMaterialSlots.join(', ') : 'none'}
- OBJ has mtllib: ${baseline.mesh.hasMaterialLibrary ? 'yes' : 'no'}
- Baseline bbox size cm: ${baseline.mesh.bbox.size.join(' x ')}
- Baseline max XY radius cm: ${baseline.mesh.maxXYRadius}

## Generated Fixture Files

${payloadFiles.map((file) => `- \`${toPosixPath(file)}\``).join('\n')}
${comparisonFile ? `- \`${toPosixPath(comparisonFile)}\`` : ''}

## Sprint 0 Manual Test Matrix

| Test | Input | What It Proves | Pass Signal | Fail Signal |
| --- | --- | --- | --- | --- |
| R1 material-slot Retexture | Source OBJ/FBX/GLB with 5 named material regions | Whether Retexture respects 4-5 material regions without colored masks | 5 regions remain visually distinct; lava limited to crack region | Single baked look, merged path/lava/cliff, or slot names ignored |
| R2 colored-mask Retexture | Same mesh plus semantic mask colors / MTL | Whether color masks steer Meshy better than slot names | Better lava/path/cliff separation than R1, natural PBR replaces mask colors | Flat mask colors remain as final albedo, or color bleeding is worse |
| M1 visible-skin Remesh | Source semantic mesh duplicate | Whether scale, pivot, material assignment, and silhouette survive | bbox within 1-2%, center near origin, material regions still usable | origin shift, material collapse, max XY radius below 0.985, crater/path rounded away |
| F1 format comparison | OBJ+MTL vs GLB/FBX if available | Whether GLB/FBX is better for input preservation | GLB/FBX keeps material regions with fewer upload/import surprises | OBJ+MTL equals or beats GLB/FBX, or local GLB export remains blocked |
| P1 production boundary | Any accepted Meshy output | Whether result is suitable as visible skin only | Original semantic mesh remains collision/PCG proxy | Meshy mesh becomes required for gameplay topology |

## Copyable Dry-Run Curl Template

Set \`MESHY_ENDPOINT\` to the current Meshy endpoint from the official docs before use. The fixture does not hard-code it.

\`\`\`powershell
$env:MESHY_API_KEY = "<your key>"
$env:MESHY_ENDPOINT = "<current Meshy endpoint>"
$payload = Get-Content -Raw "${toPosixPath(payloadFiles[0])}"
Invoke-RestMethod -Method Post -Uri $env:MESHY_ENDPOINT -Headers @{ Authorization = "Bearer $env:MESHY_API_KEY" } -ContentType "application/json" -Body $payload
\`\`\`

For the generic Node guarded call, first upload the model somewhere Meshy can fetch it, then run:

\`\`\`powershell
node Tools\\IslandMeshGen\\meshy_boundary_fixture.mjs --job retexture-colored-mask --model-url "${modelUrlExample}" --endpoint $env:MESHY_ENDPOINT --call-api
\`\`\`

## After Meshy Returns

1. Download every returned model and texture map.
2. Record returned format, texture maps, material count, and whether emissive exists.
3. If the result is OBJ, compare it locally:

\`\`\`powershell
node Tools\\IslandMeshGen\\meshy_boundary_fixture.mjs --compare-result <downloaded-result.obj>
\`\`\`

4. If the result is GLB/FBX, inspect in Blender or Unreal and manually record:
   - bbox size ratio versus baseline
   - origin / pivot shift
   - material slot count and names
   - whether region assignment still follows lava/path/cliff/top/underside
   - whether outer silhouette or crater rim visibly shrank
5. Treat accepted output as visible skin only. Keep \`${toPosixPath(args.mesh)}\` as collision and PCG proxy.
  `;
}

function validateApiPreflight(args) {
  if (!args.callApi) return;
  if (!process.env.MESHY_API_KEY) {
    throw new Error('MESHY_API_KEY is missing. Refusing to call API.');
  }
  if (!(args.endpoint || process.env.MESHY_ENDPOINT)) {
    throw new Error('MESHY_ENDPOINT or --endpoint is missing. Refusing to call API.');
  }
  if (!args.modelUrl) {
    throw new Error('--model-url is required for --call-api. Refusing to send placeholder payload.');
  }
}

async function callApi(jobName, payload, args) {
  const key = process.env.MESHY_API_KEY;
  const endpoint = args.endpoint || process.env.MESHY_ENDPOINT;
  if (!key) {
    throw new Error('MESHY_API_KEY is missing. Refusing to call API.');
  }
  if (!endpoint) {
    throw new Error('MESHY_ENDPOINT or --endpoint is missing. Refusing to call API.');
  }
  if (!args.modelUrl) {
    throw new Error('--model-url is required for --call-api. Refusing to send placeholder payload.');
  }

  const response = await fetch(endpoint, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${key}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(payload),
  });
  const body = await response.text();
  return {
    jobName,
    endpoint,
    status: response.status,
    ok: response.ok,
    body,
  };
}

async function main() {
  const args = parseArgs(process.argv.slice(2));
  if (args.help) {
    console.log(usage());
    return;
  }
  validateApiPreflight(args);

  const outputDir = args.outputDir;
  await mkdir(outputDir, { recursive: true });

  if (!existsSync(args.mesh)) {
    throw new Error(`Mesh not found: ${args.mesh}`);
  }

  const objStats = parseObj(await readFile(args.mesh, 'utf8'));
  const manifest = await readJsonIfExists(args.manifest);
  const field = await readJsonIfExists(args.fieldJson);
  const qualityReport = await readJsonIfExists(args.qualityReport);
  const baseline = buildBaseline({
    args,
    objStats,
    manifest: manifest.value,
    field: field.value,
    qualityReport: qualityReport.value,
  });

  const baselinePath = path.join(outputDir, 'baseline.json');
  const mtlPath = path.join(outputDir, 'meshy_semantic_mask.mtl');
  await writeFile(baselinePath, JSON.stringify(baseline, null, 2) + '\n', 'utf8');
  await writeFile(mtlPath, buildMaskMtl(), 'utf8');

  const jobsToWrite = args.job === 'all' ? JOBS : [args.job];
  const payloadFiles = [];
  const payloads = {};
  for (const jobName of jobsToWrite) {
    const payload = buildPayload(jobName, args, baseline);
    payloads[jobName] = payload;
    const payloadPath = path.join(outputDir, `${jobName}.payload.json`);
    await writeFile(payloadPath, JSON.stringify(payload, null, 2) + '\n', 'utf8');
    const promptPath = path.join(outputDir, `${jobName}.prompt.txt`);
    await writeFile(promptPath, `${payload.prompt}\n\nNegative prompt:\n${payload.negativePrompt}\n`, 'utf8');
    payloadFiles.push(payloadPath, promptPath);
  }
  payloadFiles.unshift(baselinePath, mtlPath);

  if (args.writeMaskedObj) {
    const maskedObjPath = await writeMaskedObjCopy(args, outputDir);
    payloadFiles.push(maskedObjPath);
  }

  let comparisonFile = '';
  if (args.compareResult) {
    const resultStats = parseObj(await readFile(args.compareResult, 'utf8'));
    const comparison = compareObjStats(objStats, resultStats);
    comparisonFile = path.join(outputDir, 'compare-result.json');
    await writeFile(comparisonFile, JSON.stringify(comparison, null, 2) + '\n', 'utf8');
  }

  const checklistPath = path.join(outputDir, 'manual-checklist.md');
  await writeFile(checklistPath, buildChecklist(args, baseline, payloadFiles, comparisonFile), 'utf8');

  if (args.callApi) {
    const apiResponse = await callApi(args.job, payloads[args.job], args);
    const apiResponsePath = path.join(outputDir, `${args.job}.api-response.json`);
    await writeFile(apiResponsePath, JSON.stringify(apiResponse, null, 2) + '\n', 'utf8');
    console.log(`API response written: ${apiResponsePath}`);
  }

  console.log(`Meshy boundary fixture written to ${outputDir}`);
  console.log(`Dry-run: ${args.callApi ? 'no, explicit API call requested' : 'yes, no network call made'}`);
  console.log(`Baseline material slots: ${objStats.materials.join(', ')}`);
  console.log(`Checklist: ${checklistPath}`);
}

main().catch((error) => {
  console.error(`ERROR: ${error.message}`);
  process.exitCode = 1;
});
