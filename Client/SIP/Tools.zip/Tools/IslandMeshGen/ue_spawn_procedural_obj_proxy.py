import json
from pathlib import Path

import unreal


DEFAULT_ARGS = {
    "source_obj": "C:/Users/12542/Documents/Unreal Projects/SkyIslandPotion/Tools/IslandMeshGen/output/plant_regroup/CrownLily_local-upload-mr9cc1z8-Meshy_AI_Flamebound_Scepter_1783275149_part-segm-Meshy_AI_Fl/07_ue_test/CrownLily_C0_SourceProxy_full.obj",
    "label": "SIP_AIGC_CrownLily_C0_ProceduralProxy",
    "tag": "AIGCPlantC0ProceduralProxy",
    "location": [-1040.0, -520.0, 220.0],
    "rotation": [0.0, -18.0, 0.0],
}


def _args():
    if hasattr(unreal, "get_mcp_args"):
        incoming = unreal.get_mcp_args() or {}
        merged = dict(DEFAULT_ARGS)
        merged.update(incoming)
        return merged
    return DEFAULT_ARGS


def _read_obj(path):
    vertices = []
    triangles = []
    with open(path, "r", encoding="utf-8") as handle:
        for line in handle:
            if line.startswith("v "):
                parts = line.strip().split()
                vertices.append(unreal.Vector(float(parts[1]), float(parts[2]), float(parts[3])))
            elif line.startswith("f "):
                raw = line.strip().split()[1:]
                face = []
                for token in raw[:3]:
                    face.append(int(token.split("/")[0]) - 1)
                if len(face) == 3:
                    triangles.extend(face)
    if not vertices or not triangles:
        raise RuntimeError("OBJ has no usable triangle geometry: {}".format(path))
    return vertices, triangles


def _clear_previous(tag, label):
    subsystem = unreal.get_editor_subsystem(unreal.EditorActorSubsystem)
    removed = 0
    for actor in subsystem.get_all_level_actors():
        if actor.get_actor_label() == label or any(str(actor_tag) == tag for actor_tag in actor.tags):
            subsystem.destroy_actor(actor)
            removed += 1
    return removed


def _make_component(actor):
    if not hasattr(unreal, "ProceduralMeshComponent"):
        raise RuntimeError("ProceduralMeshComponent is not available. Enable the ProceduralMeshComponent plugin and restart UE.")

    if hasattr(actor, "get_root_component"):
        root = actor.get_root_component()
    else:
        root = actor.root_component
    if root is None:
        raise RuntimeError("Host actor has no root component")

    component = unreal.new_object(unreal.ProceduralMeshComponent, actor, "CrownLilyC0ProceduralMesh")
    component.attach_to_component(
        root,
        "",
        unreal.AttachmentRule.KEEP_RELATIVE,
        unreal.AttachmentRule.KEEP_RELATIVE,
        unreal.AttachmentRule.KEEP_RELATIVE,
        False,
    )
    component.register_component()
    component.set_collision_enabled(unreal.CollisionEnabled.NO_COLLISION)

    material = unreal.EditorAssetLibrary.load_asset("/Engine/BasicShapes/BasicShapeMaterial.BasicShapeMaterial")
    if material:
        component.set_material(0, material)
    return component


def _create_section(component, vertices, triangles):
    normals = []
    uvs = []
    colors = []
    tangents = []
    if hasattr(component, "create_mesh_section"):
        component.create_mesh_section(0, vertices, triangles, normals, uvs, colors, tangents, False)
        return "create_mesh_section"
    if hasattr(component, "create_mesh_section_linear_color"):
        component.create_mesh_section_linear_color(0, vertices, triangles, normals, uvs, colors, tangents, False)
        return "create_mesh_section_linear_color"
    raise RuntimeError("ProceduralMeshComponent has no create_mesh_section API")


def main():
    args = _args()
    source = Path(args["source_obj"])
    if not source.exists():
        raise RuntimeError("Missing OBJ: {}".format(source))

    vertices, triangles = _read_obj(str(source))
    location = unreal.Vector(float(args["location"][0]), float(args["location"][1]), float(args["location"][2]))
    rotation = unreal.Rotator(float(args["rotation"][0]), float(args["rotation"][1]), float(args["rotation"][2]))

    removed = _clear_previous(args["tag"], args["label"])
    subsystem = unreal.get_editor_subsystem(unreal.EditorActorSubsystem)
    actor = subsystem.spawn_actor_from_class(unreal.StaticMeshActor, location, rotation)
    actor.set_actor_label(args["label"])
    actor.tags = [
        args["tag"],
        "AIGCPreview",
        "AIGCPreview.CrownLily",
        "AIGCPreview.C0",
        "AIGCSmoke.ProceduralProxy",
    ]
    component = _make_component(actor)
    api = _create_section(component, vertices, triangles)
    unreal.EditorLevelLibrary.set_selected_level_actors([actor])

    print(
        json.dumps(
            {
                "removed_previous_test_actors": removed,
                "source_obj": str(source),
                "spawned_actor": actor.get_actor_label(),
                "component": component.get_name(),
                "api": api,
                "vertices": len(vertices),
                "triangles": len(triangles) // 3,
                "location": [location.x, location.y, location.z],
            },
            indent=2,
        )
    )


main()
