import json

import unreal


def _package_name(package):
    try:
        return str(package.get_name())
    except Exception:
        return str(package)


def _call_optional(owner, name):
    fn = getattr(owner, name, None)
    if not fn:
        return []
    try:
        return list(fn())
    except Exception:
        return []


content_packages = _call_optional(unreal.EditorLoadingAndSavingUtils, "get_dirty_content_packages")
map_packages = _call_optional(unreal.EditorLoadingAndSavingUtils, "get_dirty_map_packages")

print(
    json.dumps(
        {
            "dirty_content_count": len(content_packages),
            "dirty_content_packages": [_package_name(package) for package in content_packages],
            "dirty_map_count": len(map_packages),
            "dirty_map_packages": [_package_name(package) for package in map_packages],
        },
        indent=2,
        ensure_ascii=False,
    )
)
