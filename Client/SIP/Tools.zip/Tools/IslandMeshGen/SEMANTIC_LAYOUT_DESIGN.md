# Semantic Island Layout Design

This document defines the next direction for `IslandMeshGen`: move from a heightfield mesh generator to a semantic island layout baker.

The core problem is not Python, OBJ, or noise. The current generator lacks an intermediate design model. It jumps from `biome + noise` directly to mesh vertices, so it can create terrain mood but struggles to express concept-art landmarks, readable gameplay routes, and biome-specific scene composition.

## Positioning

`IslandMeshGen` should be presented as a lightweight semantic whitebox pipeline:

```text
Concept Art / Biome Intent
    -> Semantic Layout
    -> Zones and Landmarks
    -> Mesh Bake
    -> Unreal Shader / PCG / Gameplay Validation
```

It is not a final environment art tool. It is the bridge between visual intent and playable Unreal prototypes.

## Design Tension

The recent iterations exposed three tensions.

1. Procedural terrain vs. concept-art landmark
   A continuous height function naturally creates one noisy surface. Concept art needs dominant symbols: volcano, crystal wall, giant root cave.

2. Visual identity vs. playable layout
   A strong silhouette can destroy walkability. A flat playable platform can erase biome identity. The layout model must reserve paths, arenas, hazard areas, and landmarks before height is baked.

3. Single mesh vs. composed scene
   Forest tree holes and roots should not be forced into the closed island mesh. Some biome identity belongs in attachment meshes, PCG dressing, or shader layers.

## Semantic Layout Model

The generator should accept a structured layout object before mesh generation.

```json
{
  "biome": "fire",
  "radius_m": 100,
  "seed": 2002,
  "zones": [],
  "landmarks": [],
  "paths": [],
  "hazards": [],
  "material_masks": []
}
```

### Zones

Zones are large design regions. They answer: what is this part of the island for?

```json
{
  "id": "crater_arena",
  "kind": "arena",
  "center": [0.0, 0.0],
  "radius_range": [0.24, 0.48],
  "height_role": "elevated_ring",
  "walkable": true
}
```

Supported zone kinds:

- `landmark`: primary visual identity
- `path`: traversal route
- `arena`: combat space
- `hazard`: danger or reaction area
- `resource`: reward or harvest area
- `pcg`: vegetation or dressing area
- `cliff`: silhouette and underside treatment

### Landmarks

Landmarks are biome-defining objects. They may be baked into the terrain mesh or emitted later as attachment meshes.

```json
{
  "id": "central_volcano",
  "kind": "volcano",
  "center": [0.0, 0.0],
  "radius": 0.38,
  "dominance": 0.75,
  "bake_mode": "terrain"
}
```

Supported landmark kinds:

- `volcano`
- `lava_channel`
- `ice_crystal_cluster`
- `ice_wall`
- `root_arch`
- `tree_stump_cave`
- `vine_bridge_anchor`

`bake_mode` choices:

- `terrain`: part of the island height mesh
- `attachment`: separate mesh or later PCG actor
- `mask_only`: material or PCG placement hint

### Paths

Paths are first-class data, not incidental flattened noise bands.

```json
{
  "id": "approach_to_volcano",
  "kind": "main_path",
  "points": [[0.92, 0.0], [0.62, 0.0], [0.38, 0.0]],
  "width": 0.12,
  "max_slope_m": 4.0,
  "material": "M_PathDirt"
}
```

Paths should control height after landmark shaping so the route remains readable and playable.

### Material Masks

Material masks are semantic, not just visual.

```json
{
  "slot": "M_ElementCrack",
  "source": "lava_channels",
  "meaning": "elemental_reaction_surface"
}
```

The current five slots remain useful:

- `M_TopGrass`
- `M_PathDirt`
- `M_CliffRock`
- `M_UndersideRock`
- `M_ElementCrack`

Future biome-specific material instances can be mapped onto these slots in Unreal.

## Biome Layout Specs

### Fire Island

Fire should read as a volcano island, not an island with a crater.

Required composition:

- Central volcano owns 35%-45% of visual mass.
- One main approach path reaches the crater rim.
- Optional ring path wraps part of the crater.
- Three lava channels radiate from the crater and interrupt safe space.
- Outer black-rock shelves create combat and traversal pockets.

Suggested layout objects:

```json
{
  "biome": "fire",
  "landmarks": [
    { "id": "central_volcano", "kind": "volcano", "radius": 0.42, "dominance": 0.85, "bake_mode": "terrain" },
    { "id": "lava_channels", "kind": "lava_channel", "count": 3, "bake_mode": "terrain" }
  ],
  "paths": [
    { "id": "main_approach", "kind": "main_path", "width": 0.12, "max_slope_m": 4.0 },
    { "id": "partial_crater_loop", "kind": "loop_path", "width": 0.08, "coverage": 0.55 }
  ],
  "zones": [
    { "id": "crater_arena", "kind": "arena", "walkable": true },
    { "id": "lava_hazard", "kind": "hazard", "walkable": false }
  ]
}
```

### Ice Island

Ice should read as a glacier field with crystal formations, not a flat disk with isolated spikes.

Required composition:

- Central playable ice shelf remains readable.
- Crystal spires appear as clusters and walls, with primary/secondary/tertiary scale hierarchy.
- Deep blue cracks divide the shelf into traversable plates.
- Resource pockets live near crystal clusters.

Suggested layout objects:

```json
{
  "biome": "ice",
  "landmarks": [
    { "id": "primary_crystal_wall", "kind": "ice_wall", "count": 2, "bake_mode": "terrain" },
    { "id": "secondary_spire_clusters", "kind": "ice_crystal_cluster", "count": 4, "bake_mode": "terrain" }
  ],
  "paths": [
    { "id": "central_shelf", "kind": "open_area", "width": 0.34, "max_slope_m": 2.0 },
    { "id": "broken_ice_ring", "kind": "loop_path", "width": 0.1 }
  ],
  "zones": [
    { "id": "resource_crystals", "kind": "resource", "walkable": true },
    { "id": "deep_cracks", "kind": "hazard", "walkable": false }
  ]
}
```

### Forest Island

Forest should not be solved by cutting holes in the island mesh. Its identity comes from attachments and PCG.

Required composition:

- Main island mesh stays closed.
- Giant root arch or tree-stump cave acts as the primary landmark.
- Forest pockets reserve space for mushrooms, flowers, glowing plants, and interaction targets.
- Vines or roots can create traversal bridges.

Suggested layout objects:

```json
{
  "biome": "forest",
  "landmarks": [
    { "id": "root_arch", "kind": "root_arch", "bake_mode": "attachment" },
    { "id": "tree_stump_cave", "kind": "tree_stump_cave", "bake_mode": "attachment" }
  ],
  "paths": [
    { "id": "forest_main_path", "kind": "main_path", "width": 0.14, "max_slope_m": 3.0 },
    { "id": "vine_bridge", "kind": "bridge_anchor", "width": 0.08 }
  ],
  "zones": [
    { "id": "mushroom_pocket", "kind": "pcg", "walkable": true },
    { "id": "glowing_root_cave", "kind": "pcg", "walkable": true }
  ]
}
```

## Web Demo Panel

The recording UI should be a small local web app, not a VSCode plugin, TUI, or desktop app. It has now evolved from a static demo panel into a lightweight semantic editor.

Purpose:

- Show the semantic layout clearly.
- Trigger generation commands.
- Display generated OBJ paths and metrics.
- Provide a clean screen for答辩 video recording.
- Edit the fire layout JSON through controlled parameters.
- Show both 2D semantic intent and 3D generated mesh feedback.

Recommended screen layout:

```text
+--------------------------------------------------------------+
| Sky Island Semantic Whitebox Generator                       |
+----------------------+----------------------+----------------+
| Biome Preset         | Layout Preview       | Generation     |
| - Fire               | colored zones        | radius: 200m   |
| - Ice                | paths / landmarks    | seed           |
| - Forest             | material masks       | Generate OBJ   |
+----------------------+----------------------+----------------+
| Concept Decomposition                                      |
| Landmark / Path / Hazard / PCG / Material slots             |
+--------------------------------------------------------------+
```

Recording beat:

1. Show concept image or reference board.
2. Switch to web panel and choose biome.
3. Point to semantic zones: landmark, path, hazard, PCG area.
4. Click generate.
5. Show UE import with whitebox mesh.
6. Apply prototype shader.
7. Explain that the generated mesh is a playable semantic whitebox, not final art.

Current editor features:

- Editable fire controls for `central_volcano.dominance`, `central_volcano.radius`, `main_approach.width`, `lava_channels.count`, and `partial_crater_loop.coverage`.
- Auto-link mode that keeps fire parameters coherent when the main dominance control changes.
- Design health warnings when manual edits create unnatural combinations.
- 2D semantic layout preview for intention and explanation.
- 3D OBJ canvas preview for immediate geometry feedback.
- `POST /api/generate/fire` writes the current JSON and regenerates the OBJ.

## Tool Boundary

Python should keep doing:

- deterministic layout baking
- OBJ export
- material slot assignment
- testable geometry metrics
- rapid whitebox iteration

Python should stop doing:

- final tree-root geometry
- high quality closed caves
- polished erosion
- final UV/material authoring

Unreal should do:

- material instances
- PCG dressing
- shader prototype validation
- gameplay collision checks
- PIE verification

Houdini becomes useful after the semantic layout stabilizes. It should consume the same layout data to produce better topology, roots, caves, crystal clusters, and erosion. It should not be introduced before the design model is clear.

## Next Implementation Direction

1. Add a `semantic_layout.py` module with dataclasses for `IslandLayout`, `Zone`, `Landmark`, `Path`, and `MaterialMask`.
2. Move biome presets from loose numeric dictionaries into default semantic layouts.
3. Generate terrain from layout masks rather than directly from biome-specific noise.
4. Add JSON export/import so a future web panel can edit the same data.
5. Keep OBJ export as the stable bridge into Unreal.

## Current Implementation Status

`semantic_layout.py` now implements the first step of this design:

- `IslandLayout`
- `Zone`
- `Landmark`
- `PathRoute`
- `MaterialMask`
- `default_layout(biome, radius_m=100.0, seed=42)`
- JSON roundtrip via `to_json()` and `from_json()`

The mesh baker has started consuming layouts through `generate_island_mesh_from_layout(layout)`. The first bridge is intentionally fire-focused:

- `central_volcano.dominance` controls crater rim height.
- `main_approach.width` controls path material coverage and approach flattening.
- `central_volcano.radius` controls crater footprint.
- `lava_channels.count` controls lava crack coverage.
- `partial_crater_loop.coverage` controls crater ring path coverage.

The existing `generate_island_mesh(...)` path remains stable for legacy biome previews while layout-driven baking grows one semantic object at a time.

The Web editor in `web/` now exposes this bridge as an editable workflow. It is deliberately browser-based because the goal is presentation and fast design review, while Unreal remains the authoritative runtime validation environment.
