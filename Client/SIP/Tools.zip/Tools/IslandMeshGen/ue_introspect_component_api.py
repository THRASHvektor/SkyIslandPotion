import json

import unreal


def main():
    subsystem = unreal.get_editor_subsystem(unreal.EditorActorSubsystem)
    actor = subsystem.spawn_actor_from_class(unreal.StaticMeshActor, unreal.Vector(0, 0, 0), unreal.Rotator(0, 0, 0))
    actor.set_actor_label("SIP_TMP_ComponentApiProbe")
    actor_methods = [name for name in dir(actor) if "component" in name.lower() or "root" in name.lower() or "attach" in name.lower()]
    subsystem_methods = [name for name in dir(subsystem) if "component" in name.lower() or "actor" in name.lower()]
    proc_methods = []
    if hasattr(unreal, "ProceduralMeshComponent"):
        proc = unreal.new_object(unreal.ProceduralMeshComponent, actor, "TmpProc")
        proc_methods = [name for name in dir(proc) if "mesh" in name.lower() or "section" in name.lower() or "register" in name.lower() or "attach" in name.lower()]
    subsystem.destroy_actor(actor)
    print(json.dumps({
        "has_procedural_mesh_component": hasattr(unreal, "ProceduralMeshComponent"),
        "actor_methods": actor_methods,
        "editor_actor_subsystem_methods": subsystem_methods,
        "procedural_methods": proc_methods,
    }, indent=2))


main()
