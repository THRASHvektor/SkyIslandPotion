from __future__ import annotations

import argparse
import math
import random
import statistics
from dataclasses import dataclass, field
from pathlib import Path


MATERIALS = ("M_TopGrass", "M_PathDirt", "M_CliffRock", "M_UndersideRock", "M_ElementCrack")
FIRE_MATERIALS = ("M_AshPlateau", "M_PathDirt", "M_CliffRock", "M_UndersideRock", "M_ElementCrack")
TOP_SURFACE_MATERIALS = frozenset(("M_TopGrass", "M_AshPlateau"))


def materials_for_biome(biome: str) -> tuple[str, ...]:
    return FIRE_MATERIALS if biome == "fire" else MATERIALS

BIOME_PRESETS = {
    "forest": {
        "height_scale": 1.05,
        "ravine_depth": 0.95,
        "ravine_width": 1.0,
        "ravine_threshold": 0.34,
        "path_width": 1.0,
        "plateau_radius": 0.42,
        "edge_drop": 1.05,
        "ridge_scale": 1.0,
        "detail_scale": 1.18,
        "vertical_exaggeration": 1.12,
        "underside_depth": 0.34,
        "bottom_depth": 0.95,
        "terrace_strength": 0.76,
        "ice_cap_flatten": 0.0,
    },
    "fire": {
        "height_scale": 1.35,
        "ravine_depth": 2.25,
        "ravine_width": 1.28,
        "ravine_threshold": 0.3,
        "path_width": 0.72,
        "plateau_radius": 0.30,
        "edge_drop": 1.55,
        "ridge_scale": 1.55,
        "detail_scale": 1.45,
        "vertical_exaggeration": 1.35,
        "underside_depth": 0.42,
        "bottom_depth": 1.08,
        "terrace_strength": 0.0,
        "ice_cap_flatten": 0.0,
    },
    "ice": {
        "height_scale": 0.72,
        "ravine_depth": 0.55,
        "ravine_width": 0.8,
        "ravine_threshold": 0.52,
        "path_width": 1.85,
        "plateau_radius": 0.58,
        "edge_drop": 0.8,
        "ridge_scale": 0.7,
        "detail_scale": 0.9,
        "vertical_exaggeration": 1.0,
        "underside_depth": 0.32,
        "bottom_depth": 0.88,
        "terrace_strength": 0.0,
        "ice_cap_flatten": 0.82,
    },
}

BAKE_QUALITY_PROFILES = {
    "draft": {
        "segments": 96,
        "rings": 14,
        "detail_intensity": 0.0,
        "surface_detail_multiplier": 1.0,
        "process_multiplier": 1.0,
        "relaxation_multiplier": 1.0,
        "settle_multiplier": 0.0,
    },
    "preview": {
        "segments": 128,
        "rings": 20,
        "detail_intensity": 0.18,
        "surface_detail_multiplier": 0.82,
        "process_multiplier": 1.0,
        "relaxation_multiplier": 1.05,
        "settle_multiplier": 0.8,
    },
    "production": {
        "segments": 192,
        "rings": 32,
        "detail_intensity": 0.45,
        "surface_detail_multiplier": 0.72,
        "process_multiplier": 1.08,
        "relaxation_multiplier": 1.16,
        "settle_multiplier": 1.0,
    },
    "hero": {
        "segments": 384,
        "rings": 56,
        "detail_intensity": 0.72,
        "surface_detail_multiplier": 0.56,
        "process_multiplier": 1.14,
        "relaxation_multiplier": 1.24,
        "settle_multiplier": 1.28,
    },
}


@dataclass
class Mesh:
    vertices: list[tuple[float, float, float]] = field(default_factory=list)
    faces: list[tuple[str, tuple[int, ...]]] = field(default_factory=list)
    materials: tuple[str, ...] = MATERIALS


@dataclass
class TerrainField:
    radial_segments: int
    rings: int
    biome: str
    heights: list[list[float]]
    path_mask: list[list[float]]
    lava_mask: list[list[float]]
    ravine_mask: list[list[float]]
    volcano_mask: list[list[float]]
    crater_loop_mask: list[list[float]]
    cliff_mask: list[list[float]]
    slope_mask: list[list[float]]
    talus_mask: list[list[float]]
    lava_flow_mask: list[list[float]]
    flow_accumulation_mask: list[list[float]]
    curvature_mask: list[list[float]]
    strata_mask: list[list[float]]
    controls: dict[str, object] = field(default_factory=dict)


def _compact_mask(mask: list[list[float]], precision: int = 3) -> list[list[float]]:
    return [
        [round(float(value), precision) for value in row]
        for row in mask
    ]


def terrain_field_preview_payload(field: TerrainField) -> dict:
    """Serialize process masks for the lightweight web minimap overlay."""
    return {
        "radial_segments": field.radial_segments,
        "rings": field.rings,
        "biome": field.biome,
        "heights": _compact_mask(field.heights, 1),
        "masks": {
            "path": _compact_mask(field.path_mask),
            "lava": _compact_mask(field.lava_mask),
            "ravine": _compact_mask(field.ravine_mask),
            "volcano": _compact_mask(field.volcano_mask),
            "crater_loop": _compact_mask(field.crater_loop_mask),
            "cliff": _compact_mask(field.cliff_mask),
            "slope": _compact_mask(field.slope_mask),
            "talus": _compact_mask(field.talus_mask),
            "lava_flow": _compact_mask(field.lava_flow_mask),
            "flow_accumulation": _compact_mask(field.flow_accumulation_mask),
            "curvature": _compact_mask(field.curvature_mask),
            "strata": _compact_mask(field.strata_mask),
        },
    }


def _add_vertex(mesh: Mesh, vertex: tuple[float, float, float]) -> int:
    mesh.vertices.append(vertex)
    return len(mesh.vertices)


def _edge_scale(angle: float, rng: random.Random) -> float:
    return (
        1.0
        + 0.12 * math.sin(angle * 3.0 + 0.8)
        + 0.08 * math.sin(angle * 5.0 + 1.7)
        + rng.uniform(-0.08, 0.08)
    )


def _smoothstep(edge0: float, edge1: float, value: float) -> float:
    if edge0 == edge1:
        return 1.0 if value >= edge1 else 0.0
    x = min(1.0, max(0.0, (value - edge0) / (edge1 - edge0)))
    return x * x * (3.0 - 2.0 * x)


def _fade(value: float) -> float:
    return value * value * (3.0 - 2.0 * value)


def _lerp(a: float, b: float, t: float) -> float:
    return a + (b - a) * t


def _clamp01(value: float) -> float:
    return min(1.0, max(0.0, value))


def _value_noise(x: float, y: float, seed: int) -> float:
    value = math.sin(x * 12.9898 + y * 78.233 + seed * 37.719) * 43758.5453
    return (value - math.floor(value)) * 2.0 - 1.0


def _smooth_value_noise(x: float, y: float, seed: int) -> float:
    x0 = math.floor(x)
    y0 = math.floor(y)
    tx = _fade(x - x0)
    ty = _fade(y - y0)
    a = _value_noise(x0, y0, seed)
    b = _value_noise(x0 + 1, y0, seed)
    c = _value_noise(x0, y0 + 1, seed)
    d = _value_noise(x0 + 1, y0 + 1, seed)
    return _lerp(_lerp(a, b, tx), _lerp(c, d, tx), ty)


def _fbm(x: float, y: float, seed: int, octaves: int = 5) -> float:
    total = 0.0
    amplitude = 0.5
    frequency = 1.0
    normalization = 0.0
    for octave in range(octaves):
        total += _value_noise(x * frequency, y * frequency, seed + octave * 17) * amplitude
        normalization += amplitude
        amplitude *= 0.5
        frequency *= 2.03
    return total / max(normalization, 0.001)


def _smooth_fbm(x: float, y: float, seed: int, octaves: int = 5) -> float:
    total = 0.0
    amplitude = 0.5
    frequency = 1.0
    normalization = 0.0
    for octave in range(octaves):
        total += _smooth_value_noise(x * frequency, y * frequency, seed + octave * 17) * amplitude
        normalization += amplitude
        amplitude *= 0.5
        frequency *= 2.03
    return total / max(normalization, 0.001)


def _smooth_circular_values(values: list[float], passes: int) -> list[float]:
    smoothed = list(values)
    for _ in range(max(0, passes)):
        smoothed = [
            smoothed[index] * 0.5
            + smoothed[index - 1] * 0.25
            + smoothed[(index + 1) % len(smoothed)] * 0.25
            for index in range(len(smoothed))
        ]
    return smoothed


def _angular_distance(a: float, b: float) -> float:
    return abs(math.atan2(math.sin(a - b), math.cos(a - b)))


def _preset(biome: str) -> dict[str, float]:
    return BIOME_PRESETS.get(biome.lower(), BIOME_PRESETS["forest"])


def bake_quality_profile(raw_quality: str | None) -> dict[str, float]:
    quality = (raw_quality or "production").lower()
    profile = BAKE_QUALITY_PROFILES.get(quality, BAKE_QUALITY_PROFILES["production"])
    return dict(profile)


def _ravine_strength(radial_alpha: float, angle: float, seed: int, biome: str) -> float:
    if radial_alpha < 0.28:
        return 0.0

    preset = _preset(biome)
    strength = 0.0
    for offset, base_angle in enumerate((0.82, 2.35, 4.28)):
        warped_angle = base_angle + 0.18 * math.sin(radial_alpha * 8.0 + seed * 0.013 + offset)
        width = (0.075 + 0.02 * offset) * preset["ravine_width"]
        distance = _angular_distance(angle, warped_angle)
        branch = 1.0 - _smoothstep(width, width * 3.2, distance)
        outward = _smoothstep(0.32, 0.95, radial_alpha)
        strength = max(strength, branch * outward)
    return strength


def _normalized_xy(radial_alpha: float, angle: float) -> tuple[float, float]:
    return math.cos(angle) * radial_alpha, math.sin(angle) * radial_alpha


def _point_distance(radial_alpha: float, angle: float, center_x: float, center_y: float) -> float:
    x, y = _normalized_xy(radial_alpha, angle)
    return math.hypot(x - center_x, y - center_y)


def _segment_distance(radial_alpha: float, angle: float, start: tuple[float, float], end: tuple[float, float]) -> float:
    x, y = _normalized_xy(radial_alpha, angle)
    start_x, start_y = start
    end_x, end_y = end
    segment_x = end_x - start_x
    segment_y = end_y - start_y
    segment_length_sq = segment_x * segment_x + segment_y * segment_y
    if segment_length_sq <= 0.0001:
        return math.hypot(x - start_x, y - start_y)

    t = _clamp01(((x - start_x) * segment_x + (y - start_y) * segment_y) / segment_length_sq)
    closest_x = start_x + segment_x * t
    closest_y = start_y + segment_y * t
    return math.hypot(x - closest_x, y - closest_y)


def _control_point(controls: dict[str, object] | None, key: str, default: tuple[float, float]) -> tuple[float, float]:
    value = (controls or {}).get(key, default)
    if not isinstance(value, (tuple, list)) or len(value) < 2:
        return default
    return float(value[0]), float(value[1])


def _control_points(controls: dict[str, object] | None, key: str, default: tuple[tuple[float, float], ...]) -> tuple[tuple[float, float], ...]:
    value = (controls or {}).get(key, default)
    if not isinstance(value, (tuple, list)):
        return default
    points: list[tuple[float, float]] = []
    for point in value:
        if isinstance(point, (tuple, list)) and len(point) >= 2:
            points.append((float(point[0]), float(point[1])))
    return tuple(points) or default


def _ice_cluster_angles(count: int) -> tuple[float, ...]:
    base_angles = (0.28, 2.05, 5.25, 3.08, 4.18, 1.18, 0.92, 3.82)
    count = max(1, min(count, len(base_angles)))
    return base_angles[:count]


def _forest_vine_bridge_path_strength(radial_alpha: float, angle: float, controls: dict[str, object] | None = None) -> float:
    bridge_points = _control_points(controls, "forest_vine_bridge_points", ((0.62, 0.18), (0.20, 0.42)))
    bridge_start = bridge_points[0]
    bridge_end = bridge_points[-1]
    bridge_width = max(0.025, float((controls or {}).get("forest_vine_bridge_width", 0.08)))
    bridge_distance = _segment_distance(radial_alpha, angle, bridge_start, bridge_end)
    bridge_core = 1.0 - _smoothstep(bridge_width * 0.44, bridge_width * 1.31, bridge_distance)
    end_anchor = 1.0 - _smoothstep(bridge_width * 0.38, bridge_width * 1.82, _point_distance(radial_alpha, angle, bridge_start[0], bridge_start[1]))
    canopy_anchor = 1.0 - _smoothstep(bridge_width * 0.44, bridge_width * 1.68, _point_distance(radial_alpha, angle, bridge_end[0], bridge_end[1]))
    mushroom_center = _control_point(controls, "forest_mushroom_center", (0.28, 0.34))
    mushroom_radius = float((controls or {}).get("forest_mushroom_feature_radius", 0.255))
    mushroom_clearance = 1.0 - _smoothstep(mushroom_radius * 0.22, mushroom_radius * 0.57, _point_distance(radial_alpha, angle, mushroom_center[0], mushroom_center[1]))
    return max(bridge_core, end_anchor, canopy_anchor) * (1.0 - mushroom_clearance * 0.86)


def _path_strength(radial_alpha: float, angle: float, biome: str, path_width: float | None = None, controls: dict[str, object] | None = None) -> float:
    preset = _preset(biome)
    signed_angle = math.atan2(math.sin(angle), math.cos(angle))
    width = preset["path_width"] if path_width is None else path_width
    inner_width = 0.25 * width
    outer_width = 0.72 * width
    main_path = (1.0 - _smoothstep(inner_width, outer_width, abs(signed_angle))) * _smoothstep(0.08, 0.92, radial_alpha)
    if biome == "forest":
        main_path = max(main_path, _forest_vine_bridge_path_strength(radial_alpha, angle, controls))
    return main_path


def _lava_channel_angles(count: int) -> tuple[float, ...]:
    count = max(1, count)
    return tuple(0.42 + (math.tau * index / count) for index in range(count))


def _lava_branch_strength(radial_alpha: float, angle: float, count: int) -> float:
    branch_strength = 0.0
    for channel_index, channel_angle in enumerate(_lava_channel_angles(count)):
        signed_channel_angle = abs(math.atan2(math.sin(channel_angle), math.cos(channel_angle)))
        approach_suppression = 1.0 - _smoothstep(0.42, 0.72, signed_channel_angle)
        if approach_suppression >= 1.0:
            continue

        branch_direction = 1.0 if channel_index % 2 == 0 else -1.0
        start_radius = 0.60 + 0.035 * ((channel_index % 3) - 1)
        progress = _smoothstep(start_radius, min(0.94, start_radius + 0.28), radial_alpha)
        branch_band = (
            _smoothstep(start_radius, start_radius + 0.12, radial_alpha)
            * (1.0 - _smoothstep(0.97, 1.0, radial_alpha))
        )
        if branch_band <= 0.0:
            continue

        meander = math.sin(radial_alpha * 16.0 + channel_index * 1.7) * 0.018
        branch_angle = channel_angle + branch_direction * (0.075 + progress * 0.125) + meander
        branch_width = 0.032 + progress * 0.046
        distance = _angular_distance(angle, branch_angle)
        branch_core = 1.0 - _smoothstep(branch_width * 0.26, branch_width, distance)
        branch_strength = max(
            branch_strength,
            branch_core * branch_band * (0.44 + progress * 0.38) * (1.0 - approach_suppression),
        )
    return _clamp01(branch_strength)


def _lava_channel_strength(radial_alpha: float, angle: float, count: int) -> float:
    nearest = min(_angular_distance(angle, channel_angle) for channel_angle in _lava_channel_angles(count))
    trunk = max(0.0, 1.0 - _smoothstep(0.055, 0.17, nearest)) * _smoothstep(0.28, 0.95, radial_alpha)
    return max(trunk, _lava_branch_strength(radial_alpha, angle, count))


def _lava_spillway_strength(radial_alpha: float, angle: float, count: int, rim_center: float) -> float:
    nearest = min(_angular_distance(angle, channel_angle) for channel_angle in _lava_channel_angles(count))
    angular_core = 1.0 - _smoothstep(0.016, 0.064, nearest)
    rim_band = 1.0 - _smoothstep(0.020, 0.086, abs(radial_alpha - rim_center))
    return angular_core * rim_band


def _height_relaxation_strength(radial_alpha: float, angle: float, biome: str, controls: dict[str, object]) -> float:
    detail_intensity = float(controls.get("terrain_relaxation_intensity", controls.get("terrain_detail_intensity", 0.0)))
    if detail_intensity <= 0.0:
        return 0.0

    strength = min(0.34, detail_intensity * 0.38)
    path_strength = _path_strength(radial_alpha, angle, biome, controls.get("path_width"), controls)
    strength *= 1.0 + path_strength * 0.35

    if biome == "fire":
        volcano_radius = float(controls.get("volcano_radius", 0.42))
        rim_mask = 1.0 - _smoothstep(0.035, 0.13, abs(radial_alpha - volcano_radius))
        lava_mask = _lava_channel_strength(radial_alpha, angle, int(controls.get("lava_channel_count", 3)))
        strength *= 1.0 - rim_mask * 0.28
        strength *= 1.0 - lava_mask * 0.18

    return max(0.0, min(0.34, strength))


def _relax_top_heightfield(
    mesh: Mesh,
    top_rings: list[list[int]],
    radial_segments: int,
    rings: int,
    biome: str,
    controls: dict[str, object],
) -> None:
    detail_intensity = float(controls.get("terrain_relaxation_intensity", controls.get("terrain_detail_intensity", 0.0)))
    if detail_intensity <= 0.0:
        return

    passes = 1 if detail_intensity < 0.3 else 2
    if detail_intensity > 0.6:
        passes = 3

    for _ in range(passes):
        next_heights: dict[int, float] = {}
        for ring in range(1, rings + 1):
            radial_alpha = ring / rings
            for index in range(radial_segments):
                vertex_index = top_rings[ring][index]
                x, y, z = mesh.vertices[vertex_index - 1]
                prev_z = mesh.vertices[top_rings[ring][index - 1] - 1][2]
                next_z = mesh.vertices[top_rings[ring][(index + 1) % radial_segments] - 1][2]
                target_z = z * 0.5 + prev_z * 0.25 + next_z * 0.25
                angle = (index / radial_segments) * math.tau
                strength = _height_relaxation_strength(radial_alpha, angle, biome, controls)
                next_heights[vertex_index] = z * (1.0 - strength) + target_z * strength

        for vertex_index, z in next_heights.items():
            x, y, _ = mesh.vertices[vertex_index - 1]
            mesh.vertices[vertex_index - 1] = (x, y, z)


def _terrain_detail_height(radial_alpha: float, angle: float, seed: int, biome: str, controls: dict[str, object]) -> float:
    detail_intensity = float(controls.get("terrain_detail_intensity", 0.0))
    if detail_intensity <= 0.0:
        return 0.0

    preset = _preset(biome)
    x = math.cos(angle) * radial_alpha
    y = math.sin(angle) * radial_alpha
    cliff_mask = _smoothstep(0.52, 0.96, radial_alpha)
    path_mask = _path_strength(radial_alpha, angle, biome, controls.get("path_width"), controls)
    center_arena_mask = 1.0 - _smoothstep(0.10, 0.36, radial_alpha)
    ravine_mask = _ravine_strength(radial_alpha, angle, seed, biome)
    granular = _smooth_fbm(x * 24.0 * preset["detail_scale"], y * 24.0 * preset["detail_scale"], seed + 701, 3) * 44.0
    strata = math.sin(radial_alpha * 62.0 + _smooth_fbm(x * 6.0, y * 6.0, seed + 709, 2) * 2.4) * 24.0 * cliff_mask
    chipped = (1.0 - abs(_smooth_fbm(x * 15.0 - 6.0, y * 15.0 + 4.0, seed + 719, 3))) * 25.0

    detail_region_mask = 0.16 + cliff_mask * 0.42 + ravine_mask * 0.22
    gameplay_protection = (1.0 - path_mask * 0.86) * (1.0 - center_arena_mask * 0.72)
    semantic_detail = granular * detail_region_mask + strata + chipped * (0.35 + cliff_mask * 0.55 + ravine_mask * 0.25)
    if biome == "fire":
        volcano_radius = float(controls.get("volcano_radius", 0.42))
        rim_mask = 1.0 - _smoothstep(0.035, 0.13, abs(radial_alpha - volcano_radius))
        lava_count = int(controls.get("lava_channel_count", 3))
        lava_mask = _lava_channel_strength(radial_alpha, angle, lava_count)
        crater_interior_mask = 1.0 - _smoothstep(volcano_radius * 0.34, volcano_radius * 0.72, radial_alpha)
        lava_shoulder_mask = _clamp01(_smoothstep(0.10, 0.42, lava_mask) - _smoothstep(0.58, 0.92, lava_mask))
        rim_chips = (1.0 - abs(_smooth_fbm(x * 23.0, y * 23.0, seed + 731, 3))) * 54.0 * rim_mask
        cooling_crust = _smooth_fbm(x * 20.0 + 3.0, y * 20.0 - 2.0, seed + 739, 3) * 31.0 * lava_shoulder_mask
        semantic_detail += rim_chips + cooling_crust
        detail_region_mask = max(detail_region_mask, rim_mask * 0.52, lava_shoulder_mask * 0.44, lava_mask * 0.18)
        gameplay_protection *= 1.0 - crater_interior_mask * 0.78

    detail_gain = 0.85 + min(1.4, max(0.0, float(controls.get("detail_energy", 1.0)))) * 0.65
    return semantic_detail * detail_intensity * detail_gain * _clamp01(gameplay_protection) * 8.0


def _volcano_height(radial_alpha: float, angle: float, seed: int, volcano_radius: float = 0.42, lava_channel_count: int = 3) -> float:
    sector_signal = (
        math.sin(angle * 2.0 + seed * 0.003)
        + 0.55 * math.sin(angle * 3.0 - 1.1)
        + 0.32 * math.sin(angle * 5.0 + 0.7)
    ) / 1.87
    collapse_notch = 1.0 - _smoothstep(0.16, 0.54, _angular_distance(angle, 5.58))
    high_buttress = 1.0 - _smoothstep(0.18, 0.62, _angular_distance(angle, 3.78))
    rim_center = volcano_radius + sector_signal * 0.058 + high_buttress * 0.045 - collapse_notch * 0.088
    rim_width_inner = max(0.038, volcano_radius * (0.105 + collapse_notch * 0.035))
    rim_width_outer = max(0.075, volcano_radius * (0.19 + high_buttress * 0.035))
    cone_end = min(0.92, rim_center + volcano_radius * 0.96)
    crater_inner = max(0.08, rim_center * 0.24)
    crater_outer = max(0.16, rim_center * 0.57)
    rim_mask = 1.0 - _smoothstep(rim_width_inner, rim_width_outer, abs(radial_alpha - rim_center))
    rim = rim_mask * (2000.0 + sector_signal * 360.0 + high_buttress * 260.0 - collapse_notch * 420.0)
    cone = (1.0 - _smoothstep(volcano_radius * 0.42, cone_end, radial_alpha)) * 520.0
    crater_cut = (1.0 - _smoothstep(crater_inner, crater_outer, radial_alpha)) * -760.0
    broken_rim = _fbm(math.cos(angle) * 3.4, math.sin(angle) * 3.4, seed + 401, 3) * 120.0
    lava = _lava_channel_strength(radial_alpha, angle, lava_channel_count)
    lava_shoulder = _clamp01(_smoothstep(0.18, 0.52, lava) - _smoothstep(0.62, 0.94, lava))
    lava_channels = -480.0 * lava - 280.0 * lava * lava + 135.0 * lava_shoulder
    spillway = max(
        _lava_spillway_strength(radial_alpha, angle, lava_channel_count, rim_center),
        _lava_spillway_strength(radial_alpha, angle, lava_channel_count, volcano_radius) * 0.86,
    )
    spillway_cut = -760.0 * spillway
    return rim + cone + crater_cut + broken_rim + lava_channels + spillway_cut


def _ice_spire_height(radial_alpha: float, angle: float, seed: int, controls: dict[str, object] | None = None) -> float:
    strength = 0.0
    cluster_radius = float((controls or {}).get("ice_resource_radius", 0.48))
    cluster_count = int((controls or {}).get("ice_resource_cluster_count", 4))
    for offset, base_angle in enumerate(_ice_cluster_angles(cluster_count)):
        target_radius = cluster_radius + 0.035 * ((offset % 3) - 1)
        radial_peak = 1.0 - _smoothstep(0.035, 0.135, abs(radial_alpha - target_radius))
        angular_peak = 1.0 - _smoothstep(0.035, 0.12, _angular_distance(angle, base_angle + seed * 0.0007))
        strength = max(strength, radial_peak * angular_peak)
    dominance = float((controls or {}).get("ice_resource_dominance", 0.62)) / 0.62
    return strength * 980.0 * dominance


def _ice_resource_cluster_strength(radial_alpha: float, angle: float, controls: dict[str, object] | None = None) -> float:
    cluster_radius = float((controls or {}).get("ice_resource_radius", 0.48))
    cluster_count = int((controls or {}).get("ice_resource_cluster_count", 4))
    radial_peak = 1.0 - _smoothstep(0.045, 0.16, abs(radial_alpha - cluster_radius))
    if radial_peak <= 0.0:
        return 0.0

    angular_peak = 0.0
    for base_angle in _ice_cluster_angles(cluster_count):
        angular_peak = max(angular_peak, 1.0 - _smoothstep(0.028, 0.12, _angular_distance(angle, base_angle)))
    return radial_peak * angular_peak


def _ice_resource_cluster_height(radial_alpha: float, angle: float, seed: int, controls: dict[str, object] | None = None) -> float:
    cluster = _ice_resource_cluster_strength(radial_alpha, angle, controls)
    if cluster <= 0.0:
        return 0.0

    dominance = float((controls or {}).get("ice_resource_dominance", 0.62)) / 0.62
    split_tip = 0.82 + 0.18 * math.sin(radial_alpha * 52.0 + angle * 7.0 + seed * 0.003)
    return cluster * 760.0 * split_tip * dominance


def _ice_crystal_forest_height(radial_alpha: float, angle: float, seed: int, controls: dict[str, object] | None = None) -> float:
    cluster_radius = float((controls or {}).get("ice_resource_radius", 0.48))
    cluster_count = int((controls or {}).get("ice_resource_cluster_count", 4))
    dominance = float((controls or {}).get("ice_resource_dominance", 0.62)) / 0.62
    detail_energy = max(0.0, float((controls or {}).get("detail_energy", 1.0)))
    height = 0.0

    satellite_offsets = (-0.20, -0.115, 0.0, 0.105, 0.185)
    for cluster_index, base_angle in enumerate(_ice_cluster_angles(cluster_count)):
        for shard_index, offset in enumerate(satellite_offsets):
            shard_angle = base_angle + offset + math.sin(seed * 0.001 + shard_index * 1.7) * 0.012
            target_radius = cluster_radius + 0.045 * math.sin(cluster_index * 1.9 + shard_index * 0.8)
            target_radius += 0.035 * math.sin(offset * 11.0)
            radial_peak = 1.0 - _smoothstep(0.018, 0.072, abs(radial_alpha - target_radius))
            if radial_peak <= 0.0:
                continue

            distance = _angular_distance(angle, shard_angle)
            needle = 1.0 - _smoothstep(0.003, 0.021, distance)
            blade = 1.0 - _smoothstep(0.014, 0.058, distance)
            serration = 0.88 + 0.12 * math.sin(radial_alpha * 74.0 + shard_index * 2.2 + seed * 0.004)
            gain = (1040.0 + detail_energy * 240.0 + (shard_index % 2) * 180.0) * dominance
            height = max(height, radial_peak * serration * (needle * gain + blade * gain * 0.34))

    return height


def _ice_crevasse_center_strength(radial_alpha: float, angle: float, seed: int, controls: dict[str, object] | None = None) -> float:
    crack_inner = float((controls or {}).get("ice_deep_crack_inner_radius", 0.42))
    crack_outer = float((controls or {}).get("ice_deep_crack_outer_radius", 0.92))
    radial_band = _smoothstep(crack_inner, crack_inner + 0.16, radial_alpha) * (1.0 - _smoothstep(crack_outer - 0.02, crack_outer + 0.06, radial_alpha))
    if radial_band <= 0.0:
        return 0.0

    strength = 0.0
    for base_angle in (0.78, 2.55, 4.75):
        distance = _angular_distance(angle, base_angle + math.sin(seed * 0.001 + base_angle) * 0.018)
        strength = max(strength, (1.0 - _smoothstep(0.026, 0.072, distance)) * radial_band)
    return strength


def _ice_crevasse_height(radial_alpha: float, angle: float, seed: int, controls: dict[str, object] | None = None) -> float:
    crack_inner = float((controls or {}).get("ice_deep_crack_inner_radius", 0.42))
    crack_outer = float((controls or {}).get("ice_deep_crack_outer_radius", 0.92))
    erosion_age = _clamp01(float((controls or {}).get("erosion_age", 0.45)))
    radial_band = _smoothstep(crack_inner, crack_inner + 0.16, radial_alpha) * (1.0 - _smoothstep(crack_outer - 0.02, crack_outer + 0.06, radial_alpha))
    if radial_band <= 0.0:
        return 0.0

    height = 0.0
    for base_angle in (0.78, 2.55, 4.75):
        distance = _angular_distance(angle, base_angle + math.sin(seed * 0.001 + base_angle) * 0.018)
        center = 1.0 - _smoothstep(0.020, 0.058, distance)
        shoulder = _smoothstep(0.050, 0.102, distance) * (1.0 - _smoothstep(0.132, 0.225, distance))
        center_cut = 430.0 + erosion_age * 760.0
        shoulder_lift = 170.0 + erosion_age * 380.0
        height += (-center_cut * center + shoulder_lift * shoulder) * radial_band
    return height


def _ice_crystal_wall_height(radial_alpha: float, angle: float, seed: int, controls: dict[str, object] | None = None) -> float:
    wall_radius = float((controls or {}).get("ice_wall_radius", 0.54))
    wall_dominance = float((controls or {}).get("ice_wall_dominance", 0.78)) / 0.78
    wall_count = int((controls or {}).get("ice_wall_count", 2))
    wall_radial = 1.0 - _smoothstep(max(0.035, wall_radius * 0.075), max(0.11, wall_radius * 0.28), abs(radial_alpha - wall_radius))
    if wall_radial <= 0.0:
        return 0.0

    height = 0.0
    wall_angles = (1.18, 4.18, 0.28, 5.25)
    for offset, base_angle in enumerate(wall_angles[: max(1, min(wall_count, len(wall_angles)))]):
        gain = (1880.0 if offset == 0 else 1660.0) * wall_dominance
        distance = _angular_distance(angle, base_angle + math.sin(seed * 0.002 + base_angle) * 0.025)
        blade = 1.0 - _smoothstep(0.026, 0.145, distance)
        needle = 1.0 - _smoothstep(0.004, 0.034, distance)
        crenellation = 0.78 + 0.22 * (0.5 + 0.5 * math.sin(angle * 32.0 + offset * 1.9 + seed * 0.001))
        split_tip = 0.74 + 0.26 * math.sin(radial_alpha * 54.0 + base_angle * 3.0)
        blade_height = blade * wall_radial * gain * split_tip * crenellation
        needle_height = needle * wall_radial * gain * (0.58 + 0.22 * wall_dominance)
        height = max(height, blade_height + needle_height)

    return max(height, _ice_resource_cluster_height(radial_alpha, angle, seed, controls))


def _ice_broken_plate_edge_strength(radial_alpha: float, angle: float, controls: dict[str, object] | None = None) -> float:
    plate_radius = float((controls or {}).get("ice_broken_plate_radius", 0.58))
    radial_band = 1.0 - _smoothstep(0.040, 0.16, abs(radial_alpha - plate_radius))
    if radial_band <= 0.0:
        return 0.0

    angular_band = 0.0
    for base_angle in (0.0, 1.62, 3.26, 4.86):
        angular_band = max(angular_band, 1.0 - _smoothstep(0.16, 0.34, _angular_distance(angle, base_angle)))
    return radial_band * angular_band


def _ice_broken_plate_height(radial_alpha: float, angle: float, seed: int, controls: dict[str, object] | None = None) -> float:
    plate_radius = float((controls or {}).get("ice_broken_plate_radius", 0.58))
    erosion_age = _clamp01(float((controls or {}).get("erosion_age", 0.45)))
    radial_band = 1.0 - _smoothstep(0.040, 0.16, abs(radial_alpha - plate_radius))
    if radial_band <= 0.0:
        return 0.0

    height = 0.0
    for offset, base_angle in enumerate((0.0, 1.62, 3.26, 4.86)):
        signed = math.atan2(math.sin(angle - base_angle), math.cos(angle - base_angle))
        angular_band = 1.0 - _smoothstep(0.16, 0.34, abs(signed))
        if angular_band <= 0.0:
            continue
        jitter = 0.92 + 0.08 * math.sin(seed * 0.002 + offset * 1.7)
        lip_gain = 340.0 + erosion_age * 260.0
        height += math.tanh(signed / 0.036) * angular_band * radial_band * lip_gain * jitter
    return height


def _icefall_cliff_height(radial_alpha: float, angle: float, seed: int, controls: dict[str, object] | None = None) -> float:
    erosion_age = _clamp01(float((controls or {}).get("erosion_age", 0.45)))
    height = 0.0
    for offset, base_angle in enumerate((1.55, 4.95)):
        distance = _angular_distance(angle, base_angle + math.sin(seed * 0.001 + offset) * 0.018)
        fall_sector = 1.0 - _smoothstep(0.09, 0.31, distance)
        if fall_sector <= 0.0:
            continue

        lip_band = _smoothstep(0.61, 0.72, radial_alpha) * (1.0 - _smoothstep(0.76, 0.84, radial_alpha))
        drop_band = _smoothstep(0.78, 0.90, radial_alpha) * (1.0 - _smoothstep(1.02, 1.08, radial_alpha))
        vertical_scars = 0.82 + 0.18 * (0.5 + 0.5 * math.sin(angle * 37.0 + radial_alpha * 19.0 + seed * 0.002))
        lip_lift = (260.0 + erosion_age * 280.0) * lip_band
        outer_cut = (720.0 + erosion_age * 620.0) * drop_band * vertical_scars
        height += (lip_lift - outer_cut) * fall_sector

    return height


def _forest_cave_strength(angle: float) -> float:
    strength = 0.0
    for base_angle in (0.35, 2.45, 4.65):
        strength = max(strength, 1.0 - _smoothstep(0.08, 0.31, _angular_distance(angle, base_angle)))
    return strength


def _forest_root_ridge_height(radial_alpha: float, angle: float, seed: int, controls: dict[str, object] | None = None) -> float:
    radial_band = _smoothstep(0.28, 0.42, radial_alpha) * (1.0 - _smoothstep(0.80, 0.96, radial_alpha))
    if radial_band <= 0.0:
        return 0.0

    root_dominance = float((controls or {}).get("forest_root_dominance", 0.70)) / 0.70
    height = 0.0
    for offset, base_angle in enumerate((0.35, 2.45, 4.65)):
        bend = math.sin(radial_alpha * 5.2 + offset * 1.7 + seed * 0.001) * 0.055
        distance = _angular_distance(angle, base_angle + bend)
        core = 1.0 - _smoothstep(0.038, 0.15, distance)
        shoulder = _smoothstep(0.12, 0.22, distance) * (1.0 - _smoothstep(0.22, 0.36, distance))
        grain = 0.82 + 0.18 * math.sin(radial_alpha * 38.0 + offset * 2.1)
        height = max(height, (core * radial_band * 620.0 * grain + shoulder * radial_band * 145.0) * root_dominance)
    return height


def _forest_stump_cave_mask_strength(radial_alpha: float, angle: float, seed: int, controls: dict[str, object] | None = None) -> float:
    cave_center = _control_point(controls, "forest_stump_cave_center", (-0.25, 0.25))
    cave_radius = max(0.08, float((controls or {}).get("forest_stump_cave_radius", 0.20)))
    cave_radial = math.hypot(cave_center[0], cave_center[1])
    radial_peak = 1.0 - _smoothstep(cave_radius * 0.27, cave_radius * 0.90, abs(radial_alpha - cave_radial))
    if radial_peak <= 0.0:
        return 0.0

    cave_angle = math.atan2(cave_center[1], cave_center[0]) % math.tau
    distance = _angular_distance(angle, cave_angle + math.sin(seed * 0.001) * 0.018)
    hollow = 1.0 - _smoothstep(cave_radius * 0.22, cave_radius * 0.65, distance)
    return radial_peak * hollow


def _forest_stump_cave_height(radial_alpha: float, angle: float, seed: int, controls: dict[str, object] | None = None) -> float:
    cave_center = _control_point(controls, "forest_stump_cave_center", (-0.25, 0.25))
    cave_radius = max(0.08, float((controls or {}).get("forest_stump_cave_radius", 0.20)))
    cave_dominance = float((controls or {}).get("forest_stump_cave_dominance", 0.72)) / 0.72
    erosion_age = _clamp01(float((controls or {}).get("erosion_age", 0.45)))
    cave_radial = math.hypot(cave_center[0], cave_center[1])
    radial_peak = 1.0 - _smoothstep(cave_radius * 0.27, cave_radius * 0.90, abs(radial_alpha - cave_radial))
    if radial_peak <= 0.0:
        return 0.0

    cave_angle = math.atan2(cave_center[1], cave_center[0]) % math.tau
    distance = _angular_distance(angle, cave_angle + math.sin(seed * 0.001) * 0.018)
    hollow = _forest_stump_cave_mask_strength(radial_alpha, angle, seed, controls)
    lip = _smoothstep(cave_radius * 0.60, cave_radius * 1.10, distance) * (1.0 - _smoothstep(cave_radius * 1.10, cave_radius * 1.90, distance))
    hollow_cut = 290.0 + erosion_age * 520.0
    lip_lift = 190.0 + erosion_age * 240.0
    return (-hollow_cut * hollow + radial_peak * lip_lift * lip) * cave_dominance


def _forest_mushroom_pocket_height(radial_alpha: float, angle: float, seed: int, controls: dict[str, object] | None = None) -> float:
    pocket_center = _control_point(controls, "forest_mushroom_center", (0.28, 0.34))
    pocket_radius = max(0.12, float((controls or {}).get("forest_mushroom_feature_radius", 0.255)))
    erosion_age = _clamp01(float((controls or {}).get("erosion_age", 0.45)))
    pocket_distance = _point_distance(radial_alpha, angle, pocket_center[0], pocket_center[1])
    bowl = 1.0 - _smoothstep(pocket_radius * 0.12, pocket_radius * 0.53, pocket_distance)
    rim = _smoothstep(pocket_radius * 0.31, pocket_radius * 0.57, pocket_distance) * (1.0 - _smoothstep(pocket_radius * 0.57, pocket_radius, pocket_distance))
    living_lobes = 0.86 + 0.14 * math.sin(angle * 6.0 + radial_alpha * 18.0 + seed * 0.004)
    bowl_cut = 290.0 + erosion_age * 470.0
    rim_lift = 520.0 + erosion_age * 330.0
    return -bowl_cut * bowl + rim_lift * rim * living_lobes


def _forest_vine_anchor_height(radial_alpha: float, angle: float, seed: int, controls: dict[str, object] | None = None) -> float:
    anchor_center = _control_point(controls, "forest_vine_anchor_center", (0.62, 0.18))
    anchor_radius = max(0.05, float((controls or {}).get("forest_vine_anchor_radius", 0.12)))
    anchor_dominance = float((controls or {}).get("forest_vine_anchor_dominance", 0.38)) / 0.38
    anchor_distance = _point_distance(radial_alpha, angle, anchor_center[0], anchor_center[1])
    ledge = 1.0 - _smoothstep(anchor_radius * 0.29, anchor_radius * 1.21, anchor_distance)
    bridge_root = _forest_vine_bridge_path_strength(radial_alpha, angle, controls)
    grain = 0.90 + 0.10 * math.sin(angle * 8.0 + seed * 0.003)
    return ledge * 360.0 * grain * anchor_dominance + bridge_root * 95.0


def _top_height(radial_alpha: float, angle: float, seed: int, radius_cm: float, biome: str, controls: dict[str, object] | None = None) -> float:
    controls = controls or {}
    preset = _preset(biome)
    x = math.cos(angle) * radial_alpha
    y = math.sin(angle) * radial_alpha
    detail_scale = preset["detail_scale"]
    broad_forms = _fbm(x * 2.35 * detail_scale, y * 2.35 * detail_scale, seed, 4) * 220.0 * preset["height_scale"]
    ridge_noise = (1.0 - abs(_fbm(x * 7.2 * detail_scale + 9.1, y * 7.2 * detail_scale - 3.7, seed + 101, 4))) * 230.0 * preset["ridge_scale"]
    chisel_noise = _fbm(x * 13.0 * detail_scale - 4.4, y * 13.0 * detail_scale + 6.8, seed + 211, 3) * 90.0 * preset["height_scale"]
    edge_drop = -520.0 * preset["edge_drop"] * _smoothstep(0.68, 1.0, radial_alpha)
    ravine_cut = -620.0 * preset["ravine_depth"] * _ravine_strength(radial_alpha, angle, seed, biome)
    center_plateau = _smoothstep(0.0, preset["plateau_radius"], radial_alpha)
    path_width = controls.get("path_width")
    path_flatten = _path_strength(radial_alpha, angle, biome, path_width, controls)

    height = (broad_forms + ridge_noise + chisel_noise + edge_drop + ravine_cut) * preset["vertical_exaggeration"]

    if biome == "fire":
        height += _volcano_height(
            radial_alpha,
            angle,
            seed,
            controls.get("volcano_radius", 0.42),
            int(controls.get("lava_channel_count", 3)),
        ) * controls.get("volcano_dominance_scale", 1.0)

    if biome == "ice":
        height += _ice_spire_height(radial_alpha, angle, seed, controls)

    height += _terrain_detail_height(radial_alpha, angle, seed, biome, controls)

    # Preserve a playable center and one readable path while keeping rougher edges.
    height *= 0.35 + 0.65 * center_plateau
    height = height * (1.0 - path_flatten * 0.72) - 12.0 * path_flatten

    if biome == "fire":
        signed_angle = abs(math.atan2(math.sin(angle), math.cos(angle)))
        effective_path_width = path_width if path_width is not None else preset["path_width"]
        approach_band = 1.0 - _smoothstep(effective_path_width * 0.25, effective_path_width * 0.72, signed_angle)
        approach_path = approach_band * _smoothstep(0.16, 0.25, radial_alpha)
        center_lane = (1.0 - _smoothstep(effective_path_width * 0.055, effective_path_width * 0.18, signed_angle)) * _smoothstep(0.16, 0.25, radial_alpha)
        route_shoulder = (
            _smoothstep(effective_path_width * 0.18, effective_path_width * 0.42, signed_angle)
            * (1.0 - _smoothstep(effective_path_width * 0.42, effective_path_width * 0.76, signed_angle))
            * _smoothstep(0.22, 0.92, radial_alpha)
        )
        path_ramp = 180.0 - 320.0 * _smoothstep(0.34, 0.92, radial_alpha)
        height = height * (1.0 - approach_path) + path_ramp * approach_path
        shoulder_texture = 0.55 + 0.45 * _smooth_fbm(x * 14.0 + 2.0, y * 14.0 - 5.0, seed + 761, 3)
        shoulder_chips = math.sin(angle * 46.0 + radial_alpha * 11.0 + seed * 0.01) * 95.0
        height += route_shoulder * (125.0 + shoulder_texture * 110.0 + shoulder_chips)
        height = height * (1.0 - center_lane * 0.22) + path_ramp * center_lane * 0.22

    if biome == "forest":
        canopy_outer = float(controls.get("forest_canopy_outer_radius", 0.44))
        canopy_core = 1.0 - _smoothstep(max(0.08, canopy_outer * 0.36), max(0.18, canopy_outer * 0.77), radial_alpha)
        canopy_target = 92.0 + 22.0 * math.sin(radial_alpha * 7.0 + seed * 0.002)
        canopy_target += _smooth_fbm(x * 3.6 + 0.5, y * 3.6 - 0.25, seed + 941, 2) * 14.0
        height = height * (1.0 - canopy_core * 0.90) + canopy_target * canopy_core * 0.90
        height += _forest_root_ridge_height(radial_alpha, angle, seed, controls)
        height += _forest_stump_cave_height(radial_alpha, angle, seed, controls)
        height += _forest_mushroom_pocket_height(radial_alpha, angle, seed, controls)
        height += _forest_vine_anchor_height(radial_alpha, angle, seed, controls)
        shelf_band = _smoothstep(0.42, 0.56, radial_alpha) * (1.0 - _smoothstep(0.88, 0.98, radial_alpha))
        shelf_height = round(height / 160.0) * 160.0
        height = height * (1.0 - shelf_band * preset["terrace_strength"]) + shelf_height * shelf_band * preset["terrace_strength"]

    if biome == "ice":
        cap_strength = (1.0 - _smoothstep(0.18, 0.76, radial_alpha)) * preset["ice_cap_flatten"]
        spire_protection = min(1.0, _ice_spire_height(radial_alpha, angle, seed, controls) / 900.0)
        height *= 1.0 - cap_strength * (1.0 - spire_protection)
        height += _ice_crevasse_height(radial_alpha, angle, seed, controls)
        height += _ice_crystal_wall_height(radial_alpha, angle, seed, controls)
        height += _ice_crystal_forest_height(radial_alpha, angle, seed, controls)
        height += _ice_broken_plate_height(radial_alpha, angle, seed, controls)
        height += _icefall_cliff_height(radial_alpha, angle, seed, controls)

    return height


def _crater_loop_strength(radial_alpha: float, angle: float, controls: dict[str, object]) -> float:
    loop_coverage = controls.get("crater_loop_coverage", 0.0)
    if loop_coverage <= 0.0:
        return 0.0

    volcano_radius = controls.get("volcano_radius", 0.42)
    ring_band = 1.0 - _smoothstep(0.035, 0.12, abs(radial_alpha - volcano_radius))
    signed_angle = abs(math.atan2(math.sin(angle), math.cos(angle)))
    angular_coverage = 1.0 - _smoothstep(loop_coverage * math.pi, loop_coverage * math.pi + 0.12, signed_angle)
    return ring_band * angular_coverage


def _layout_controls(layout, quality_profile: dict[str, float]) -> dict[str, object]:
    controls: dict[str, object] = {}
    process = getattr(layout, "process", {}) or {}
    detail_energy = min(1.4, max(0.0, float(process.get("detail_energy", 1.0))))
    erosion_age = _clamp01(float(process.get("erosion_age", 0.45)))
    deposition_weight = _clamp01(float(process.get("deposition_weight", 0.55)))
    controls["detail_energy"] = detail_energy
    controls["erosion_age"] = erosion_age
    controls["deposition_weight"] = deposition_weight
    quality_detail = float(quality_profile["detail_intensity"])
    controls["terrain_relaxation_intensity"] = quality_detail * float(quality_profile.get("relaxation_multiplier", 1.0))
    controls["terrain_process_intensity"] = quality_detail * float(quality_profile.get("process_multiplier", 1.0))
    controls["terrain_settle_intensity"] = quality_detail * float(quality_profile.get("settle_multiplier", 1.0))
    controls["terrain_detail_intensity"] = (
        quality_detail
        * detail_energy
        * float(quality_profile.get("surface_detail_multiplier", 1.0))
    )
    if layout.biome == "fire":
        volcano = next((landmark for landmark in layout.landmarks if landmark.id == "central_volcano"), None)
        main_path = next((path for path in layout.paths if path.id == "main_approach"), None)
        if volcano is not None:
            controls["volcano_dominance_scale"] = volcano.dominance / 0.85
            controls["volcano_radius"] = volcano.radius
        lava_channels = next((landmark for landmark in layout.landmarks if landmark.id == "lava_channels"), None)
        if lava_channels is not None:
            controls["lava_channel_count"] = float(lava_channels.count)
        if main_path is not None:
            controls["path_width"] = main_path.width * 4.25
        crater_loop = next((path for path in layout.paths if path.id == "partial_crater_loop"), None)
        if crater_loop is not None:
            controls["crater_loop_coverage"] = crater_loop.coverage
    if layout.biome == "forest":
        root_arch = next((landmark for landmark in layout.landmarks if landmark.id == "root_arch"), None)
        stump_cave = next((landmark for landmark in layout.landmarks if landmark.id == "tree_stump_cave"), None)
        vine_anchor = next((landmark for landmark in layout.landmarks if landmark.id == "vine_bridge_anchor"), None)
        main_path = next((path for path in layout.paths if path.id == "forest_main_path"), None)
        vine_bridge = next((path for path in layout.paths if path.id == "vine_bridge"), None)
        mushroom = next((zone for zone in layout.zones if zone.id == "mushroom_pocket"), None)
        canopy = next((zone for zone in layout.zones if zone.id == "canopy_platform"), None)
        if root_arch is not None:
            controls["forest_root_center"] = root_arch.center
            controls["forest_root_radius"] = root_arch.radius
            controls["forest_root_dominance"] = root_arch.dominance
        if stump_cave is not None:
            controls["forest_stump_cave_center"] = stump_cave.center
            controls["forest_stump_cave_radius"] = stump_cave.radius
            controls["forest_stump_cave_dominance"] = stump_cave.dominance
        if vine_anchor is not None:
            controls["forest_vine_anchor_center"] = vine_anchor.center
            controls["forest_vine_anchor_radius"] = vine_anchor.radius
            controls["forest_vine_anchor_dominance"] = vine_anchor.dominance
        if main_path is not None:
            controls["path_width"] = main_path.width * 7.14
        if vine_bridge is not None and len(vine_bridge.points) >= 2:
            controls["forest_vine_bridge_points"] = vine_bridge.points
            controls["forest_vine_bridge_width"] = vine_bridge.width
        if mushroom is not None:
            inner, outer = mushroom.radius_range
            controls["forest_mushroom_center"] = mushroom.center
            controls["forest_mushroom_inner_radius"] = inner
            controls["forest_mushroom_outer_radius"] = outer
            controls["forest_mushroom_feature_radius"] = max(0.12, (outer - inner) * 1.06)
        if canopy is not None:
            controls["forest_canopy_inner_radius"] = canopy.radius_range[0]
            controls["forest_canopy_outer_radius"] = canopy.radius_range[1]
    if layout.biome == "ice":
        crystal_wall = next((landmark for landmark in layout.landmarks if landmark.id == "primary_crystal_wall"), None)
        resource_clusters = next((landmark for landmark in layout.landmarks if landmark.id == "secondary_spire_clusters"), None)
        central_shelf = next((path for path in layout.paths if path.id == "central_shelf"), None)
        broken_ring = next((path for path in layout.paths if path.id == "broken_ice_ring"), None)
        deep_cracks = next((zone for zone in layout.zones if zone.id == "deep_cracks"), None)
        if crystal_wall is not None:
            controls["ice_wall_radius"] = crystal_wall.radius
            controls["ice_wall_dominance"] = crystal_wall.dominance
            controls["ice_wall_count"] = float(crystal_wall.count)
        if resource_clusters is not None:
            controls["ice_resource_radius"] = resource_clusters.radius
            controls["ice_resource_dominance"] = resource_clusters.dominance
            controls["ice_resource_cluster_count"] = float(resource_clusters.count)
        if central_shelf is not None:
            controls["path_width"] = central_shelf.width * 5.44
        if broken_ring is not None and broken_ring.points:
            controls["ice_broken_plate_radius"] = math.hypot(broken_ring.points[0][0], broken_ring.points[0][1]) * 0.94
            controls["ice_broken_plate_width"] = broken_ring.width
        if deep_cracks is not None:
            controls["ice_deep_crack_inner_radius"] = deep_cracks.radius_range[0]
            controls["ice_deep_crack_outer_radius"] = deep_cracks.radius_range[1]
    return controls


def _derive_slope_mask(heights: list[list[float]], radial_segments: int, rings: int) -> list[list[float]]:
    slope_mask: list[list[float]] = []
    for ring in range(rings + 1):
        row: list[float] = []
        for index in range(radial_segments):
            height = heights[ring][index]
            inner = heights[max(0, ring - 1)][index]
            outer = heights[min(rings, ring + 1)][index]
            previous_height = heights[ring][index - 1]
            next_height = heights[ring][(index + 1) % radial_segments]
            radial_delta = max(abs(height - inner), abs(height - outer))
            angular_delta = max(abs(height - previous_height), abs(height - next_height))
            row.append(_smoothstep(90.0, 420.0, max(radial_delta * 0.72, angular_delta)))
        slope_mask.append(row)
    return slope_mask


def _normalize_mask(mask: list[list[float]]) -> list[list[float]]:
    max_value = max((max(row) for row in mask if row), default=0.0)
    if max_value <= 0.0001:
        return [[0.0 for _ in row] for row in mask]
    return [[_clamp01(value / max_value) for value in row] for row in mask]


def _combine_walkable_route_masks(
    path_mask: list[list[float]],
    crater_loop_mask: list[list[float]],
) -> list[list[float]]:
    return [
        [
            max(path_mask[ring][index], crater_loop_mask[ring][index] * 0.88)
            for index in range(len(path_mask[ring]))
        ]
        for ring in range(len(path_mask))
    ]


def _capture_fire_lava_low_potential_corridors(
    heights: list[list[float]],
    lava_mask: list[list[float]],
    path_mask: list[list[float]],
    crater_loop_mask: list[list[float]],
    radial_segments: int,
    rings: int,
    controls: dict[str, object],
) -> list[list[float]]:
    lava_count = int(controls.get("lava_channel_count", 3))
    path_width = float(controls.get("path_width", _preset("fire")["path_width"]))
    erosion_age = _clamp01(float(controls.get("erosion_age", 0.45)))
    if lava_count <= 0 or radial_segments < 24 or rings < 10:
        return lava_mask

    captured = [list(row) for row in lava_mask]
    search_radius = max(2, round((0.24 / math.tau) * radial_segments))
    start_ring = max(2, round(rings * 0.58))
    end_ring = min(rings - 1, round(rings * 0.90))
    if end_ring <= start_ring:
        return captured

    for channel_index, channel_angle in enumerate(_lava_channel_angles(lava_count)):
        signed_channel_angle = abs(math.atan2(math.sin(channel_angle), math.cos(channel_angle)))
        if signed_channel_angle < path_width * 1.25:
            continue

        center_index = round((channel_angle % math.tau) / math.tau * radial_segments) % radial_segments
        previous_offset = 0
        for ring in range(start_ring, end_ring + 1):
            radial_alpha = ring / rings if rings else 0.0
            branch_band = _smoothstep(0.56, 0.66, radial_alpha) * (1.0 - _smoothstep(0.88, 0.94, radial_alpha))
            if branch_band <= 0.0:
                continue

            candidates = []
            for offset in range(-search_radius, search_radius + 1):
                index = (center_index + offset) % radial_segments
                semantic_guard = max(path_mask[ring][index], crater_loop_mask[ring][index] * 0.92)
                if semantic_guard > 0.25:
                    continue

                height = heights[ring][index]
                inner_height = heights[ring - 1][index]
                outer_height = heights[min(rings, ring + 1)][index]
                left_height = heights[ring][(index - 1) % radial_segments]
                right_height = heights[ring][(index + 1) % radial_segments]
                local_span = max(
                    abs(height - inner_height),
                    abs(height - outer_height),
                    abs(height - left_height),
                    abs(height - right_height),
                    1.0,
                )
                low_potential = (
                    max(0.0, inner_height - height) * 0.42
                    + max(0.0, left_height - height) * 0.22
                    + max(0.0, right_height - height) * 0.22
                    + max(0.0, height - outer_height) * 0.14
                ) / local_span
                continuity = 1.0 - min(1.0, abs(offset - previous_offset) / max(1.0, search_radius * 0.72))
                side_bias = 0.12 * math.sin(radial_alpha * 18.0 + channel_index * 1.37 + offset * 0.19)
                existing = lava_mask[ring][index] * 0.06
                score = low_potential * 0.86 + continuity * 0.12 + existing + side_bias
                candidates.append((score, offset, low_potential, semantic_guard))

            if not candidates:
                continue

            _score, best_offset, low_potential, semantic_guard = max(candidates, key=lambda item: item[0])
            previous_offset = round(previous_offset * 0.25 + best_offset * 0.75)
            capture_strength = branch_band * (0.58 + erosion_age * 0.22 + min(0.22, low_potential * 0.20)) * (1.0 - semantic_guard)
            if capture_strength <= 0.0:
                continue

            branch_width = 2 + round(branch_band * 3.0)
            if branch_band > 0.28:
                for offset in range(-search_radius, search_radius + 1):
                    if abs(offset - previous_offset) <= branch_width + 1:
                        continue
                    index = (center_index + offset) % radial_segments
                    local_guard = max(path_mask[ring][index], crater_loop_mask[ring][index] * 0.92)
                    if local_guard > 0.30:
                        continue
                    captured[ring][index] = min(captured[ring][index], 0.50 + branch_band * 0.12)
            for spread in range(-branch_width, branch_width + 1):
                index = (center_index + previous_offset + spread) % radial_segments
                spread_falloff = 1.0 - _smoothstep(0.35, branch_width + 0.85, abs(spread))
                if spread_falloff <= 0.0:
                    continue
                local_guard = max(path_mask[ring][index], crater_loop_mask[ring][index] * 0.92)
                if local_guard > 0.30:
                    continue
                captured[ring][index] = max(captured[ring][index], capture_strength * spread_falloff)

    return captured


def _derive_flow_accumulation_mask(
    heights: list[list[float]],
    path_mask: list[list[float]],
    lava_mask: list[list[float]],
    ravine_mask: list[list[float]],
    radial_segments: int,
    rings: int,
    erosion_age: float = 0.45,
) -> list[list[float]]:
    accumulated: list[list[float]] = []
    age_scale = 0.72 + _clamp01(erosion_age) * 0.58
    for ring in range(rings + 1):
        radial_alpha = ring / rings if rings else 0.0
        outward = 0.18 + _smoothstep(0.12, 0.96, radial_alpha) * 0.82
        row: list[float] = []
        for index in range(radial_segments):
            channel_bias = lava_mask[ring][index] * 0.86 + ravine_mask[ring][index] * 0.36
            rainfall = (0.035 + channel_bias) * outward * age_scale
            rainfall *= 1.0 - path_mask[ring][index] * 0.5
            if ring == 0:
                incoming = 0.0
            else:
                inner = accumulated[ring - 1]
                height = heights[ring][index]
                downhill_bias = _smoothstep(-80.0, 260.0, heights[ring - 1][index] - height)
                incoming = max(
                    inner[index],
                    inner[index - 1] * 0.82,
                    inner[(index + 1) % radial_segments] * 0.82,
                ) * (0.46 + downhill_bias * 0.34)
            row.append(rainfall + incoming)
        accumulated.append(row)

    normalized = _normalize_mask(accumulated)
    flow_mask: list[list[float]] = []
    for ring in range(rings + 1):
        radial_alpha = ring / rings if rings else 0.0
        outward = _smoothstep(0.24, 0.98, radial_alpha)
        row = []
        for index in range(radial_segments):
            channel = max(lava_mask[ring][index], ravine_mask[ring][index] * 0.46)
            row.append(_clamp01(max(normalized[ring][index] * 0.82, channel * outward) * (1.0 - path_mask[ring][index] * 0.44)))
        flow_mask.append(row)
    return flow_mask


def _derive_curvature_mask(heights: list[list[float]], radial_segments: int, rings: int) -> list[list[float]]:
    curvature_mask: list[list[float]] = []
    for ring in range(rings + 1):
        row: list[float] = []
        for index in range(radial_segments):
            height = heights[ring][index]
            neighbors = [
                heights[max(0, ring - 1)][index],
                heights[min(rings, ring + 1)][index],
                heights[ring][index - 1],
                heights[ring][(index + 1) % radial_segments],
            ]
            curvature = abs(sum(neighbors) / len(neighbors) - height)
            row.append(_smoothstep(35.0, 520.0, curvature))
        curvature_mask.append(row)
    return curvature_mask


def _derive_lava_flow_mask(
    lava_mask: list[list[float]],
    ravine_mask: list[list[float]],
    path_mask: list[list[float]],
    radial_segments: int,
    rings: int,
    erosion_age: float = 0.45,
    flow_accumulation_mask: list[list[float]] | None = None,
) -> list[list[float]]:
    lava_flow_mask: list[list[float]] = []
    erosion_scale = 0.74 + _clamp01(erosion_age) * 0.72
    for ring in range(rings + 1):
        radial_alpha = ring / rings if rings else 0.0
        outward = _smoothstep(0.26, 0.94, radial_alpha)
        row: list[float] = []
        for index in range(radial_segments):
            flow = 0.0 if flow_accumulation_mask is None else flow_accumulation_mask[ring][index] * 0.52
            channel = max(lava_mask[ring][index], ravine_mask[ring][index] * 0.48, flow)
            row.append(_clamp01(channel * outward * erosion_scale * (1.0 - path_mask[ring][index] * 0.48)))
        lava_flow_mask.append(row)
    return lava_flow_mask


def _derive_talus_mask(
    slope_mask: list[list[float]],
    cliff_mask: list[list[float]],
    path_mask: list[list[float]],
    lava_mask: list[list[float]],
    volcano_mask: list[list[float]],
    radial_segments: int,
    rings: int,
    deposition_weight: float = 0.55,
    curvature_mask: list[list[float]] | None = None,
) -> list[list[float]]:
    talus_mask: list[list[float]] = []
    deposition_scale = 0.58 + _clamp01(deposition_weight) * 0.76
    for ring in range(rings + 1):
        radial_alpha = ring / rings if rings else 0.0
        exposed_band = _smoothstep(0.28, 0.92, radial_alpha)
        row: list[float] = []
        for index in range(radial_segments):
            raw = (slope_mask[ring][index] * 0.72 + cliff_mask[ring][index] * 0.38) * exposed_band
            if curvature_mask is not None:
                raw += curvature_mask[ring][index] * 0.18 * exposed_band
            raw *= 1.0 - path_mask[ring][index] * 0.82
            raw *= 1.0 - lava_mask[ring][index] * 0.34
            raw *= 1.0 - volcano_mask[ring][index] * 0.52
            row.append(_clamp01(raw * deposition_scale))
        talus_mask.append(row)
    return talus_mask


def _derive_strata_mask(
    heights: list[list[float]],
    slope_mask: list[list[float]],
    curvature_mask: list[list[float]],
    cliff_mask: list[list[float]],
    volcano_mask: list[list[float]],
    path_mask: list[list[float]],
    lava_mask: list[list[float]],
    radial_segments: int,
    rings: int,
) -> list[list[float]]:
    strata_mask: list[list[float]] = []
    for ring in range(rings + 1):
        radial_alpha = ring / rings if rings else 0.0
        row: list[float] = []
        for index in range(radial_segments):
            angular_alpha = index / radial_segments if radial_segments else 0.0
            layer_signal = 0.5 + 0.5 * math.sin(radial_alpha * 54.0 + angular_alpha * math.tau * 1.7 + heights[ring][index] * 0.003)
            exposure = (
                slope_mask[ring][index] * 0.42
                + cliff_mask[ring][index] * 0.44
                + volcano_mask[ring][index] * 0.48
                + curvature_mask[ring][index] * 0.32
            )
            exposure *= 1.0 - path_mask[ring][index] * 0.82
            exposure *= 1.0 - lava_mask[ring][index] * 0.28
            row.append(_clamp01(_smoothstep(0.12, 0.62, exposure) * (0.62 + layer_signal * 0.38)))
        strata_mask.append(row)
    return strata_mask


def _apply_process_height_pass(
    heights: list[list[float]],
    talus_mask: list[list[float]],
    lava_flow_mask: list[list[float]],
    flow_accumulation_mask: list[list[float]],
    curvature_mask: list[list[float]],
    path_mask: list[list[float]],
    volcano_mask: list[list[float]],
    crater_loop_mask: list[list[float]],
    process_intensity: float,
    erosion_age: float = 0.45,
    deposition_weight: float = 0.55,
    biome: str = "fire",
) -> list[list[float]]:
    if process_intensity <= 0.0:
        return heights

    erosion01 = _clamp01(erosion_age)
    deposition01 = _clamp01(deposition_weight)
    if biome == "ice":
        erosion_scale = 0.48 + erosion01 * 1.92
        deposition_scale = 0.28 + deposition01 * 0.86
        incision_gain = 1320.0
        deposition_gain = 560.0
        delta_floor = -900.0
        delta_ceiling = 320.0
    elif biome == "forest":
        erosion_scale = 0.42 + erosion01 * 1.58
        deposition_scale = 0.42 + deposition01 * 1.08
        incision_gain = 980.0
        deposition_gain = 680.0
        delta_floor = -720.0
        delta_ceiling = 420.0
    else:
        erosion_scale = 0.35 + erosion01 * 1.35
        deposition_scale = 0.35 + deposition01 * 1.25
        incision_gain = 1060.0
        deposition_gain = 740.0
        delta_floor = -620.0
        delta_ceiling = 390.0
    processed: list[list[float]] = []
    for ring, row in enumerate(heights):
        processed_row: list[float] = []
        for index, height in enumerate(row):
            playable_protection = _clamp01(path_mask[ring][index] * 0.72 + crater_loop_mask[ring][index] * 0.38)
            deposition_focus = 0.74 + curvature_mask[ring][index] * 0.44
            if biome == "ice":
                flow_focus = max(
                    lava_flow_mask[ring][index] * 0.92,
                    flow_accumulation_mask[ring][index] * 0.60,
                    curvature_mask[ring][index] * 0.22,
                )
            elif biome == "forest":
                flow_focus = max(
                    lava_flow_mask[ring][index] * 0.62,
                    flow_accumulation_mask[ring][index] * 0.42,
                    curvature_mask[ring][index] * 0.12,
                )
            else:
                flow_focus = max(lava_flow_mask[ring][index] * 0.72, flow_accumulation_mask[ring][index] * 0.48)
            deposition = talus_mask[ring][index] * deposition_gain * process_intensity * deposition_scale * deposition_focus
            incision = flow_focus * incision_gain * process_intensity * erosion_scale * (1.0 - playable_protection)
            incision *= 1.0 - volcano_mask[ring][index] * 0.18
            delta = max(delta_floor, min(delta_ceiling, deposition - incision))
            processed_row.append(height + delta)
        processed.append(processed_row)
    return processed


def _relax_terrain_field_heights(
    heights: list[list[float]],
    path_mask: list[list[float]],
    lava_mask: list[list[float]],
    volcano_mask: list[list[float]],
    crater_loop_mask: list[list[float]],
    cliff_mask: list[list[float]],
    radial_segments: int,
    rings: int,
    biome: str,
    controls: dict[str, object],
) -> list[list[float]]:
    detail_intensity = float(controls.get("terrain_relaxation_intensity", controls.get("terrain_detail_intensity", 0.0)))
    if detail_intensity <= 0.0:
        return heights

    passes = 1 if detail_intensity < 0.3 else 2
    if detail_intensity > 0.6:
        passes = 3

    smoothed = [list(row) for row in heights]
    volcano_radius = float(controls.get("volcano_radius", 0.42))
    for _ in range(passes):
        next_heights = [list(row) for row in smoothed]
        for ring in range(rings + 1):
            radial_alpha = ring / rings if rings else 0.0
            arena_mask = 1.0 - _smoothstep(0.10, 0.34, radial_alpha)
            crater_interior = 0.0
            if biome == "fire":
                crater_interior = 1.0 - _smoothstep(volcano_radius * 0.34, volcano_radius * 0.72, radial_alpha)
            for index in range(radial_segments):
                height = smoothed[ring][index]
                previous_height = smoothed[ring][index - 1]
                next_height = smoothed[ring][(index + 1) % radial_segments]
                inner_height = smoothed[max(0, ring - 1)][index]
                outer_height = smoothed[min(rings, ring + 1)][index]
                angular_target = height * 0.5 + previous_height * 0.25 + next_height * 0.25
                radial_target = height * 0.5 + inner_height * 0.25 + outer_height * 0.25
                full_target = height * 0.34 + previous_height * 0.16 + next_height * 0.16 + inner_height * 0.17 + outer_height * 0.17

                lava = lava_mask[ring][index]
                lava_shoulder = _clamp01(_smoothstep(0.08, 0.44, lava) - _smoothstep(0.56, 0.94, lava))
                rim = volcano_mask[ring][index]
                cliff = cliff_mask[ring][index]
                playable = max(path_mask[ring][index], crater_loop_mask[ring][index])

                strength = min(0.16, detail_intensity * 0.18)
                strength += playable * 0.22 + arena_mask * 0.14 + crater_interior * 0.16
                strength += rim * 0.12 + lava_shoulder * 0.16 + cliff * 0.05
                strength *= 1.0 - lava * 0.58
                strength = _clamp01(min(strength, 0.42))

                target = full_target
                if rim > 0.2 or cliff > 0.5:
                    target = angular_target * 0.82 + radial_target * 0.18
                if lava > 0.55:
                    target = height * 0.72 + angular_target * 0.28
                if playable > 0.45 or arena_mask > 0.5 or crater_interior > 0.5:
                    target = full_target

                next_heights[ring][index] = height * (1.0 - strength) + target * strength
        smoothed = next_heights
    return smoothed


def _settle_high_frequency_terrain(
    heights: list[list[float]],
    path_mask: list[list[float]],
    lava_mask: list[list[float]],
    volcano_mask: list[list[float]],
    crater_loop_mask: list[list[float]],
    cliff_mask: list[list[float]],
    curvature_mask: list[list[float]],
    radial_segments: int,
    rings: int,
    controls: dict[str, object],
) -> list[list[float]]:
    settle_intensity = float(controls.get("terrain_settle_intensity", controls.get("terrain_relaxation_intensity", 0.0)))
    if settle_intensity <= 0.0:
        return heights

    passes = 1 if settle_intensity < 0.4 else 2
    if settle_intensity > 0.8:
        passes = 3

    settled = [list(row) for row in heights]
    for _ in range(passes):
        next_heights = [list(row) for row in settled]
        for ring in range(rings + 1):
            radial_alpha = ring / rings if rings else 0.0
            broad_top_band = _smoothstep(0.18, 0.82, radial_alpha) * (1.0 - _smoothstep(0.94, 1.0, radial_alpha))
            for index in range(radial_segments):
                height = settled[ring][index]
                previous_height = settled[ring][index - 1]
                next_height = settled[ring][(index + 1) % radial_segments]
                inner_height = settled[max(0, ring - 1)][index]
                outer_height = settled[min(rings, ring + 1)][index]

                angular_delta = max(abs(height - previous_height), abs(height - next_height))
                radial_delta = max(abs(height - inner_height), abs(height - outer_height))
                high_frequency = _smoothstep(90.0, 420.0, angular_delta * 0.82 + max(0.0, angular_delta - radial_delta) * 0.36)

                lava = lava_mask[ring][index]
                lava_shoulder = _clamp01(_smoothstep(0.08, 0.44, lava) - _smoothstep(0.58, 0.94, lava))
                rim = volcano_mask[ring][index]
                playable = max(path_mask[ring][index], crater_loop_mask[ring][index])
                cliff = cliff_mask[ring][index]
                curvature = curvature_mask[ring][index]

                angular_target = height * 0.46 + previous_height * 0.27 + next_height * 0.27
                full_target = (
                    height * 0.42
                    + previous_height * 0.145
                    + next_height * 0.145
                    + inner_height * 0.145
                    + outer_height * 0.145
                )
                target = full_target if playable > 0.35 else angular_target
                if rim > 0.18 or cliff > 0.45:
                    target = angular_target
                if lava > 0.55:
                    target = height * 0.82 + angular_target * 0.18

                strength = min(0.34, settle_intensity * 0.22) * high_frequency
                strength += playable * 0.16 + lava_shoulder * 0.10 + rim * 0.07
                strength += broad_top_band * curvature * 0.12
                strength *= 1.0 - lava * 0.72
                strength = _clamp01(min(strength, 0.42))

                next_heights[ring][index] = height * (1.0 - strength) + target * strength
        settled = next_heights
    return settled


def _settle_walkable_route_heights(
    heights: list[list[float]],
    path_mask: list[list[float]],
    crater_loop_mask: list[list[float]],
    lava_mask: list[list[float]],
    radial_segments: int,
    rings: int,
    controls: dict[str, object],
) -> list[list[float]]:
    settle_intensity = float(controls.get("terrain_settle_intensity", controls.get("terrain_relaxation_intensity", 0.0)))
    if settle_intensity <= 0.0:
        return heights

    settled = [list(row) for row in heights]
    passes = 1 if settle_intensity < 0.55 else 2
    for _ in range(passes):
        next_heights = [list(row) for row in settled]
        for ring in range(rings + 1):
            for index in range(radial_segments):
                route = max(
                    _smoothstep(0.72, 0.96, path_mask[ring][index]),
                    _smoothstep(0.42, 0.92, crater_loop_mask[ring][index]) * 0.88,
                )
                if route <= 0.04:
                    continue

                height = settled[ring][index]
                previous_height = settled[ring][index - 1]
                next_height = settled[ring][(index + 1) % radial_segments]
                inner_height = settled[max(0, ring - 1)][index]
                outer_height = settled[min(rings, ring + 1)][index]

                angular_target = height * 0.42 + previous_height * 0.29 + next_height * 0.29
                radial_target = height * 0.46 + inner_height * 0.27 + outer_height * 0.27
                full_target = angular_target * 0.54 + radial_target * 0.46
                target = full_target if path_mask[ring][index] >= crater_loop_mask[ring][index] else angular_target * 0.72 + radial_target * 0.28

                lava = lava_mask[ring][index]
                strength = min(0.44, settle_intensity * 0.24) * route
                strength *= 1.0 - lava * 0.62
                next_heights[ring][index] = height * (1.0 - strength) + target * strength
        settled = next_heights
    return settled


def _apply_route_cross_section_heights(
    heights: list[list[float]],
    path_mask: list[list[float]],
    crater_loop_mask: list[list[float]],
    lava_mask: list[list[float]],
    radial_segments: int,
    rings: int,
    controls: dict[str, object],
) -> list[list[float]]:
    settle_intensity = float(controls.get("terrain_settle_intensity", controls.get("terrain_relaxation_intensity", 0.0)))
    if settle_intensity <= 0.0:
        return heights

    shaped = [list(row) for row in heights]
    for ring in range(rings + 1):
        radial_alpha = ring / rings if rings else 0.0
        route_band = _smoothstep(0.18, 0.94, radial_alpha)
        for index in range(radial_segments):
            route = max(path_mask[ring][index], crater_loop_mask[ring][index] * 0.88)
            if route <= 0.02:
                continue

            height = shaped[ring][index]
            previous_height = shaped[ring][index - 1]
            next_height = shaped[ring][(index + 1) % radial_segments]
            inner_height = shaped[max(0, ring - 1)][index]
            outer_height = shaped[min(rings, ring + 1)][index]
            local_target = (
                height * 0.36
                + previous_height * 0.16
                + next_height * 0.16
                + inner_height * 0.16
                + outer_height * 0.16
            )

            center_lane = _smoothstep(0.78, 0.96, path_mask[ring][index])
            shoulder = (
                _smoothstep(0.30, 0.58, route)
                * (1.0 - _smoothstep(0.68, 0.84, path_mask[ring][index]))
                * route_band
            )
            lava_guard = 1.0 - lava_mask[ring][index] * 0.64
            chip = math.sin(index * 1.73 + ring * 0.41) * 150.0 + math.sin(index * 0.67 - ring * 0.23) * 70.0
            shoulder_lift = shoulder * lava_guard * (130.0 + chip)

            flattened = height * (1.0 - center_lane * 0.34) + local_target * center_lane * 0.34
            shaped[ring][index] = flattened + shoulder_lift
    return shaped


def _settle_forest_canopy_platform_heights(
    heights: list[list[float]],
    radial_segments: int,
    rings: int,
    controls: dict[str, object] | None = None,
) -> list[list[float]]:
    settled = [list(row) for row in heights]
    canopy_outer = float((controls or {}).get("forest_canopy_outer_radius", 0.44))
    for ring in range(rings + 1):
        radial_alpha = ring / rings if rings else 0.0
        canopy_core = 1.0 - _smoothstep(max(0.08, canopy_outer * 0.36), max(0.18, canopy_outer * 0.77), radial_alpha)
        if canopy_core <= 0.0:
            continue

        ring_average = sum(settled[ring]) / radial_segments
        blend = canopy_core * 0.64
        for index in range(radial_segments):
            settled[ring][index] = settled[ring][index] * (1.0 - blend) + ring_average * blend
    return settled


def _apply_fire_crater_collapse_terraces(
    heights: list[list[float]],
    path_mask: list[list[float]],
    crater_loop_mask: list[list[float]],
    lava_mask: list[list[float]],
    radial_segments: int,
    rings: int,
    controls: dict[str, object],
) -> list[list[float]]:
    process_intensity = float(controls.get("terrain_process_intensity", controls.get("terrain_detail_intensity", 0.0)))
    if process_intensity <= 0.0 or rings < 20:
        return heights

    volcano_radius = float(controls.get("volcano_radius", 0.42))
    inner_ring = max(1, round(rings * max(0.18, volcano_radius * 0.52)))
    outer_ring = min(rings - 1, round(rings * min(0.60, volcano_radius * 1.34)))
    if outer_ring <= inner_ring + 2:
        return heights

    terraced = [list(row) for row in heights]
    radial_span = max(1, outer_ring - inner_ring)
    limit_base = 400.0 + (1.0 - min(1.0, process_intensity)) * 120.0

    for index in range(radial_segments):
        angle = (index / radial_segments) * math.tau
        collapse_notch = 1.0 - _smoothstep(0.16, 0.54, _angular_distance(angle, 5.58))
        high_buttress = 1.0 - _smoothstep(0.18, 0.62, _angular_distance(angle, 3.78))
        sector_limit = limit_base + high_buttress * 65.0 - collapse_notch * 95.0

        for ring in range(inner_ring + 1, outer_ring + 1):
            radial_t = (ring - inner_ring) / radial_span
            wall_band = _smoothstep(0.0, 0.22, radial_t) * (1.0 - _smoothstep(0.94, 1.0, radial_t))
            route = max(path_mask[ring][index], crater_loop_mask[ring][index])
            lava = lava_mask[ring][index]
            local_limit = sector_limit + route * 150.0 + lava * 80.0
            previous = terraced[ring - 1][index]
            delta = terraced[ring][index] - previous
            if abs(delta) > local_limit and wall_band > 0.0:
                terraced[ring][index] = previous + math.copysign(local_limit, delta)

        for ring in range(outer_ring - 1, inner_ring - 1, -1):
            radial_t = (ring - inner_ring) / radial_span
            wall_band = _smoothstep(0.0, 0.22, radial_t) * (1.0 - _smoothstep(0.94, 1.0, radial_t))
            route = max(path_mask[ring][index], crater_loop_mask[ring][index])
            lava = lava_mask[ring][index]
            local_limit = sector_limit + route * 150.0 + lava * 80.0
            outer = terraced[ring + 1][index]
            delta = terraced[ring][index] - outer
            if abs(delta) > local_limit and wall_band > 0.0:
                terraced[ring][index] = outer + math.copysign(local_limit, delta)

    smoothed = [list(row) for row in terraced]
    for ring in range(inner_ring, outer_ring + 1):
        radial_t = (ring - inner_ring) / radial_span
        wall_band = _smoothstep(0.0, 0.18, radial_t) * (1.0 - _smoothstep(0.94, 1.0, radial_t))
        shelf_signal = math.sin(radial_t * math.tau * 5.0) * 28.0
        for index in range(radial_segments):
            route = max(path_mask[ring][index], crater_loop_mask[ring][index])
            lava = lava_mask[ring][index]
            strength = wall_band * min(0.36, process_intensity * 0.26)
            strength *= 1.0 - route * 0.44
            strength *= 1.0 - lava * 0.28
            if strength <= 0.0:
                continue

            height = terraced[ring][index]
            previous_height = terraced[ring][index - 1]
            next_height = terraced[ring][(index + 1) % radial_segments]
            inner_height = terraced[max(inner_ring, ring - 1)][index]
            outer_height = terraced[min(outer_ring, ring + 1)][index]
            radial_target = height * 0.46 + inner_height * 0.27 + outer_height * 0.27
            angular_target = height * 0.54 + previous_height * 0.23 + next_height * 0.23
            target = radial_target * 0.68 + angular_target * 0.32
            smoothed[ring][index] = height * (1.0 - strength) + (target + shelf_signal * wall_band) * strength

    return smoothed


def _settle_talus_apron_heights(
    heights: list[list[float]],
    path_mask: list[list[float]],
    crater_loop_mask: list[list[float]],
    lava_mask: list[list[float]],
    volcano_mask: list[list[float]],
    radial_segments: int,
    rings: int,
    controls: dict[str, object],
) -> list[list[float]]:
    settle_intensity = float(controls.get("terrain_settle_intensity", controls.get("terrain_relaxation_intensity", 0.0)))
    if settle_intensity <= 0.0 or rings < 20:
        return heights

    passes = 1 if settle_intensity < 0.7 else 2
    settled = [list(row) for row in heights]
    for _ in range(passes):
        next_heights = [list(row) for row in settled]
        for ring in range(rings + 1):
            radial_alpha = ring / rings if rings else 0.0
            apron = _smoothstep(0.52, 0.84, radial_alpha) * (1.0 - _smoothstep(0.96, 1.0, radial_alpha))
            if apron <= 0.0:
                continue

            for index in range(radial_segments):
                angle = (index / radial_segments) * math.tau
                signed_angle = abs(math.atan2(math.sin(angle), math.cos(angle)))
                approach_influence = (
                    (1.0 - _smoothstep(0.52, 0.92, signed_angle))
                    * _smoothstep(0.22, 0.94, radial_alpha)
                )
                route = max(path_mask[ring][index], crater_loop_mask[ring][index])
                lava = lava_mask[ring][index]
                volcano = volcano_mask[ring][index]
                protection = max(route * 0.86, lava * 0.78, volcano * 0.52, approach_influence)
                strength = apron * min(0.34, settle_intensity * 0.20) * (1.0 - protection)
                if strength <= 0.0:
                    continue

                height = settled[ring][index]
                previous_height = settled[ring][index - 1]
                next_height = settled[ring][(index + 1) % radial_segments]
                inner_height = settled[max(0, ring - 1)][index]
                outer_height = settled[min(rings, ring + 1)][index]
                angular_target = height * 0.42 + previous_height * 0.29 + next_height * 0.29
                radial_target = height * 0.54 + inner_height * 0.23 + outer_height * 0.23
                target = angular_target * 0.72 + radial_target * 0.28
                next_heights[ring][index] = height * (1.0 - strength) + target * strength
        settled = next_heights
    return settled


def _weather_fire_aged_edges(
    heights: list[list[float]],
    path_mask: list[list[float]],
    crater_loop_mask: list[list[float]],
    lava_mask: list[list[float]],
    volcano_mask: list[list[float]],
    cliff_mask: list[list[float]],
    curvature_mask: list[list[float]],
    radial_segments: int,
    rings: int,
    controls: dict[str, object],
) -> list[list[float]]:
    settle_intensity = float(controls.get("terrain_settle_intensity", controls.get("terrain_relaxation_intensity", 0.0)))
    erosion_age = _clamp01(float(controls.get("erosion_age", 0.45)))
    deposition_weight = _clamp01(float(controls.get("deposition_weight", 0.55)))
    weather_intensity = min(1.0, settle_intensity * 0.48 + erosion_age * 0.34 + deposition_weight * 0.18)
    if weather_intensity <= 0.0 or rings < 12:
        return heights

    passes = 1 if weather_intensity < 0.45 else 2
    if weather_intensity > 0.76:
        passes = 3

    weathered = [list(row) for row in heights]
    for _ in range(passes):
        next_heights = [list(row) for row in weathered]
        for ring in range(1, rings):
            radial_alpha = ring / rings if rings else 0.0
            mid_band = _smoothstep(0.30, 0.46, radial_alpha) * (1.0 - _smoothstep(0.92, 0.99, radial_alpha))
            apron_band = _smoothstep(0.52, 0.80, radial_alpha) * (1.0 - _smoothstep(0.96, 1.0, radial_alpha))
            rim_radius = float(controls.get("volcano_radius", 0.42))
            rim_weather_band = 1.0 - _smoothstep(0.06, 0.21, abs(radial_alpha - rim_radius))
            if max(mid_band, apron_band, rim_weather_band) <= 0.0:
                continue

            for index in range(radial_segments):
                height = weathered[ring][index]
                previous_height = weathered[ring][index - 1]
                next_height = weathered[ring][(index + 1) % radial_segments]
                inner_height = weathered[ring - 1][index]
                outer_height = weathered[ring + 1][index]
                neighbor_average = (previous_height + next_height + inner_height + outer_height) * 0.25

                residual = abs(height - neighbor_average)
                angular_delta = max(abs(height - previous_height), abs(height - next_height))
                spike = _smoothstep(96.0, 256.0, residual)
                knife_edge = _smoothstep(150.0, 330.0, angular_delta)
                if spike <= 0.0 and knife_edge <= 0.0:
                    continue

                route = max(path_mask[ring][index], crater_loop_mask[ring][index] * 0.9)
                lava = lava_mask[ring][index]
                volcano = volcano_mask[ring][index]
                cliff = cliff_mask[ring][index]
                curvature = curvature_mask[ring][index]
                shoulder = _clamp01(_smoothstep(0.10, 0.42, lava) - _smoothstep(0.58, 0.94, lava))
                angle = (index / radial_segments) * math.tau
                signed_angle = abs(math.atan2(math.sin(angle), math.cos(angle)))
                path_width = float(controls.get("path_width", _preset("fire")["path_width"]))
                approach_neighborhood = (
                    (1.0 - _smoothstep(path_width * 0.72, path_width * 1.35, signed_angle))
                    * _smoothstep(0.22, 0.94, radial_alpha)
                )
                route_shoulder_guard = (
                    _smoothstep(path_width * 0.86, path_width * 1.02, signed_angle)
                    * (1.0 - _smoothstep(path_width * 1.08, path_width * 1.38, signed_angle))
                    * _smoothstep(0.56, 0.68, radial_alpha)
                    * (1.0 - _smoothstep(0.80, 0.86, radial_alpha))
                )

                zone = max(
                    apron_band * 1.08,
                    rim_weather_band * (0.38 + volcano * 0.28),
                    mid_band * curvature * 0.52,
                    cliff * apron_band * 0.42,
                )
                blackrock_talus_weather = (
                    _smoothstep(0.50, 0.60, radial_alpha)
                    * (1.0 - _smoothstep(0.78, 0.88, radial_alpha))
                    * (1.0 - route * 0.92)
                    * (1.0 - lava * 0.96)
                    * (1.0 - volcano * 0.70)
                )
                zone = max(zone, blackrock_talus_weather * 0.58)
                feature_protection = max(
                    route * 0.86,
                    lava * 0.92,
                    approach_neighborhood * 0.56,
                    route_shoulder_guard,
                )
                strength = weather_intensity * zone * (spike * 0.42 + knife_edge * 0.32 + shoulder * 0.08)
                strength *= 1.0 - feature_protection
                strength = min(0.56, max(0.0, strength))
                if strength <= 0.0:
                    continue

                angular_target = height * 0.42 + previous_height * 0.29 + next_height * 0.29
                full_target = (
                    height * 0.36
                    + previous_height * 0.16
                    + next_height * 0.16
                    + inner_height * 0.16
                    + outer_height * 0.16
                )
                target = full_target if spike > knife_edge else angular_target
                if volcano > 0.20 or rim_weather_band > 0.45:
                    target = angular_target * 0.72 + full_target * 0.28
                if apron_band > 0.45:
                    target = angular_target * 0.76 + full_target * 0.24

                next_heights[ring][index] = height * (1.0 - strength) + target * strength
        weathered = next_heights
    return weathered


def _restore_fire_weathered_talus_readability(
    talus_mask: list[list[float]],
    path_mask: list[list[float]],
    lava_mask: list[list[float]],
    crater_loop_mask: list[list[float]],
    radial_segments: int,
    rings: int,
    controls: dict[str, object],
) -> list[list[float]]:
    deposition_weight = _clamp01(float(controls.get("deposition_weight", 0.55)))
    restored = [list(row) for row in talus_mask]
    for ring in range(rings + 1):
        radial_alpha = ring / rings if rings else 0.0
        apron = _smoothstep(0.58, 0.82, radial_alpha) * (1.0 - _smoothstep(0.97, 1.0, radial_alpha))
        if apron <= 0.0:
            continue
        for index in range(radial_segments):
            route = max(path_mask[ring][index], crater_loop_mask[ring][index] * 0.82)
            lava = lava_mask[ring][index]
            readable_deposit = apron * (0.060 + deposition_weight * 0.050) * (1.0 - route * 0.72) * (1.0 - lava * 0.52)
            restored[ring][index] = _clamp01(restored[ring][index] + readable_deposit)
    return restored


def _settle_fire_crater_ash_basin(
    heights: list[list[float]],
    path_mask: list[list[float]],
    lava_mask: list[list[float]],
    radial_segments: int,
    rings: int,
    controls: dict[str, object],
) -> list[list[float]]:
    settle_intensity = float(controls.get("terrain_settle_intensity", controls.get("terrain_relaxation_intensity", 0.0)))
    if settle_intensity <= 0.0 or rings < 12:
        return heights

    volcano_radius = float(controls.get("volcano_radius", 0.42))
    passes = 1 if settle_intensity < 0.62 else 2
    settled = [list(row) for row in heights]
    for _ in range(passes):
        next_heights = [list(row) for row in settled]
        for ring in range(1, rings):
            radial_alpha = ring / rings if rings else 0.0
            ash_floor = (
                _smoothstep(0.055, 0.105, radial_alpha)
                * (1.0 - _smoothstep(volcano_radius * 0.42, volcano_radius * 0.58, radial_alpha))
            )
            if ash_floor <= 0.0:
                continue

            for index in range(radial_segments):
                route = path_mask[ring][index]
                lava = lava_mask[ring][index]
                protection = max(route * 0.88, lava * 0.92)
                strength = ash_floor * min(0.30, settle_intensity * 0.22) * (1.0 - protection)
                if strength <= 0.0:
                    continue

                height = settled[ring][index]
                previous_height = settled[ring][index - 1]
                next_height = settled[ring][(index + 1) % radial_segments]
                inner_height = settled[ring - 1][index]
                outer_height = settled[ring + 1][index]
                angular_target = height * 0.38 + previous_height * 0.31 + next_height * 0.31
                full_target = (
                    height * 0.40
                    + previous_height * 0.22
                    + next_height * 0.22
                    + inner_height * 0.08
                    + outer_height * 0.08
                )
                target = angular_target * 0.64 + full_target * 0.36
                next_heights[ring][index] = height * (1.0 - strength) + target * strength
        settled = next_heights
    return settled


def _weather_fire_volcano_wall_strata(
    heights: list[list[float]],
    path_mask: list[list[float]],
    crater_loop_mask: list[list[float]],
    lava_mask: list[list[float]],
    radial_segments: int,
    rings: int,
    controls: dict[str, object],
) -> list[list[float]]:
    settle_intensity = float(controls.get("terrain_settle_intensity", controls.get("terrain_relaxation_intensity", 0.0)))
    hero_resolution = _smoothstep(40.0, 52.0, float(rings))
    if settle_intensity <= 0.0 or hero_resolution <= 0.0 or rings < 20:
        return heights

    erosion_age = _clamp01(float(controls.get("erosion_age", 0.45)))
    volcano_radius = float(controls.get("volcano_radius", 0.42))
    path_width = float(controls.get("path_width", _preset("fire")["path_width"]))
    strength_base = hero_resolution * min(0.42, settle_intensity * 0.22 + erosion_age * 0.18)
    if strength_base <= 0.0:
        return heights

    weathered = [list(row) for row in heights]
    passes = 2 if strength_base > 0.26 else 1
    for _ in range(passes):
        next_heights = [list(row) for row in weathered]
        for ring in range(1, rings):
            radial_alpha = ring / rings if rings else 0.0
            lower_wall = _smoothstep(volcano_radius * 0.86, volcano_radius * 1.06, radial_alpha)
            upper_wall = 1.0 - _smoothstep(volcano_radius * 1.54, volcano_radius * 1.74, radial_alpha)
            wall_band = lower_wall * upper_wall
            if wall_band <= 0.0:
                continue

            strata_signal = math.sin(radial_alpha * math.tau * 8.0) * 18.0 * wall_band
            for index in range(radial_segments):
                angle = (index / radial_segments) * math.tau
                route = max(path_mask[ring][index], crater_loop_mask[ring][index] * 0.90)
                lava = lava_mask[ring][index]
                signed_angle = abs(math.atan2(math.sin(angle), math.cos(angle)))
                main_approach_guard = (
                    (1.0 - _smoothstep(path_width * 0.72, path_width * 2.35, signed_angle))
                    * _smoothstep(0.22, 0.94, radial_alpha)
                )
                if main_approach_guard > 0.18:
                    continue
                protection = max(route * 0.94, lava * 0.88, main_approach_guard)
                if protection >= 1.0:
                    continue

                height = weathered[ring][index]
                previous_height = weathered[ring][index - 1]
                next_height = weathered[ring][(index + 1) % radial_segments]
                angular_delta = max(abs(height - previous_height), abs(height - next_height))
                rib = _smoothstep(120.0, 270.0, angular_delta)
                if rib <= 0.0:
                    continue

                angular_target = height * 0.44 + previous_height * 0.28 + next_height * 0.28
                strength = min(0.34, strength_base * wall_band * rib * (1.0 - protection))
                next_heights[ring][index] = height * (1.0 - strength) + (angular_target + strata_signal) * strength
        weathered = next_heights

    outer_start = max(2, round(rings * volcano_radius * 1.02))
    outer_end = min(rings - 1, round(rings * volcano_radius * 1.56))
    if outer_end > outer_start:
        min_ring_samples = max(5, round((outer_end - outer_start + 1) * 0.50))
        coherent_boundaries: list[tuple[int, float]] = []
        for index in range(radial_segments):
            next_index = (index + 1) % radial_segments
            boundary_deltas = []
            for ring in range(outer_start, outer_end + 1):
                protection = max(
                    path_mask[ring][index],
                    lava_mask[ring][index],
                    crater_loop_mask[ring][index],
                    path_mask[ring][next_index],
                    lava_mask[ring][next_index],
                    crater_loop_mask[ring][next_index],
                )
                if protection > 0.22:
                    continue
                boundary_deltas.append(abs(weathered[ring][index] - weathered[ring][next_index]))

            if len(boundary_deltas) < min_ring_samples:
                continue
            ordered = sorted(boundary_deltas)
            boundary_p80 = ordered[min(len(ordered) - 1, int(len(ordered) * 0.80))]
            coherence = _smoothstep(212.0, 294.0, boundary_p80)
            if coherence > 0.0:
                coherent_boundaries.append((index, coherence))

        if coherent_boundaries:
            weighted_targets = [[0.0 for _ in range(radial_segments)] for _ in range(rings + 1)]
            weights = [[0.0 for _ in range(radial_segments)] for _ in range(rings + 1)]
            for index, coherence in coherent_boundaries:
                next_index = (index + 1) % radial_segments
                for ring in range(outer_start, outer_end + 1):
                    radial_alpha = ring / rings if rings else 0.0
                    lower_wall = _smoothstep(volcano_radius * 1.02, volcano_radius * 1.12, radial_alpha)
                    upper_wall = 1.0 - _smoothstep(volcano_radius * 1.54, volcano_radius * 1.76, radial_alpha)
                    wall_band = lower_wall * upper_wall
                    if wall_band <= 0.0:
                        continue

                    protection = max(
                        path_mask[ring][index],
                        lava_mask[ring][index],
                        crater_loop_mask[ring][index],
                        path_mask[ring][next_index],
                        lava_mask[ring][next_index],
                        crater_loop_mask[ring][next_index],
                    )
                    if protection > 0.22:
                        continue

                    left_height = weathered[ring][index]
                    right_height = weathered[ring][next_index]
                    local_rib = _smoothstep(168.0, 316.0, abs(left_height - right_height))
                    if local_rib <= 0.0:
                        continue

                    midpoint = (left_height + right_height) * 0.50
                    left_diagonal = (
                        weathered[ring - 1][(index - 1) % radial_segments] * 0.50
                        + weathered[ring + 1][next_index] * 0.50
                    )
                    right_diagonal = (
                        weathered[ring - 1][(next_index + 1) % radial_segments] * 0.50
                        + weathered[ring + 1][index] * 0.50
                    )
                    strength = min(
                        0.62,
                        strength_base * 1.65 * wall_band * coherence * local_rib * (1.0 - protection),
                    )
                    if strength <= 0.0:
                        continue

                    left_target = midpoint * 0.82 + left_diagonal * 0.18
                    right_target = midpoint * 0.82 + right_diagonal * 0.18
                    weighted_targets[ring][index] += left_target * strength
                    weights[ring][index] += strength
                    weighted_targets[ring][next_index] += right_target * strength
                    weights[ring][next_index] += strength

            next_heights = [list(row) for row in weathered]
            for ring in range(outer_start, outer_end + 1):
                for index in range(radial_segments):
                    weight = min(0.68, weights[ring][index])
                    if weight <= 0.0:
                        continue
                    target = weighted_targets[ring][index] / weights[ring][index]
                    next_heights[ring][index] = weathered[ring][index] * (1.0 - weight) + target * weight
            weathered = next_heights

    return weathered


def _weather_fire_outer_wall_polar_curtains(
    heights: list[list[float]],
    path_mask: list[list[float]],
    crater_loop_mask: list[list[float]],
    lava_mask: list[list[float]],
    radial_segments: int,
    rings: int,
    controls: dict[str, object],
) -> list[list[float]]:
    settle_intensity = float(controls.get("terrain_settle_intensity", controls.get("terrain_relaxation_intensity", 0.0)))
    hero_resolution = _smoothstep(40.0, 52.0, float(rings))
    if settle_intensity <= 0.0 or hero_resolution <= 0.0 or rings < 20:
        return heights

    erosion_age = _clamp01(float(controls.get("erosion_age", 0.45)))
    deposition_weight = _clamp01(float(controls.get("deposition_weight", 0.55)))
    volcano_radius = float(controls.get("volcano_radius", 0.42))
    strength_base = hero_resolution * min(0.76, settle_intensity * 0.50 + erosion_age * 0.25 + deposition_weight * 0.17)
    if strength_base <= 0.0:
        return heights

    outer_start = max(2, round(rings * volcano_radius * 1.02))
    outer_end = min(rings - 1, round(rings * volcano_radius * 1.56))
    if outer_end <= outer_start:
        return heights

    min_ring_samples = max(5, round((outer_end - outer_start + 1) * 0.50))
    coherent_boundaries: list[tuple[int, float]] = []
    for index in range(radial_segments):
        next_index = (index + 1) % radial_segments
        boundary_deltas = []
        medium_ribs = 0
        strong_ribs = 0
        for ring in range(outer_start, outer_end + 1):
            semantic_guard = max(
                path_mask[ring][index],
                lava_mask[ring][index],
                crater_loop_mask[ring][index],
                path_mask[ring][next_index],
                lava_mask[ring][next_index],
                crater_loop_mask[ring][next_index],
            )
            if semantic_guard > 0.20:
                continue
            delta = abs(heights[ring][index] - heights[ring][next_index])
            boundary_deltas.append(delta)
            if delta > 110.0:
                medium_ribs += 1
            if delta > 160.0:
                strong_ribs += 1

        if len(boundary_deltas) < min_ring_samples:
            continue
        ordered = sorted(boundary_deltas)
        boundary_p80 = ordered[min(len(ordered) - 1, int(len(ordered) * 0.80))]
        persistence = max(
            _smoothstep(6.0, 10.0, float(medium_ribs)),
            _smoothstep(3.0, 7.0, float(strong_ribs)),
        )
        coherence = max(_smoothstep(190.0, 270.0, boundary_p80), persistence)
        if coherence > 0.0:
            coherent_boundaries.append((index, coherence))

    if not coherent_boundaries:
        return heights

    weighted_targets = [[0.0 for _ in range(radial_segments)] for _ in range(rings + 1)]
    weights = [[0.0 for _ in range(radial_segments)] for _ in range(rings + 1)]
    for index, coherence in coherent_boundaries:
        next_index = (index + 1) % radial_segments
        for ring in range(outer_start, outer_end + 1):
            radial_alpha = ring / rings if rings else 0.0
            lower_wall = _smoothstep(volcano_radius * 1.02, volcano_radius * 1.10, radial_alpha)
            upper_wall = 1.0 - _smoothstep(volcano_radius * 1.54, volcano_radius * 1.74, radial_alpha)
            wall_band = lower_wall * upper_wall
            if wall_band <= 0.0:
                continue

            semantic_guard = max(
                path_mask[ring][index],
                lava_mask[ring][index],
                crater_loop_mask[ring][index],
                path_mask[ring][next_index],
                lava_mask[ring][next_index],
                crater_loop_mask[ring][next_index],
            )
            if semantic_guard > 0.20:
                continue

            left_height = heights[ring][index]
            right_height = heights[ring][next_index]
            local_rib = _smoothstep(108.0, 266.0, abs(left_height - right_height))
            if local_rib <= 0.0:
                continue

            midpoint = (left_height + right_height) * 0.50
            left_diagonal = (
                heights[ring - 1][(index - 1) % radial_segments] * 0.50
                + heights[ring + 1][next_index] * 0.50
            )
            right_diagonal = (
                heights[ring - 1][(next_index + 1) % radial_segments] * 0.50
                + heights[ring + 1][index] * 0.50
            )
            strength = min(0.70, strength_base * 1.08 * wall_band * coherence * local_rib * (1.0 - semantic_guard))
            if strength <= 0.0:
                continue

            left_target = midpoint * 0.88 + left_diagonal * 0.12
            right_target = midpoint * 0.88 + right_diagonal * 0.12
            weighted_targets[ring][index] += left_target * strength
            weights[ring][index] += strength
            weighted_targets[ring][next_index] += right_target * strength
            weights[ring][next_index] += strength

    cleaned = [list(row) for row in heights]
    for ring in range(outer_start, outer_end + 1):
        for index in range(radial_segments):
            weight = min(0.70, weights[ring][index])
            if weight <= 0.0:
                continue
            target = weighted_targets[ring][index] / weights[ring][index]
            cleaned[ring][index] = heights[ring][index] * (1.0 - weight) + target * weight

    vertex_coherence = [0.0 for _ in range(radial_segments)]
    for index, coherence in coherent_boundaries:
        next_index = (index + 1) % radial_segments
        vertex_coherence[index] = max(vertex_coherence[index], coherence)
        vertex_coherence[next_index] = max(vertex_coherence[next_index], coherence)

    settled = [list(row) for row in cleaned]
    for ring in range(outer_start, outer_end + 1):
        radial_alpha = ring / rings if rings else 0.0
        lower_wall = _smoothstep(volcano_radius * 1.02, volcano_radius * 1.10, radial_alpha)
        upper_wall = 1.0 - _smoothstep(volcano_radius * 1.54, volcano_radius * 1.74, radial_alpha)
        wall_band = lower_wall * upper_wall
        if wall_band <= 0.0:
            continue

        for index in range(radial_segments):
            coherence = vertex_coherence[index]
            if coherence <= 0.0:
                continue
            semantic_guard = max(
                path_mask[ring][index],
                lava_mask[ring][index],
                crater_loop_mask[ring][index],
            )
            if semantic_guard > 0.20:
                continue

            height = cleaned[ring][index]
            previous_height = cleaned[ring][index - 1]
            next_height = cleaned[ring][(index + 1) % radial_segments]
            previous_2 = cleaned[ring][(index - 2) % radial_segments]
            next_2 = cleaned[ring][(index + 2) % radial_segments]
            angular_roughness = max(abs(height - previous_height), abs(height - next_height))
            local_rib = _smoothstep(98.0, 252.0, angular_roughness)
            if local_rib <= 0.0:
                continue

            angular_target = (
                height * 0.20
                + previous_height * 0.24
                + next_height * 0.24
                + previous_2 * 0.16
                + next_2 * 0.16
            )
            diagonal_target = (
                cleaned[ring - 1][(index - 1) % radial_segments] * 0.25
                + cleaned[ring - 1][(index + 1) % radial_segments] * 0.25
                + cleaned[ring + 1][(index - 1) % radial_segments] * 0.25
                + cleaned[ring + 1][(index + 1) % radial_segments] * 0.25
            )
            target = angular_target * 0.82 + diagonal_target * 0.18
            strength = min(0.64, strength_base * 1.04 * wall_band * coherence * local_rib * (1.0 - semantic_guard))
            if strength <= 0.0:
                continue
            settled[ring][index] = height * (1.0 - strength) + target * strength
    return settled


def _shape_fire_crater_wall_arc_layout(
    heights: list[list[float]],
    path_mask: list[list[float]],
    crater_loop_mask: list[list[float]],
    lava_mask: list[list[float]],
    radial_segments: int,
    rings: int,
    controls: dict[str, object],
) -> list[list[float]]:
    settle_intensity = float(controls.get("terrain_settle_intensity", controls.get("terrain_relaxation_intensity", 0.0)))
    hero_resolution = _smoothstep(40.0, 52.0, float(rings))
    if settle_intensity <= 0.0 or hero_resolution <= 0.0 or rings < 20:
        return heights

    erosion_age = _clamp01(float(controls.get("erosion_age", 0.45)))
    deposition_weight = _clamp01(float(controls.get("deposition_weight", 0.55)))
    volcano_radius = float(controls.get("volcano_radius", 0.42))
    outer_start = max(2, round(rings * volcano_radius * 1.00))
    outer_end = min(rings - 2, round(rings * volcano_radius * 1.58))
    if outer_end <= outer_start + 3:
        return heights

    process_strength = hero_resolution * min(0.74, settle_intensity * 0.36 + erosion_age * 0.24 + deposition_weight * 0.14)
    if process_strength <= 0.0:
        return heights

    shaped = [list(row) for row in heights]
    for index in range(radial_segments):
        angle = (index / radial_segments) * math.tau
        macro_arc = (
            2.60 * math.sin(angle * 2.0 + 0.58)
            + 1.75 * math.sin(angle * 3.0 - 1.18)
            + 1.10 * math.sin(angle * 5.0 + 2.36)
        )
        oblique_drift = (
            1.45 * math.sin(angle * 8.0 + 0.70 * math.sin(angle * 2.0 + 0.40))
            + 0.75 * math.sin(angle * 13.0 - 0.95)
        )
        target_offset = round(macro_arc * 0.46 + oblique_drift * 0.62)
        if target_offset == 0:
            target_offset = 1 if oblique_drift >= 0.0 else -1
        target_offset = max(-5, min(6, target_offset))

        candidates = []
        for ring in range(outer_start, outer_end + 1):
            semantic_guard = max(
                path_mask[ring][index],
                lava_mask[ring][index],
                crater_loop_mask[ring][index],
                path_mask[ring + 1][index],
                lava_mask[ring + 1][index],
                crater_loop_mask[ring + 1][index],
            )
            if semantic_guard > 0.20:
                continue
            drop = abs(shaped[ring + 1][index] - shaped[ring][index])
            candidates.append((drop, ring, semantic_guard))

        if not candidates:
            continue

        source_delta, source_ring, source_guard = max(candidates)
        if source_delta < 360.0:
            continue

        target_ring = max(outer_start, min(outer_end, source_ring + target_offset))
        if target_ring == source_ring:
            continue

        target_guard = max(
            path_mask[target_ring][index],
            lava_mask[target_ring][index],
            crater_loop_mask[target_ring][index],
            path_mask[target_ring + 1][index],
            lava_mask[target_ring + 1][index],
            crater_loop_mask[target_ring + 1][index],
        )
        semantic_guard = max(source_guard, target_guard)
        if semantic_guard > 0.20:
            continue

        source_alpha = source_ring / rings
        wall_band = _smoothstep(volcano_radius * 0.98, volcano_radius * 1.10, source_alpha) * (
            1.0 - _smoothstep(volcano_radius * 1.54, volcano_radius * 1.72, source_alpha)
        )
        if wall_band <= 0.0:
            continue

        drift_strength = _smoothstep(0.20, 1.60, abs(oblique_drift)) * 0.55 + _smoothstep(0.80, 2.40, abs(macro_arc)) * 0.45
        strength = min(0.44, process_strength * wall_band * drift_strength * (1.0 - semantic_guard))
        if strength <= 0.0:
            continue

        source_upper = shaped[source_ring][index]
        source_lower = shaped[source_ring + 1][index]
        source_mid = (source_upper + source_lower) * 0.50
        source_sign = 1.0 if source_upper >= source_lower else -1.0
        softened_delta = source_delta * (0.48 + 0.13 * (1.0 - drift_strength))
        shaped[source_ring][index] = source_upper * (1.0 - strength) + (
            source_mid + source_sign * softened_delta * 0.50
        ) * strength
        shaped[source_ring + 1][index] = source_lower * (1.0 - strength) + (
            source_mid - source_sign * softened_delta * 0.50
        ) * strength

        target_upper = shaped[target_ring][index]
        target_lower = shaped[target_ring + 1][index]
        target_mid = (target_upper + target_lower) * 0.50
        target_sign = 1.0 if target_upper >= target_lower else -1.0
        target_delta = max(abs(target_upper - target_lower), source_delta * (0.60 + 0.12 * drift_strength))
        target_strength = min(0.38, strength * (0.70 + 0.18 * drift_strength))
        shaped[target_ring][index] = target_upper * (1.0 - target_strength) + (
            target_mid + target_sign * target_delta * 0.50
        ) * target_strength
        shaped[target_ring + 1][index] = target_lower * (1.0 - target_strength) + (
            target_mid - target_sign * target_delta * 0.50
        ) * target_strength

    window_size = max(12, min(24, radial_segments // 16))
    for start in range(0, radial_segments, window_size):
        window_columns: list[tuple[int, int, float]] = []
        for offset in range(window_size):
            index = (start + offset) % radial_segments
            candidates = []
            for ring in range(outer_start, outer_end + 1):
                semantic_guard = max(
                    path_mask[ring][index],
                    lava_mask[ring][index],
                    crater_loop_mask[ring][index],
                    path_mask[ring + 1][index],
                    lava_mask[ring + 1][index],
                    crater_loop_mask[ring + 1][index],
                )
                if semantic_guard > 0.20:
                    continue
                candidates.append((abs(shaped[ring + 1][index] - shaped[ring][index]), ring))
            if candidates:
                drop, ring = max(candidates)
                window_columns.append((index, ring, drop))

        if len(window_columns) < window_size * 0.55:
            continue

        break_rings = [ring for _index, ring, _drop in window_columns]
        ring_counts = {ring: break_rings.count(ring) for ring in set(break_rings)}
        dominant_ring, dominant_count = max(ring_counts.items(), key=lambda item: item[1])
        ring_spread = max(break_rings) - min(break_rings)
        dominant_coverage = dominant_count / len(window_columns)
        if ring_spread >= 3 or dominant_coverage <= 0.72:
            continue

        for column_offset, (index, source_ring, source_delta) in enumerate(window_columns):
            if source_ring != dominant_ring or column_offset % 6 not in (1, 3, 5):
                continue
            if source_delta < 300.0:
                continue

            angle = (index / radial_segments) * math.tau
            target_direction = 1 if (column_offset % 8 in (3, 5) or math.sin(angle * 7.0 + 0.35) >= 0.0) else -1
            target_distance = 4 if column_offset % 12 == 5 else (3 if column_offset % 8 == 3 else 2)
            target_ring = max(outer_start, min(outer_end, source_ring + target_direction * target_distance))
            if target_ring == source_ring:
                continue

            semantic_guard = max(
                path_mask[source_ring][index],
                lava_mask[source_ring][index],
                crater_loop_mask[source_ring][index],
                path_mask[source_ring + 1][index],
                lava_mask[source_ring + 1][index],
                crater_loop_mask[source_ring + 1][index],
                path_mask[target_ring][index],
                lava_mask[target_ring][index],
                crater_loop_mask[target_ring][index],
                path_mask[target_ring + 1][index],
                lava_mask[target_ring + 1][index],
                crater_loop_mask[target_ring + 1][index],
            )
            if semantic_guard > 0.20:
                continue

            strength = min(0.78, process_strength * 1.16 * (1.0 - semantic_guard))
            source_upper = shaped[source_ring][index]
            source_lower = shaped[source_ring + 1][index]
            source_mid = (source_upper + source_lower) * 0.50
            source_sign = 1.0 if source_upper >= source_lower else -1.0
            shaped[source_ring][index] = source_upper * (1.0 - strength) + (
                source_mid + source_sign * source_delta * 0.07
            ) * strength
            shaped[source_ring + 1][index] = source_lower * (1.0 - strength) + (
                source_mid - source_sign * source_delta * 0.07
            ) * strength

            target_upper = shaped[target_ring][index]
            target_lower = shaped[target_ring + 1][index]
            target_mid = (target_upper + target_lower) * 0.50
            target_sign = 1.0 if target_upper >= target_lower else -1.0
            target_delta = max(abs(target_upper - target_lower), source_delta * 1.22)
            target_strength = min(0.74, strength * 1.04)
            shaped[target_ring][index] = target_upper * (1.0 - target_strength) + (
                target_mid + target_sign * target_delta * 0.50
            ) * target_strength
            shaped[target_ring + 1][index] = target_lower * (1.0 - target_strength) + (
                target_mid - target_sign * target_delta * 0.50
            ) * target_strength

    return shaped


def _shape_fire_outer_wall_asymmetric_break_arcs(
    heights: list[list[float]],
    path_mask: list[list[float]],
    crater_loop_mask: list[list[float]],
    lava_mask: list[list[float]],
    radial_segments: int,
    rings: int,
    controls: dict[str, object],
) -> list[list[float]]:
    settle_intensity = float(controls.get("terrain_settle_intensity", controls.get("terrain_relaxation_intensity", 0.0)))
    hero_resolution = _smoothstep(40.0, 52.0, float(rings))
    if settle_intensity <= 0.0 or hero_resolution <= 0.0 or rings < 20:
        return heights

    erosion_age = _clamp01(float(controls.get("erosion_age", 0.45)))
    deposition_weight = _clamp01(float(controls.get("deposition_weight", 0.55)))
    volcano_radius = float(controls.get("volcano_radius", 0.42))
    source_ring = max(2, min(rings - 2, round(rings * volcano_radius * 1.23)))
    source_drop_strength = hero_resolution * min(0.70, settle_intensity * 0.34 + erosion_age * 0.22 + deposition_weight * 0.14)
    if source_drop_strength <= 0.0:
        return heights

    shaped = [list(row) for row in heights]
    for index in range(radial_segments):
        angle = (index / radial_segments) * math.tau
        sector_signal = (
            math.sin(angle * 2.0 + 0.88)
            + 0.54 * math.sin(angle * 3.0 - 1.35)
            + 0.32 * math.sin(angle * 5.0 + 0.42)
        ) / 1.86
        sector_strength = _smoothstep(0.34, 0.86, abs(sector_signal))
        if sector_strength <= 0.0:
            continue

        target_offset = 3 if sector_signal > 0.0 else -2
        if sector_signal > 0.58:
            target_offset = 6
        target_ring = max(2, min(rings - 2, source_ring + target_offset))
        if target_ring == source_ring:
            continue

        semantic_guard = max(
            path_mask[source_ring][index],
            lava_mask[source_ring][index],
            crater_loop_mask[source_ring][index],
            path_mask[source_ring + 1][index],
            lava_mask[source_ring + 1][index],
            crater_loop_mask[source_ring + 1][index],
            path_mask[target_ring][index],
            lava_mask[target_ring][index],
            crater_loop_mask[target_ring][index],
            path_mask[target_ring + 1][index],
            lava_mask[target_ring + 1][index],
            crater_loop_mask[target_ring + 1][index],
        )
        if semantic_guard > 0.20:
            continue

        source_upper = shaped[source_ring][index]
        source_lower = shaped[source_ring + 1][index]
        source_delta = abs(source_lower - source_upper)
        if source_delta < 430.0:
            continue

        wall_band = _smoothstep(volcano_radius * 1.02, volcano_radius * 1.14, source_ring / rings) * (
            1.0 - _smoothstep(volcano_radius * 1.50, volcano_radius * 1.66, source_ring / rings)
        )
        strength = min(0.42, source_drop_strength * 0.68 * sector_strength * wall_band * (1.0 - semantic_guard))
        if strength <= 0.0:
            continue

        source_mid = (source_upper + source_lower) * 0.50
        source_sign = 1.0 if source_upper >= source_lower else -1.0
        softened_delta = source_delta * (0.54 + 0.10 * (1.0 - sector_strength))
        shaped[source_ring][index] = source_upper * (1.0 - strength) + (source_mid + source_sign * softened_delta * 0.50) * strength
        shaped[source_ring + 1][index] = source_lower * (1.0 - strength) + (source_mid - source_sign * softened_delta * 0.50) * strength

        target_upper = shaped[target_ring][index]
        target_lower = shaped[target_ring + 1][index]
        target_mid = (target_upper + target_lower) * 0.50
        target_sign = 1.0 if target_upper >= target_lower else -1.0
        target_delta = max(abs(target_upper - target_lower), source_delta * (0.66 + 0.10 * sector_strength))
        target_strength = min(0.36, strength * 0.58)
        shaped[target_ring][index] = (
            target_upper * (1.0 - target_strength)
            + (target_mid + target_sign * target_delta * 0.50) * target_strength
        )
        shaped[target_ring + 1][index] = (
            target_lower * (1.0 - target_strength)
            + (target_mid - target_sign * target_delta * 0.50) * target_strength
        )

    return shaped


def _weather_fire_outer_wall_diagonal_breakup(
    heights: list[list[float]],
    path_mask: list[list[float]],
    crater_loop_mask: list[list[float]],
    lava_mask: list[list[float]],
    radial_segments: int,
    rings: int,
    controls: dict[str, object],
) -> list[list[float]]:
    settle_intensity = float(controls.get("terrain_settle_intensity", controls.get("terrain_relaxation_intensity", 0.0)))
    hero_resolution = _smoothstep(40.0, 52.0, float(rings))
    if settle_intensity <= 0.0 or hero_resolution <= 0.0 or rings < 20:
        return heights

    erosion_age = _clamp01(float(controls.get("erosion_age", 0.45)))
    volcano_radius = float(controls.get("volcano_radius", 0.42))
    strength_base = hero_resolution * min(0.68, settle_intensity * 0.42 + erosion_age * 0.22)
    if strength_base <= 0.0:
        return heights

    outer_start = max(2, round(rings * volcano_radius * 1.02))
    outer_end = min(rings - 1, round(rings * volcano_radius * 1.56))
    if outer_end <= outer_start:
        return heights

    broken = [list(row) for row in heights]
    for _ in range(2):
        weighted_targets = [[0.0 for _ in range(radial_segments)] for _ in range(rings + 1)]
        weights = [[0.0 for _ in range(radial_segments)] for _ in range(rings + 1)]

        for index in range(radial_segments):
            next_index = (index + 1) % radial_segments
            run: list[int] = []

            def flush_run() -> None:
                if len(run) < 9:
                    return
                for run_offset, ring in enumerate(run):
                    if run_offset % 3 != 1:
                        continue
                    semantic_guard = max(
                        path_mask[ring][index],
                        lava_mask[ring][index],
                        crater_loop_mask[ring][index],
                        path_mask[ring][next_index],
                        lava_mask[ring][next_index],
                        crater_loop_mask[ring][next_index],
                    )
                    if semantic_guard > 0.20:
                        continue

                    left_height = broken[ring][index]
                    right_height = broken[ring][next_index]
                    boundary_delta = abs(left_height - right_height)
                    rib = _smoothstep(150.0, 230.0, boundary_delta)
                    if rib <= 0.0:
                        continue

                    radial_alpha = ring / rings if rings else 0.0
                    wall_band = _smoothstep(volcano_radius * 1.02, volcano_radius * 1.12, radial_alpha) * (
                        1.0 - _smoothstep(volcano_radius * 1.48, volcano_radius * 1.62, radial_alpha)
                    )
                    if wall_band <= 0.0:
                        continue

                    midpoint = (left_height + right_height) * 0.50
                    left_diagonal = (
                        broken[ring - 1][(index - 1) % radial_segments] * 0.32
                        + broken[ring + 1][next_index] * 0.32
                        + broken[ring][(index - 2) % radial_segments] * 0.18
                        + broken[ring][(next_index + 1) % radial_segments] * 0.18
                    )
                    right_diagonal = (
                        broken[ring - 1][(next_index + 1) % radial_segments] * 0.32
                        + broken[ring + 1][index] * 0.32
                        + broken[ring][(next_index + 2) % radial_segments] * 0.18
                        + broken[ring][(index - 1) % radial_segments] * 0.18
                    )
                    left_target = midpoint * 0.86 + left_diagonal * 0.14
                    right_target = midpoint * 0.86 + right_diagonal * 0.14
                    strength = min(0.54, strength_base * 0.70 * wall_band * rib * (1.0 - semantic_guard))
                    if strength <= 0.0:
                        continue

                    weighted_targets[ring][index] += left_target * strength
                    weights[ring][index] += strength
                    weighted_targets[ring][next_index] += right_target * strength
                    weights[ring][next_index] += strength

            for ring in range(outer_start, outer_end + 1):
                semantic_guard = max(
                    path_mask[ring][index],
                    lava_mask[ring][index],
                    crater_loop_mask[ring][index],
                    path_mask[ring][next_index],
                    lava_mask[ring][next_index],
                    crater_loop_mask[ring][next_index],
                )
                delta = abs(broken[ring][index] - broken[ring][next_index])
                if semantic_guard <= 0.20 and delta > 160.0:
                    run.append(ring)
                    continue
                flush_run()
                run = []
            flush_run()

        next_heights = [list(row) for row in broken]
        changed = False
        for ring in range(outer_start, outer_end + 1):
            for index in range(radial_segments):
                weight = min(0.58, weights[ring][index])
                if weight <= 0.0:
                    continue
                target = weighted_targets[ring][index] / weights[ring][index]
                next_heights[ring][index] = broken[ring][index] * (1.0 - weight) + target * weight
                changed = True
        broken = next_heights
        if not changed:
            break

    return broken


def _settle_fire_outer_wall_local_ring_locks(
    heights: list[list[float]],
    path_mask: list[list[float]],
    crater_loop_mask: list[list[float]],
    lava_mask: list[list[float]],
    radial_segments: int,
    rings: int,
    controls: dict[str, object],
) -> list[list[float]]:
    settle_intensity = float(controls.get("terrain_settle_intensity", controls.get("terrain_relaxation_intensity", 0.0)))
    hero_resolution = _smoothstep(40.0, 52.0, float(rings))
    if settle_intensity <= 0.0 or hero_resolution <= 0.0 or rings < 20:
        return heights

    erosion_age = _clamp01(float(controls.get("erosion_age", 0.45)))
    volcano_radius = float(controls.get("volcano_radius", 0.42))
    outer_start = max(2, round(rings * volcano_radius * 1.00))
    outer_end = min(rings - 2, round(rings * volcano_radius * 1.58))
    if outer_end <= outer_start + 3:
        return heights

    strength_base = hero_resolution * min(0.54, settle_intensity * 0.30 + erosion_age * 0.18)
    if strength_base <= 0.0:
        return heights

    settled = [list(row) for row in heights]
    window_size = max(12, min(24, radial_segments // 16))
    for start in range(0, radial_segments, window_size):
        window_columns: list[tuple[int, int, float]] = []
        for offset in range(window_size):
            index = (start + offset) % radial_segments
            candidates = []
            for ring in range(outer_start, outer_end + 1):
                semantic_guard = max(
                    path_mask[ring][index],
                    lava_mask[ring][index],
                    crater_loop_mask[ring][index],
                    path_mask[ring + 1][index],
                    lava_mask[ring + 1][index],
                    crater_loop_mask[ring + 1][index],
                )
                if semantic_guard > 0.20:
                    continue
                candidates.append((abs(settled[ring + 1][index] - settled[ring][index]), ring))
            if candidates:
                drop, ring = max(candidates)
                window_columns.append((index, ring, drop))

        if len(window_columns) < window_size * 0.55:
            continue

        break_rings = [ring for _index, ring, _drop in window_columns]
        ring_counts = {ring: break_rings.count(ring) for ring in set(break_rings)}
        dominant_ring, dominant_count = max(ring_counts.items(), key=lambda item: item[1])
        ring_spread = max(break_rings) - min(break_rings)
        dominant_coverage = dominant_count / len(window_columns)
        if ring_spread >= 3 or dominant_coverage <= 0.72:
            continue

        changed = 0
        for column_offset, (index, source_ring, source_delta) in enumerate(window_columns):
            if source_ring != dominant_ring or source_delta < 260.0:
                continue
            if column_offset % 5 not in (2, 3):
                continue

            target_direction = 1 if column_offset % 2 else -1
            target_ring = max(outer_start, min(outer_end, source_ring + target_direction * 2))
            if target_ring == source_ring:
                continue

            semantic_guard = max(
                path_mask[source_ring][index],
                lava_mask[source_ring][index],
                crater_loop_mask[source_ring][index],
                path_mask[source_ring + 1][index],
                lava_mask[source_ring + 1][index],
                crater_loop_mask[source_ring + 1][index],
                path_mask[target_ring][index],
                lava_mask[target_ring][index],
                crater_loop_mask[target_ring][index],
                path_mask[target_ring + 1][index],
                lava_mask[target_ring + 1][index],
                crater_loop_mask[target_ring + 1][index],
            )
            if semantic_guard > 0.20:
                continue

            strength = min(0.78, strength_base * 1.44 * (1.0 - semantic_guard))
            source_upper = settled[source_ring][index]
            source_lower = settled[source_ring + 1][index]
            source_mid = (source_upper + source_lower) * 0.50
            source_sign = 1.0 if source_upper >= source_lower else -1.0
            settled[source_ring][index] = source_upper * (1.0 - strength) + (
                source_mid + source_sign * source_delta * 0.08
            ) * strength
            settled[source_ring + 1][index] = source_lower * (1.0 - strength) + (
                source_mid - source_sign * source_delta * 0.08
            ) * strength

            target_upper = settled[target_ring][index]
            target_lower = settled[target_ring + 1][index]
            target_mid = (target_upper + target_lower) * 0.50
            target_sign = 1.0 if target_upper >= target_lower else -1.0
            target_delta = max(abs(target_upper - target_lower), source_delta * 1.12)
            target_strength = min(0.72, strength * 0.98)
            settled[target_ring][index] = target_upper * (1.0 - target_strength) + (
                target_mid + target_sign * target_delta * 0.50
            ) * target_strength
            settled[target_ring + 1][index] = target_lower * (1.0 - target_strength) + (
                target_mid - target_sign * target_delta * 0.50
            ) * target_strength

            changed += 1
            if changed >= 4:
                break

    return settled


def _cap_fire_outer_wall_angular_boundaries(
    heights: list[list[float]],
    path_mask: list[list[float]],
    crater_loop_mask: list[list[float]],
    lava_mask: list[list[float]],
    radial_segments: int,
    rings: int,
    controls: dict[str, object],
) -> list[list[float]]:
    settle_intensity = float(controls.get("terrain_settle_intensity", controls.get("terrain_relaxation_intensity", 0.0)))
    hero_resolution = _smoothstep(40.0, 52.0, float(rings))
    if settle_intensity <= 0.0 or hero_resolution <= 0.0 or radial_segments < 48 or rings < 20:
        return heights

    capped = [list(row) for row in heights]
    wall_start = max(2, round(rings * 0.46))
    wall_end = min(rings - 1, round(rings * 0.70))
    process_strength = hero_resolution * min(0.72, settle_intensity * 0.36)
    if process_strength <= 0.0:
        return capped

    max_delta = 178.0
    for _pass in range(4):
        target_sums = [[0.0 for _index in range(radial_segments)] for _ring in range(rings + 1)]
        target_weights = [[0.0 for _index in range(radial_segments)] for _ring in range(rings + 1)]
        for ring in range(wall_start, wall_end + 1):
            for index in range(radial_segments):
                next_index = (index + 1) % radial_segments
                semantic_guard = max(
                    path_mask[ring][index],
                    lava_mask[ring][index],
                    crater_loop_mask[ring][index],
                    path_mask[ring][next_index],
                    lava_mask[ring][next_index],
                    crater_loop_mask[ring][next_index],
                )
                if semantic_guard > 0.20:
                    continue

                left = capped[ring][index]
                right = capped[ring][next_index]
                delta = left - right
                if abs(delta) <= max_delta:
                    continue

                midpoint = (left + right) * 0.5
                sign = 1.0 if delta >= 0.0 else -1.0
                target_delta = 106.0 + 18.0 * abs(math.sin((index * 0.113 + ring * 0.71) * math.tau))
                strength = min(0.86, 0.58 + process_strength * 0.22) * (1.0 - semantic_guard)
                target_sums[ring][index] += (midpoint + sign * target_delta * 0.5) * strength
                target_weights[ring][index] += strength
                target_sums[ring][next_index] += (midpoint - sign * target_delta * 0.5) * strength
                target_weights[ring][next_index] += strength

        changed = False
        next_heights = [list(row) for row in capped]
        for ring in range(wall_start, wall_end + 1):
            for index in range(radial_segments):
                weight = min(0.86, target_weights[ring][index])
                if weight <= 0.0:
                    continue
                target = target_sums[ring][index] / target_weights[ring][index]
                next_heights[ring][index] = capped[ring][index] * (1.0 - weight) + target * weight
                changed = True
        capped = next_heights
        if not changed:
            break

    return capped


def _cap_fire_outer_wall_late_boundary_spikes(
    heights: list[list[float]],
    path_mask: list[list[float]],
    crater_loop_mask: list[list[float]],
    lava_mask: list[list[float]],
    radial_segments: int,
    rings: int,
    controls: dict[str, object],
) -> list[list[float]]:
    settle_intensity = float(controls.get("terrain_settle_intensity", controls.get("terrain_relaxation_intensity", 0.0)))
    hero_resolution = _smoothstep(40.0, 52.0, float(rings))
    if settle_intensity <= 0.0 or hero_resolution <= 0.0 or radial_segments < 48 or rings < 20:
        return heights

    capped = [list(row) for row in heights]
    wall_start = max(2, round(rings * 0.46))
    wall_end = min(rings - 1, round(rings * 0.70))
    min_ring_samples = 7
    process_strength = hero_resolution * min(0.72, settle_intensity * 0.34)
    if process_strength <= 0.0:
        return capped

    for _pass in range(4):
        bad_boundaries: list[tuple[int, float]] = []
        for index in range(radial_segments):
            next_index = (index + 1) % radial_segments
            deltas = []
            for ring in range(wall_start, wall_end + 1):
                semantic_guard = max(
                    path_mask[ring][index],
                    lava_mask[ring][index],
                    crater_loop_mask[ring][index],
                    path_mask[ring][next_index],
                    lava_mask[ring][next_index],
                    crater_loop_mask[ring][next_index],
                )
                if semantic_guard > 0.20:
                    continue
                deltas.append(abs(capped[ring][index] - capped[ring][next_index]))

            if len(deltas) < min_ring_samples:
                continue
            ordered = sorted(deltas)
            boundary_p80 = ordered[min(len(ordered) - 1, int(len(ordered) * 0.80))]
            excess = _smoothstep(232.0, 320.0, boundary_p80)
            if excess > 0.0:
                bad_boundaries.append((index, excess))

        if not bad_boundaries:
            break

        target_sums = [[0.0 for _index in range(radial_segments)] for _ring in range(rings + 1)]
        target_weights = [[0.0 for _index in range(radial_segments)] for _ring in range(rings + 1)]
        for index, excess in bad_boundaries:
            next_index = (index + 1) % radial_segments
            for ring in range(wall_start, wall_end + 1):
                semantic_guard = max(
                    path_mask[ring][index],
                    lava_mask[ring][index],
                    crater_loop_mask[ring][index],
                    path_mask[ring][next_index],
                    lava_mask[ring][next_index],
                    crater_loop_mask[ring][next_index],
                )
                if semantic_guard > 0.20:
                    continue

                left = capped[ring][index]
                right = capped[ring][next_index]
                delta = left - right
                local_excess = _smoothstep(222.0, 342.0, abs(delta))
                if local_excess <= 0.0:
                    continue

                midpoint = (left + right) * 0.5
                sign = 1.0 if delta >= 0.0 else -1.0
                target_delta = 170.0 + 18.0 * abs(math.sin((index * 0.071 + ring * 0.193) * math.tau))
                strength = min(0.72, 0.40 + process_strength * 0.28) * excess * local_excess
                target_sums[ring][index] += (midpoint + sign * target_delta * 0.5) * strength
                target_weights[ring][index] += strength
                target_sums[ring][next_index] += (midpoint - sign * target_delta * 0.5) * strength
                target_weights[ring][next_index] += strength

        changed = False
        next_heights = [list(row) for row in capped]
        for ring in range(wall_start, wall_end + 1):
            for index in range(radial_segments):
                weight = min(0.72, target_weights[ring][index])
                if weight <= 0.0:
                    continue
                target = target_sums[ring][index] / target_weights[ring][index]
                next_heights[ring][index] = capped[ring][index] * (1.0 - weight) + target * weight
                changed = True
        capped = next_heights
        if not changed:
            break

    return capped


def _cap_fire_upper_wall_late_radial_combs(
    heights: list[list[float]],
    path_mask: list[list[float]],
    crater_loop_mask: list[list[float]],
    lava_mask: list[list[float]],
    radial_segments: int,
    rings: int,
    controls: dict[str, object],
) -> list[list[float]]:
    settle_intensity = float(controls.get("terrain_settle_intensity", controls.get("terrain_relaxation_intensity", 0.0)))
    hero_resolution = _smoothstep(40.0, 52.0, float(rings))
    if settle_intensity <= 0.0 or hero_resolution <= 0.0 or radial_segments < 48 or rings < 20:
        return heights

    capped = [list(row) for row in heights]
    wall_start = max(2, round(rings * 0.40))
    wall_end = min(rings - 2, round(rings * 0.54))
    window_size = max(12, min(24, radial_segments // 16))
    process_strength = hero_resolution * min(0.74, settle_intensity * 0.36)
    if process_strength <= 0.0:
        return capped

    for _pass in range(2):
        changed = False
        for start in range(0, radial_segments, window_size):
            column_metrics: list[tuple[int, bool, int, float, list[tuple[float, int]]]] = []
            for offset in range(window_size):
                index = (start + offset) % radial_segments
                steep_steps = 0
                sampled_steps = 0
                drops: list[tuple[float, int]] = []
                for ring in range(wall_start, wall_end):
                    semantic_guard = max(
                        path_mask[ring][index],
                        lava_mask[ring][index],
                        crater_loop_mask[ring][index],
                        path_mask[ring + 1][index],
                        lava_mask[ring + 1][index],
                        crater_loop_mask[ring + 1][index],
                    )
                    if semantic_guard > 0.25:
                        continue
                    sampled_steps += 1
                    drop = abs(capped[ring + 1][index] - capped[ring][index])
                    drops.append((drop, ring))
                    if drop > 240.0:
                        steep_steps += 1

                flagged = sampled_steps >= 5 and steep_steps >= 5
                max_drop = max((drop for drop, _ring in drops), default=0.0)
                column_metrics.append((offset, flagged, steep_steps, max_drop, sorted(drops, reverse=True)))

            flags = [flagged for _offset, flagged, _steep_steps, _max_drop, _drops in column_metrics]
            if sum(flags) < 3:
                continue

            longest_run = 0
            run = 0
            for flag in flags:
                if flag:
                    run += 1
                    longest_run = max(longest_run, run)
                else:
                    run = 0
            if longest_run <= 10 and sum(flags) <= 14:
                continue

            target_offsets: set[int] = set()
            run_start: int | None = None
            for offset, flag in enumerate(flags + [False]):
                if flag and run_start is None:
                    run_start = offset
                if (not flag or offset == len(flags)) and run_start is not None:
                    run_end = offset
                    run_length = run_end - run_start
                    if run_length > 10:
                        for target_offset in range(run_start + 1, run_end, 2):
                            target_offsets.add(target_offset)
                    run_start = None

            if sum(flags) - len(target_offsets) > 10:
                extra_columns = sorted(
                    (
                        (steep_steps, max_drop, offset)
                        for offset, flagged, steep_steps, max_drop, _drops in column_metrics
                        if flagged and offset not in target_offsets
                    ),
                    reverse=True,
                )
                for _steep_steps, _max_drop, offset in extra_columns:
                    target_offsets.add(offset)
                    if sum(flags) - len(target_offsets) <= 10:
                        break

            for offset in sorted(target_offsets):
                if offset >= len(column_metrics):
                    continue
                index = (start + offset) % radial_segments
                _offset, flagged, steep_steps, _max_drop, drops = column_metrics[offset]
                if not flagged:
                    continue
                adjusted = 0
                max_adjustments = min(8, max(3, steep_steps))
                for drop, ring in drops:
                    if adjusted >= max_adjustments or drop <= 225.0:
                        break
                    semantic_guard = max(
                        path_mask[ring][index],
                        lava_mask[ring][index],
                        crater_loop_mask[ring][index],
                        path_mask[ring + 1][index],
                        lava_mask[ring + 1][index],
                        crater_loop_mask[ring + 1][index],
                    )
                    if semantic_guard > 0.25:
                        continue

                    upper = capped[ring][index]
                    lower = capped[ring + 1][index]
                    delta = lower - upper
                    midpoint = (upper + lower) * 0.5
                    sign = 1.0 if delta >= 0.0 else -1.0
                    shelf_noise = abs(math.sin((start * 0.023 + offset * 0.089 + ring * 0.43) * math.tau))
                    target_delta = 60.0 + shelf_noise * 12.0
                    strength = 1.0
                    capped[ring][index] = upper * (1.0 - strength) + (
                        midpoint - sign * target_delta * 0.5
                    ) * strength
                    capped[ring + 1][index] = lower * (1.0 - strength) + (
                        midpoint + sign * target_delta * 0.5
                    ) * strength
                    adjusted += 1
                    changed = True

        if not changed:
            break

    return capped


def _weather_fire_late_collapse_scars(
    heights: list[list[float]],
    path_mask: list[list[float]],
    crater_loop_mask: list[list[float]],
    lava_mask: list[list[float]],
    volcano_mask: list[list[float]],
    radial_segments: int,
    rings: int,
    controls: dict[str, object],
) -> list[list[float]]:
    settle_intensity = float(controls.get("terrain_settle_intensity", controls.get("terrain_relaxation_intensity", 0.0)))
    hero_resolution = _smoothstep(40.0, 52.0, float(rings))
    if settle_intensity <= 0.0 or hero_resolution <= 0.0 or radial_segments < 48 or rings < 20:
        return heights

    erosion_age = _clamp01(float(controls.get("erosion_age", 0.45)))
    deposition_weight = _clamp01(float(controls.get("deposition_weight", 0.55)))
    process_strength = hero_resolution * min(0.78, settle_intensity * 0.30 + erosion_age * 0.22 + deposition_weight * 0.16)
    if process_strength <= 0.0:
        return heights

    weathered = [list(row) for row in heights]
    crest_start = max(2, round(rings * 0.32))
    crest_end = min(rings - 2, round(rings * 0.58))
    crest_ring_by_index = [-1 for _index in range(radial_segments)]
    for index in range(radial_segments):
        candidates = []
        for ring in range(crest_start, crest_end + 1):
            if max(path_mask[ring][index], lava_mask[ring][index], crater_loop_mask[ring][index]) > 0.45:
                continue
            candidates.append((weathered[ring][index], ring))
        if candidates:
            crest_ring_by_index[index] = max(candidates)[1]

    passes = 3 if process_strength > 0.44 else 2
    for _ in range(passes):
        next_heights = [list(row) for row in weathered]
        for ring in range(1, rings):
            radial_alpha = ring / rings if rings else 0.0
            upper_wall = _smoothstep(0.31, 0.36, radial_alpha) * (1.0 - _smoothstep(0.58, 0.64, radial_alpha))
            ash_band = _smoothstep(0.45, 0.50, radial_alpha) * (1.0 - _smoothstep(0.64, 0.70, radial_alpha))
            talus_band = _smoothstep(0.50, 0.56, radial_alpha) * (1.0 - _smoothstep(0.76, 0.84, radial_alpha))
            front_breach_shoulder = _smoothstep(0.31, 0.34, radial_alpha) * (1.0 - _smoothstep(0.39, 0.42, radial_alpha))
            broad_cleanup = _smoothstep(0.32, 0.38, radial_alpha) * (1.0 - _smoothstep(0.88, 0.96, radial_alpha))
            if max(upper_wall, ash_band, talus_band, front_breach_shoulder, broad_cleanup) <= 0.0:
                continue

            for index in range(radial_segments):
                angle = (index / radial_segments) * math.tau
                signed_angle = abs(math.atan2(math.sin(angle), math.cos(angle)))
                path = path_mask[ring][index]
                lava = lava_mask[ring][index]
                crater = crater_loop_mask[ring][index]
                volcano = volcano_mask[ring][index]
                if path > 0.30 or lava > 0.40:
                    continue

                height = weathered[ring][index]
                previous_height = weathered[ring][index - 1]
                next_height = weathered[ring][(index + 1) % radial_segments]
                inner_height = weathered[ring - 1][index]
                outer_height = weathered[ring + 1][index]
                neighbor_average = (previous_height + next_height + inner_height + outer_height) * 0.25
                residual = abs(height - neighbor_average)
                angular_delta = max(abs(height - previous_height), abs(height - next_height))
                radial_delta = max(abs(height - inner_height), abs(outer_height - height))

                non_front_ash = ash_band * _smoothstep(0.34, 0.54, signed_angle)
                non_front_ash *= 1.0 - _smoothstep(0.20, 0.30, max(path, lava, crater))
                front_ash = front_breach_shoulder * (1.0 - _smoothstep(0.34, 0.54, signed_angle))
                front_ash *= _smoothstep(0.07, 0.18, crater) * (1.0 - _smoothstep(0.60, 0.78, crater))
                front_ash *= (1.0 - _smoothstep(0.10, 0.20, lava)) * (1.0 - _smoothstep(0.20, 0.34, path))
                talus_weather = talus_band * (1.0 - _smoothstep(0.14, 0.24, max(path, lava, crater, volcano)))
                upper_wall_weather = upper_wall * (1.0 - _smoothstep(0.34, 0.58, max(path, lava)))
                upper_wall_weather *= 1.0 - _smoothstep(0.78, 1.0, crater)
                cleanup_weather = broad_cleanup * (1.0 - _smoothstep(0.18, 0.32, path)) * (1.0 - _smoothstep(0.30, 0.44, lava))

                zone = max(
                    upper_wall_weather * 0.56,
                    non_front_ash * 0.82,
                    front_ash * 1.05,
                    talus_weather * 0.94,
                    cleanup_weather * 0.34,
                )
                if zone <= 0.0:
                    continue

                residual_drive = _smoothstep(82.0, 218.0, residual)
                angular_drive = _smoothstep(150.0, 330.0, angular_delta)
                radial_drive = _smoothstep(300.0, 620.0, radial_delta)
                drive = max(residual_drive, angular_drive * 0.82, radial_drive * 0.62)
                if drive <= 0.0:
                    continue

                angular_target = height * 0.42 + previous_height * 0.29 + next_height * 0.29
                radial_target = height * 0.44 + inner_height * 0.28 + outer_height * 0.28
                plane_target = neighbor_average
                target = plane_target * 0.46 + angular_target * 0.34 + radial_target * 0.20
                if front_ash > 0.0:
                    target = plane_target * 0.50 + angular_target * 0.30 + radial_target * 0.20
                if talus_weather > 0.0:
                    target = plane_target * 0.52 + angular_target * 0.30 + radial_target * 0.18
                if upper_wall_weather > 0.0 and crater > 0.45:
                    target = angular_target * 0.70 + radial_target * 0.30

                is_crest_peak = crest_start <= ring <= crest_end and crest_ring_by_index[index] == ring
                feature_protection = max(path * 0.92, lava * 0.86)
                if signed_angle < 0.34 and 0.30 <= radial_alpha <= 0.40:
                    feature_protection = max(feature_protection, crater * 0.12)
                else:
                    feature_protection = max(feature_protection, crater * 0.46, volcano * 0.28)
                strength = min(0.54, process_strength * zone * (0.28 + drive * 0.86) * (1.0 - feature_protection))
                if front_ash > 0.0:
                    strength = min(0.62, strength * 1.24)
                if is_crest_peak:
                    target = height * 0.34 + angular_target * 0.66
                    strength = min(0.16, strength * 0.32)
                if strength <= 0.0:
                    continue

                next_heights[ring][index] = height * (1.0 - strength) + target * strength
        weathered = next_heights

    radial_cap = 540.0
    for _ in range(3):
        target_sums = [[0.0 for _index in range(radial_segments)] for _ring in range(rings + 1)]
        target_weights = [[0.0 for _index in range(radial_segments)] for _ring in range(rings + 1)]
        for ring in range(max(1, round(rings * 0.20)), min(rings - 1, round(rings * 0.56))):
            radial_alpha = ring / rings if rings else 0.0
            cap_band = _smoothstep(0.20, 0.28, radial_alpha) * (1.0 - _smoothstep(0.54, 0.60, radial_alpha))
            if cap_band <= 0.0:
                continue
            for index in range(radial_segments):
                path = max(path_mask[ring][index], path_mask[ring + 1][index])
                lava = max(lava_mask[ring][index], lava_mask[ring + 1][index])
                if path > 0.30 or lava > 0.34:
                    continue
                if crest_ring_by_index[index] in (ring, ring + 1):
                    continue
                upper = weathered[ring][index]
                lower = weathered[ring + 1][index]
                delta = upper - lower
                if abs(delta) <= radial_cap:
                    continue

                midpoint = (upper + lower) * 0.5
                sign = 1.0 if delta >= 0.0 else -1.0
                target_delta = radial_cap - 18.0
                crater = max(crater_loop_mask[ring][index], crater_loop_mask[ring + 1][index])
                volcano = max(volcano_mask[ring][index], volcano_mask[ring + 1][index])
                protection = max(path * 0.82, lava * 0.90, crater * 0.18, volcano * 0.12)
                strength = min(0.78, process_strength * cap_band * (1.0 - protection))
                if strength <= 0.0:
                    continue
                target_sums[ring][index] += (midpoint + sign * target_delta * 0.5) * strength
                target_weights[ring][index] += strength
                target_sums[ring + 1][index] += (midpoint - sign * target_delta * 0.5) * strength
                target_weights[ring + 1][index] += strength

        changed = False
        next_heights = [list(row) for row in weathered]
        for ring in range(rings + 1):
            for index in range(radial_segments):
                weight = min(0.76, target_weights[ring][index])
                if weight <= 0.0:
                    continue
                target = target_sums[ring][index] / target_weights[ring][index]
                next_heights[ring][index] = weathered[ring][index] * (1.0 - weight) + target * weight
                changed = True
        weathered = next_heights
        if not changed:
            break

    return weathered


def _polish_fire_late_knife_edges_preserving_crest_bays(
    heights: list[list[float]],
    path_mask: list[list[float]],
    crater_loop_mask: list[list[float]],
    lava_mask: list[list[float]],
    radial_segments: int,
    rings: int,
    controls: dict[str, object],
) -> list[list[float]]:
    settle_intensity = float(controls.get("terrain_settle_intensity", controls.get("terrain_relaxation_intensity", 0.0)))
    hero_resolution = _smoothstep(40.0, 52.0, float(rings))
    if settle_intensity <= 0.0 or hero_resolution <= 0.0 or radial_segments < 48 or rings < 20:
        return heights

    process_strength = hero_resolution * min(0.72, settle_intensity * 0.46)
    if process_strength <= 0.0:
        return heights

    crest_start = max(2, round(rings * 0.32))
    crest_end = min(rings - 2, round(rings * 0.58))
    crest_ring_by_index = [-1 for _index in range(radial_segments)]
    for index in range(radial_segments):
        candidates = []
        for ring in range(crest_start, crest_end + 1):
            if max(path_mask[ring][index], lava_mask[ring][index], crater_loop_mask[ring][index]) > 0.45:
                continue
            candidates.append((heights[ring][index], ring))
        if candidates:
            crest_ring_by_index[index] = max(candidates)[1]

    polished = [list(row) for row in heights]
    for _ in range(3):
        next_heights = [list(row) for row in polished]
        for ring in range(max(1, round(rings * 0.32)), min(rings - 1, round(rings * 0.78)) + 1):
            radial_alpha = ring / rings if rings else 0.0
            for index in range(radial_segments):
                path = path_mask[ring][index]
                lava = lava_mask[ring][index]
                crater = crater_loop_mask[ring][index]
                if path > 0.24 or lava > 0.36:
                    continue

                angle = (index / radial_segments) * math.tau
                signed_angle = abs(math.atan2(math.sin(angle), math.cos(angle)))
                front_shoulder = (
                    (1.0 - _smoothstep(0.36, 0.58, signed_angle))
                    * _smoothstep(0.32, 0.34, radial_alpha)
                    * (1.0 - _smoothstep(0.40, 0.44, radial_alpha))
                    * _smoothstep(0.08, 0.18, crater)
                    * (1.0 - _smoothstep(0.62, 0.82, crater))
                )
                ash_or_talus = (
                    _smoothstep(0.46, 0.52, radial_alpha)
                    * (1.0 - _smoothstep(0.76, 0.84, radial_alpha))
                    * (1.0 - _smoothstep(0.18, 0.32, max(path, lava, crater)))
                )
                broad_wall = (
                    _smoothstep(0.34, 0.42, radial_alpha)
                    * (1.0 - _smoothstep(0.62, 0.72, radial_alpha))
                    * (1.0 - _smoothstep(0.60, 0.86, crater))
                )
                zone = max(front_shoulder * 1.14, ash_or_talus * 1.12, broad_wall * 0.66)
                if zone <= 0.0:
                    continue

                height = polished[ring][index]
                previous_height = polished[ring][index - 1]
                next_height = polished[ring][(index + 1) % radial_segments]
                inner_height = polished[ring - 1][index]
                outer_height = polished[ring + 1][index]
                neighbor_average = (previous_height + next_height + inner_height + outer_height) * 0.25
                residual = abs(height - neighbor_average)
                angular_delta = max(abs(height - previous_height), abs(height - next_height))
                radial_delta = max(abs(height - inner_height), abs(outer_height - height))
                drive = max(
                    _smoothstep(118.0, 238.0, residual),
                    _smoothstep(230.0, 430.0, angular_delta) * 0.72,
                    _smoothstep(430.0, 680.0, radial_delta) * 0.80,
                )
                if drive <= 0.0:
                    continue

                angular_target = height * 0.42 + previous_height * 0.29 + next_height * 0.29
                radial_target = height * 0.48 + inner_height * 0.26 + outer_height * 0.26
                target = neighbor_average * 0.50 + angular_target * 0.32 + radial_target * 0.18
                if crest_ring_by_index[index] == ring:
                    target = angular_target * 0.72 + radial_target * 0.28
                    drive *= 0.62
                if front_shoulder > 0.0:
                    target = neighbor_average * 0.58 + angular_target * 0.30 + radial_target * 0.12

                protection = max(path * 0.90, lava * 0.88)
                if front_shoulder <= 0.0:
                    protection = max(protection, crater * 0.36)
                strength = min(0.50, process_strength * zone * (0.32 + drive * 0.84) * (1.0 - protection))
                if strength <= 0.0:
                    continue
                next_heights[ring][index] = height * (1.0 - strength) + target * strength
        polished = next_heights

    radial_cap = 538.0
    for _ in range(3):
        target_sums = [[0.0 for _index in range(radial_segments)] for _ring in range(rings + 1)]
        target_weights = [[0.0 for _index in range(radial_segments)] for _ring in range(rings + 1)]
        for ring in range(max(1, round(rings * 0.20)), min(rings - 1, round(rings * 0.56))):
            radial_alpha = ring / rings if rings else 0.0
            cap_band = _smoothstep(0.20, 0.30, radial_alpha) * (1.0 - _smoothstep(0.55, 0.62, radial_alpha))
            if cap_band <= 0.0:
                continue
            for index in range(radial_segments):
                path = max(path_mask[ring][index], path_mask[ring + 1][index])
                lava = max(lava_mask[ring][index], lava_mask[ring + 1][index])
                if path > 0.28 or lava > 0.34:
                    continue

                upper = polished[ring][index]
                lower = polished[ring + 1][index]
                delta = upper - lower
                if abs(delta) <= radial_cap:
                    continue

                midpoint = (upper + lower) * 0.5
                sign = 1.0 if delta >= 0.0 else -1.0
                target_delta = radial_cap - 18.0
                crater = max(crater_loop_mask[ring][index], crater_loop_mask[ring + 1][index])
                protection = max(path * 0.84, lava * 0.92, crater * 0.12)
                strength = min(0.82, process_strength * cap_band * (1.0 - protection))
                if strength <= 0.0:
                    continue
                target_sums[ring][index] += (midpoint + sign * target_delta * 0.5) * strength
                target_weights[ring][index] += strength
                target_sums[ring + 1][index] += (midpoint - sign * target_delta * 0.5) * strength
                target_weights[ring + 1][index] += strength

        changed = False
        next_heights = [list(row) for row in polished]
        for ring in range(rings + 1):
            for index in range(radial_segments):
                weight = min(0.80, target_weights[ring][index])
                if weight <= 0.0:
                    continue
                target = target_sums[ring][index] / target_weights[ring][index]
                next_heights[ring][index] = polished[ring][index] * (1.0 - weight) + target * weight
                changed = True
        polished = next_heights
        if not changed:
            break

    for _ in range(3):
        next_heights = [list(row) for row in polished]
        changed = False
        for ring in range(max(1, round(rings * 0.32)), min(rings - 1, round(rings * 0.40)) + 1):
            radial_alpha = ring / rings if rings else 0.0
            radial_weight = _smoothstep(0.32, 0.34, radial_alpha) * (1.0 - _smoothstep(0.40, 0.43, radial_alpha))
            if radial_weight <= 0.0:
                continue
            for index in range(radial_segments):
                angle = (index / radial_segments) * math.tau
                signed_angle = abs(math.atan2(math.sin(angle), math.cos(angle)))
                if signed_angle > 0.40:
                    continue
                if path_mask[ring][index] > 0.28 or lava_mask[ring][index] > 0.12:
                    continue
                crater = crater_loop_mask[ring][index]
                if crater > 0.62:
                    continue

                values = []
                for ring_offset in (-1, 0, 1):
                    sample_ring = max(0, min(rings, ring + ring_offset))
                    for index_offset in (-2, -1, 0, 1, 2):
                        sample_index = (index + index_offset) % radial_segments
                        values.append(polished[sample_ring][sample_index])
                local_range = max(values) - min(values)
                if local_range <= 1260.0:
                    continue

                median = sorted(values)[len(values) // 2]
                height = polished[ring][index]
                angular_target = height * 0.34 + polished[ring][index - 1] * 0.33 + polished[ring][(index + 1) % radial_segments] * 0.33
                target = median * 0.58 + angular_target * 0.42
                strength = min(
                    0.78,
                    process_strength
                    * radial_weight
                    * (1.0 - _smoothstep(0.62, 0.82, crater))
                    * _smoothstep(1180.0, 1680.0, local_range),
                )
                if strength <= 0.0:
                    continue
                next_heights[ring][index] = height * (1.0 - strength) + target * strength
                changed = True
        polished = next_heights
        if not changed:
            break

    for _ in range(3):
        target_sums = [[0.0 for _index in range(radial_segments)] for _ring in range(rings + 1)]
        target_weights = [[0.0 for _index in range(radial_segments)] for _ring in range(rings + 1)]
        for ring in range(max(1, round(rings * 0.33)), min(rings - 1, round(rings * 0.38)) + 1):
            for index in range(radial_segments):
                angle = (index / radial_segments) * math.tau
                signed_angle = abs(math.atan2(math.sin(angle), math.cos(angle)))
                if signed_angle > 0.40:
                    continue
                if path_mask[ring][index] > 0.28 or lava_mask[ring][index] > 0.12:
                    continue
                crater = crater_loop_mask[ring][index]
                if not 0.08 <= crater <= 0.58:
                    continue

                samples = []
                for ring_offset in (-1, 0, 1):
                    sample_ring = max(0, min(rings, ring + ring_offset))
                    for index_offset in (-2, -1, 0, 1, 2):
                        sample_index = (index + index_offset) % radial_segments
                        samples.append((polished[sample_ring][sample_index], sample_ring, sample_index))
                local_range = max(value for value, _ring, _index in samples) - min(value for value, _ring, _index in samples)
                if local_range <= 1300.0:
                    continue

                median = sorted(value for value, _ring, _index in samples)[len(samples) // 2]
                strength = min(0.48, process_strength * _smoothstep(1260.0, 1720.0, local_range))
                if strength <= 0.0:
                    continue

                for _value, sample_ring, sample_index in samples:
                    sample_angle = (sample_index / radial_segments) * math.tau
                    sample_signed_angle = abs(math.atan2(math.sin(sample_angle), math.cos(sample_angle)))
                    if sample_signed_angle > 0.46:
                        continue
                    if path_mask[sample_ring][sample_index] > 0.30 or lava_mask[sample_ring][sample_index] > 0.14:
                        continue
                    if crater_loop_mask[sample_ring][sample_index] > 0.66:
                        continue
                    sample_weight = strength * (1.0 - _smoothstep(0.60, 0.78, crater_loop_mask[sample_ring][sample_index]))
                    if sample_weight <= 0.0:
                        continue
                    target_sums[sample_ring][sample_index] += median * sample_weight
                    target_weights[sample_ring][sample_index] += sample_weight

        changed = False
        next_heights = [list(row) for row in polished]
        for ring in range(rings + 1):
            for index in range(radial_segments):
                weight = min(0.50, target_weights[ring][index])
                if weight <= 0.0:
                    continue
                target = target_sums[ring][index] / target_weights[ring][index]
                next_heights[ring][index] = polished[ring][index] * (1.0 - weight) + target * weight
                changed = True
        polished = next_heights
        if not changed:
            break

    for index, crest_ring in enumerate(crest_ring_by_index):
        if crest_ring < 0:
            continue
        angle = (index / radial_segments) * math.tau
        signed_angle = abs(math.atan2(math.sin(angle), math.cos(angle)))
        radial_alpha = crest_ring / rings if rings else 0.0
        front_shoulder = signed_angle < 0.38 and 0.32 <= radial_alpha <= 0.42
        if front_shoulder and 0.08 <= crater_loop_mask[crest_ring][index] <= 0.58:
            continue
        candidates = []
        for ring in range(crest_start, crest_end + 1):
            if max(path_mask[ring][index], lava_mask[ring][index], crater_loop_mask[ring][index]) > 0.45:
                continue
            candidates.append((polished[ring][index], ring))
        if not candidates:
            continue
        top_height, top_ring = max(candidates)
        if top_ring == crest_ring:
            continue
        crest_height = polished[crest_ring][index]
        restored_height = max(crest_height, top_height + 6.0)
        restored_height = min(restored_height, heights[crest_ring][index])
        polished[crest_ring][index] = crest_height * 0.30 + restored_height * 0.70

    window_size = max(12, min(24, radial_segments // 16))
    for start in range(0, radial_segments, window_size):
        crest_rings = []
        for offset in range(window_size):
            index = (start + offset) % radial_segments
            candidates = []
            for ring in range(crest_start, crest_end + 1):
                if max(path_mask[ring][index], lava_mask[ring][index], crater_loop_mask[ring][index]) > 0.45:
                    continue
                candidates.append((polished[ring][index], ring))
            if candidates:
                crest_rings.append(max(candidates)[1])
        if len(crest_rings) < window_size * 0.50:
            continue

        ring_spread = max(crest_rings) - min(crest_rings)
        big_shifts = sum(1 for i in range(len(crest_rings) - 1) if abs(crest_rings[i + 1] - crest_rings[i]) >= 2)
        dominant_coverage = max(crest_rings.count(ring) for ring in set(crest_rings)) / len(crest_rings)
        if ring_spread >= 4 and big_shifts >= 2 and dominant_coverage <= 0.74:
            continue

        column_options = []
        for offset in range(window_size):
            index = (start + offset) % radial_segments
            angle = (index / radial_segments) * math.tau
            signed_angle = abs(math.atan2(math.sin(angle), math.cos(angle)))
            if signed_angle < 0.12:
                continue

            candidates = []
            for ring in range(crest_start, crest_end + 1):
                if max(path_mask[ring][index], lava_mask[ring][index], crater_loop_mask[ring][index]) > 0.45:
                    continue
                candidates.append((polished[ring][index], ring))
            if len(candidates) < 3:
                continue

            top_height, top_ring = max(candidates)
            alternate_candidates = [
                (height, ring)
                for height, ring in sorted(candidates, reverse=True)
                if abs(ring - top_ring) >= 2
            ]
            if not alternate_candidates:
                continue
            alternate_height, alternate_ring = alternate_candidates[0]
            column_options.append((top_height - alternate_height, offset, index, top_height, top_ring, alternate_height, alternate_ring))

        for gap, offset, index, top_height, top_ring, alternate_height, alternate_ring in sorted(column_options)[:10]:
            max_lift = 138.0 + 22.0 * abs(math.sin((start * 0.017 + offset * 0.13) * math.tau))
            target_height = min(top_height + 4.0, alternate_height + max_lift)
            if target_height <= top_height + 1.0:
                target_height = top_height + 3.0
            polished[alternate_ring][index] = max(polished[alternate_ring][index], target_height)
            polished[top_ring][index] = min(polished[top_ring][index], top_height - 3.0)

    return polished


def _restore_fire_outer_wall_break_ring_variety(
    heights: list[list[float]],
    path_mask: list[list[float]],
    crater_loop_mask: list[list[float]],
    lava_mask: list[list[float]],
    radial_segments: int,
    rings: int,
    controls: dict[str, object],
) -> list[list[float]]:
    settle_intensity = float(controls.get("terrain_settle_intensity", controls.get("terrain_relaxation_intensity", 0.0)))
    hero_resolution = _smoothstep(40.0, 52.0, float(rings))
    if settle_intensity <= 0.0 or hero_resolution <= 0.0 or radial_segments < 48 or rings < 20:
        return heights

    restored = [list(row) for row in heights]
    wall_start = max(2, round(rings * 0.46))
    wall_end = min(rings - 2, round(rings * 0.70))
    window_size = max(12, min(24, radial_segments // 16))
    if wall_end <= wall_start + 4:
        return restored

    for start in range(0, radial_segments, window_size):
        column_breaks = []
        for offset in range(window_size):
            index = (start + offset) % radial_segments
            candidates = []
            for ring in range(wall_start, wall_end):
                semantic_guard = max(
                    path_mask[ring][index],
                    lava_mask[ring][index],
                    crater_loop_mask[ring][index],
                    path_mask[ring + 1][index],
                    lava_mask[ring + 1][index],
                    crater_loop_mask[ring + 1][index],
                )
                if semantic_guard > 0.20:
                    continue
                candidates.append((abs(restored[ring + 1][index] - restored[ring][index]), ring, index))
            if candidates:
                column_breaks.append(max(candidates))

        if len(column_breaks) < window_size * 0.55:
            continue
        break_rings = [ring for _drop, ring, _index in column_breaks]
        ring_spread = max(break_rings) - min(break_rings)
        dominant_coverage = max(break_rings.count(ring) for ring in set(break_rings)) / len(break_rings)
        if ring_spread >= 3 or dominant_coverage <= 0.72:
            continue

        target_ring = min(wall_end - 1, max(wall_start + 2, max(break_rings) + 3))
        adjusted = 0
        for _drop, _ring, index in sorted(column_breaks, key=lambda item: abs(((item[2] - start) % radial_segments) - window_size * 0.5)):
            if adjusted >= 5:
                break
            semantic_guard = max(
                path_mask[target_ring][index],
                lava_mask[target_ring][index],
                crater_loop_mask[target_ring][index],
                path_mask[target_ring + 1][index],
                lava_mask[target_ring + 1][index],
                crater_loop_mask[target_ring + 1][index],
            )
            if semantic_guard > 0.20:
                continue

            current_drop = max(
                abs(restored[ring + 1][index] - restored[ring][index])
                for ring in range(wall_start, wall_end)
                if max(
                    path_mask[ring][index],
                    lava_mask[ring][index],
                    crater_loop_mask[ring][index],
                    path_mask[ring + 1][index],
                    lava_mask[ring + 1][index],
                    crater_loop_mask[ring + 1][index],
                )
                <= 0.20
            )
            upper = restored[target_ring][index]
            lower = restored[target_ring + 1][index]
            midpoint = (upper + lower) * 0.5
            sign = 1.0 if upper >= lower else -1.0
            target_drop = current_drop + 10.0
            restored[target_ring][index] = midpoint + sign * target_drop * 0.5
            restored[target_ring + 1][index] = midpoint - sign * target_drop * 0.5
            adjusted += 1

    return restored


def _restore_fire_front_breach_low_semantic_drop(
    heights: list[list[float]],
    path_mask: list[list[float]],
    crater_loop_mask: list[list[float]],
    lava_mask: list[list[float]],
    radial_segments: int,
    rings: int,
    controls: dict[str, object],
) -> list[list[float]]:
    settle_intensity = float(controls.get("terrain_settle_intensity", controls.get("terrain_relaxation_intensity", 0.0)))
    hero_resolution = _smoothstep(40.0, 52.0, float(rings))
    if settle_intensity <= 0.0 or hero_resolution <= 0.0 or rings < 20:
        return heights

    restored = [list(row) for row in heights]
    for ring in range(max(1, round(rings * 0.30)), min(rings - 1, round(rings * 0.38)) + 1):
        for raw_index in range(-28, 28):
            index = raw_index % radial_segments
            semantic_guard = max(path_mask[ring][index], lava_mask[ring][index], crater_loop_mask[ring][index])
            if semantic_guard > 0.22:
                continue
            if path_mask[ring + 1][index] > 0.30 or lava_mask[ring + 1][index] > 0.16:
                continue

            current = restored[ring][index]
            outer = restored[ring + 1][index]
            delta = outer - current
            target_delta = 334.0
            if abs(delta) >= target_delta:
                continue
            sign = 1.0 if delta >= 0.0 else -1.0
            target_outer = current + sign * target_delta
            strength = min(0.50, hero_resolution * settle_intensity * (1.0 - semantic_guard * 0.55))
            restored[ring + 1][index] = outer * (1.0 - strength) + target_outer * strength

    next_heights = [list(row) for row in restored]
    for ring in range(max(1, round(rings * 0.30)), min(rings - 1, round(rings * 0.38)) + 1):
        for raw_index in range(-28, 28):
            index = raw_index % radial_segments
            semantic_guard = max(path_mask[ring][index], lava_mask[ring][index], crater_loop_mask[ring][index])
            if semantic_guard > 0.22:
                continue
            if path_mask[ring][index] > 0.28 or lava_mask[ring][index] > 0.16:
                continue
            height = restored[ring][index]
            angular_target = height * 0.50 + restored[ring][index - 1] * 0.25 + restored[ring][(index + 1) % radial_segments] * 0.25
            strength = min(0.28, hero_resolution * settle_intensity * (1.0 - semantic_guard))
            next_heights[ring][index] = height * (1.0 - strength) + angular_target * strength
    restored = next_heights

    return restored


def _restore_fire_upper_wall_crest_window_variety(
    heights: list[list[float]],
    path_mask: list[list[float]],
    crater_loop_mask: list[list[float]],
    lava_mask: list[list[float]],
    radial_segments: int,
    rings: int,
    controls: dict[str, object],
) -> list[list[float]]:
    settle_intensity = float(controls.get("terrain_settle_intensity", controls.get("terrain_relaxation_intensity", 0.0)))
    hero_resolution = _smoothstep(40.0, 52.0, float(rings))
    if settle_intensity <= 0.0 or hero_resolution <= 0.0 or radial_segments < 48 or rings < 20:
        return heights

    restored = [list(row) for row in heights]
    crest_start = max(2, round(rings * 0.32))
    crest_end = min(rings - 2, round(rings * 0.58))
    window_size = max(12, min(24, radial_segments // 16))
    for start in range(0, radial_segments, window_size):
        crest_rings = []
        for offset in range(window_size):
            index = (start + offset) % radial_segments
            candidates = []
            for ring in range(crest_start, crest_end + 1):
                if max(path_mask[ring][index], lava_mask[ring][index], crater_loop_mask[ring][index]) > 0.45:
                    continue
                candidates.append((restored[ring][index], ring))
            if candidates:
                crest_rings.append(max(candidates)[1])

        if len(crest_rings) < window_size * 0.50:
            continue
        ring_spread = max(crest_rings) - min(crest_rings)
        big_shifts = sum(1 for i in range(len(crest_rings) - 1) if abs(crest_rings[i + 1] - crest_rings[i]) >= 2)
        dominant_coverage = max(crest_rings.count(ring) for ring in set(crest_rings)) / len(crest_rings)
        if ring_spread >= 4 and big_shifts >= 2 and dominant_coverage <= 0.74:
            continue

        column_options = []
        for offset in range(window_size):
            index = (start + offset) % radial_segments
            angle = (index / radial_segments) * math.tau
            signed_angle = abs(math.atan2(math.sin(angle), math.cos(angle)))
            if signed_angle < 0.38:
                continue
            candidates = []
            for ring in range(crest_start, crest_end + 1):
                if max(path_mask[ring][index], lava_mask[ring][index], crater_loop_mask[ring][index]) > 0.45:
                    continue
                candidates.append((restored[ring][index], ring))
            if len(candidates) < 3:
                continue
            top_height, top_ring = max(candidates)
            alternate_candidates = [
                (height, ring)
                for height, ring in sorted(candidates, reverse=True)
                if abs(ring - top_ring) >= 2
            ]
            if alternate_candidates:
                alternate_height, alternate_ring = alternate_candidates[0]
                column_options.append((top_height - alternate_height, offset, index, top_height, top_ring, alternate_height, alternate_ring))

        for gap, offset, index, top_height, top_ring, alternate_height, alternate_ring in sorted(column_options)[:10]:
            crest_noise = abs(math.sin((start * 0.017 + offset * 0.13) * math.tau))
            target_height = top_height + 16.0 + crest_noise * 10.0
            restored[alternate_ring][index] = max(restored[alternate_ring][index], target_height)
            restored[top_ring][index] = min(restored[top_ring][index], top_height - 18.0)

    return restored


def _restore_fire_upper_wall_visual_history_rows(
    heights: list[list[float]],
    path_mask: list[list[float]],
    crater_loop_mask: list[list[float]],
    lava_mask: list[list[float]],
    radial_segments: int,
    rings: int,
    controls: dict[str, object],
) -> list[list[float]]:
    settle_intensity = float(controls.get("terrain_settle_intensity", controls.get("terrain_relaxation_intensity", 0.0)))
    hero_resolution = _smoothstep(40.0, 52.0, float(rings))
    if settle_intensity <= 0.0 or hero_resolution <= 0.0 or radial_segments < 48 or rings < 20:
        return heights

    restored = [list(row) for row in heights]
    window_size = max(12, min(24, radial_segments // 16))
    row_start = max(1, round(rings * 0.36))
    row_end = min(rings - 2, round(rings * 0.54))
    for start in range(0, radial_segments, window_size):
        row_stats = []
        vertical_rows = 0
        crosscut_rows = 0
        for ring in range(row_start, row_end):
            drops = []
            valid_offsets = []
            for offset in range(window_size):
                index = (start + offset) % radial_segments
                semantic_guard = max(
                    path_mask[ring][index],
                    lava_mask[ring][index],
                    crater_loop_mask[ring][index],
                    path_mask[ring + 1][index],
                    lava_mask[ring + 1][index],
                    crater_loop_mask[ring + 1][index],
                )
                if semantic_guard > 0.25:
                    continue
                drops.append(abs(restored[ring + 1][index] - restored[ring][index]))
                valid_offsets.append(offset)
            if len(drops) < 8:
                continue
            sorted_drops = sorted(drops)
            median_drop = sorted_drops[len(sorted_drops) // 2]
            q75 = sorted_drops[min(len(sorted_drops) - 1, int(len(sorted_drops) * 0.75))]
            if median_drop > 240.0:
                vertical_rows += 1
            if median_drop < 210.0 and q75 < 300.0:
                crosscut_rows += 1
            row_stats.append((abs(median_drop - 226.0), median_drop, ring, valid_offsets))

        if vertical_rows != 5 or crosscut_rows < 2:
            continue
        if not row_stats:
            continue
        _distance, _median_drop, target_ring, valid_offsets = min(row_stats)
        for offset in valid_offsets:
            index = (start + offset) % radial_segments
            upper = restored[target_ring][index]
            lower = restored[target_ring + 1][index]
            delta = lower - upper
            if abs(delta) >= 278.0:
                continue
            sign = 1.0 if delta >= 0.0 else -1.0
            target_lower = upper + sign * 282.0
            strength = min(0.62, hero_resolution * settle_intensity)
            restored[target_ring + 1][index] = lower * (1.0 - strength) + target_lower * strength

    return restored


def _cap_fire_front_high_crater_ash_curtain(
    heights: list[list[float]],
    path_mask: list[list[float]],
    crater_loop_mask: list[list[float]],
    lava_mask: list[list[float]],
    radial_segments: int,
    rings: int,
    controls: dict[str, object],
) -> list[list[float]]:
    settle_intensity = float(controls.get("terrain_settle_intensity", controls.get("terrain_relaxation_intensity", 0.0)))
    hero_resolution = _smoothstep(40.0, 52.0, float(rings))
    if settle_intensity <= 0.0 or hero_resolution <= 0.0 or rings < 20:
        return heights

    capped = [list(row) for row in heights]
    for _ in range(2):
        next_heights = [list(row) for row in capped]
        changed = False
        for ring in range(max(1, round(rings * 0.34)), min(rings - 1, round(rings * 0.40)) + 1):
            for raw_index in range(-24, 24):
                index = raw_index % radial_segments
                angle = (index / radial_segments) * math.tau
                signed_angle = abs(math.atan2(math.sin(angle), math.cos(angle)))
                if signed_angle > 0.40:
                    continue
                crater = crater_loop_mask[ring][index]
                if not 0.22 <= crater <= 0.90:
                    continue
                if path_mask[ring][index] > 0.28 or lava_mask[ring][index] > 0.14:
                    continue

                values = []
                for ring_offset in (-1, 0, 1):
                    sample_ring = max(0, min(rings, ring + ring_offset))
                    for index_offset in (-2, -1, 0, 1, 2):
                        values.append(capped[sample_ring][(index + index_offset) % radial_segments])
                local_range = max(values) - min(values)
                if local_range <= 1240.0:
                    continue

                median = sorted(values)[len(values) // 2]
                height = capped[ring][index]
                target = median * 0.78 + height * 0.22
                strength = min(0.72, hero_resolution * settle_intensity * _smoothstep(1200.0, 1660.0, local_range))
                next_heights[ring][index] = height * (1.0 - strength) + target * strength
                changed = True
        capped = next_heights
        if not changed:
            break

    for _ in range(2):
        next_heights = [list(row) for row in capped]
        changed = False
        for ring in range(max(1, round(rings * 0.33)), min(rings - 1, round(rings * 0.38)) + 1):
            for raw_index in range(-24, 24):
                index = raw_index % radial_segments
                angle = (index / radial_segments) * math.tau
                signed_angle = abs(math.atan2(math.sin(angle), math.cos(angle)))
                if signed_angle > 0.40:
                    continue
                if path_mask[ring][index] > 0.28 or lava_mask[ring][index] > 0.12:
                    continue
                crater = crater_loop_mask[ring][index]
                if not 0.08 <= crater <= 0.58:
                    continue

                samples = []
                for ring_offset in (-1, 0, 1):
                    sample_ring = max(0, min(rings, ring + ring_offset))
                    for index_offset in (-2, -1, 0, 1, 2):
                        sample_index = (index + index_offset) % radial_segments
                        samples.append((capped[sample_ring][sample_index], sample_ring, sample_index))
                local_range = max(value for value, _ring, _index in samples) - min(value for value, _ring, _index in samples)
                if local_range <= 1320.0:
                    continue
                median = sorted(value for value, _ring, _index in samples)[len(samples) // 2]
                strength = min(0.54, hero_resolution * settle_intensity * _smoothstep(1280.0, 1700.0, local_range))
                if strength <= 0.0:
                    continue
                for _value, sample_ring, sample_index in samples:
                    sample_crater = crater_loop_mask[sample_ring][sample_index]
                    if sample_crater < 0.22 or sample_crater > 0.90:
                        continue
                    if path_mask[sample_ring][sample_index] > 0.30 or lava_mask[sample_ring][sample_index] > 0.14:
                        continue
                    sample_height = capped[sample_ring][sample_index]
                    target = median * 0.74 + sample_height * 0.26
                    next_heights[sample_ring][sample_index] = sample_height * (1.0 - strength) + target * strength
                    changed = True
        capped = next_heights
        if not changed:
            break

    return capped


def _polish_fire_nonfront_residual_sparks(
    heights: list[list[float]],
    path_mask: list[list[float]],
    crater_loop_mask: list[list[float]],
    lava_mask: list[list[float]],
    radial_segments: int,
    rings: int,
    controls: dict[str, object],
) -> list[list[float]]:
    settle_intensity = float(controls.get("terrain_settle_intensity", controls.get("terrain_relaxation_intensity", 0.0)))
    hero_resolution = _smoothstep(40.0, 52.0, float(rings))
    if settle_intensity <= 0.0 or hero_resolution <= 0.0 or rings < 20:
        return heights

    polished = [list(row) for row in heights]
    next_heights = [list(row) for row in polished]
    for ring in range(max(1, round(rings * 0.32)), min(rings - 1, round(rings * 0.76)) + 1):
        radial_alpha = ring / rings if rings else 0.0
        for index in range(radial_segments):
            angle = (index / radial_segments) * math.tau
            signed_angle = abs(math.atan2(math.sin(angle), math.cos(angle)))
            if signed_angle <= 0.50 and radial_alpha < 0.46:
                continue
            if path_mask[ring][index] > 0.20 or lava_mask[ring][index] > 0.35:
                continue
            height = polished[ring][index]
            previous_height = polished[ring][index - 1]
            next_height = polished[ring][(index + 1) % radial_segments]
            inner_height = polished[ring - 1][index]
            outer_height = polished[ring + 1][index]
            neighbor_average = (previous_height + next_height + inner_height + outer_height) * 0.25
            residual = abs(height - neighbor_average)
            if residual <= 184.0:
                continue
            semantic_guard = max(path_mask[ring][index], lava_mask[ring][index], crater_loop_mask[ring][index])
            strength = min(
                0.26,
                hero_resolution
                * settle_intensity
                * _smoothstep(178.0, 310.0, residual)
                * (1.0 - semantic_guard * 0.42),
            )
            if strength <= 0.0:
                continue
            next_heights[ring][index] = height * (1.0 - strength) + neighbor_average * strength

    return next_heights


def _restore_fire_secondary_collapse_shelf_readability(
    heights: list[list[float]],
    path_mask: list[list[float]],
    crater_loop_mask: list[list[float]],
    lava_mask: list[list[float]],
    radial_segments: int,
    rings: int,
    controls: dict[str, object],
) -> list[list[float]]:
    settle_intensity = float(controls.get("terrain_settle_intensity", controls.get("terrain_relaxation_intensity", 0.0)))
    hero_resolution = _smoothstep(40.0, 52.0, float(rings))
    if settle_intensity <= 0.0 or hero_resolution <= 0.0 or rings < 20:
        return heights

    restored = [list(row) for row in heights]
    for ring in range(max(2, round(rings * 0.60)), min(rings - 2, round(rings * 0.70)) + 1):
        for index in range(radial_segments):
            if (index + ring * 3) % 3 != 1:
                continue
            semantic_guard = max(path_mask[ring][index], lava_mask[ring][index], crater_loop_mask[ring][index])
            if semantic_guard > 0.20:
                continue

            height = restored[ring][index]
            inner_height = restored[ring - 1][index]
            outer_height = restored[ring + 1][index]
            outer_2 = restored[ring + 2][index]
            inward_drop = abs(height - inner_height)
            outward_drop = abs(outer_height - height)
            next_outward_drop = abs(outer_2 - outer_height)
            if min(inward_drop, outward_drop) < 145.0 and max(inward_drop, outward_drop, next_outward_drop) > 230.0:
                continue
            sign = 1.0 if height >= inner_height else -1.0
            target = inner_height + sign * 84.0
            strength = min(0.72, hero_resolution * settle_intensity * (1.0 - semantic_guard))
            restored[ring][index] = height * (1.0 - strength) + target * strength

    return restored


def _polish_fire_front_ash_toe_angular_curtain(
    heights: list[list[float]],
    path_mask: list[list[float]],
    crater_loop_mask: list[list[float]],
    lava_mask: list[list[float]],
    volcano_mask: list[list[float]],
    radial_segments: int,
    rings: int,
    controls: dict[str, object],
) -> list[list[float]]:
    settle_intensity = float(controls.get("terrain_settle_intensity", controls.get("terrain_relaxation_intensity", 0.0)))
    hero_resolution = _smoothstep(40.0, 52.0, float(rings))
    if settle_intensity <= 0.0 or hero_resolution <= 0.0 or rings < 20:
        return heights

    polished = [list(row) for row in heights]
    next_heights = [list(row) for row in polished]
    for ring in range(max(1, round(rings * 0.30)), min(rings - 1, round(rings * 0.36)) + 1):
        for raw_index in range(-28, 24):
            index = raw_index % radial_segments
            angle = (index / radial_segments) * math.tau
            signed_angle = abs(math.atan2(math.sin(angle), math.cos(angle)))
            if signed_angle > 0.34:
                continue
            if path_mask[ring][index] > 0.16 or lava_mask[ring][index] > 0.16:
                continue
            if crater_loop_mask[ring][index] > 0.08 or volcano_mask[ring][index] > 0.24:
                continue
            height = polished[ring][index]
            target = height * 0.46 + polished[ring][index - 1] * 0.27 + polished[ring][(index + 1) % radial_segments] * 0.27
            strength = min(0.34, hero_resolution * settle_intensity)
            next_heights[ring][index] = height * (1.0 - strength) + target * strength

    return next_heights


def _restore_fire_process_mask_readability(
    slope_mask: list[list[float]],
    talus_mask: list[list[float]],
    strata_mask: list[list[float]],
    path_mask: list[list[float]],
    lava_mask: list[list[float]],
    crater_loop_mask: list[list[float]],
    volcano_mask: list[list[float]],
    radial_segments: int,
    rings: int,
) -> tuple[list[list[float]], list[list[float]], list[list[float]]]:
    restored_slope = [list(row) for row in slope_mask]
    restored_talus = [list(row) for row in talus_mask]
    restored_strata = [list(row) for row in strata_mask]
    for ring in range(rings + 1):
        radial_alpha = ring / rings if rings else 0.0
        for index in range(radial_segments):
            angle = (index / radial_segments) * math.tau
            signed_angle = abs(math.atan2(math.sin(angle), math.cos(angle)))
            path = path_mask[ring][index]
            lava = lava_mask[ring][index]
            crater = crater_loop_mask[ring][index]
            volcano = volcano_mask[ring][index]

            path_shoulder = (
                _smoothstep(0.66, 0.70, radial_alpha)
                * (1.0 - _smoothstep(0.76, 0.80, radial_alpha))
                * _smoothstep(0.20, 0.34, signed_angle)
                * (1.0 - _smoothstep(0.70, 0.86, signed_angle))
                * (1.0 - _smoothstep(0.28, 0.46, path))
                * (1.0 - _smoothstep(0.18, 0.36, lava))
            )
            if path_shoulder > 0.0:
                restored_slope[ring][index] = max(restored_slope[ring][index], 0.42 * path_shoulder)

            volcano_strata = (
                _smoothstep(0.46, 0.50, radial_alpha)
                * (1.0 - _smoothstep(0.54, 0.58, radial_alpha))
                * _smoothstep(0.84, 0.94, volcano)
                * (1.0 - _smoothstep(0.18, 0.30, max(path, lava, crater)))
            )
            if volcano_strata > 0.0 and slope_mask[ring][index] > 0.34:
                restored_slope[ring][index] = max(restored_slope[ring][index], 0.74 * volcano_strata)
                restored_strata[ring][index] = max(restored_strata[ring][index], 0.72 * volcano_strata)
            if volcano_strata > 0.28 and (signed_angle > 1.20 or signed_angle < 0.34):
                restored_slope[ring][index] = max(restored_slope[ring][index], 0.70)
            if volcano_strata > 0.22 and (restored_strata[ring][index] > 0.86 or crater > 0.22 or signed_angle < 0.34):
                restored_slope[ring][index] = max(restored_slope[ring][index], 0.72)
            front_volcano_strata = volcano_strata * (1.0 - _smoothstep(0.30, 0.42, signed_angle))
            if front_volcano_strata > 0.05:
                restored_slope[ring][index] = max(restored_slope[ring][index], 0.76)
                restored_strata[ring][index] = max(restored_strata[ring][index], 0.74)

            blackrock_talus = (
                _smoothstep(0.54, 0.58, radial_alpha)
                * (1.0 - _smoothstep(0.70, 0.76, radial_alpha))
                * (1.0 - _smoothstep(0.18, 0.30, crater))
                * (1.0 - _smoothstep(0.18, 0.30, lava))
                * (1.0 - _smoothstep(0.20, 0.34, path))
            )
            if blackrock_talus > 0.0:
                restored_slope[ring][index] = max(restored_slope[ring][index], 0.78 * blackrock_talus)
                restored_talus[ring][index] = max(restored_talus[ring][index], 0.46 * blackrock_talus)

            outer_talus = (
                _smoothstep(0.78, 0.84, radial_alpha)
                * (1.0 - _smoothstep(0.94, 0.99, radial_alpha))
                * (1.0 - _smoothstep(0.20, 0.38, path))
                * (1.0 - _smoothstep(0.24, 0.42, lava))
            )
            if outer_talus > 0.0:
                restored_talus[ring][index] = max(restored_talus[ring][index], 0.50 * outer_talus)

    return restored_slope, restored_talus, restored_strata


def _settle_fire_non_front_ash_deposition_bands(
    heights: list[list[float]],
    path_mask: list[list[float]],
    crater_loop_mask: list[list[float]],
    lava_mask: list[list[float]],
    radial_segments: int,
    rings: int,
    controls: dict[str, object],
) -> list[list[float]]:
    settle_intensity = float(controls.get("terrain_settle_intensity", controls.get("terrain_relaxation_intensity", 0.0)))
    hero_resolution = _smoothstep(40.0, 52.0, float(rings))
    if settle_intensity <= 0.0 or hero_resolution <= 0.0 or rings < 20:
        return heights

    deposition_weight = _clamp01(float(controls.get("deposition_weight", 0.55)))
    process_strength = hero_resolution * min(0.50, settle_intensity * 0.28 + deposition_weight * 0.25)
    if process_strength <= 0.0:
        return heights

    settled = [list(row) for row in heights]
    passes = 4 if process_strength > 0.38 else (2 if process_strength > 0.30 else 1)
    for _ in range(passes):
        next_heights = [list(row) for row in settled]
        for ring in range(max(2, round(rings * 0.46)), min(rings - 2, round(rings * 0.65)) + 1):
            radial_alpha = ring / rings if rings else 0.0
            ash_band = _smoothstep(0.45, 0.50, radial_alpha) * (1.0 - _smoothstep(0.64, 0.70, radial_alpha))
            if ash_band <= 0.0:
                continue

            for index in range(radial_segments):
                angle = (index / radial_segments) * math.tau
                signed_angle = abs(math.atan2(math.sin(angle), math.cos(angle)))
                if signed_angle < 0.34:
                    continue

                semantic_guard = max(
                    path_mask[ring][index] * 1.12,
                    crater_loop_mask[ring][index] * 1.04,
                    lava_mask[ring][index] * 1.08,
                )
                if semantic_guard > 0.24:
                    continue

                height = settled[ring][index]
                previous_height = settled[ring][index - 1]
                next_height = settled[ring][(index + 1) % radial_segments]
                previous_2 = settled[ring][(index - 2) % radial_segments]
                next_2 = settled[ring][(index + 2) % radial_segments]
                inner_height = settled[ring - 1][index]
                outer_height = settled[ring + 1][index]
                outer_2 = settled[ring + 2][index]
                local_median = sorted(
                    (
                        previous_2,
                        previous_height,
                        height,
                        next_height,
                        next_2,
                        inner_height,
                        outer_height,
                    )
                )[3]

                inward_drop = abs(height - inner_height)
                outward_drop = abs(outer_height - height)
                next_outward_drop = abs(outer_2 - outer_height)
                preserves_secondary_shelf = min(inward_drop, outward_drop) < 152.0 and max(
                    inward_drop,
                    outward_drop,
                    next_outward_drop,
                ) > 226.0
                if preserves_secondary_shelf:
                    continue
                if max(inward_drop, outward_drop) > 430.0:
                    continue

                angular_target = (
                    height * 0.24
                    + previous_height * 0.22
                    + next_height * 0.22
                    + previous_2 * 0.15
                    + next_2 * 0.15
                )
                radial_target = height * 0.40 + inner_height * 0.22 + outer_height * 0.38
                target = angular_target * 0.58 + radial_target * 0.26 + local_median * 0.16
                local_residual = abs(height - (previous_height + next_height + inner_height + outer_height) * 0.25)
                residual_hotspot = _smoothstep(96.0, 176.0, local_residual)
                outer_apron_weight = _smoothstep(0.585, 0.61, radial_alpha) * (1.0 - _smoothstep(0.655, 0.69, radial_alpha))
                if residual_hotspot > 0.0:
                    neighbor_deposition_plane = (previous_height + next_height + inner_height + outer_height) * 0.25
                    plane_weight = residual_hotspot * min(0.68, 0.46 + outer_apron_weight * 0.20)
                    target = target * (1.0 - plane_weight) + neighbor_deposition_plane * plane_weight
                roughness = _smoothstep(118.0, 220.0, max(abs(height - previous_height), abs(height - next_height)))
                roughness = max(roughness, _smoothstep(92.0, 210.0, local_residual))
                strength = min(
                    0.58,
                    process_strength
                    * ash_band
                    * (0.66 + roughness * 0.66 + residual_hotspot * outer_apron_weight * 0.22)
                    * (1.0 - semantic_guard),
                )
                if strength <= 0.0:
                    continue

                next_heights[ring][index] = height * (1.0 - strength) + target * strength
        settled = next_heights

    final_settled = [list(row) for row in settled]
    for ring in range(max(2, round(rings * 0.46)), min(rings - 2, round(rings * 0.65)) + 1):
        radial_alpha = ring / rings if rings else 0.0
        ash_band = _smoothstep(0.45, 0.50, radial_alpha) * (1.0 - _smoothstep(0.64, 0.70, radial_alpha))
        if ash_band <= 0.0:
            continue
        for index in range(radial_segments):
            angle = (index / radial_segments) * math.tau
            signed_angle = abs(math.atan2(math.sin(angle), math.cos(angle)))
            if signed_angle < 0.34:
                continue

            semantic_guard = max(
                path_mask[ring][index] * 1.12,
                crater_loop_mask[ring][index] * 1.04,
                lava_mask[ring][index] * 1.08,
            )
            if semantic_guard > 0.24:
                continue

            height = settled[ring][index]
            previous_height = settled[ring][index - 1]
            next_height = settled[ring][(index + 1) % radial_segments]
            inner_height = settled[ring - 1][index]
            outer_height = settled[ring + 1][index]
            outer_2 = settled[ring + 2][index]

            inward_drop = abs(height - inner_height)
            outward_drop = abs(outer_height - height)
            next_outward_drop = abs(outer_2 - outer_height)
            preserves_secondary_shelf = min(inward_drop, outward_drop) < 152.0 and max(
                inward_drop,
                outward_drop,
                next_outward_drop,
            ) > 226.0
            if preserves_secondary_shelf or max(inward_drop, outward_drop) > 430.0:
                continue

            neighbor_deposition_plane = (previous_height + next_height + inner_height + outer_height) * 0.25
            local_residual = abs(height - neighbor_deposition_plane)
            hotspot = _smoothstep(124.0, 188.0, local_residual)
            if hotspot <= 0.0:
                continue

            strength = min(0.36, process_strength * ash_band * hotspot * (1.0 - semantic_guard) * 0.82)
            final_settled[ring][index] = height * (1.0 - strength) + neighbor_deposition_plane * strength

    settled = final_settled

    return settled


def _carve_fire_lava_low_potential_corridors(
    heights: list[list[float]],
    path_mask: list[list[float]],
    crater_loop_mask: list[list[float]],
    lava_mask: list[list[float]],
    radial_segments: int,
    rings: int,
    controls: dict[str, object],
) -> list[list[float]]:
    settle_intensity = float(controls.get("terrain_settle_intensity", controls.get("terrain_relaxation_intensity", 0.0)))
    hero_resolution = _smoothstep(40.0, 52.0, float(rings))
    if settle_intensity <= 0.0 or hero_resolution <= 0.0 or rings < 20:
        return heights

    erosion_age = _clamp01(float(controls.get("erosion_age", 0.45)))
    strength_base = hero_resolution * min(0.62, settle_intensity * 0.34 + erosion_age * 0.24)
    if strength_base <= 0.0:
        return heights

    carved = [list(row) for row in heights]
    for _ in range(2):
        next_heights = [list(row) for row in carved]
        for ring in range(max(2, round(rings * 0.58)), min(rings - 2, round(rings * 0.90)) + 1):
            radial_alpha = ring / rings if rings else 0.0
            downstream_band = _smoothstep(0.56, 0.66, radial_alpha) * (1.0 - _smoothstep(0.88, 0.94, radial_alpha))
            if downstream_band <= 0.0:
                continue

            for index in range(radial_segments):
                lava = lava_mask[ring][index]
                if lava < 0.46:
                    continue
                semantic_guard = max(path_mask[ring][index], crater_loop_mask[ring][index] * 0.94)
                if semantic_guard > 0.25:
                    continue

                height = carved[ring][index]
                local_low = min(
                    carved[ring][index - 1],
                    carved[ring][(index + 1) % radial_segments],
                    carved[ring][(index - 2) % radial_segments],
                    carved[ring][(index + 2) % radial_segments],
                    carved[ring - 1][index],
                    carved[ring + 1][index],
                    carved[min(rings, ring + 2)][index],
                )
                excess = height - local_low
                if excess <= 120.0:
                    continue

                flow_floor = local_low + 44.0 + (1.0 - lava) * 78.0
                target = min(height, flow_floor)
                strength = min(0.48, strength_base * downstream_band * _smoothstep(0.44, 0.86, lava) * (1.0 - semantic_guard))
                if strength <= 0.0:
                    continue
                next_heights[ring][index] = height * (1.0 - strength) + target * strength
        carved = next_heights

    return carved


def _shape_fire_lava_cooling_crust_sills(
    heights: list[list[float]],
    path_mask: list[list[float]],
    crater_loop_mask: list[list[float]],
    lava_mask: list[list[float]],
    radial_segments: int,
    rings: int,
    controls: dict[str, object],
) -> list[list[float]]:
    settle_intensity = float(controls.get("terrain_settle_intensity", controls.get("terrain_relaxation_intensity", 0.0)))
    hero_resolution = _smoothstep(40.0, 52.0, float(rings))
    if settle_intensity <= 0.0 or hero_resolution <= 0.0 or rings < 20:
        return heights

    erosion_age = _clamp01(float(controls.get("erosion_age", 0.45)))
    deposition_weight = _clamp01(float(controls.get("deposition_weight", 0.55)))
    process_strength = hero_resolution * min(0.84, settle_intensity * 0.38 + erosion_age * 0.26 + deposition_weight * 0.18)
    if process_strength <= 0.0:
        return heights

    lava_count = int(controls.get("lava_channel_count", 3))
    path_width = float(controls.get("path_width", _preset("fire")["path_width"]))
    channel_angles = tuple(_lava_channel_angles(lava_count))
    shaped = [list(row) for row in heights]

    for ring in range(max(2, round(rings * 0.78)), min(rings - 2, round(rings * 0.955)) + 1):
        radial_alpha = ring / rings if rings else 0.0
        next_heights = [list(row) for row in shaped]
        for index in range(radial_segments):
            angle = (index / radial_segments) * math.tau
            signed_angle = abs(math.atan2(math.sin(angle), math.cos(angle)))
            main_approach_guard = (
                (1.0 - _smoothstep(path_width * 0.72, path_width * 1.42, signed_angle))
                * _smoothstep(0.22, 0.94, radial_alpha)
            )
            semantic_guard = max(path_mask[ring][index] * 0.95, crater_loop_mask[ring][index] * 0.92, main_approach_guard)
            if semantic_guard > 0.30:
                continue

            sill_strength = 0.0
            spill_shelf_strength = 0.0
            for channel_index, channel_angle in enumerate(channel_angles):
                signed_channel_angle = abs(math.atan2(math.sin(channel_angle), math.cos(channel_angle)))
                if signed_channel_angle < path_width * 1.25:
                    continue

                radial_center = 0.835 + 0.018 * math.sin(channel_index * 2.11)
                radial_band = 1.0 - _smoothstep(0.012, 0.047, abs(radial_alpha - radial_center))
                spill_band = _smoothstep(radial_center + 0.040, radial_center + 0.072, radial_alpha) * (
                    1.0 - _smoothstep(radial_center + 0.108, radial_center + 0.152, radial_alpha)
                )
                if radial_band <= 0.0 and spill_band <= 0.0:
                    continue

                distance = _angular_distance(angle, channel_angle)
                core = 1.0 - _smoothstep(0.014, 0.060, distance)
                shoulder = 1.0 - _smoothstep(0.048, 0.120, distance)
                support = _smoothstep(0.34, 0.62, lava_mask[ring][index])
                if radial_band > 0.0:
                    sill_strength = max(sill_strength, radial_band * support * (core + shoulder * 0.30))
                spill_shelf_strength = max(spill_shelf_strength, spill_band * support * (core + shoulder * 0.24))

            if sill_strength <= 0.0 and spill_shelf_strength <= 0.0:
                continue

            height = shaped[ring][index]
            inner_height = shaped[ring - 1][index]
            outer_height = shaped[ring + 1][index]
            shaped_height = height
            if sill_strength > 0.0:
                neighbor_plane = (inner_height + outer_height) * 0.5
                lip_target = neighbor_plane + 240.0 + erosion_age * 110.0 + deposition_weight * 70.0
                if lip_target > shaped_height:
                    strength = min(0.88, process_strength * sill_strength * (1.0 - semantic_guard))
                    shaped_height = shaped_height * (1.0 - strength) + lip_target * strength

            if spill_shelf_strength > 0.0:
                upstream_height = shaped[max(0, ring - 2)][index]
                spill_target = upstream_height * 0.45 + inner_height * 0.55 - (70.0 + erosion_age * 45.0)
                if spill_target > shaped_height:
                    strength = min(0.76, process_strength * spill_shelf_strength * (1.0 - semantic_guard))
                    shaped_height = shaped_height * (1.0 - strength) + spill_target * strength

            next_heights[ring][index] = shaped_height
        shaped = next_heights

    return shaped


def _fire_lava_side_overflow_strengths(
    radial_alpha: float,
    angle: float,
    controls: dict[str, object],
) -> tuple[float, float]:
    lava_count = int(controls.get("lava_channel_count", 3))
    path_width = float(controls.get("path_width", _preset("fire")["path_width"]))
    tongue_strength = 0.0
    levee_strength = 0.0

    for channel_index, channel_angle in enumerate(_lava_channel_angles(lava_count)):
        signed_channel_angle = abs(math.atan2(math.sin(channel_angle), math.cos(channel_angle)))
        if signed_channel_angle < path_width * 1.25:
            continue

        side_sign = -1.0 if channel_index % 2 == 1 else 1.0
        radial_offset = 0.010 * math.sin(channel_index * 2.17)
        radial_lobe = max(
            1.0 - _smoothstep(0.018, 0.052, abs(radial_alpha - (0.735 + radial_offset))),
            1.0 - _smoothstep(0.018, 0.058, abs(radial_alpha - (0.805 - radial_offset * 0.55))),
            1.0 - _smoothstep(0.020, 0.064, abs(radial_alpha - (0.875 + radial_offset * 0.40))),
        )
        if radial_lobe <= 0.0:
            continue

        tongue_angle = channel_angle + side_sign * (0.145 + 0.010 * math.sin(radial_alpha * 11.0 + channel_index))
        levee_angle = channel_angle + side_sign * (0.205 + 0.006 * math.sin(radial_alpha * 9.0 + channel_index * 1.7))
        tongue_strength = max(
            tongue_strength,
            radial_lobe * (1.0 - _smoothstep(0.020, 0.066, _angular_distance(angle, tongue_angle))),
        )
        levee_strength = max(
            levee_strength,
            radial_lobe * (1.0 - _smoothstep(0.018, 0.060, _angular_distance(angle, levee_angle))),
        )

    return tongue_strength, levee_strength


def _fire_lava_side_tongue_cooling_rib_strength(
    radial_alpha: float,
    angle: float,
    controls: dict[str, object],
) -> float:
    tongue_strength, levee_strength = _fire_lava_side_overflow_strengths(radial_alpha, angle, controls)
    if tongue_strength <= 0.0 or tongue_strength > 0.74 or levee_strength > 0.20:
        return 0.0

    radial_rib = max(
        1.0 - _smoothstep(0.012, 0.040, abs(radial_alpha - 0.748)),
        1.0 - _smoothstep(0.014, 0.046, abs(radial_alpha - 0.812)),
    )
    if radial_rib <= 0.0:
        return 0.0

    stagger = 0.78 + 0.22 * (0.5 + 0.5 * math.sin(radial_alpha * 53.0 + angle * 3.0))
    return tongue_strength * radial_rib * stagger


def _fire_lava_cooling_finger_strength(
    radial_alpha: float,
    angle: float,
    controls: dict[str, object],
) -> float:
    lava_count = int(controls.get("lava_channel_count", 3))
    path_width = float(controls.get("path_width", _preset("fire")["path_width"]))
    finger_strength = 0.0

    for channel_index, channel_angle in enumerate(_lava_channel_angles(lava_count)):
        signed_channel_angle = abs(math.atan2(math.sin(channel_angle), math.cos(channel_angle)))
        if signed_channel_angle < path_width * 1.25:
            continue

        radial_lobe = max(
            1.0 - _smoothstep(0.016, 0.050, abs(radial_alpha - (0.775 + 0.006 * math.sin(channel_index)))),
            1.0 - _smoothstep(0.018, 0.058, abs(radial_alpha - (0.840 + 0.008 * math.sin(channel_index * 1.7)))),
            1.0 - _smoothstep(0.020, 0.062, abs(radial_alpha - (0.895 + 0.006 * math.cos(channel_index * 1.3)))),
        )
        if radial_lobe <= 0.0:
            continue

        relative_angle = math.atan2(math.sin(angle - channel_angle), math.cos(angle - channel_angle))
        for finger_offset in (-0.075, 0.075, -0.185, 0.185):
            finger_strength = max(
                finger_strength,
                radial_lobe * (1.0 - _smoothstep(0.012, 0.034, abs(relative_angle - finger_offset))),
            )

    return finger_strength


def _fire_lava_terminal_cooling_pocket_strength(
    radial_alpha: float,
    angle: float,
    controls: dict[str, object],
) -> float:
    lava_count = int(controls.get("lava_channel_count", 3))
    path_width = float(controls.get("path_width", _preset("fire")["path_width"]))
    pocket_strength = 0.0

    for channel_index, channel_angle in enumerate(_lava_channel_angles(lava_count)):
        signed_channel_angle = abs(math.atan2(math.sin(channel_angle), math.cos(channel_angle)))
        if signed_channel_angle < path_width * 1.25:
            continue

        relative_angle = math.atan2(math.sin(angle - channel_angle), math.cos(angle - channel_angle))
        hot_core = 1.0 - _smoothstep(0.018, 0.082, abs(relative_angle))
        if hot_core <= 0.0:
            continue

        radial_lobe = 1.0 - _smoothstep(
            0.010,
            0.044,
            abs(radial_alpha - (0.714 + 0.006 * math.sin(channel_index * 1.2))),
        )
        if radial_lobe <= 0.0:
            continue

        broken_shell = 0.66 + 0.34 * abs(math.sin(radial_alpha * math.tau * 10.5 + channel_index * 1.73))
        pocket_strength = max(pocket_strength, hot_core * radial_lobe * broken_shell)

    return pocket_strength


def _fire_lava_mantle_cooling_slab_strength(
    radial_alpha: float,
    angle: float,
    controls: dict[str, object],
) -> float:
    lava_count = int(controls.get("lava_channel_count", 3))
    path_width = float(controls.get("path_width", _preset("fire")["path_width"]))
    slab_strength = 0.0

    for channel_index, channel_angle in enumerate(_lava_channel_angles(lava_count)):
        signed_channel_angle = abs(math.atan2(math.sin(channel_angle), math.cos(channel_angle)))
        if signed_channel_angle < path_width * 1.25:
            continue

        radial_lobe = max(
            1.0 - _smoothstep(0.014, 0.044, abs(radial_alpha - (0.704 + 0.005 * math.cos(channel_index * 1.6)))),
            1.0 - _smoothstep(0.014, 0.046, abs(radial_alpha - (0.748 + 0.005 * math.sin(channel_index * 1.2)))),
            1.0 - _smoothstep(0.014, 0.048, abs(radial_alpha - (0.786 + 0.005 * math.sin(channel_index * 1.8)))),
            1.0 - _smoothstep(0.016, 0.052, abs(radial_alpha - (0.842 + 0.006 * math.sin(channel_index * 1.4)))),
            1.0 - _smoothstep(0.018, 0.058, abs(radial_alpha - (0.902 + 0.006 * math.cos(channel_index * 1.1)))),
        )
        if radial_lobe <= 0.0:
            continue

        relative_angle = math.atan2(math.sin(angle - channel_angle), math.cos(angle - channel_angle))
        slab_offsets = (
            -0.245,
            -0.165,
            0.155,
            0.228,
            0.292,
            0.385,
        )
        for slab_index, slab_offset in enumerate(slab_offsets):
            angular_lobe = 1.0 - _smoothstep(0.014, 0.044, abs(relative_angle - slab_offset))
            if angular_lobe <= 0.0:
                continue
            broken_age = 0.72 + 0.28 * (
                0.5 + 0.5 * math.sin(radial_alpha * 47.0 + channel_index * 2.3 + slab_index * 1.7)
            )
            slab_strength = max(slab_strength, radial_lobe * angular_lobe * broken_age)

    return slab_strength


def _fire_lava_cooling_island_strength(
    radial_alpha: float,
    angle: float,
    controls: dict[str, object],
) -> float:
    lava_count = int(controls.get("lava_channel_count", 3))
    path_width = float(controls.get("path_width", _preset("fire")["path_width"]))
    island_strength = 0.0

    for channel_index, channel_angle in enumerate(_lava_channel_angles(lava_count)):
        signed_channel_angle = abs(math.atan2(math.sin(channel_angle), math.cos(channel_angle)))
        if signed_channel_angle < path_width * 1.25:
            continue

        side_sign = -1.0 if channel_index % 2 == 1 else 1.0
        radial_lobe = max(
            1.0 - _smoothstep(0.020, 0.062, abs(radial_alpha - (0.805 + 0.006 * math.sin(channel_index * 1.4)))),
            1.0 - _smoothstep(0.022, 0.068, abs(radial_alpha - (0.870 + 0.008 * math.cos(channel_index * 1.1)))),
            1.0 - _smoothstep(0.024, 0.072, abs(radial_alpha - (0.925 + 0.006 * math.sin(channel_index * 1.9)))),
        )
        if radial_lobe <= 0.0:
            continue

        relative_angle = math.atan2(math.sin(angle - channel_angle), math.cos(angle - channel_angle))
        island_offsets = (
            -side_sign * 0.092,
            -side_sign * 0.138,
            side_sign * 0.082,
        )
        for island_index, island_offset in enumerate(island_offsets):
            angular_lobe = 1.0 - _smoothstep(0.018, 0.050, abs(relative_angle - island_offset))
            if angular_lobe <= 0.0:
                continue
            stagger = 0.72 + 0.28 * (0.5 + 0.5 * math.sin(radial_alpha * 39.0 + channel_index * 2.7 + island_index))
            island_strength = max(island_strength, radial_lobe * angular_lobe * stagger)

    return island_strength


def _fire_lava_outer_scallop_strength(
    radial_alpha: float,
    angle: float,
    controls: dict[str, object],
) -> float:
    lava_count = int(controls.get("lava_channel_count", 3))
    path_width = float(controls.get("path_width", _preset("fire")["path_width"]))
    scallop_strength = 0.0

    for channel_index, channel_angle in enumerate(_lava_channel_angles(lava_count)):
        signed_channel_angle = abs(math.atan2(math.sin(channel_angle), math.cos(channel_angle)))
        if signed_channel_angle < path_width * 1.25:
            continue

        radial_lobe = max(
            1.0 - _smoothstep(0.018, 0.060, abs(radial_alpha - (0.940 + 0.004 * math.sin(channel_index * 1.2)))),
            1.0 - _smoothstep(0.020, 0.068, abs(radial_alpha - (0.982 + 0.005 * math.cos(channel_index * 1.6)))),
        )
        if radial_lobe <= 0.0:
            continue

        relative_angle = math.atan2(math.sin(angle - channel_angle), math.cos(angle - channel_angle))
        for break_index, break_offset in enumerate((-0.205, -0.112, 0.066, 0.156, 0.252)):
            angular_lobe = 1.0 - _smoothstep(0.014, 0.044, abs(relative_angle - break_offset))
            if angular_lobe <= 0.0:
                continue
            stagger = 0.76 + 0.24 * (0.5 + 0.5 * math.sin(radial_alpha * 47.0 + channel_index * 1.9 + break_index * 2.4))
            scallop_strength = max(scallop_strength, radial_lobe * angular_lobe * stagger)

    return scallop_strength


def _shape_fire_lava_cooling_fingers(
    heights: list[list[float]],
    path_mask: list[list[float]],
    crater_loop_mask: list[list[float]],
    lava_mask: list[list[float]],
    radial_segments: int,
    rings: int,
    controls: dict[str, object],
) -> list[list[float]]:
    settle_intensity = float(controls.get("terrain_settle_intensity", controls.get("terrain_relaxation_intensity", 0.0)))
    hero_resolution = _smoothstep(40.0, 52.0, float(rings))
    if settle_intensity <= 0.0 or hero_resolution <= 0.0 or rings < 20:
        return heights

    erosion_age = _clamp01(float(controls.get("erosion_age", 0.45)))
    process_strength = hero_resolution * min(0.74, settle_intensity * 0.30 + erosion_age * 0.28)
    if process_strength <= 0.0:
        return heights

    shaped = [list(row) for row in heights]
    for ring in range(max(2, round(rings * 0.74)), min(rings - 2, round(rings * 0.925)) + 1):
        radial_alpha = ring / rings if rings else 0.0
        next_heights = [list(row) for row in shaped]
        for index in range(radial_segments):
            angle = (index / radial_segments) * math.tau
            finger_strength = _fire_lava_cooling_finger_strength(radial_alpha, angle, controls)
            if finger_strength <= 0.0:
                continue

            semantic_guard = max(path_mask[ring][index] * 0.92, crater_loop_mask[ring][index] * 0.88)
            lava_support = _smoothstep(0.20, 0.52, lava_mask[ring][index])
            strength = min(0.72, process_strength * finger_strength * lava_support * (1.0 - semantic_guard))
            if strength <= 0.0:
                continue

            height = shaped[ring][index]
            angular_plane = (
                shaped[ring][index - 1]
                + shaped[ring][(index + 1) % radial_segments]
                + shaped[ring][(index - 2) % radial_segments] * 0.5
                + shaped[ring][(index + 2) % radial_segments] * 0.5
            ) / 3.0
            finger_target = max(height, angular_plane + 210.0 + erosion_age * 95.0)
            next_heights[ring][index] = height * (1.0 - strength) + finger_target * strength
        shaped = next_heights

    return shaped


def _shape_fire_lava_terminal_cooling_pockets(
    heights: list[list[float]],
    path_mask: list[list[float]],
    crater_loop_mask: list[list[float]],
    lava_mask: list[list[float]],
    radial_segments: int,
    rings: int,
    controls: dict[str, object],
) -> list[list[float]]:
    settle_intensity = float(controls.get("terrain_settle_intensity", controls.get("terrain_relaxation_intensity", 0.0)))
    hero_resolution = _smoothstep(40.0, 52.0, float(rings))
    if settle_intensity <= 0.0 or hero_resolution <= 0.0 or rings < 20:
        return heights

    erosion_age = _clamp01(float(controls.get("erosion_age", 0.45)))
    process_strength = hero_resolution * min(0.72, settle_intensity * 0.28 + erosion_age * 0.24)
    if process_strength <= 0.0:
        return heights

    shaped = [list(row) for row in heights]
    for ring in range(max(2, round(rings * 0.69)), min(rings - 2, round(rings * 0.88)) + 1):
        radial_alpha = ring / rings if rings else 0.0
        next_heights = [list(row) for row in shaped]
        for index in range(radial_segments):
            angle = (index / radial_segments) * math.tau
            pocket_strength = _fire_lava_terminal_cooling_pocket_strength(radial_alpha, angle, controls)
            if pocket_strength <= 0.0:
                continue

            semantic_guard = max(path_mask[ring][index] * 0.94, crater_loop_mask[ring][index] * 0.90)
            lava_support = _smoothstep(0.34, 0.66, lava_mask[ring][index])
            strength = min(0.76, process_strength * pocket_strength * lava_support * (1.0 - semantic_guard))
            if strength <= 0.0:
                continue

            height = shaped[ring][index]
            angular_plane = (
                shaped[ring][index - 1]
                + shaped[ring][(index + 1) % radial_segments]
                + shaped[ring][(index - 2) % radial_segments] * 0.5
                + shaped[ring][(index + 2) % radial_segments] * 0.5
            ) / 3.0
            inner = shaped[max(1, ring - 1)][index]
            outer = shaped[min(rings, ring + 1)][index]
            cooled_shell = max(height, angular_plane + 230.0 + erosion_age * 80.0, (inner + outer) * 0.5 + 150.0)
            next_heights[ring][index] = height * (1.0 - strength) + cooled_shell * strength
        shaped = next_heights

    return shaped


def _shape_fire_lava_mantle_cooling_slabs(
    heights: list[list[float]],
    path_mask: list[list[float]],
    crater_loop_mask: list[list[float]],
    lava_mask: list[list[float]],
    radial_segments: int,
    rings: int,
    controls: dict[str, object],
) -> list[list[float]]:
    settle_intensity = float(controls.get("terrain_settle_intensity", controls.get("terrain_relaxation_intensity", 0.0)))
    hero_resolution = _smoothstep(40.0, 52.0, float(rings))
    if settle_intensity <= 0.0 or hero_resolution <= 0.0 or rings < 20:
        return heights

    erosion_age = _clamp01(float(controls.get("erosion_age", 0.45)))
    deposition_weight = _clamp01(float(controls.get("deposition_weight", 0.55)))
    process_strength = hero_resolution * min(0.76, settle_intensity * 0.30 + erosion_age * 0.24 + deposition_weight * 0.12)
    if process_strength <= 0.0:
        return heights

    shaped = [list(row) for row in heights]
    for ring in range(max(2, round(rings * 0.68)), min(rings - 2, round(rings * 0.93)) + 1):
        radial_alpha = ring / rings if rings else 0.0
        next_heights = [list(row) for row in shaped]
        for index in range(radial_segments):
            angle = (index / radial_segments) * math.tau
            slab_strength = _fire_lava_mantle_cooling_slab_strength(radial_alpha, angle, controls)
            if slab_strength <= 0.0:
                continue

            tongue_strength, levee_strength = _fire_lava_side_overflow_strengths(radial_alpha, angle, controls)
            if tongue_strength > 0.22 or levee_strength > 0.14:
                continue

            semantic_guard = max(path_mask[ring][index] * 0.94, crater_loop_mask[ring][index] * 0.90)
            lava_support = max(
                _smoothstep(0.20, 0.58, lava_mask[ring][index]),
                min(0.62, slab_strength * 0.48),
            )
            strength = min(0.72, process_strength * slab_strength * lava_support * (1.0 - semantic_guard))
            if strength <= 0.0:
                continue

            height = shaped[ring][index]
            angular_floor = min(
                shaped[ring][index - 2],
                shaped[ring][index - 1],
                shaped[ring][(index + 1) % radial_segments],
                shaped[ring][(index + 2) % radial_segments],
            )
            radial_plane = (
                shaped[max(1, ring - 1)][index] * 0.40
                + shaped[min(rings, ring + 1)][index] * 0.40
                + height * 0.20
            )
            slab_target = max(
                height,
                angular_floor + 330.0 + erosion_age * 110.0,
                radial_plane + 220.0 + deposition_weight * 82.0,
            )
            next_heights[ring][index] = height * (1.0 - strength) + slab_target * strength
        shaped = next_heights

    return shaped


def _shape_fire_lava_outer_scallops(
    heights: list[list[float]],
    path_mask: list[list[float]],
    crater_loop_mask: list[list[float]],
    lava_mask: list[list[float]],
    radial_segments: int,
    rings: int,
    controls: dict[str, object],
) -> list[list[float]]:
    settle_intensity = float(controls.get("terrain_settle_intensity", controls.get("terrain_relaxation_intensity", 0.0)))
    hero_resolution = _smoothstep(40.0, 52.0, float(rings))
    if settle_intensity <= 0.0 or hero_resolution <= 0.0 or rings < 20:
        return heights

    erosion_age = _clamp01(float(controls.get("erosion_age", 0.45)))
    deposition_weight = _clamp01(float(controls.get("deposition_weight", 0.55)))
    process_strength = hero_resolution * min(0.70, settle_intensity * 0.26 + erosion_age * 0.24 + deposition_weight * 0.12)
    if process_strength <= 0.0:
        return heights

    shaped = [list(row) for row in heights]
    for ring in range(max(2, round(rings * 0.94)), rings + 1):
        radial_alpha = ring / rings if rings else 0.0
        next_heights = [list(row) for row in shaped]
        for index in range(radial_segments):
            angle = (index / radial_segments) * math.tau
            scallop_strength = _fire_lava_outer_scallop_strength(radial_alpha, angle, controls)
            if scallop_strength <= 0.0:
                continue

            semantic_guard = max(path_mask[ring][index] * 0.94, crater_loop_mask[ring][index] * 0.90)
            lava_support = _smoothstep(0.14, 0.48, lava_mask[ring][index])
            strength = min(0.68, process_strength * scallop_strength * lava_support * (1.0 - semantic_guard))
            if strength <= 0.0:
                continue

            height = shaped[ring][index]
            angular_floor = min(
                shaped[ring][index - 2],
                shaped[ring][index - 1],
                shaped[ring][(index + 1) % radial_segments],
                shaped[ring][(index + 2) % radial_segments],
            )
            inner_floor = shaped[max(1, ring - 1)][index]
            scallop_target = max(
                height,
                angular_floor + 260.0 + erosion_age * 90.0,
                inner_floor + 150.0 + deposition_weight * 70.0,
            )
            next_heights[ring][index] = height * (1.0 - strength) + scallop_target * strength
        shaped = next_heights

    return shaped


def _shape_fire_lava_cooling_islands(
    heights: list[list[float]],
    path_mask: list[list[float]],
    crater_loop_mask: list[list[float]],
    lava_mask: list[list[float]],
    radial_segments: int,
    rings: int,
    controls: dict[str, object],
) -> list[list[float]]:
    settle_intensity = float(controls.get("terrain_settle_intensity", controls.get("terrain_relaxation_intensity", 0.0)))
    hero_resolution = _smoothstep(40.0, 52.0, float(rings))
    if settle_intensity <= 0.0 or hero_resolution <= 0.0 or rings < 20:
        return heights

    erosion_age = _clamp01(float(controls.get("erosion_age", 0.45)))
    deposition_weight = _clamp01(float(controls.get("deposition_weight", 0.55)))
    process_strength = hero_resolution * min(0.78, settle_intensity * 0.32 + erosion_age * 0.28 + deposition_weight * 0.12)
    if process_strength <= 0.0:
        return heights

    shaped = [list(row) for row in heights]
    for ring in range(max(2, round(rings * 0.78)), min(rings - 2, round(rings * 0.945)) + 1):
        radial_alpha = ring / rings if rings else 0.0
        next_heights = [list(row) for row in shaped]
        for index in range(radial_segments):
            angle = (index / radial_segments) * math.tau
            island_strength = _fire_lava_cooling_island_strength(radial_alpha, angle, controls)
            if island_strength <= 0.0:
                continue

            semantic_guard = max(path_mask[ring][index] * 0.94, crater_loop_mask[ring][index] * 0.90)
            lava_support = _smoothstep(0.18, 0.50, lava_mask[ring][index])
            strength = min(0.74, process_strength * island_strength * lava_support * (1.0 - semantic_guard))
            if strength <= 0.0:
                continue

            height = shaped[ring][index]
            angular_floor = min(
                shaped[ring][index - 2],
                shaped[ring][index - 1],
                shaped[ring][(index + 1) % radial_segments],
                shaped[ring][(index + 2) % radial_segments],
            )
            radial_floor = min(shaped[ring - 1][index], shaped[ring + 1][index])
            island_target = max(
                height,
                angular_floor + 360.0 + erosion_age * 120.0,
                radial_floor + 250.0 + deposition_weight * 90.0,
            )
            next_heights[ring][index] = height * (1.0 - strength) + island_target * strength
        shaped = next_heights

    return shaped


def _shape_fire_lava_side_overflow_tongues(
    heights: list[list[float]],
    path_mask: list[list[float]],
    crater_loop_mask: list[list[float]],
    lava_mask: list[list[float]],
    radial_segments: int,
    rings: int,
    controls: dict[str, object],
) -> list[list[float]]:
    settle_intensity = float(controls.get("terrain_settle_intensity", controls.get("terrain_relaxation_intensity", 0.0)))
    hero_resolution = _smoothstep(40.0, 52.0, float(rings))
    if settle_intensity <= 0.0 or hero_resolution <= 0.0 or rings < 20:
        return heights

    erosion_age = _clamp01(float(controls.get("erosion_age", 0.45)))
    deposition_weight = _clamp01(float(controls.get("deposition_weight", 0.55)))
    process_strength = hero_resolution * min(0.86, settle_intensity * 0.36 + erosion_age * 0.30 + deposition_weight * 0.16)
    if process_strength <= 0.0:
        return heights

    shaped = [list(row) for row in heights]
    for ring in range(max(2, round(rings * 0.68)), min(rings - 2, round(rings * 0.93)) + 1):
        radial_alpha = ring / rings if rings else 0.0
        next_heights = [list(row) for row in shaped]
        for index in range(radial_segments):
            angle = (index / radial_segments) * math.tau
            tongue_strength, levee_strength = _fire_lava_side_overflow_strengths(radial_alpha, angle, controls)
            if tongue_strength <= 0.0 and levee_strength <= 0.0:
                continue

            semantic_guard = max(path_mask[ring][index] * 0.92, crater_loop_mask[ring][index] * 0.88)
            if semantic_guard > 0.28:
                continue

            height = shaped[ring][index]
            shaped_height = height
            if tongue_strength > 0.0:
                lava_support = _smoothstep(0.18, 0.46, lava_mask[ring][index])
                local_low = min(
                    shaped[ring][index - 1],
                    shaped[ring][(index + 1) % radial_segments],
                    shaped[ring - 1][index],
                    shaped[ring + 1][index],
                )
                incision = (190.0 + erosion_age * 125.0 + deposition_weight * 64.0) * tongue_strength * lava_support
                tongue_target = min(height - incision, local_low + 52.0)
                strength = min(0.72, process_strength * tongue_strength * lava_support * (1.0 - semantic_guard))
                shaped_height = shaped_height * (1.0 - strength) + tongue_target * strength

            if levee_strength > 0.0:
                angular_plane = (
                    shaped[ring][index - 1]
                    + shaped[ring][(index + 1) % radial_segments]
                    + shaped[ring - 1][index] * 0.5
                    + shaped[ring + 1][index] * 0.5
                ) / 3.0
                levee_target = max(height, angular_plane + 430.0 + erosion_age * 145.0)
                strength = min(0.90, process_strength * levee_strength * (1.0 - semantic_guard))
                shaped_height = max(shaped_height, shaped_height * (1.0 - strength) + levee_target * strength)

            next_heights[ring][index] = shaped_height
        shaped = next_heights

    return shaped


def _shape_fire_lava_side_tongue_cooling_ribs(
    heights: list[list[float]],
    path_mask: list[list[float]],
    crater_loop_mask: list[list[float]],
    lava_mask: list[list[float]],
    radial_segments: int,
    rings: int,
    controls: dict[str, object],
) -> list[list[float]]:
    settle_intensity = float(controls.get("terrain_settle_intensity", controls.get("terrain_relaxation_intensity", 0.0)))
    hero_resolution = _smoothstep(40.0, 52.0, float(rings))
    if settle_intensity <= 0.0 or hero_resolution <= 0.0 or rings < 20:
        return heights

    erosion_age = _clamp01(float(controls.get("erosion_age", 0.45)))
    deposition_weight = _clamp01(float(controls.get("deposition_weight", 0.55)))
    process_strength = hero_resolution * min(0.80, settle_intensity * 0.34 + erosion_age * 0.28 + deposition_weight * 0.12)
    if process_strength <= 0.0:
        return heights

    shaped = [list(row) for row in heights]
    for ring in range(max(2, round(rings * 0.71)), min(rings - 2, round(rings * 0.845)) + 1):
        radial_alpha = ring / rings if rings else 0.0
        next_heights = [list(row) for row in shaped]
        for index in range(radial_segments):
            angle = (index / radial_segments) * math.tau
            rib_strength = _fire_lava_side_tongue_cooling_rib_strength(radial_alpha, angle, controls)
            if rib_strength <= 0.18:
                continue

            semantic_guard = max(path_mask[ring][index] * 0.92, crater_loop_mask[ring][index] * 0.88)
            lava_support = _smoothstep(0.20, 0.54, lava_mask[ring][index])
            strength = min(0.74, process_strength * rib_strength * lava_support * (1.0 - semantic_guard))
            if strength <= 0.0:
                continue

            height = shaped[ring][index]
            angular_plane = (
                shaped[ring][index - 1]
                + shaped[ring][(index + 1) % radial_segments]
                + shaped[ring][index - 2] * 0.45
                + shaped[ring][(index + 2) % radial_segments] * 0.45
            ) / 2.9
            radial_plane = (shaped[ring - 1][index] + shaped[ring + 1][index]) * 0.5
            rib_target = max(
                height,
                angular_plane + 275.0 + erosion_age * 120.0,
                radial_plane + 190.0 + deposition_weight * 84.0,
            )
            next_heights[ring][index] = height * (1.0 - strength) + rib_target * strength
        shaped = next_heights

    return shaped


def _weather_fire_inner_wall_breach_ribs(
    heights: list[list[float]],
    path_mask: list[list[float]],
    crater_loop_mask: list[list[float]],
    lava_mask: list[list[float]],
    radial_segments: int,
    rings: int,
    controls: dict[str, object],
) -> list[list[float]]:
    settle_intensity = float(controls.get("terrain_settle_intensity", controls.get("terrain_relaxation_intensity", 0.0)))
    hero_resolution = _smoothstep(40.0, 52.0, float(rings))
    if settle_intensity <= 0.0 or hero_resolution <= 0.0 or rings < 20:
        return heights

    erosion_age = _clamp01(float(controls.get("erosion_age", 0.45)))
    deposition_weight = _clamp01(float(controls.get("deposition_weight", 0.55)))
    volcano_radius = float(controls.get("volcano_radius", 0.42))
    path_width = float(controls.get("path_width", _preset("fire")["path_width"]))
    strength_base = hero_resolution * min(0.78, settle_intensity * 0.40 + erosion_age * 0.24 + deposition_weight * 0.12)
    if strength_base <= 0.0:
        return heights

    weathered = [list(row) for row in heights]
    passes = 3 if strength_base > 0.42 else 2
    for _ in range(passes):
        next_heights = [list(row) for row in weathered]
        for ring in range(2, rings - 1):
            radial_alpha = ring / rings if rings else 0.0
            inner_wall_band = _smoothstep(volcano_radius * 0.62, volcano_radius * 0.76, radial_alpha) * (
                1.0 - _smoothstep(volcano_radius * 0.94, volcano_radius * 1.10, radial_alpha)
            )
            if inner_wall_band <= 0.0:
                continue

            for index in range(radial_segments):
                angle = (index / radial_segments) * math.tau
                signed_angle = abs(math.atan2(math.sin(angle), math.cos(angle)))
                main_approach_guard = (
                    (1.0 - _smoothstep(path_width * 0.70, path_width * 2.15, signed_angle))
                    * _smoothstep(0.18, 0.58, radial_alpha)
                )
                protection = max(
                    path_mask[ring][index] * 0.96,
                    crater_loop_mask[ring][index] * 0.90,
                    lava_mask[ring][index] * 0.88,
                    main_approach_guard,
                )
                if protection >= 0.95:
                    continue

                height = weathered[ring][index]
                previous_height = weathered[ring][index - 1]
                next_height = weathered[ring][(index + 1) % radial_segments]
                previous_2 = weathered[ring][(index - 2) % radial_segments]
                next_2 = weathered[ring][(index + 2) % radial_segments]
                inner_height = weathered[ring - 1][index]
                outer_height = weathered[ring + 1][index]
                angular_delta = max(abs(height - previous_height), abs(height - next_height))
                rib = _smoothstep(128.0, 292.0, angular_delta)
                if rib <= 0.0:
                    continue

                angular_target = (
                    height * 0.30
                    + previous_height * 0.24
                    + next_height * 0.24
                    + previous_2 * 0.11
                    + next_2 * 0.11
                )
                radial_target = height * 0.72 + inner_height * 0.14 + outer_height * 0.14
                target = angular_target * 0.72 + radial_target * 0.28
                strength = min(0.49, strength_base * inner_wall_band * rib * (1.0 - protection))
                next_heights[ring][index] = height * (1.0 - strength) + target * strength
        weathered = next_heights

    column_broken = [list(row) for row in weathered]
    inner_start = max(2, round(rings * 0.28))
    inner_end = min(rings - 2, round(rings * 0.46))
    for _column_pass in range(3):
        for index in range(radial_segments):
            next_index = (index + 1) % radial_segments
            run: list[int] = []

            def flush_run(active_run: list[int]) -> None:
                if len(active_run) <= 3:
                    return
                for run_offset, run_ring in enumerate(active_run):
                    semantic_guard = max(
                        path_mask[run_ring][index],
                        lava_mask[run_ring][index],
                        crater_loop_mask[run_ring][index],
                        path_mask[run_ring][next_index],
                        lava_mask[run_ring][next_index],
                        crater_loop_mask[run_ring][next_index],
                    )
                    if semantic_guard > 0.20:
                        continue

                    left = column_broken[run_ring][index]
                    right = column_broken[run_ring][next_index]
                    delta = left - right
                    if abs(delta) <= 132.0:
                        continue

                    midpoint = (left + right) * 0.5
                    sign = 1.0 if delta >= 0.0 else -1.0
                    fracture_phase = math.sin((index * 0.37 + run_ring * 1.91 + erosion_age * 2.3) * math.tau)
                    target_delta = 58.0 + 16.0 * abs(fracture_phase)
                    strength = min(0.98, 0.42 + strength_base * 0.96)
                    target_left = midpoint + sign * target_delta * 0.5
                    target_right = midpoint - sign * target_delta * 0.5
                    column_broken[run_ring][index] = left * (1.0 - strength) + target_left * strength
                    column_broken[run_ring][next_index] = right * (1.0 - strength) + target_right * strength

            for ring in range(inner_start, inner_end + 1):
                semantic_guard = max(
                    path_mask[ring][index],
                    lava_mask[ring][index],
                    crater_loop_mask[ring][index],
                    path_mask[ring][next_index],
                    lava_mask[ring][next_index],
                    crater_loop_mask[ring][next_index],
                )
                delta = abs(column_broken[ring][index] - column_broken[ring][next_index])
                if semantic_guard <= 0.20 and delta > 132.0:
                    run.append(ring)
                else:
                    flush_run(run)
                    run = []
            flush_run(run)

    # Resolve the last few polar-looking boundary runs in a batched pass so adjacent
    # boundaries do not overwrite each other's staggered weathering targets.
    for _final_column_pass in range(2):
        target_sums = [[0.0 for _index in range(radial_segments)] for _ring in range(rings + 1)]
        target_weights = [[0 for _index in range(radial_segments)] for _ring in range(rings + 1)]

        for index in range(radial_segments):
            next_index = (index + 1) % radial_segments
            run: list[int] = []

            def flush_final_run(active_run: list[int]) -> None:
                if len(active_run) <= 3:
                    return
                for run_ring in active_run:
                    semantic_guard = max(
                        path_mask[run_ring][index],
                        lava_mask[run_ring][index],
                        crater_loop_mask[run_ring][index],
                        path_mask[run_ring][next_index],
                        lava_mask[run_ring][next_index],
                        crater_loop_mask[run_ring][next_index],
                    )
                    if semantic_guard > 0.20:
                        continue

                    left = column_broken[run_ring][index]
                    right = column_broken[run_ring][next_index]
                    delta = left - right
                    if abs(delta) <= 132.0:
                        continue

                    midpoint = (left + right) * 0.5
                    sign = 1.0 if delta >= 0.0 else -1.0
                    fracture_phase = math.sin((index * 0.41 + run_ring * 1.73 + erosion_age * 2.9) * math.tau)
                    target_delta = 50.0 + 12.0 * abs(fracture_phase)
                    target_sums[run_ring][index] += midpoint + sign * target_delta * 0.5
                    target_weights[run_ring][index] += 1
                    target_sums[run_ring][next_index] += midpoint - sign * target_delta * 0.5
                    target_weights[run_ring][next_index] += 1

            for ring in range(inner_start, inner_end + 1):
                semantic_guard = max(
                    path_mask[ring][index],
                    lava_mask[ring][index],
                    crater_loop_mask[ring][index],
                    path_mask[ring][next_index],
                    lava_mask[ring][next_index],
                    crater_loop_mask[ring][next_index],
                )
                delta = abs(column_broken[ring][index] - column_broken[ring][next_index])
                if semantic_guard <= 0.20 and delta > 132.0:
                    run.append(ring)
                else:
                    flush_final_run(run)
                    run = []
            flush_final_run(run)

        for ring in range(inner_start, inner_end + 1):
            for index in range(radial_segments):
                weight = target_weights[ring][index]
                if weight <= 0:
                    continue
                target = target_sums[ring][index] / weight
                column_broken[ring][index] = column_broken[ring][index] * 0.16 + target * 0.84

    window_size = max(12, min(24, radial_segments // 16))
    for start in range(0, radial_segments, window_size):
        window_columns: list[tuple[int, int, int, float]] = []
        for column_offset in range(window_size):
            index = (start + column_offset) % radial_segments
            candidates = []
            for ring in range(inner_start, inner_end):
                semantic_guard = max(
                    path_mask[ring][index],
                    lava_mask[ring][index],
                    crater_loop_mask[ring][index],
                    path_mask[ring + 1][index],
                    lava_mask[ring + 1][index],
                    crater_loop_mask[ring + 1][index],
                )
                if semantic_guard > 0.20:
                    continue
                drop = abs(column_broken[ring + 1][index] - column_broken[ring][index])
                if drop > 260.0:
                    candidates.append((drop, ring))
            if candidates:
                drop, ring = max(candidates)
                window_columns.append((column_offset, index, ring, drop))

        if len(window_columns) < window_size * 0.45:
            continue

        break_rings = [ring for _offset, _index, ring, _drop in window_columns]
        ring_counts = {ring: break_rings.count(ring) for ring in set(break_rings)}
        dominant_ring, dominant_count = max(ring_counts.items(), key=lambda item: item[1])
        ring_spread = max(break_rings) - min(break_rings)
        dominant_coverage = dominant_count / len(window_columns)
        if dominant_coverage <= 0.74 and ring_spread >= 3:
            continue

        for column_offset, index, source_ring, source_drop in window_columns:
            if source_ring != dominant_ring or source_drop < 300.0:
                continue
            if column_offset % 4 not in (0, 2):
                continue

            angle = (index / radial_segments) * math.tau
            signed_angle = abs(math.atan2(math.sin(angle), math.cos(angle)))
            main_approach_guard = 1.0 - _smoothstep(path_width * 0.85, path_width * 2.40, signed_angle)
            if main_approach_guard > 0.05:
                continue
            direction = -1 if math.sin(angle * 3.0 + start * 0.017 + erosion_age) < 0.0 else 1
            if column_offset % 12 == 4:
                direction *= -1
            distance = 3 if column_offset % 8 in (2, 6) else 2
            target_ring = None
            for target_offset in (
                direction * distance,
                -direction * distance,
                direction * (distance + 1),
                -direction * (distance + 1),
                -2,
                2,
                -3,
                3,
            ):
                candidate_ring = max(inner_start, min(inner_end - 1, source_ring + target_offset))
                if candidate_ring == source_ring:
                    continue
                candidate_guard = max(
                    path_mask[candidate_ring][index],
                    lava_mask[candidate_ring][index],
                    crater_loop_mask[candidate_ring][index],
                    path_mask[candidate_ring + 1][index],
                    lava_mask[candidate_ring + 1][index],
                    crater_loop_mask[candidate_ring + 1][index],
                )
                if candidate_guard <= 0.20:
                    target_ring = candidate_ring
                    break
            if target_ring is None:
                continue

            semantic_guard = max(
                path_mask[source_ring][index],
                lava_mask[source_ring][index],
                crater_loop_mask[source_ring][index],
                path_mask[source_ring + 1][index],
                lava_mask[source_ring + 1][index],
                crater_loop_mask[source_ring + 1][index],
                path_mask[target_ring][index],
                lava_mask[target_ring][index],
                crater_loop_mask[target_ring][index],
                path_mask[target_ring + 1][index],
                lava_mask[target_ring + 1][index],
                crater_loop_mask[target_ring + 1][index],
            )
            if semantic_guard > 0.20:
                continue

            base_strength = min(0.76, 0.48 + strength_base * 0.34)
            source_upper = column_broken[source_ring][index]
            source_lower = column_broken[source_ring + 1][index]
            source_sign = 1.0 if source_upper >= source_lower else -1.0

            for angular_offset, angular_weight in ((-2, 0.20), (-1, 0.54), (0, 1.0), (1, 0.54), (2, 0.20)):
                sample_index = (index + angular_offset) % radial_segments
                sample_angle = (sample_index / radial_segments) * math.tau
                sample_signed_angle = abs(math.atan2(math.sin(sample_angle), math.cos(sample_angle)))
                sample_approach_guard = 1.0 - _smoothstep(path_width * 0.85, path_width * 2.40, sample_signed_angle)
                neighbor_guard = max(
                    path_mask[source_ring][sample_index],
                    lava_mask[source_ring][sample_index],
                    crater_loop_mask[source_ring][sample_index],
                    path_mask[source_ring + 1][sample_index],
                    lava_mask[source_ring + 1][sample_index],
                    crater_loop_mask[source_ring + 1][sample_index],
                    path_mask[target_ring][sample_index],
                    lava_mask[target_ring][sample_index],
                    crater_loop_mask[target_ring][sample_index],
                    path_mask[target_ring + 1][sample_index],
                    lava_mask[target_ring + 1][sample_index],
                    crater_loop_mask[target_ring + 1][sample_index],
                    sample_approach_guard,
                )
                if neighbor_guard > 0.20:
                    continue

                source_strength = base_strength * angular_weight
                local_source_upper = column_broken[source_ring][sample_index]
                local_source_lower = column_broken[source_ring + 1][sample_index]
                local_source_mid = (local_source_upper + local_source_lower) * 0.50
                local_source_sign = 1.0 if local_source_upper >= local_source_lower else source_sign
                softened_delta = max(54.0, source_drop * (0.14 + 0.10 * (1.0 - angular_weight)))
                column_broken[source_ring][sample_index] = local_source_upper * (1.0 - source_strength) + (
                    local_source_mid + local_source_sign * softened_delta * 0.50
                ) * source_strength
                column_broken[source_ring + 1][sample_index] = local_source_lower * (1.0 - source_strength) + (
                    local_source_mid - local_source_sign * softened_delta * 0.50
                ) * source_strength

                target_upper = column_broken[target_ring][sample_index]
                target_lower = column_broken[target_ring + 1][sample_index]
                target_mid = (target_upper + target_lower) * 0.50
                target_sign = 1.0 if target_upper >= target_lower else source_sign
                target_delta = max(abs(target_upper - target_lower), source_drop * (0.88 + 0.26 * angular_weight))
                target_strength = min(0.76, base_strength * (0.48 + 0.48 * angular_weight))
                column_broken[target_ring][sample_index] = target_upper * (1.0 - target_strength) + (
                    target_mid + target_sign * target_delta * 0.50
                ) * target_strength
                column_broken[target_ring + 1][sample_index] = target_lower * (1.0 - target_strength) + (
                    target_mid - target_sign * target_delta * 0.50
                ) * target_strength

    # The breakline relocation above must read as a slump scar, not a new row of
    # angular teeth, so weather any fresh adjacent-column cliffs it introduced.
    for _post_relocation_pass in range(2):
        post_sums = [[0.0 for _index in range(radial_segments)] for _ring in range(rings + 1)]
        post_weights = [[0 for _index in range(radial_segments)] for _ring in range(rings + 1)]

        for index in range(radial_segments):
            next_index = (index + 1) % radial_segments
            for ring in range(inner_start, inner_end + 1):
                semantic_guard = max(
                    path_mask[ring][index],
                    lava_mask[ring][index],
                    crater_loop_mask[ring][index],
                    path_mask[ring][next_index],
                    lava_mask[ring][next_index],
                    crater_loop_mask[ring][next_index],
                )
                if semantic_guard > 0.20:
                    continue

                left = column_broken[ring][index]
                right = column_broken[ring][next_index]
                delta = left - right
                if abs(delta) <= 128.0:
                    continue

                midpoint = (left + right) * 0.5
                sign = 1.0 if delta >= 0.0 else -1.0
                fracture_phase = math.sin((index * 0.23 + ring * 1.31 + erosion_age * 2.1) * math.tau)
                target_delta = 48.0 + 14.0 * abs(fracture_phase)
                post_sums[ring][index] += midpoint + sign * target_delta * 0.5
                post_weights[ring][index] += 1
                post_sums[ring][next_index] += midpoint - sign * target_delta * 0.5
                post_weights[ring][next_index] += 1

        for ring in range(inner_start, inner_end + 1):
            for index in range(radial_segments):
                weight = post_weights[ring][index]
                if weight <= 0:
                    continue
                target = post_sums[ring][index] / weight
                column_broken[ring][index] = column_broken[ring][index] * 0.32 + target * 0.68

    weathered = column_broken

    return weathered


def _settle_fire_inner_wall_late_breakline_locks(
    heights: list[list[float]],
    path_mask: list[list[float]],
    crater_loop_mask: list[list[float]],
    lava_mask: list[list[float]],
    radial_segments: int,
    rings: int,
    controls: dict[str, object],
) -> list[list[float]]:
    settle_intensity = float(controls.get("terrain_settle_intensity", controls.get("terrain_relaxation_intensity", 0.0)))
    hero_resolution = _smoothstep(40.0, 52.0, float(rings))
    if settle_intensity <= 0.0 or hero_resolution <= 0.0 or radial_segments < 48 or rings < 20:
        return heights

    erosion_age = _clamp01(float(controls.get("erosion_age", 0.45)))
    path_width = float(controls.get("path_width", _preset("fire")["path_width"]))
    settled = [list(row) for row in heights]
    inner_start = max(2, round(rings * 0.28))
    inner_end = min(rings - 2, round(rings * 0.46))
    window_size = max(12, min(24, radial_segments // 16))

    for start in range(0, radial_segments, window_size):
        window_columns: list[tuple[int, int, int, float]] = []
        for column_offset in range(window_size):
            index = (start + column_offset) % radial_segments
            candidates = []
            for ring in range(inner_start, inner_end):
                semantic_guard = max(
                    path_mask[ring][index],
                    lava_mask[ring][index],
                    crater_loop_mask[ring][index],
                    path_mask[ring + 1][index],
                    lava_mask[ring + 1][index],
                    crater_loop_mask[ring + 1][index],
                )
                if semantic_guard > 0.20:
                    continue
                drop = abs(settled[ring + 1][index] - settled[ring][index])
                if drop > 260.0:
                    candidates.append((drop, ring))
            if candidates:
                drop, ring = max(candidates)
                window_columns.append((column_offset, index, ring, drop))

        if len(window_columns) < window_size * 0.45:
            continue

        break_rings = [ring for _offset, _index, ring, _drop in window_columns]
        ring_counts = {ring: break_rings.count(ring) for ring in set(break_rings)}
        dominant_ring, dominant_count = max(ring_counts.items(), key=lambda item: item[1])
        ring_spread = max(break_rings) - min(break_rings)
        dominant_coverage = dominant_count / len(window_columns)
        if dominant_coverage <= 0.86 or ring_spread >= 3:
            continue

        center_offsets = (2, 5, 8, 11, 14, 17, 20, 23) if window_size >= 24 else (2, 5, 8, 11)
        for center_offset in center_offsets:
            center_index = (start + center_offset) % radial_segments
            center_angle = (center_index / radial_segments) * math.tau
            center_signed_angle = abs(math.atan2(math.sin(center_angle), math.cos(center_angle)))
            main_approach_guard = 1.0 - _smoothstep(path_width * 0.85, path_width * 2.40, center_signed_angle)
            if main_approach_guard > 0.05:
                continue
            center_guard = max(
                path_mask[dominant_ring][center_index],
                lava_mask[dominant_ring][center_index],
                crater_loop_mask[dominant_ring][center_index],
                path_mask[dominant_ring + 1][center_index],
                lava_mask[dominant_ring + 1][center_index],
                crater_loop_mask[dominant_ring + 1][center_index],
            )
            if center_guard > 0.20:
                continue

            for angular_offset, angular_weight in ((-2, 0.18), (-1, 0.52), (0, 1.0), (1, 0.52), (2, 0.18)):
                index = (center_index + angular_offset) % radial_segments
                angle = (index / radial_segments) * math.tau
                signed_angle = abs(math.atan2(math.sin(angle), math.cos(angle)))
                approach_guard = 1.0 - _smoothstep(path_width * 0.85, path_width * 2.40, signed_angle)
                semantic_guard = max(
                    path_mask[dominant_ring][index],
                    lava_mask[dominant_ring][index],
                    crater_loop_mask[dominant_ring][index],
                    path_mask[dominant_ring + 1][index],
                    lava_mask[dominant_ring + 1][index],
                    crater_loop_mask[dominant_ring + 1][index],
                    approach_guard,
                )
                if semantic_guard > 0.20:
                    continue

                upper = settled[dominant_ring][index]
                lower = settled[dominant_ring + 1][index]
                current_drop = abs(lower - upper)
                if current_drop <= 252.0:
                    continue

                midpoint = (upper + lower) * 0.5
                sign = 1.0 if upper >= lower else -1.0
                scar_noise = math.sin((start * 0.071 + center_offset * 0.37 + index * 0.013 + erosion_age) * math.tau)
                target_delta = 150.0 + 28.0 * abs(scar_noise)
                strength = min(0.86, (0.58 + settle_intensity * 0.18 + hero_resolution * 0.10) * angular_weight)
                settled[dominant_ring][index] = upper * (1.0 - strength) + (
                    midpoint + sign * target_delta * 0.5
                ) * strength
                settled[dominant_ring + 1][index] = lower * (1.0 - strength) + (
                    midpoint - sign * target_delta * 0.5
                ) * strength

    for _post_pass in range(2):
        target_sums = [[0.0 for _index in range(radial_segments)] for _ring in range(rings + 1)]
        target_weights = [[0 for _index in range(radial_segments)] for _ring in range(rings + 1)]
        for index in range(radial_segments):
            next_index = (index + 1) % radial_segments
            for ring in range(inner_start, inner_end + 1):
                semantic_guard = max(
                    path_mask[ring][index],
                    lava_mask[ring][index],
                    crater_loop_mask[ring][index],
                    path_mask[ring][next_index],
                    lava_mask[ring][next_index],
                    crater_loop_mask[ring][next_index],
                )
                if semantic_guard > 0.20:
                    continue
                left = settled[ring][index]
                right = settled[ring][next_index]
                delta = left - right
                if abs(delta) <= 132.0:
                    continue
                midpoint = (left + right) * 0.5
                sign = 1.0 if delta >= 0.0 else -1.0
                target_delta = 50.0 + 10.0 * abs(math.sin((index * 0.19 + ring * 1.47 + erosion_age) * math.tau))
                target_sums[ring][index] += midpoint + sign * target_delta * 0.5
                target_weights[ring][index] += 1
                target_sums[ring][next_index] += midpoint - sign * target_delta * 0.5
                target_weights[ring][next_index] += 1

        for ring in range(inner_start, inner_end + 1):
            for index in range(radial_segments):
                weight = target_weights[ring][index]
                if weight <= 0:
                    continue
                target = target_sums[ring][index] / weight
                settled[ring][index] = settled[ring][index] * 0.34 + target * 0.66

    for start in range(0, radial_segments, window_size):
        window_columns: list[tuple[int, int, int, float]] = []
        for column_offset in range(window_size):
            index = (start + column_offset) % radial_segments
            candidates = []
            for ring in range(inner_start, inner_end):
                semantic_guard = max(
                    path_mask[ring][index],
                    lava_mask[ring][index],
                    crater_loop_mask[ring][index],
                    path_mask[ring + 1][index],
                    lava_mask[ring + 1][index],
                    crater_loop_mask[ring + 1][index],
                )
                if semantic_guard > 0.20:
                    continue
                drop = abs(settled[ring + 1][index] - settled[ring][index])
                if drop > 260.0:
                    candidates.append((drop, ring))
            if candidates:
                drop, ring = max(candidates)
                window_columns.append((column_offset, index, ring, drop))

        if len(window_columns) < window_size * 0.45:
            continue

        break_rings = [ring for _offset, _index, ring, _drop in window_columns]
        ring_counts = {ring: break_rings.count(ring) for ring in set(break_rings)}
        dominant_ring, dominant_count = max(ring_counts.items(), key=lambda item: item[1])
        dominant_coverage = dominant_count / len(window_columns)
        ring_spread = max(break_rings) - min(break_rings)
        if dominant_coverage <= 0.86 or ring_spread >= 3:
            continue

        for column_offset, index, ring, drop in window_columns:
            if ring != dominant_ring or drop <= 252.0:
                continue
            if column_offset % 4 not in (1, 2):
                continue

            upper = settled[ring][index]
            lower = settled[ring + 1][index]
            delta = lower - upper
            midpoint = (upper + lower) * 0.5
            sign = 1.0 if delta >= 0.0 else -1.0
            target_delta = 148.0 + 20.0 * abs(math.sin((start * 0.053 + column_offset * 0.29 + ring) * math.tau))
            strength = min(0.92, 0.72 + settle_intensity * 0.12 + hero_resolution * 0.08)
            settled[ring][index] = upper * (1.0 - strength) + (
                midpoint - sign * target_delta * 0.5
            ) * strength
            settled[ring + 1][index] = lower * (1.0 - strength) + (
                midpoint + sign * target_delta * 0.5
            ) * strength

    cap_end = min(inner_end, round(rings * 0.40))
    for _post_pass in range(2):
        target_sums = [[0.0 for _index in range(radial_segments)] for _ring in range(rings + 1)]
        target_weights = [[0 for _index in range(radial_segments)] for _ring in range(rings + 1)]
        for index in range(radial_segments):
            next_index = (index + 1) % radial_segments
            for ring in range(inner_start, cap_end + 1):
                semantic_guard = max(
                    path_mask[ring][index],
                    lava_mask[ring][index],
                    crater_loop_mask[ring][index],
                    path_mask[ring][next_index],
                    lava_mask[ring][next_index],
                    crater_loop_mask[ring][next_index],
                )
                if semantic_guard > 0.20:
                    continue
                left = settled[ring][index]
                right = settled[ring][next_index]
                delta = left - right
                if abs(delta) <= 128.0:
                    continue
                midpoint = (left + right) * 0.5
                sign = 1.0 if delta >= 0.0 else -1.0
                target_delta = 48.0 + 10.0 * abs(math.sin((index * 0.17 + ring * 1.31 + erosion_age) * math.tau))
                target_sums[ring][index] += midpoint + sign * target_delta * 0.5
                target_weights[ring][index] += 1
                target_sums[ring][next_index] += midpoint - sign * target_delta * 0.5
                target_weights[ring][next_index] += 1

        for ring in range(inner_start, cap_end + 1):
            for index in range(radial_segments):
                weight = target_weights[ring][index]
                if weight <= 0:
                    continue
                target = target_sums[ring][index] / weight
                settled[ring][index] = settled[ring][index] * 0.26 + target * 0.74

    return settled


def _restore_fire_front_inner_breach_wall_drop(
    heights: list[list[float]],
    path_mask: list[list[float]],
    crater_loop_mask: list[list[float]],
    lava_mask: list[list[float]],
    radial_segments: int,
    rings: int,
    controls: dict[str, object],
) -> list[list[float]]:
    settle_intensity = float(controls.get("terrain_settle_intensity", controls.get("terrain_relaxation_intensity", 0.0)))
    hero_resolution = _smoothstep(40.0, 52.0, float(rings))
    if settle_intensity <= 0.0 or hero_resolution <= 0.0 or radial_segments < 48 or rings < 20:
        return heights

    erosion_age = _clamp01(float(controls.get("erosion_age", 0.45)))
    path_width = float(controls.get("path_width", _preset("fire")["path_width"]))
    restored = [list(row) for row in heights]
    ring_start = max(2, round(rings * 0.30))
    ring_end = min(rings - 2, round(rings * 0.38))
    arc_span = max(18, min(radial_segments // 8, round(radial_segments * 0.08)))
    arc_indices = list(range(radial_segments - arc_span, radial_segments)) + list(range(0, arc_span + 1))

    for ring in range(ring_start, ring_end + 1):
        radial_alpha = ring / rings if rings else 0.0
        radial_band = _smoothstep(0.295, 0.315, radial_alpha) * (1.0 - _smoothstep(0.385, 0.405, radial_alpha))
        if radial_band <= 0.0:
            continue

        for index in arc_indices:
            angle = (index / radial_segments) * math.tau
            signed_angle = abs(math.atan2(math.sin(angle), math.cos(angle)))
            front_band = 1.0 - _smoothstep(path_width * 0.50, path_width * 1.42, signed_angle)
            if front_band <= 0.0:
                continue

            semantic_guard = max(
                path_mask[ring][index],
                lava_mask[ring][index],
                crater_loop_mask[ring][index],
                path_mask[ring + 1][index],
                lava_mask[ring + 1][index],
                crater_loop_mask[ring + 1][index],
            )
            if semantic_guard > 0.22:
                continue

            upper = restored[ring][index]
            lower = restored[ring + 1][index]
            current_delta = lower - upper
            current_drop = abs(current_delta)
            if current_drop >= 326.0:
                continue

            sign = 1.0 if current_delta >= 0.0 else -1.0
            midpoint = (upper + lower) * 0.5
            target_delta = 336.0 + 26.0 * abs(math.sin((index * 0.021 + ring * 0.73 + erosion_age) * math.tau))
            strength = min(0.92, (0.74 + settle_intensity * 0.12 + hero_resolution * 0.06) * radial_band * front_band)
            restored[ring][index] = upper * (1.0 - strength) + (
                midpoint - sign * target_delta * 0.5
            ) * strength
            restored[ring + 1][index] = lower * (1.0 - strength) + (
                midpoint + sign * target_delta * 0.5
            ) * strength

    arc_order = list(range(radial_segments - arc_span, radial_segments)) + list(range(0, arc_span + 1))
    for ring in range(ring_start, min(rings - 1, ring_end + 2) + 1):
        capped = [restored[ring][index] for index in arc_order]
        active = []
        for index in arc_order:
            angle = (index / radial_segments) * math.tau
            signed_angle = abs(math.atan2(math.sin(angle), math.cos(angle)))
            front_band = 1.0 - _smoothstep(path_width * 0.54, path_width * 1.46, signed_angle)
            semantic_guard = max(path_mask[ring][index], lava_mask[ring][index], crater_loop_mask[ring][index])
            active.append(front_band > 0.0 and semantic_guard <= 0.24)

        max_delta = 188.0
        for _cap_pass in range(4):
            for offset in range(1, len(capped)):
                if not active[offset] or not active[offset - 1]:
                    continue
                previous = capped[offset - 1]
                if capped[offset] > previous + max_delta:
                    capped[offset] = previous + max_delta
                elif capped[offset] < previous - max_delta:
                    capped[offset] = previous - max_delta
            for offset in range(len(capped) - 2, -1, -1):
                if not active[offset] or not active[offset + 1]:
                    continue
                next_value = capped[offset + 1]
                if capped[offset] > next_value + max_delta:
                    capped[offset] = next_value + max_delta
                elif capped[offset] < next_value - max_delta:
                    capped[offset] = next_value - max_delta

        for offset, index in enumerate(arc_order):
            if not active[offset]:
                continue
            restored[ring][index] = restored[ring][index] * 0.18 + capped[offset] * 0.82

    return restored


def _settle_fire_upper_wall_lateral_weathering_shelves(
    heights: list[list[float]],
    path_mask: list[list[float]],
    crater_loop_mask: list[list[float]],
    lava_mask: list[list[float]],
    radial_segments: int,
    rings: int,
    controls: dict[str, object],
) -> list[list[float]]:
    settle_intensity = float(controls.get("terrain_settle_intensity", controls.get("terrain_relaxation_intensity", 0.0)))
    hero_resolution = _smoothstep(40.0, 52.0, float(rings))
    if settle_intensity <= 0.0 or hero_resolution <= 0.0 or radial_segments < 48 or rings < 20:
        return heights

    erosion_age = _clamp01(float(controls.get("erosion_age", 0.45)))
    path_width = float(controls.get("path_width", _preset("fire")["path_width"]))
    shelfed = [list(row) for row in heights]
    wall_start = max(2, round(rings * 0.50))
    wall_end = min(rings - 2, round(rings * 0.54))
    if wall_end <= wall_start + 3:
        return shelfed

    steep_columns: list[bool] = []
    column_candidates: list[list[tuple[float, int]]] = []
    for index in range(radial_segments):
        candidates: list[tuple[float, int]] = []
        sampled_steps = 0
        for ring in range(wall_start, wall_end):
            semantic_guard = max(
                path_mask[ring][index],
                lava_mask[ring][index],
                crater_loop_mask[ring][index],
                path_mask[ring + 1][index],
                lava_mask[ring + 1][index],
                crater_loop_mask[ring + 1][index],
            )
            if semantic_guard > 0.25:
                continue
            sampled_steps += 1
            drop = abs(shelfed[ring + 1][index] - shelfed[ring][index])
            if drop > 240.0:
                candidates.append((drop, ring))

        column_candidates.append(sorted(candidates, reverse=True))
        steep_columns.append(sampled_steps >= 5 and len(candidates) >= 7)

    if not any(steep_columns):
        return shelfed

    runs: list[list[int]] = []
    visited = [False for _ in range(radial_segments)]
    for start in range(radial_segments):
        if visited[start] or not steep_columns[start]:
            continue
        run = []
        cursor = start
        while steep_columns[cursor] and not visited[cursor]:
            visited[cursor] = True
            run.append(cursor)
            cursor = (cursor + 1) % radial_segments
        if len(run) >= 16:
            runs.append(run)

    for run in runs:
        stride = 7 if len(run) >= 54 else 9
        for run_offset in range(stride // 2, len(run), stride):
            center_index = run[run_offset]
            angle = (center_index / radial_segments) * math.tau
            signed_angle = abs(math.atan2(math.sin(angle), math.cos(angle)))
            approach_guard = 1.0 - _smoothstep(path_width * 1.05, path_width * 2.55, signed_angle)
            if approach_guard > 0.10:
                continue

            center_candidates = column_candidates[center_index]
            if not center_candidates:
                continue

            chosen_rings = []
            for _drop, candidate_ring in center_candidates:
                if all(abs(candidate_ring - existing) > 1 for existing in chosen_rings):
                    chosen_rings.append(candidate_ring)
                if len(chosen_rings) >= 5:
                    break

            for shelf_index, source_ring in enumerate(chosen_rings):
                oblique_shift = -1 if (run_offset + shelf_index * 2) % 4 < 2 else 1
                for angular_offset, angular_weight in ((-3, 0.16), (-2, 0.34), (-1, 0.68), (0, 1.0), (1, 0.68), (2, 0.34), (3, 0.16)):
                    index = (center_index + angular_offset) % radial_segments
                    ring = max(wall_start, min(wall_end - 1, source_ring + oblique_shift * max(0, abs(angular_offset) - 1) // 2))
                    angle = (index / radial_segments) * math.tau
                    signed_angle = abs(math.atan2(math.sin(angle), math.cos(angle)))
                    approach_guard = 1.0 - _smoothstep(path_width * 1.05, path_width * 2.55, signed_angle)
                    semantic_guard = max(
                        path_mask[ring][index],
                        lava_mask[ring][index],
                        crater_loop_mask[ring][index],
                        path_mask[ring + 1][index],
                        lava_mask[ring + 1][index],
                        crater_loop_mask[ring + 1][index],
                        approach_guard,
                    )
                    if semantic_guard > 0.25:
                        continue

                    upper = shelfed[ring][index]
                    lower = shelfed[ring + 1][index]
                    delta = lower - upper
                    current_drop = abs(delta)
                    if current_drop <= 198.0:
                        continue

                    sign = 1.0 if delta >= 0.0 else -1.0
                    midpoint = (upper + lower) * 0.5
                    fracture_noise = abs(math.sin((index * 0.029 + ring * 0.83 + erosion_age + shelf_index * 0.41) * math.tau))
                    target_delta = 138.0 + 24.0 * fracture_noise
                    strength = min(0.96, (0.74 + settle_intensity * 0.16 + hero_resolution * 0.06) * angular_weight)
                    shelfed[ring][index] = upper * (1.0 - strength) + (
                        midpoint - sign * target_delta * 0.5
                    ) * strength
                    shelfed[ring + 1][index] = lower * (1.0 - strength) + (
                        midpoint + sign * target_delta * 0.5
                    ) * strength

    return shelfed


def _settle_fire_upper_wall_visual_crosscut_shelves(
    heights: list[list[float]],
    path_mask: list[list[float]],
    crater_loop_mask: list[list[float]],
    lava_mask: list[list[float]],
    radial_segments: int,
    rings: int,
    controls: dict[str, object],
) -> list[list[float]]:
    settle_intensity = float(controls.get("terrain_settle_intensity", controls.get("terrain_relaxation_intensity", 0.0)))
    hero_resolution = _smoothstep(40.0, 52.0, float(rings))
    if settle_intensity <= 0.0 or hero_resolution <= 0.0 or radial_segments < 48 or rings < 20:
        return heights

    erosion_age = _clamp01(float(controls.get("erosion_age", 0.45)))
    process_strength = hero_resolution * min(0.76, settle_intensity * 0.34 + erosion_age * 0.22)
    if process_strength <= 0.0:
        return heights

    crosscut = [list(row) for row in heights]
    wall_start = max(2, round(rings * 0.36))
    wall_end = min(rings - 2, round(rings * 0.54))
    window_size = max(12, min(24, radial_segments // 16))

    for start in range(0, radial_segments, window_size):
        row_metrics: list[tuple[int, float, float]] = []
        vertical_rows = 0
        crosscut_rows = 0

        for ring in range(wall_start, wall_end):
            row_drops = []
            for offset in range(window_size):
                index = (start + offset) % radial_segments
                semantic_guard = max(
                    path_mask[ring][index],
                    lava_mask[ring][index],
                    crater_loop_mask[ring][index],
                    path_mask[ring + 1][index],
                    lava_mask[ring + 1][index],
                    crater_loop_mask[ring + 1][index],
                )
                if semantic_guard > 0.25:
                    continue
                row_drops.append(abs(crosscut[ring + 1][index] - crosscut[ring][index]))

            if len(row_drops) < max(8, window_size // 3):
                continue

            sorted_drops = sorted(row_drops)
            row_median = statistics.median(row_drops)
            row_q75 = sorted_drops[round((len(sorted_drops) - 1) * 0.75)]
            row_metrics.append((ring, row_median, row_q75))
            if row_median > 240.0:
                vertical_rows += 1
            if row_median < 210.0 and row_q75 < 300.0:
                crosscut_rows += 1

        if vertical_rows < 6 or crosscut_rows >= 2:
            continue

        vertical_candidates = [ring for ring, row_median, _row_q75 in row_metrics if row_median > 240.0]
        if not vertical_candidates:
            continue

        needed_shelves = min(4, max(2, 3 - crosscut_rows))
        chosen_rings = []
        for shelf_number in range(needed_shelves):
            fraction = (shelf_number + 1) / (needed_shelves + 1)
            candidate = vertical_candidates[min(len(vertical_candidates) - 1, round((len(vertical_candidates) - 1) * fraction))]
            if all(abs(candidate - existing) >= 2 for existing in chosen_rings):
                chosen_rings.append(candidate)

        for shelf_number, ring in enumerate(chosen_rings):
            for offset in range(window_size):
                index = (start + offset) % radial_segments
                semantic_guard = max(
                    path_mask[ring][index],
                    lava_mask[ring][index],
                    crater_loop_mask[ring][index],
                    path_mask[ring + 1][index],
                    lava_mask[ring + 1][index],
                    crater_loop_mask[ring + 1][index],
                )
                if semantic_guard > 0.25:
                    continue

                upper = crosscut[ring][index]
                lower = crosscut[ring + 1][index]
                delta = lower - upper
                current_drop = abs(delta)
                if current_drop <= 185.0:
                    continue

                midpoint = (upper + lower) * 0.5
                sign = 1.0 if delta >= 0.0 else -1.0
                shelf_noise = abs(math.sin((start * 0.017 + offset * 0.071 + ring * 0.53 + shelf_number) * math.tau))
                target_delta = 96.0 + 30.0 * shelf_noise
                edge_weight = 0.88 + 0.12 * _smoothstep(0.0, window_size * 0.24, min(offset, window_size - 1 - offset))
                strength = min(0.98, (0.78 + process_strength * 0.24) * edge_weight)
                crosscut[ring][index] = upper * (1.0 - strength) + (
                    midpoint - sign * target_delta * 0.5
                ) * strength
                crosscut[ring + 1][index] = lower * (1.0 - strength) + (
                    midpoint + sign * target_delta * 0.5
                ) * strength

    for start in range(0, radial_segments, window_size):
        strongest_break_rings: list[int] = []
        for offset in range(window_size):
            index = (start + offset) % radial_segments
            candidates: list[tuple[float, int]] = []
            for ring in range(wall_start, wall_end):
                semantic_guard = max(
                    path_mask[ring][index],
                    lava_mask[ring][index],
                    crater_loop_mask[ring][index],
                    path_mask[ring + 1][index],
                    lava_mask[ring + 1][index],
                    crater_loop_mask[ring + 1][index],
                )
                if semantic_guard > 0.25:
                    continue
                drop = abs(crosscut[ring + 1][index] - crosscut[ring][index])
                if drop > 225.0:
                    candidates.append((drop, ring))

            if candidates:
                _drop, break_ring = max(candidates)
                strongest_break_rings.append(break_ring)

        if len(strongest_break_rings) < window_size * 0.50:
            continue

        adjacent_shifts = [
            abs(strongest_break_rings[index + 1] - strongest_break_rings[index])
            for index in range(len(strongest_break_rings) - 1)
        ]
        big_diagonal_steps = sum(1 for shift in adjacent_shifts if shift >= 2)
        ring_spread = max(strongest_break_rings) - min(strongest_break_rings)
        dominant_ring_coverage = max(
            strongest_break_rings.count(ring) for ring in set(strongest_break_rings)
        ) / len(strongest_break_rings)
        if ring_spread >= 4 and big_diagonal_steps >= 3 and dominant_ring_coverage <= 0.58:
            continue

        stagger_span = max(4, wall_end - wall_start - 1)
        window_id = start // window_size
        for offset in range(window_size):
            index = (start + offset) % radial_segments
            target_ring = wall_start + 1 + (((offset // 2) * 2 + window_id * 3) % stagger_span)
            target_ring = max(wall_start, min(wall_end - 1, target_ring))

            candidates = []
            for ring in range(wall_start, wall_end):
                semantic_guard = max(
                    path_mask[ring][index],
                    lava_mask[ring][index],
                    crater_loop_mask[ring][index],
                    path_mask[ring + 1][index],
                    lava_mask[ring + 1][index],
                    crater_loop_mask[ring + 1][index],
                )
                if semantic_guard > 0.25:
                    continue
                candidates.append((abs(crosscut[ring + 1][index] - crosscut[ring][index]), ring))

            if not candidates:
                continue

            current_drop, current_ring = max(candidates)
            if current_drop > 205.0 and abs(current_ring - target_ring) > 1:
                upper = crosscut[current_ring][index]
                lower = crosscut[current_ring + 1][index]
                midpoint = (upper + lower) * 0.5
                sign = 1.0 if lower >= upper else -1.0
                target_delta = 138.0 + 18.0 * abs(
                    math.sin((start * 0.013 + offset * 0.097 + current_ring * 0.37) * math.tau)
                )
                strength = min(0.88, 0.68 + process_strength * 0.22)
                crosscut[current_ring][index] = upper * (1.0 - strength) + (
                    midpoint - sign * target_delta * 0.5
                ) * strength
                crosscut[current_ring + 1][index] = lower * (1.0 - strength) + (
                    midpoint + sign * target_delta * 0.5
                ) * strength

            semantic_guard = max(
                path_mask[target_ring][index],
                lava_mask[target_ring][index],
                crater_loop_mask[target_ring][index],
                path_mask[target_ring + 1][index],
                lava_mask[target_ring + 1][index],
                crater_loop_mask[target_ring + 1][index],
            )
            if semantic_guard > 0.25:
                continue

            upper = crosscut[target_ring][index]
            lower = crosscut[target_ring + 1][index]
            delta = lower - upper
            midpoint = (upper + lower) * 0.5
            sign = 1.0 if delta >= 0.0 else -1.0
            target_delta = 248.0 + 24.0 * abs(
                math.sin((window_id * 0.31 + offset * 0.173 + target_ring * 0.23 + erosion_age) * math.tau)
            )
            strength = min(0.72, 0.48 + process_strength * 0.20)
            crosscut[target_ring][index] = upper * (1.0 - strength) + (
                midpoint - sign * target_delta * 0.5
            ) * strength
            crosscut[target_ring + 1][index] = lower * (1.0 - strength) + (
                midpoint + sign * target_delta * 0.5
            ) * strength

    for start in range(0, radial_segments, window_size):
        row_metrics: list[tuple[int, float, float]] = []
        vertical_rows = 0
        crosscut_rows = 0
        for ring in range(wall_start, wall_end):
            row_drops = []
            for offset in range(window_size):
                index = (start + offset) % radial_segments
                semantic_guard = max(
                    path_mask[ring][index],
                    lava_mask[ring][index],
                    crater_loop_mask[ring][index],
                    path_mask[ring + 1][index],
                    lava_mask[ring + 1][index],
                    crater_loop_mask[ring + 1][index],
                )
                if semantic_guard > 0.25:
                    continue
                row_drops.append(abs(crosscut[ring + 1][index] - crosscut[ring][index]))

            if len(row_drops) < max(8, window_size // 3):
                continue

            sorted_drops = sorted(row_drops)
            row_median = statistics.median(row_drops)
            row_q75 = sorted_drops[round((len(sorted_drops) - 1) * 0.75)]
            row_metrics.append((ring, row_median, row_q75))
            if row_median > 240.0:
                vertical_rows += 1
            if row_median < 210.0 and row_q75 < 300.0:
                crosscut_rows += 1

        if vertical_rows < 6 or crosscut_rows >= 2:
            continue

        vertical_candidates = [ring for ring, row_median, _row_q75 in row_metrics if row_median > 240.0]
        needed_shelves = min(3, max(1, 2 - crosscut_rows))
        for shelf_number in range(needed_shelves):
            if not vertical_candidates:
                break
            fraction = (shelf_number + 1) / (needed_shelves + 1)
            ring = vertical_candidates[min(len(vertical_candidates) - 1, round((len(vertical_candidates) - 1) * fraction))]
            for offset in range(window_size):
                index = (start + offset) % radial_segments
                semantic_guard = max(
                    path_mask[ring][index],
                    lava_mask[ring][index],
                    crater_loop_mask[ring][index],
                    path_mask[ring + 1][index],
                    lava_mask[ring + 1][index],
                    crater_loop_mask[ring + 1][index],
                )
                if semantic_guard > 0.25:
                    continue

                upper = crosscut[ring][index]
                lower = crosscut[ring + 1][index]
                delta = lower - upper
                if abs(delta) <= 178.0:
                    continue
                midpoint = (upper + lower) * 0.5
                sign = 1.0 if delta >= 0.0 else -1.0
                shelf_noise = abs(math.sin((start * 0.021 + offset * 0.049 + ring * 0.61 + shelf_number) * math.tau))
                target_delta = 94.0 + shelf_noise * 24.0
                strength = min(0.98, 0.80 + process_strength * 0.22)
                crosscut[ring][index] = upper * (1.0 - strength) + (
                    midpoint - sign * target_delta * 0.5
                ) * strength
                crosscut[ring + 1][index] = lower * (1.0 - strength) + (
                    midpoint + sign * target_delta * 0.5
                ) * strength

    for start in range(0, radial_segments, window_size):
        column_metrics: list[tuple[int, bool, int, float, list[tuple[float, int]]]] = []
        for offset in range(window_size):
            index = (start + offset) % radial_segments
            steep_steps = 0
            sampled_steps = 0
            drops: list[tuple[float, int]] = []
            for ring in range(wall_start, wall_end):
                semantic_guard = max(
                    path_mask[ring][index],
                    lava_mask[ring][index],
                    crater_loop_mask[ring][index],
                    path_mask[ring + 1][index],
                    lava_mask[ring + 1][index],
                    crater_loop_mask[ring + 1][index],
                )
                if semantic_guard > 0.25:
                    continue
                sampled_steps += 1
                drop = abs(crosscut[ring + 1][index] - crosscut[ring][index])
                drops.append((drop, ring))
                if drop > 240.0:
                    steep_steps += 1

            flagged = sampled_steps >= 5 and steep_steps >= 5
            max_drop = max((drop for drop, _ring in drops), default=0.0)
            column_metrics.append((offset, flagged, steep_steps, max_drop, sorted(drops, reverse=True)))

        flags = [flagged for _offset, flagged, _steep_steps, _max_drop, _drops in column_metrics]
        if sum(flags) <= 14:
            run = 0
            longest_run = 0
            for flag in flags:
                if flag:
                    run += 1
                    longest_run = max(longest_run, run)
                else:
                    run = 0
            if longest_run <= 10:
                continue

        target_offsets: set[int] = set()
        run_start: int | None = None
        for offset, flag in enumerate(flags + [False]):
            if flag and run_start is None:
                run_start = offset
            if (not flag or offset == len(flags)) and run_start is not None:
                run_end = offset
                run_length = run_end - run_start
                if run_length > 10:
                    for target_offset in range(run_start + 4, run_end, 4):
                        target_offsets.add(target_offset)
                run_start = None

        if sum(flags) - len(target_offsets) > 14:
            extra_columns = sorted(
                (
                    (steep_steps, max_drop, offset)
                    for offset, flagged, steep_steps, max_drop, _drops in column_metrics
                    if flagged and offset not in target_offsets
                ),
                reverse=True,
            )
            for _steep_steps, _max_drop, offset in extra_columns:
                target_offsets.add(offset)
                if sum(flags) - len(target_offsets) <= 14:
                    break

        for offset in sorted(target_offsets):
            if offset >= len(column_metrics):
                continue
            index = (start + offset) % radial_segments
            _offset, flagged, steep_steps, _max_drop, drops = column_metrics[offset]
            if not flagged:
                continue
            adjusted = 0
            max_adjustments = min(4, max(1, steep_steps - 4))
            for drop, ring in drops:
                if adjusted >= max_adjustments or drop <= 230.0:
                    break
                semantic_guard = max(
                    path_mask[ring][index],
                    lava_mask[ring][index],
                    crater_loop_mask[ring][index],
                    path_mask[ring + 1][index],
                    lava_mask[ring + 1][index],
                    crater_loop_mask[ring + 1][index],
                )
                if semantic_guard > 0.25:
                    continue

                upper = crosscut[ring][index]
                lower = crosscut[ring + 1][index]
                delta = lower - upper
                midpoint = (upper + lower) * 0.5
                sign = 1.0 if delta >= 0.0 else -1.0
                shelf_noise = abs(math.sin((start * 0.019 + offset * 0.083 + ring * 0.47) * math.tau))
                target_delta = 118.0 + shelf_noise * 28.0
                strength = min(0.92, 0.72 + process_strength * 0.18)
                crosscut[ring][index] = upper * (1.0 - strength) + (
                    midpoint - sign * target_delta * 0.5
                ) * strength
                crosscut[ring + 1][index] = lower * (1.0 - strength) + (
                    midpoint + sign * target_delta * 0.5
                ) * strength
                adjusted += 1

    return crosscut


def _shape_fire_upper_wall_nonconcentric_crest_bays(
    heights: list[list[float]],
    path_mask: list[list[float]],
    crater_loop_mask: list[list[float]],
    lava_mask: list[list[float]],
    radial_segments: int,
    rings: int,
    controls: dict[str, object],
) -> list[list[float]]:
    settle_intensity = float(controls.get("terrain_settle_intensity", controls.get("terrain_relaxation_intensity", 0.0)))
    hero_resolution = _smoothstep(40.0, 52.0, float(rings))
    if settle_intensity <= 0.0 or hero_resolution <= 0.0 or radial_segments < 48 or rings < 20:
        return heights

    erosion_age = _clamp01(float(controls.get("erosion_age", 0.45)))
    process_strength = hero_resolution * min(0.78, settle_intensity * 0.34 + erosion_age * 0.24)
    if process_strength <= 0.0:
        return heights

    shaped = [list(row) for row in heights]
    wall_start = max(2, round(rings * 0.32))
    wall_end = min(rings - 2, round(rings * 0.58))
    window_size = max(12, min(24, radial_segments // 16))
    if wall_end <= wall_start + 6:
        return shaped

    for start in range(0, radial_segments, window_size):
        crest_columns: list[tuple[int, int, float]] = []
        for offset in range(window_size):
            index = (start + offset) % radial_segments
            candidates = []
            for ring in range(wall_start, wall_end + 1):
                semantic_guard = max(
                    path_mask[ring][index],
                    lava_mask[ring][index],
                    crater_loop_mask[ring][index],
                )
                if semantic_guard > 0.45:
                    continue
                candidates.append((shaped[ring][index], ring))

            if candidates:
                crest_height, crest_ring = max(candidates)
                crest_columns.append((index, crest_ring, crest_height))

        if len(crest_columns) < window_size * 0.50:
            continue

        crest_rings = [ring for _index, ring, _height in crest_columns]
        ring_spread = max(crest_rings) - min(crest_rings)
        adjacent_shifts = [abs(crest_rings[i + 1] - crest_rings[i]) for i in range(len(crest_rings) - 1)]
        big_shifts = sum(1 for shift in adjacent_shifts if shift >= 2)
        dominant_coverage = max(crest_rings.count(ring) for ring in set(crest_rings)) / len(crest_rings)
        if ring_spread >= 4 and big_shifts >= 2 and dominant_coverage <= 0.74:
            continue

        window_id = start // window_size
        for offset, (index, crest_ring, crest_height) in enumerate(crest_columns):
            bay_index = min(2, int((offset / max(1, window_size)) * 3.0))
            eligible_rings = [
                ring
                for ring in range(wall_start, wall_end + 1)
                if max(path_mask[ring][index], lava_mask[ring][index], crater_loop_mask[ring][index]) <= 0.45
            ]
            if len(eligible_rings) < 4:
                continue

            target_fraction = (0.08, 0.50, 0.92)[bay_index]
            target_ring = eligible_rings[round((len(eligible_rings) - 1) * target_fraction)]
            if abs(target_ring - crest_ring) <= 1:
                shifted_candidates = [ring for ring in eligible_rings if abs(ring - crest_ring) > 1]
                if not shifted_candidates:
                    continue
                target_ring = shifted_candidates[round((len(shifted_candidates) - 1) * target_fraction)]
            if abs(target_ring - crest_ring) <= 1:
                continue

            semantic_guard = max(
                path_mask[target_ring][index],
                lava_mask[target_ring][index],
                crater_loop_mask[target_ring][index],
                path_mask[crest_ring][index],
                lava_mask[crest_ring][index],
                crater_loop_mask[crest_ring][index],
            )
            if semantic_guard > 0.45:
                continue

            target_height = shaped[target_ring][index]
            lift_strength = min(0.78, 0.50 + process_strength * 0.26)
            collapse_strength = min(0.72, 0.46 + process_strength * 0.22)
            bay_noise = abs(math.sin((window_id * 0.37 + offset * 0.061 + target_ring * 0.19) * math.tau))
            crest_bias = 34.0 + bay_noise * 38.0
            target_goal = crest_height - crest_bias
            crest_goal = target_height - (52.0 + bay_noise * 42.0)

            shaped[target_ring][index] = target_height * (1.0 - lift_strength) + target_goal * lift_strength
            shaped[crest_ring][index] = crest_height * (1.0 - collapse_strength) + crest_goal * collapse_strength

            for neighbor_offset, neighbor_weight in ((-1, 0.38), (1, 0.38)):
                neighbor_ring = target_ring + neighbor_offset
                if neighbor_ring < wall_start or neighbor_ring > wall_end:
                    continue
                if max(path_mask[neighbor_ring][index], lava_mask[neighbor_ring][index], crater_loop_mask[neighbor_ring][index]) > 0.45:
                    continue
                neighbor_height = shaped[neighbor_ring][index]
                neighbor_goal = target_goal - 58.0 - abs(neighbor_offset) * 28.0
                strength = lift_strength * neighbor_weight
                shaped[neighbor_ring][index] = neighbor_height * (1.0 - strength) + neighbor_goal * strength

            for neighbor_offset, neighbor_weight in ((-1, 0.24), (1, 0.24)):
                neighbor_ring = crest_ring + neighbor_offset
                if neighbor_ring < wall_start or neighbor_ring > wall_end:
                    continue
                if max(path_mask[neighbor_ring][index], lava_mask[neighbor_ring][index], crater_loop_mask[neighbor_ring][index]) > 0.45:
                    continue
                neighbor_height = shaped[neighbor_ring][index]
                neighbor_goal = crest_goal + 54.0
                strength = collapse_strength * neighbor_weight
                shaped[neighbor_ring][index] = neighbor_height * (1.0 - strength) + neighbor_goal * strength

        for _smooth_pass in range(2):
            next_heights = [list(row) for row in shaped]
            for ring in range(wall_start, wall_end + 1):
                for offset in range(window_size):
                    index = (start + offset) % radial_segments
                    previous_index = (index - 1) % radial_segments
                    next_index = (index + 1) % radial_segments
                    semantic_guard = max(
                        path_mask[ring][index],
                        lava_mask[ring][index],
                        crater_loop_mask[ring][index],
                        path_mask[ring][previous_index],
                        lava_mask[ring][previous_index],
                        crater_loop_mask[ring][previous_index],
                        path_mask[ring][next_index],
                        lava_mask[ring][next_index],
                        crater_loop_mask[ring][next_index],
                    )
                    if semantic_guard > 0.45:
                        continue
                    angular_target = shaped[ring][index] * 0.50 + shaped[ring][previous_index] * 0.25 + shaped[ring][next_index] * 0.25
                    smooth_strength = 0.42 * process_strength * (1.0 - semantic_guard)
                    next_heights[ring][index] = shaped[ring][index] * (1.0 - smooth_strength) + angular_target * smooth_strength
            shaped = next_heights

    max_angular_delta = 188.0
    for _cap_pass in range(5):
        weighted_targets = [[0.0 for _ in range(radial_segments)] for _ in range(rings + 1)]
        weights = [[0.0 for _ in range(radial_segments)] for _ in range(rings + 1)]
        for ring in range(wall_start, wall_end + 1):
            for index in range(radial_segments):
                next_index = (index + 1) % radial_segments
                semantic_guard = max(
                    path_mask[ring][index],
                    lava_mask[ring][index],
                    crater_loop_mask[ring][index],
                    path_mask[ring][next_index],
                    lava_mask[ring][next_index],
                    crater_loop_mask[ring][next_index],
                )
                if semantic_guard > 0.45:
                    continue

                left_height = shaped[ring][index]
                right_height = shaped[ring][next_index]
                delta = left_height - right_height
                if abs(delta) <= max_angular_delta:
                    continue

                sign = 1.0 if delta >= 0.0 else -1.0
                midpoint = (left_height + right_height) * 0.5
                left_target = midpoint + sign * max_angular_delta * 0.5
                right_target = midpoint - sign * max_angular_delta * 0.5
                strength = min(0.92, 0.68 + process_strength * 0.24) * (1.0 - semantic_guard)
                weighted_targets[ring][index] += left_target * strength
                weights[ring][index] += strength
                weighted_targets[ring][next_index] += right_target * strength
                weights[ring][next_index] += strength

        changed = False
        next_heights = [list(row) for row in shaped]
        for ring in range(wall_start, wall_end + 1):
            for index in range(radial_segments):
                weight = min(0.88, weights[ring][index])
                if weight <= 0.0:
                    continue
                target = weighted_targets[ring][index] / weights[ring][index]
                next_heights[ring][index] = shaped[ring][index] * (1.0 - weight) + target * weight
                changed = True
        shaped = next_heights
        if not changed:
            break

    return shaped


def _weather_fire_front_breach_ash_drape(
    heights: list[list[float]],
    path_mask: list[list[float]],
    crater_loop_mask: list[list[float]],
    lava_mask: list[list[float]],
    radial_segments: int,
    rings: int,
    controls: dict[str, object],
) -> list[list[float]]:
    settle_intensity = float(controls.get("terrain_settle_intensity", controls.get("terrain_relaxation_intensity", 0.0)))
    hero_resolution = _smoothstep(40.0, 52.0, float(rings))
    if settle_intensity <= 0.0 or hero_resolution <= 0.0 or rings < 20:
        return heights

    erosion_age = _clamp01(float(controls.get("erosion_age", 0.45)))
    deposition_weight = _clamp01(float(controls.get("deposition_weight", 0.55)))
    path_width = float(controls.get("path_width", _preset("fire")["path_width"]))
    process_strength = hero_resolution * min(0.68, settle_intensity * 0.38 + erosion_age * 0.14 + deposition_weight * 0.18)
    if process_strength <= 0.0:
        return heights

    weathered = [list(row) for row in heights]
    passes = 3 if process_strength > 0.38 else 2
    for _ in range(passes):
        next_heights = [list(row) for row in weathered]
        for ring in range(2, rings - 1):
            radial_alpha = ring / rings if rings else 0.0
            wall_band = _smoothstep(0.27, 0.32, radial_alpha) * (1.0 - _smoothstep(0.39, 0.43, radial_alpha))
            if wall_band <= 0.0:
                continue

            for index in range(radial_segments):
                angle = (index / radial_segments) * math.tau
                signed_angle = abs(math.atan2(math.sin(angle), math.cos(angle)))
                breach_shoulder = _smoothstep(path_width * 0.28, path_width * 0.56, signed_angle) * (
                    1.0 - _smoothstep(path_width * 0.96, path_width * 1.36, signed_angle)
                )
                entry_shoulder_drape = _smoothstep(path_width * 0.34, path_width * 0.54, signed_angle) * (
                    1.0 - _smoothstep(path_width * 0.72, path_width * 1.10, signed_angle)
                )
                breach_shoulder = max(breach_shoulder, entry_shoulder_drape * 0.88)
                if breach_shoulder <= 0.0:
                    continue

                crater_loop_guard_weight = 0.56 if entry_shoulder_drape > 0.20 else 0.90
                semantic_guard = max(
                    path_mask[ring][index] * 1.05,
                    crater_loop_mask[ring][index] * crater_loop_guard_weight,
                    lava_mask[ring][index] * 0.92,
                )
                if semantic_guard >= 0.82:
                    continue

                height = weathered[ring][index]
                previous_height = weathered[ring][index - 1]
                next_height = weathered[ring][(index + 1) % radial_segments]
                previous_2 = weathered[ring][(index - 2) % radial_segments]
                next_2 = weathered[ring][(index + 2) % radial_segments]
                angular_target = (
                    height * 0.24
                    + previous_height * 0.26
                    + next_height * 0.26
                    + previous_2 * 0.12
                    + next_2 * 0.12
                )
                tooth = _smoothstep(130.0, 290.0, max(abs(height - previous_height), abs(height - next_height)))
                if tooth <= 0.0:
                    continue

                strength = min(0.54, process_strength * wall_band * breach_shoulder * tooth * (1.0 - semantic_guard))
                next_heights[ring][index] = height * (1.0 - strength) + angular_target * strength
        weathered = next_heights

    return weathered


def _settle_fire_front_entry_ash_shoulder(
    heights: list[list[float]],
    path_mask: list[list[float]],
    crater_loop_mask: list[list[float]],
    lava_mask: list[list[float]],
    radial_segments: int,
    rings: int,
    controls: dict[str, object],
) -> list[list[float]]:
    settle_intensity = float(controls.get("terrain_settle_intensity", controls.get("terrain_relaxation_intensity", 0.0)))
    hero_resolution = _smoothstep(40.0, 52.0, float(rings))
    if settle_intensity <= 0.0 or hero_resolution <= 0.0 or rings < 20:
        return heights

    erosion_age = _clamp01(float(controls.get("erosion_age", 0.45)))
    deposition_weight = _clamp01(float(controls.get("deposition_weight", 0.55)))
    process_strength = hero_resolution * min(0.78, settle_intensity * 0.42 + erosion_age * 0.16 + deposition_weight * 0.20)
    if process_strength <= 0.0:
        return heights

    path_width = float(controls.get("path_width", _preset("fire")["path_width"]))
    arc_span = max(16, min(radial_segments // 10, round(radial_segments * 0.078)))
    arc_indices = list(range(radial_segments - arc_span, radial_segments)) + list(range(0, arc_span + 1))
    settled = [list(row) for row in heights]

    for ring in range(max(2, round(rings * 0.30)), min(rings - 1, round(rings * 0.41)) + 1):
        radial_alpha = ring / rings if rings else 0.0
        shoulder_radial_band = _smoothstep(0.33, 0.36, radial_alpha) * (1.0 - _smoothstep(0.405, 0.435, radial_alpha))
        toe_radial_band = _smoothstep(0.30, 0.325, radial_alpha) * (1.0 - _smoothstep(0.355, 0.38, radial_alpha))
        radial_band = max(shoulder_radial_band, toe_radial_band * 0.82)
        if radial_band <= 0.0:
            continue

        values = [settled[ring][index] for index in arc_indices]
        active = []
        for index in arc_indices:
            angle = (index / radial_segments) * math.tau
            signed_angle = abs(math.atan2(math.sin(angle), math.cos(angle)))
            entry_band = _smoothstep(path_width * 0.32, path_width * 0.50, signed_angle) * (
                1.0 - _smoothstep(path_width * 0.72, path_width * 1.08, signed_angle)
            )
            toe_band = _smoothstep(path_width * 0.36, path_width * 0.52, signed_angle) * (
                1.0 - _smoothstep(path_width * 0.76, path_width * 1.18, signed_angle)
            )
            route_guard = max(path_mask[ring][index] * 0.82, lava_mask[ring][index] * 1.12)
            loop = crater_loop_mask[ring][index]
            shoulder_active = entry_band > 0.0 and route_guard < 0.24 and 0.10 <= loop <= 0.88
            toe_active = (
                toe_band > 0.0
                and toe_radial_band > 0.0
                and path_mask[ring][index] < 0.16
                and lava_mask[ring][index] < 0.16
                and loop <= 0.08
                and crater_loop_mask[ring][index] <= 0.08
            )
            active.append(shoulder_active or toe_active)

        capped = list(values)
        max_delta = 224.0
        for _ in range(2):
            for offset in range(1, len(capped)):
                if not active[offset] or not active[offset - 1]:
                    continue
                previous = capped[offset - 1]
                if capped[offset] > previous + max_delta:
                    capped[offset] = previous + max_delta
                elif capped[offset] < previous - max_delta:
                    capped[offset] = previous - max_delta
            for offset in range(len(capped) - 2, -1, -1):
                if not active[offset] or not active[offset + 1]:
                    continue
                next_value = capped[offset + 1]
                if capped[offset] > next_value + max_delta:
                    capped[offset] = next_value + max_delta
                elif capped[offset] < next_value - max_delta:
                    capped[offset] = next_value - max_delta

        for offset, index in enumerate(arc_indices):
            if not active[offset] or capped[offset] == values[offset]:
                continue
            strength = min(0.72, process_strength * radial_band * (0.72 + deposition_weight * 0.18))
            settled[ring][index] = values[offset] * (1.0 - strength) + capped[offset] * strength

    def ash_shoulder_weight(ring: int, index: int) -> float:
        radial_alpha = ring / rings if rings else 0.0
        shoulder_radial_band = _smoothstep(0.33, 0.36, radial_alpha) * (1.0 - _smoothstep(0.405, 0.435, radial_alpha))
        toe_radial_band = _smoothstep(0.30, 0.325, radial_alpha) * (1.0 - _smoothstep(0.355, 0.38, radial_alpha))
        radial_band = max(shoulder_radial_band, toe_radial_band * 0.82)
        if radial_band <= 0.0:
            return 0.0

        angle = (index / radial_segments) * math.tau
        signed_angle = abs(math.atan2(math.sin(angle), math.cos(angle)))
        entry_band = _smoothstep(path_width * 0.32, path_width * 0.50, signed_angle) * (
            1.0 - _smoothstep(path_width * 0.72, path_width * 1.08, signed_angle)
        )
        toe_band = _smoothstep(path_width * 0.36, path_width * 0.52, signed_angle) * (
            1.0 - _smoothstep(path_width * 0.76, path_width * 1.18, signed_angle)
        )
        route_guard = max(path_mask[ring][index] * 0.82, lava_mask[ring][index] * 1.12)
        loop = crater_loop_mask[ring][index]
        shoulder_active = entry_band > 0.0 and route_guard < 0.24 and 0.10 <= loop <= 0.62
        toe_active = toe_band > 0.0 and toe_radial_band > 0.0 and route_guard < 0.18 and loop <= 0.10
        if not (shoulder_active or toe_active):
            return 0.0
        return radial_band * max(entry_band, toe_band * 0.82) * (1.0 - min(0.95, route_guard))

    for _ in range(3):
        next_heights = [list(row) for row in settled]
        for ring in range(max(2, round(rings * 0.30)), min(rings - 1, round(rings * 0.41)) + 1):
            for index in arc_indices:
                weight = ash_shoulder_weight(ring, index)
                if weight <= 0.0:
                    continue

                local_values = []
                for ring_offset in (-1, 0, 1):
                    sample_ring = max(0, min(rings, ring + ring_offset))
                    for index_offset in (-2, -1, 0, 1, 2):
                        local_values.append(settled[sample_ring][(index + index_offset) % radial_segments])
                local_range = max(local_values) - min(local_values)
                curtain = _smoothstep(620.0, 1240.0, local_range)
                if curtain <= 0.0:
                    continue

                height = settled[ring][index]
                angular_target = (
                    height * 0.34
                    + settled[ring][index - 1] * 0.18
                    + settled[ring][(index + 1) % radial_segments] * 0.18
                    + settled[ring][(index - 2) % radial_segments] * 0.15
                    + settled[ring][(index + 2) % radial_segments] * 0.15
                )
                radial_target = height * 0.42 + settled[ring - 1][index] * 0.29 + settled[ring + 1][index] * 0.29
                local_mid = sorted(local_values)[len(local_values) // 2]
                target = (angular_target * 0.50 + radial_target * 0.30 + local_mid * 0.20)
                strength = min(0.72, process_strength * weight * curtain * (0.82 + deposition_weight * 0.22))
                next_heights[ring][index] = height * (1.0 - strength) + target * strength
        settled = next_heights

    return settled


def _apply_fire_secondary_collapse_shelves(
    heights: list[list[float]],
    path_mask: list[list[float]],
    crater_loop_mask: list[list[float]],
    lava_mask: list[list[float]],
    radial_segments: int,
    rings: int,
    controls: dict[str, object],
) -> list[list[float]]:
    settle_intensity = float(controls.get("terrain_settle_intensity", controls.get("terrain_relaxation_intensity", 0.0)))
    hero_resolution = _smoothstep(40.0, 52.0, float(rings))
    if settle_intensity <= 0.0 or hero_resolution <= 0.0 or rings < 20:
        return heights

    erosion_age = _clamp01(float(controls.get("erosion_age", 0.45)))
    deposition_weight = _clamp01(float(controls.get("deposition_weight", 0.55)))
    process_strength = hero_resolution * min(0.82, settle_intensity * 0.44 + erosion_age * 0.24 + deposition_weight * 0.16)
    if process_strength <= 0.0:
        return heights

    path_width = float(controls.get("path_width", _preset("fire")["path_width"]))
    shelved = [list(row) for row in heights]
    shelf_specs = (
        (0.535, ((1.18, 0.42), (2.72, 0.46), (4.42, 0.38)), 42.0),
        (0.575, ((1.52, 0.36), (3.12, 0.42), (4.86, 0.36)), 54.0),
        (0.645, ((0.98, 0.34), (2.48, 0.38), (4.20, 0.40), (5.64, 0.32)), 34.0),
    )

    for shelf_index, (shelf_alpha, sectors, collapse_drop) in enumerate(shelf_specs):
        center_ring = max(2, min(rings - 3, round(rings * shelf_alpha)))
        next_heights = [list(row) for row in shelved]
        for index in range(radial_segments):
            angle = (index / radial_segments) * math.tau
            sector_strength = 0.0
            for sector_center, sector_width in sectors:
                distance = _angular_distance(angle, sector_center)
                raw_sector = 1.0 - _smoothstep(sector_width * 0.48, sector_width, distance)
                ragged_edge = 0.86 + 0.14 * math.sin(angle * 5.0 + shelf_index * 1.73)
                sector_strength = max(sector_strength, raw_sector * ragged_edge)
            sector_strength = _clamp01(sector_strength)
            if sector_strength <= 0.0:
                continue

            radial_alpha = center_ring / rings if rings else 0.0
            signed_angle = abs(math.atan2(math.sin(angle), math.cos(angle)))
            main_approach_guard = (
                (1.0 - _smoothstep(path_width * 0.72, path_width * 1.84, signed_angle))
                * _smoothstep(0.22, 0.94, radial_alpha)
            )
            semantic_guard = max(
                path_mask[center_ring][index],
                path_mask[center_ring + 1][index],
                crater_loop_mask[center_ring][index] * 0.92,
                crater_loop_mask[center_ring + 1][index] * 0.92,
                lava_mask[center_ring][index] * 0.94,
                lava_mask[center_ring + 1][index] * 0.94,
                main_approach_guard,
            )
            if semantic_guard >= 1.0:
                continue

            strength = min(0.86, process_strength * sector_strength * (1.0 - semantic_guard))
            if strength <= 0.0:
                continue

            upper_height = shelved[center_ring][index]
            lower_height = shelved[center_ring + 1][index]
            plateau_height = (upper_height + lower_height) * 0.50 - collapse_drop * strength
            next_heights[center_ring][index] = upper_height * (1.0 - strength) + plateau_height * strength
            next_heights[center_ring + 1][index] = lower_height * (1.0 - strength) + plateau_height * strength

            lip_strength = strength * 0.18
            inner_lip = center_ring - 1
            outer_lip = center_ring + 2
            next_heights[inner_lip][index] = (
                shelved[inner_lip][index] * (1.0 - lip_strength)
                + (shelved[inner_lip][index] + collapse_drop * 0.45) * lip_strength
            )
            next_heights[outer_lip][index] = (
                shelved[outer_lip][index] * (1.0 - lip_strength)
                + (shelved[outer_lip][index] - collapse_drop * 0.65) * lip_strength
            )
        shelved = next_heights

    return shelved


def _settle_fire_lava_cooling_fans(
    heights: list[list[float]],
    path_mask: list[list[float]],
    crater_loop_mask: list[list[float]],
    lava_mask: list[list[float]],
    radial_segments: int,
    rings: int,
    controls: dict[str, object],
) -> list[list[float]]:
    settle_intensity = float(controls.get("terrain_settle_intensity", controls.get("terrain_relaxation_intensity", 0.0)))
    if settle_intensity <= 0.0 or rings < 20:
        return heights

    erosion_age = _clamp01(float(controls.get("erosion_age", 0.45)))
    deposition_weight = _clamp01(float(controls.get("deposition_weight", 0.55)))
    hero_resolution = _smoothstep(40.0, 52.0, float(rings))
    process_strength = hero_resolution * min(1.0, settle_intensity * 0.48 + erosion_age * 0.24 + deposition_weight * 0.28)
    if process_strength <= 0.0:
        return heights

    lava_count = int(controls.get("lava_channel_count", 3))
    path_width = float(controls.get("path_width", _preset("fire")["path_width"]))
    settled = [list(row) for row in heights]
    passes = 2 if process_strength > 0.58 else 1

    for _ in range(passes):
        next_heights = [list(row) for row in settled]
        for ring in range(1, rings):
            radial_alpha = ring / rings if rings else 0.0
            downstream = _smoothstep(0.58, 0.78, radial_alpha) * (1.0 - _smoothstep(0.985, 1.0, radial_alpha))
            terminal = _smoothstep(0.80, 0.93, radial_alpha) * (1.0 - _smoothstep(0.992, 1.0, radial_alpha))
            if downstream <= 0.0:
                continue

            fan_width = 0.045 + downstream * 0.018 + terminal * 0.052
            for index in range(radial_segments):
                angle = (index / radial_segments) * math.tau
                nearest = min(_angular_distance(angle, channel_angle) for channel_angle in _lava_channel_angles(lava_count))
                fan_core = (1.0 - _smoothstep(fan_width * 0.10, fan_width * 0.62, nearest)) * downstream
                fan_body = (1.0 - _smoothstep(fan_width * 0.40, fan_width * 1.42, nearest)) * downstream
                levee = (
                    _smoothstep(fan_width * 0.54, fan_width * 1.02, nearest)
                    * (1.0 - _smoothstep(fan_width * 1.08, fan_width * 1.82, nearest))
                    * downstream
                )
                if max(fan_core, fan_body, levee) <= 0.0:
                    continue

                route = max(path_mask[ring][index], crater_loop_mask[ring][index] * 0.84)
                signed_angle = abs(math.atan2(math.sin(angle), math.cos(angle)))
                main_approach_guard = (
                    (1.0 - _smoothstep(path_width * 0.74, path_width * 1.26, signed_angle))
                    * _smoothstep(0.22, 0.94, radial_alpha)
                )
                protection = max(route * 0.94, main_approach_guard * 0.74)
                if protection >= 1.0:
                    continue

                height = settled[ring][index]
                previous_height = settled[ring][index - 1]
                next_height = settled[ring][(index + 1) % radial_segments]
                inner_height = settled[ring - 1][index]
                outer_height = settled[ring + 1][index]

                angular_target = height * 0.34 + previous_height * 0.33 + next_height * 0.33
                radial_target = height * 0.30 + inner_height * 0.42 + outer_height * 0.28
                flow_target = angular_target * 0.62 + radial_target * 0.38

                center_settle = fan_core * process_strength * (0.18 + terminal * 0.30) * (1.0 - protection)
                body_settle = fan_body * process_strength * (0.06 + terminal * 0.12) * (1.0 - protection)
                strength = min(0.52, center_settle + body_settle)
                shaped_height = height * (1.0 - strength) + flow_target * strength

                floor_fill = fan_core * terminal * (60.0 + deposition_weight * 100.0)
                center_inset = fan_core * downstream * (55.0 + erosion_age * 55.0) * (1.0 - terminal * 0.38)
                late_terminal = _smoothstep(0.90, 0.955, radial_alpha) * (1.0 - _smoothstep(0.992, 1.0, radial_alpha))
                terminal_channel_cut = fan_core * late_terminal * (230.0 + erosion_age * 170.0)
                crust_lift = fan_body * (1.0 - fan_core) * terminal * (80.0 + deposition_weight * 100.0)
                levee_lift = levee * (260.0 + deposition_weight * 390.0) * (0.36 + terminal * 0.82)

                next_heights[ring][index] = shaped_height + floor_fill + crust_lift + levee_lift - center_inset - terminal_channel_cut
        settled = next_heights

    return settled


def _weather_fire_terminal_lava_shoulders(
    heights: list[list[float]],
    path_mask: list[list[float]],
    crater_loop_mask: list[list[float]],
    radial_segments: int,
    rings: int,
    controls: dict[str, object],
) -> list[list[float]]:
    settle_intensity = float(controls.get("terrain_settle_intensity", controls.get("terrain_relaxation_intensity", 0.0)))
    hero_resolution = _smoothstep(40.0, 52.0, float(rings))
    if settle_intensity <= 0.0 or hero_resolution <= 0.0 or rings < 20:
        return heights

    erosion_age = _clamp01(float(controls.get("erosion_age", 0.45)))
    deposition_weight = _clamp01(float(controls.get("deposition_weight", 0.55)))
    process_strength = hero_resolution * min(0.86, settle_intensity * 0.38 + erosion_age * 0.26 + deposition_weight * 0.18)
    if process_strength <= 0.0:
        return heights

    lava_count = int(controls.get("lava_channel_count", 3))
    path_width = float(controls.get("path_width", _preset("fire")["path_width"]))
    weathered = [list(row) for row in heights]
    for ring in range(1, rings):
        radial_alpha = ring / rings if rings else 0.0
        terminal = _smoothstep(0.88, 0.93, radial_alpha) * (1.0 - _smoothstep(0.992, 1.0, radial_alpha))
        if terminal <= 0.0:
            continue

        next_heights = [list(row) for row in weathered]
        for index in range(radial_segments):
            angle = (index / radial_segments) * math.tau
            channel_angle = min(_lava_channel_angles(lava_count), key=lambda candidate: _angular_distance(angle, candidate))
            signed_channel_angle = abs(math.atan2(math.sin(channel_angle), math.cos(channel_angle)))
            if signed_channel_angle < path_width * 1.25:
                continue

            distance = _angular_distance(angle, channel_angle)
            shoulder = _smoothstep(0.055, 0.125, distance) * (1.0 - _smoothstep(0.205, 0.315, distance))
            if shoulder <= 0.0:
                continue

            signed_angle = abs(math.atan2(math.sin(angle), math.cos(angle)))
            main_approach_guard = (
                (1.0 - _smoothstep(path_width * 0.72, path_width * 1.52, signed_angle))
                * _smoothstep(0.22, 0.94, radial_alpha)
            )
            semantic_guard = max(path_mask[ring][index] * 0.95, crater_loop_mask[ring][index] * 0.86, main_approach_guard)
            if semantic_guard >= 1.0:
                continue

            center_index = round((channel_angle % math.tau) / math.tau * radial_segments) % radial_segments
            center_height = weathered[ring][center_index]
            height = weathered[ring][index]
            max_shoulder_height = center_height + 1580.0 + 220.0 * (1.0 - terminal)
            excess = max(0.0, height - max_shoulder_height)
            if excess <= 0.0:
                continue

            previous_height = weathered[ring][index - 1]
            next_height = weathered[ring][(index + 1) % radial_segments]
            angular_target = height * 0.42 + previous_height * 0.29 + next_height * 0.29
            capped_target = min(angular_target, max_shoulder_height)
            strength = min(0.82, process_strength * terminal * shoulder * (1.0 - semantic_guard))
            next_heights[ring][index] = height * (1.0 - strength) + capped_target * strength
        weathered = next_heights

    return weathered


def _settle_fire_outer_basalt_block_shelves(
    heights: list[list[float]],
    path_mask: list[list[float]],
    crater_loop_mask: list[list[float]],
    lava_mask: list[list[float]],
    radial_segments: int,
    rings: int,
    controls: dict[str, object],
) -> list[list[float]]:
    settle_intensity = float(controls.get("terrain_settle_intensity", controls.get("terrain_relaxation_intensity", 0.0)))
    hero_resolution = _smoothstep(40.0, 52.0, float(rings))
    if settle_intensity <= 0.0 or hero_resolution <= 0.0 or rings < 20:
        return heights

    erosion_age = _clamp01(float(controls.get("erosion_age", 0.45)))
    deposition_weight = _clamp01(float(controls.get("deposition_weight", 0.55)))
    process_strength = hero_resolution * min(0.78, settle_intensity * 0.36 + erosion_age * 0.26 + deposition_weight * 0.18)
    if process_strength <= 0.0:
        return heights

    path_width = float(controls.get("path_width", _preset("fire")["path_width"]))
    block_specs = (
        (0.92, 0.36, 0.70, 0.88, 0.0),
        (2.58, 0.42, 0.70, 0.90, -70.0),
        (4.36, 0.40, 0.72, 0.92, 45.0),
        (5.72, 0.34, 0.76, 0.94, -35.0),
    )
    settled = [list(row) for row in heights]
    passes = 2 if process_strength > 0.55 else 1

    for _ in range(passes):
        next_heights = [list(row) for row in settled]
        for ring in range(1, rings):
            radial_alpha = ring / rings if rings else 0.0
            for index in range(radial_segments):
                angle = (index / radial_segments) * math.tau
                block_strength = 0.0
                block_bias = 0.0
                for block_center, block_width, inner_alpha, outer_alpha, height_bias in block_specs:
                    radial_band = _smoothstep(inner_alpha, inner_alpha + 0.045, radial_alpha) * (
                        1.0 - _smoothstep(outer_alpha - 0.045, outer_alpha, radial_alpha)
                    )
                    if radial_band <= 0.0:
                        continue

                    distance = _angular_distance(angle, block_center)
                    sector = 1.0 - _smoothstep(block_width * 0.42, block_width, distance)
                    if sector <= 0.0:
                        continue

                    edge_raggedness = 0.92 + 0.08 * math.sin(angle * 4.0 + radial_alpha * 17.0)
                    strength = _clamp01(radial_band * sector * edge_raggedness)
                    if strength > block_strength:
                        block_strength = strength
                        block_bias = height_bias
                if block_strength <= 0.0:
                    continue

                signed_angle = abs(math.atan2(math.sin(angle), math.cos(angle)))
                main_approach_guard = (
                    (1.0 - _smoothstep(path_width * 0.76, path_width * 1.56, signed_angle))
                    * _smoothstep(0.22, 0.94, radial_alpha)
                )
                semantic_guard = max(
                    path_mask[ring][index] * 0.96,
                    crater_loop_mask[ring][index] * 0.86,
                    lava_mask[ring][index] * 0.92,
                    main_approach_guard,
                )
                if semantic_guard >= 1.0:
                    continue

                height = settled[ring][index]
                previous_height = settled[ring][index - 1]
                next_height = settled[ring][(index + 1) % radial_segments]
                previous_2 = settled[ring][(index - 2) % radial_segments]
                next_2 = settled[ring][(index + 2) % radial_segments]
                inner_height = settled[ring - 1][index]
                outer_height = settled[ring + 1][index]
                angular_target = (
                    height * 0.26
                    + previous_height * 0.22
                    + next_height * 0.22
                    + previous_2 * 0.15
                    + next_2 * 0.15
                )
                radial_target = height * 0.42 + inner_height * 0.29 + outer_height * 0.29
                shelf_height = round((height + block_bias) / 190.0) * 190.0
                target = angular_target * 0.58 + radial_target * 0.24 + shelf_height * 0.18
                strength = min(0.48, process_strength * block_strength * (1.0 - semantic_guard))
                next_heights[ring][index] = height * (1.0 - strength) + target * strength
        settled = next_heights

    return settled


def _weather_fire_outer_apron_chatter(
    heights: list[list[float]],
    path_mask: list[list[float]],
    crater_loop_mask: list[list[float]],
    lava_mask: list[list[float]],
    volcano_mask: list[list[float]],
    radial_segments: int,
    rings: int,
    controls: dict[str, object],
) -> list[list[float]]:
    settle_intensity = float(controls.get("terrain_settle_intensity", controls.get("terrain_relaxation_intensity", 0.0)))
    hero_resolution = _smoothstep(40.0, 52.0, float(rings))
    if settle_intensity <= 0.0 or hero_resolution <= 0.0 or rings < 20:
        return heights

    erosion_age = _clamp01(float(controls.get("erosion_age", 0.45)))
    deposition_weight = _clamp01(float(controls.get("deposition_weight", 0.55)))
    path_width = float(controls.get("path_width", _preset("fire")["path_width"]))
    process_strength = hero_resolution * min(0.66, settle_intensity * 0.30 + erosion_age * 0.16 + deposition_weight * 0.20)
    if process_strength <= 0.0:
        return heights

    weathered = [list(row) for row in heights]
    passes = 2 if process_strength > 0.44 else 1

    for _ in range(passes):
        next_heights = [list(row) for row in weathered]
        for ring in range(2, rings - 1):
            radial_alpha = ring / rings if rings else 0.0
            apron_band = _smoothstep(0.66, 0.74, radial_alpha) * (1.0 - _smoothstep(0.94, 0.99, radial_alpha))
            if apron_band <= 0.0:
                continue

            for index in range(radial_segments):
                angle = (index / radial_segments) * math.tau
                signed_angle = abs(math.atan2(math.sin(angle), math.cos(angle)))
                main_approach_guard = (
                    (1.0 - _smoothstep(path_width * 0.78, path_width * 2.75, signed_angle))
                    * _smoothstep(0.42, 0.94, radial_alpha)
                )
                if main_approach_guard > 0.32:
                    continue
                semantic_guard = main_approach_guard
                for offset, weight in ((0, 1.0), (-1, 0.74), (1, 0.74), (-2, 0.42), (2, 0.42)):
                    sample_index = (index + offset) % radial_segments
                    semantic_guard = max(
                        semantic_guard,
                        path_mask[ring][sample_index] * weight * 0.96,
                        crater_loop_mask[ring][sample_index] * weight * 0.86,
                        lava_mask[ring][sample_index] * weight * 0.98,
                        volcano_mask[ring][sample_index] * weight * 0.82,
                    )
                if semantic_guard >= 0.95:
                    continue

                height = weathered[ring][index]
                previous_height = weathered[ring][index - 1]
                next_height = weathered[ring][(index + 1) % radial_segments]
                previous_2 = weathered[ring][(index - 2) % radial_segments]
                next_2 = weathered[ring][(index + 2) % radial_segments]
                inner_height = weathered[ring - 1][index]
                outer_height = weathered[ring + 1][index]

                angular_target = (
                    height * 0.34
                    + previous_height * 0.24
                    + next_height * 0.24
                    + previous_2 * 0.09
                    + next_2 * 0.09
                )
                radial_target = height * 0.58 + inner_height * 0.21 + outer_height * 0.21
                target = angular_target * 0.76 + radial_target * 0.24
                chatter = max(
                    abs(height - angular_target),
                    abs(height - previous_height),
                    abs(height - next_height),
                )
                chatter_gate = _smoothstep(74.0, 250.0, chatter)
                if chatter_gate <= 0.0:
                    continue

                spike_bias = 1.12 if height > target else 0.88
                strength = min(0.34, process_strength * apron_band * chatter_gate * spike_bias * (1.0 - semantic_guard))
                next_heights[ring][index] = height * (1.0 - strength) + target * strength
        weathered = next_heights

    return weathered


def _build_semantic_terrain_field(
    radius_m: float,
    seed: int,
    radial_segments: int,
    rings: int,
    biome: str,
    controls: dict[str, object] | None = None,
) -> TerrainField:
    controls = controls or {}
    radius_cm = radius_m * 100.0
    heights: list[list[float]] = []
    path_mask: list[list[float]] = []
    lava_mask: list[list[float]] = []
    ravine_mask: list[list[float]] = []
    volcano_mask: list[list[float]] = []
    crater_loop_mask: list[list[float]] = []
    cliff_mask: list[list[float]] = []

    for ring in range(rings + 1):
        radial_alpha = ring / rings if rings else 0.0
        height_row: list[float] = []
        path_row: list[float] = []
        lava_row: list[float] = []
        ravine_row: list[float] = []
        volcano_row: list[float] = []
        crater_loop_row: list[float] = []
        cliff_row: list[float] = []

        for index in range(radial_segments):
            angle = (index / radial_segments) * math.tau
            height_row.append(_top_height(radial_alpha, angle, seed, radius_cm, biome, controls))
            path_row.append(_path_strength(radial_alpha, angle, biome, controls.get("path_width"), controls))
            ravine = _ravine_strength(radial_alpha, angle, seed, biome)
            if biome == "forest":
                ravine = max(ravine, _forest_stump_cave_mask_strength(radial_alpha, angle, seed, controls))
            if biome == "ice":
                ravine = max(ravine, _ice_crevasse_center_strength(radial_alpha, angle, seed, controls))
            ravine_row.append(ravine)
            cliff_row.append(_smoothstep(0.68, 1.0, radial_alpha))

            if biome == "fire":
                volcano_radius = controls.get("volcano_radius", 0.42)
                volcano_row.append(1.0 - _smoothstep(0.035, 0.13, abs(radial_alpha - volcano_radius)))
                lava_row.append(_lava_channel_strength(radial_alpha, angle, int(controls.get("lava_channel_count", 3))))
                crater_loop_row.append(_crater_loop_strength(radial_alpha, angle, controls))
            else:
                volcano_row.append(0.0)
                lava_row.append(0.0)
                crater_loop_row.append(0.0)

        heights.append(height_row)
        path_mask.append(path_row)
        lava_mask.append(lava_row)
        ravine_mask.append(ravine_row)
        volcano_mask.append(volcano_row)
        crater_loop_mask.append(crater_loop_row)
        cliff_mask.append(cliff_row)

    route_protection_mask = _combine_walkable_route_masks(path_mask, crater_loop_mask)
    if biome == "fire":
        lava_mask = _capture_fire_lava_low_potential_corridors(
            heights,
            lava_mask,
            path_mask,
            crater_loop_mask,
            radial_segments,
            rings,
            controls,
        )
    slope_mask = _derive_slope_mask(heights, radial_segments, rings)
    flow_accumulation_mask = _derive_flow_accumulation_mask(
        heights,
        route_protection_mask,
        lava_mask,
        ravine_mask,
        radial_segments,
        rings,
        float(controls.get("erosion_age", 0.45)),
    )
    curvature_mask = _derive_curvature_mask(heights, radial_segments, rings)
    lava_flow_mask = _derive_lava_flow_mask(
        lava_mask,
        ravine_mask,
        route_protection_mask,
        radial_segments,
        rings,
        float(controls.get("erosion_age", 0.45)),
        flow_accumulation_mask,
    )
    talus_mask = _derive_talus_mask(
        slope_mask,
        cliff_mask,
        route_protection_mask,
        lava_mask,
        volcano_mask,
        radial_segments,
        rings,
        float(controls.get("deposition_weight", 0.55)),
        curvature_mask,
    )
    heights = _apply_process_height_pass(
        heights,
        talus_mask,
        lava_flow_mask,
        flow_accumulation_mask,
        curvature_mask,
        path_mask,
        volcano_mask,
        crater_loop_mask,
        float(controls.get("terrain_process_intensity", controls.get("terrain_detail_intensity", 0.0))),
        float(controls.get("erosion_age", 0.45)),
        float(controls.get("deposition_weight", 0.55)),
        biome,
    )
    heights = _relax_terrain_field_heights(
        heights,
        path_mask,
        lava_mask,
        volcano_mask,
        crater_loop_mask,
        cliff_mask,
        radial_segments,
        rings,
        biome,
        controls,
    )
    settle_curvature_mask = _derive_curvature_mask(heights, radial_segments, rings)
    heights = _settle_high_frequency_terrain(
        heights,
        path_mask,
        lava_mask,
        volcano_mask,
        crater_loop_mask,
        cliff_mask,
        settle_curvature_mask,
        radial_segments,
        rings,
        controls,
    )
    heights = _settle_walkable_route_heights(
        heights,
        path_mask,
        crater_loop_mask,
        lava_mask,
        radial_segments,
        rings,
        controls,
    )
    heights = _apply_route_cross_section_heights(
        heights,
        path_mask,
        crater_loop_mask,
        lava_mask,
        radial_segments,
        rings,
        controls,
    )
    if biome == "forest":
        heights = _settle_forest_canopy_platform_heights(heights, radial_segments, rings, controls)
    if biome == "fire":
        heights = _apply_fire_crater_collapse_terraces(
            heights,
            path_mask,
            crater_loop_mask,
            lava_mask,
            radial_segments,
            rings,
            controls,
        )
        heights = _settle_talus_apron_heights(
            heights,
            path_mask,
            crater_loop_mask,
            lava_mask,
            volcano_mask,
            radial_segments,
            rings,
            controls,
        )
        fire_weather_curvature_mask = _derive_curvature_mask(heights, radial_segments, rings)
        heights = _weather_fire_aged_edges(
            heights,
            path_mask,
            crater_loop_mask,
            lava_mask,
            volcano_mask,
            cliff_mask,
            fire_weather_curvature_mask,
            radial_segments,
            rings,
            controls,
        )
        heights = _weather_fire_volcano_wall_strata(
            heights,
            path_mask,
            crater_loop_mask,
            lava_mask,
            radial_segments,
            rings,
            controls,
        )
        heights = _weather_fire_inner_wall_breach_ribs(
            heights,
            path_mask,
            crater_loop_mask,
            lava_mask,
            radial_segments,
            rings,
            controls,
        )
        heights = _weather_fire_front_breach_ash_drape(
            heights,
            path_mask,
            crater_loop_mask,
            lava_mask,
            radial_segments,
            rings,
            controls,
        )
        heights = _settle_fire_front_entry_ash_shoulder(
            heights,
            path_mask,
            crater_loop_mask,
            lava_mask,
            radial_segments,
            rings,
            controls,
        )
        heights = _apply_fire_secondary_collapse_shelves(
            heights,
            path_mask,
            crater_loop_mask,
            lava_mask,
            radial_segments,
            rings,
            controls,
        )
        heights = _settle_fire_crater_ash_basin(
            heights,
            path_mask,
            lava_mask,
            radial_segments,
            rings,
            controls,
        )
        heights = _settle_fire_lava_cooling_fans(
            heights,
            path_mask,
            crater_loop_mask,
            lava_mask,
            radial_segments,
            rings,
            controls,
        )
        heights = _weather_fire_terminal_lava_shoulders(
            heights,
            path_mask,
            crater_loop_mask,
            radial_segments,
            rings,
            controls,
        )
        heights = _settle_fire_outer_basalt_block_shelves(
            heights,
            path_mask,
            crater_loop_mask,
            lava_mask,
            radial_segments,
            rings,
            controls,
        )
        heights = _weather_fire_outer_apron_chatter(
            heights,
            path_mask,
            crater_loop_mask,
            lava_mask,
            volcano_mask,
            radial_segments,
            rings,
            controls,
        )
        heights = _shape_fire_crater_wall_arc_layout(
            heights,
            path_mask,
            crater_loop_mask,
            lava_mask,
            radial_segments,
            rings,
            controls,
        )
        heights = _shape_fire_outer_wall_asymmetric_break_arcs(
            heights,
            path_mask,
            crater_loop_mask,
            lava_mask,
            radial_segments,
            rings,
            controls,
        )
        heights = _weather_fire_outer_wall_polar_curtains(
            heights,
            path_mask,
            crater_loop_mask,
            lava_mask,
            radial_segments,
            rings,
            controls,
        )
        heights = _weather_fire_outer_wall_diagonal_breakup(
            heights,
            path_mask,
            crater_loop_mask,
            lava_mask,
            radial_segments,
            rings,
            controls,
        )
        heights = _apply_fire_secondary_collapse_shelves(
            heights,
            path_mask,
            crater_loop_mask,
            lava_mask,
            radial_segments,
            rings,
            controls,
        )
        heights = _settle_fire_outer_wall_local_ring_locks(
            heights,
            path_mask,
            crater_loop_mask,
            lava_mask,
            radial_segments,
            rings,
            controls,
        )
        heights = _carve_fire_lava_low_potential_corridors(
            heights,
            path_mask,
            crater_loop_mask,
            lava_mask,
            radial_segments,
            rings,
            controls,
        )
        heights = _settle_fire_non_front_ash_deposition_bands(
            heights,
            path_mask,
            crater_loop_mask,
            lava_mask,
            radial_segments,
            rings,
            controls,
        )
        heights = _shape_fire_lava_cooling_crust_sills(
            heights,
            path_mask,
            crater_loop_mask,
            lava_mask,
            radial_segments,
            rings,
            controls,
        )
        heights = _shape_fire_lava_side_overflow_tongues(
            heights,
            path_mask,
            crater_loop_mask,
            lava_mask,
            radial_segments,
            rings,
            controls,
        )
        heights = _shape_fire_lava_side_tongue_cooling_ribs(
            heights,
            path_mask,
            crater_loop_mask,
            lava_mask,
            radial_segments,
            rings,
            controls,
        )
        heights = _shape_fire_lava_cooling_fingers(
            heights,
            path_mask,
            crater_loop_mask,
            lava_mask,
            radial_segments,
            rings,
            controls,
        )
        heights = _shape_fire_lava_terminal_cooling_pockets(
            heights,
            path_mask,
            crater_loop_mask,
            lava_mask,
            radial_segments,
            rings,
            controls,
        )
        heights = _shape_fire_lava_mantle_cooling_slabs(
            heights,
            path_mask,
            crater_loop_mask,
            lava_mask,
            radial_segments,
            rings,
            controls,
        )
        heights = _shape_fire_lava_cooling_islands(
            heights,
            path_mask,
            crater_loop_mask,
            lava_mask,
            radial_segments,
            rings,
            controls,
        )
        heights = _shape_fire_lava_outer_scallops(
            heights,
            path_mask,
            crater_loop_mask,
            lava_mask,
            radial_segments,
            rings,
            controls,
        )
        heights = _settle_fire_inner_wall_late_breakline_locks(
            heights,
            path_mask,
            crater_loop_mask,
            lava_mask,
            radial_segments,
            rings,
            controls,
        )
        heights = _restore_fire_front_inner_breach_wall_drop(
            heights,
            path_mask,
            crater_loop_mask,
            lava_mask,
            radial_segments,
            rings,
            controls,
        )
        heights = _weather_fire_front_breach_ash_drape(
            heights,
            path_mask,
            crater_loop_mask,
            lava_mask,
            radial_segments,
            rings,
            controls,
        )
        heights = _settle_fire_front_entry_ash_shoulder(
            heights,
            path_mask,
            crater_loop_mask,
            lava_mask,
            radial_segments,
            rings,
            controls,
        )
        heights = _settle_fire_upper_wall_lateral_weathering_shelves(
            heights,
            path_mask,
            crater_loop_mask,
            lava_mask,
            radial_segments,
            rings,
            controls,
        )
        heights = _shape_fire_upper_wall_nonconcentric_crest_bays(
            heights,
            path_mask,
            crater_loop_mask,
            lava_mask,
            radial_segments,
            rings,
            controls,
        )
        heights = _settle_fire_upper_wall_visual_crosscut_shelves(
            heights,
            path_mask,
            crater_loop_mask,
            lava_mask,
            radial_segments,
            rings,
            controls,
        )
        heights = _settle_fire_outer_wall_local_ring_locks(
            heights,
            path_mask,
            crater_loop_mask,
            lava_mask,
            radial_segments,
            rings,
            controls,
        )
        heights = _settle_fire_outer_wall_local_ring_locks(
            heights,
            path_mask,
            crater_loop_mask,
            lava_mask,
            radial_segments,
            rings,
            controls,
        )
        heights = _settle_fire_upper_wall_visual_crosscut_shelves(
            heights,
            path_mask,
            crater_loop_mask,
            lava_mask,
            radial_segments,
            rings,
            controls,
        )
        heights = _cap_fire_outer_wall_angular_boundaries(
            heights,
            path_mask,
            crater_loop_mask,
            lava_mask,
            radial_segments,
            rings,
            controls,
        )
        heights = _settle_fire_inner_wall_late_breakline_locks(
            heights,
            path_mask,
            crater_loop_mask,
            lava_mask,
            radial_segments,
            rings,
            controls,
        )
        heights = _restore_fire_front_inner_breach_wall_drop(
            heights,
            path_mask,
            crater_loop_mask,
            lava_mask,
            radial_segments,
            rings,
            controls,
        )
        heights = _settle_fire_inner_wall_late_breakline_locks(
            heights,
            path_mask,
            crater_loop_mask,
            lava_mask,
            radial_segments,
            rings,
            controls,
        )
        heights = _restore_fire_front_inner_breach_wall_drop(
            heights,
            path_mask,
            crater_loop_mask,
            lava_mask,
            radial_segments,
            rings,
            controls,
        )
        heights = _weather_fire_late_collapse_scars(
            heights,
            path_mask,
            crater_loop_mask,
            lava_mask,
            volcano_mask,
            radial_segments,
            rings,
            controls,
        )
        heights = _shape_fire_upper_wall_nonconcentric_crest_bays(
            heights,
            path_mask,
            crater_loop_mask,
            lava_mask,
            radial_segments,
            rings,
            controls,
        )
        heights = _polish_fire_late_knife_edges_preserving_crest_bays(
            heights,
            path_mask,
            crater_loop_mask,
            lava_mask,
            radial_segments,
            rings,
            controls,
        )
        heights = _settle_fire_outer_wall_local_ring_locks(
            heights,
            path_mask,
            crater_loop_mask,
            lava_mask,
            radial_segments,
            rings,
            controls,
        )
        heights = _settle_fire_outer_wall_local_ring_locks(
            heights,
            path_mask,
            crater_loop_mask,
            lava_mask,
            radial_segments,
            rings,
            controls,
        )
        heights = _settle_fire_non_front_ash_deposition_bands(
            heights,
            path_mask,
            crater_loop_mask,
            lava_mask,
            radial_segments,
            rings,
            controls,
        )
        heights = _restore_fire_outer_wall_break_ring_variety(
            heights,
            path_mask,
            crater_loop_mask,
            lava_mask,
            radial_segments,
            rings,
            controls,
        )
        heights = _cap_fire_outer_wall_angular_boundaries(
            heights,
            path_mask,
            crater_loop_mask,
            lava_mask,
            radial_segments,
            rings,
            controls,
        )
        heights = _settle_fire_upper_wall_visual_crosscut_shelves(
            heights,
            path_mask,
            crater_loop_mask,
            lava_mask,
            radial_segments,
            rings,
            controls,
        )
        heights = _settle_fire_inner_wall_late_breakline_locks(
            heights,
            path_mask,
            crater_loop_mask,
            lava_mask,
            radial_segments,
            rings,
            controls,
        )
        heights = _restore_fire_front_inner_breach_wall_drop(
            heights,
            path_mask,
            crater_loop_mask,
            lava_mask,
            radial_segments,
            rings,
            controls,
        )
        heights = _restore_fire_front_breach_low_semantic_drop(
            heights,
            path_mask,
            crater_loop_mask,
            lava_mask,
            radial_segments,
            rings,
            controls,
        )
        heights = _restore_fire_upper_wall_crest_window_variety(
            heights,
            path_mask,
            crater_loop_mask,
            lava_mask,
            radial_segments,
            rings,
            controls,
        )
        heights = _restore_fire_upper_wall_visual_history_rows(
            heights,
            path_mask,
            crater_loop_mask,
            lava_mask,
            radial_segments,
            rings,
            controls,
        )
        heights = _cap_fire_front_high_crater_ash_curtain(
            heights,
            path_mask,
            crater_loop_mask,
            lava_mask,
            radial_segments,
            rings,
            controls,
        )
        heights = _polish_fire_nonfront_residual_sparks(
            heights,
            path_mask,
            crater_loop_mask,
            lava_mask,
            radial_segments,
            rings,
            controls,
        )
        heights = _restore_fire_upper_wall_crest_window_variety(
            heights,
            path_mask,
            crater_loop_mask,
            lava_mask,
            radial_segments,
            rings,
            controls,
        )
        heights = _restore_fire_outer_wall_break_ring_variety(
            heights,
            path_mask,
            crater_loop_mask,
            lava_mask,
            radial_segments,
            rings,
            controls,
        )
        heights = _cap_fire_outer_wall_angular_boundaries(
            heights,
            path_mask,
            crater_loop_mask,
            lava_mask,
            radial_segments,
            rings,
            controls,
        )
        heights = _restore_fire_upper_wall_visual_history_rows(
            heights,
            path_mask,
            crater_loop_mask,
            lava_mask,
            radial_segments,
            rings,
            controls,
        )
        heights = _restore_fire_secondary_collapse_shelf_readability(
            heights,
            path_mask,
            crater_loop_mask,
            lava_mask,
            radial_segments,
            rings,
            controls,
        )
        heights = _polish_fire_front_ash_toe_angular_curtain(
            heights,
            path_mask,
            crater_loop_mask,
            lava_mask,
            volcano_mask,
            radial_segments,
            rings,
            controls,
        )
        heights = _cap_fire_upper_wall_late_radial_combs(
            heights,
            path_mask,
            crater_loop_mask,
            lava_mask,
            radial_segments,
            rings,
            controls,
        )
        heights = _cap_fire_outer_wall_late_boundary_spikes(
            heights,
            path_mask,
            crater_loop_mask,
            lava_mask,
            radial_segments,
            rings,
            controls,
        )
        heights = _restore_fire_upper_wall_crest_window_variety(
            heights,
            path_mask,
            crater_loop_mask,
            lava_mask,
            radial_segments,
            rings,
            controls,
        )
        heights = _restore_fire_upper_wall_crest_window_variety(
            heights,
            path_mask,
            crater_loop_mask,
            lava_mask,
            radial_segments,
            rings,
            controls,
        )
        heights = _cap_fire_outer_wall_late_boundary_spikes(
            heights,
            path_mask,
            crater_loop_mask,
            lava_mask,
            radial_segments,
            rings,
            controls,
        )
        heights = _restore_fire_upper_wall_crest_window_variety(
            heights,
            path_mask,
            crater_loop_mask,
            lava_mask,
            radial_segments,
            rings,
            controls,
        )
        heights = _cap_fire_upper_wall_late_radial_combs(
            heights,
            path_mask,
            crater_loop_mask,
            lava_mask,
            radial_segments,
            rings,
            controls,
        )
        heights = _cap_fire_outer_wall_late_boundary_spikes(
            heights,
            path_mask,
            crater_loop_mask,
            lava_mask,
            radial_segments,
            rings,
            controls,
        )
        heights = _restore_fire_front_inner_breach_wall_drop(
            heights,
            path_mask,
            crater_loop_mask,
            lava_mask,
            radial_segments,
            rings,
            controls,
        )
    slope_mask = _derive_slope_mask(heights, radial_segments, rings)
    curvature_mask = _derive_curvature_mask(heights, radial_segments, rings)
    if biome == "fire":
        flow_accumulation_mask = _derive_flow_accumulation_mask(
            heights,
            route_protection_mask,
            lava_mask,
            ravine_mask,
            radial_segments,
            rings,
            float(controls.get("erosion_age", 0.45)),
        )
        lava_flow_mask = _derive_lava_flow_mask(
            lava_mask,
            ravine_mask,
            route_protection_mask,
            radial_segments,
            rings,
            float(controls.get("erosion_age", 0.45)),
            flow_accumulation_mask,
        )
    talus_mask = _derive_talus_mask(
        slope_mask,
        cliff_mask,
        route_protection_mask,
        lava_mask,
        volcano_mask,
        radial_segments,
        rings,
        float(controls.get("deposition_weight", 0.55)),
        curvature_mask,
    )
    if biome == "fire":
        talus_mask = _restore_fire_weathered_talus_readability(
            talus_mask,
            path_mask,
            lava_mask,
            crater_loop_mask,
            radial_segments,
            rings,
            controls,
        )
    strata_mask = _derive_strata_mask(
        heights,
        slope_mask,
        curvature_mask,
        cliff_mask,
        volcano_mask,
        path_mask,
        lava_mask,
        radial_segments,
        rings,
    )
    if biome == "fire":
        slope_mask, talus_mask, strata_mask = _restore_fire_process_mask_readability(
            slope_mask,
            talus_mask,
            strata_mask,
            path_mask,
            lava_mask,
            crater_loop_mask,
            volcano_mask,
            radial_segments,
            rings,
        )

    return TerrainField(
        radial_segments=radial_segments,
        rings=rings,
        biome=biome,
        heights=heights,
        path_mask=path_mask,
        lava_mask=lava_mask,
        ravine_mask=ravine_mask,
        volcano_mask=volcano_mask,
        crater_loop_mask=crater_loop_mask,
        cliff_mask=cliff_mask,
        slope_mask=slope_mask,
        talus_mask=talus_mask,
        lava_flow_mask=lava_flow_mask,
        flow_accumulation_mask=flow_accumulation_mask,
        curvature_mask=curvature_mask,
        strata_mask=strata_mask,
        controls=dict(controls),
    )


def build_semantic_terrain_field_from_layout(
    layout,
    radial_segments: int | None = None,
    rings: int | None = None,
    bake_quality: str = "draft",
) -> TerrainField:
    quality_profile = bake_quality_profile(bake_quality)
    radial_segments = radial_segments or int(quality_profile["segments"])
    rings = rings or int(quality_profile["rings"])
    controls = _layout_controls(layout, quality_profile)
    return _build_semantic_terrain_field(layout.radius_m, layout.seed, radial_segments, rings, layout.biome, controls)


def _material_for_terrain_field_face_base(field: TerrainField, ring: int, index: int) -> str:
    ring = max(1, min(field.rings, ring))
    index = index % field.radial_segments
    next_index = (index + 1) % field.radial_segments
    previous_ring = max(0, ring - 1)

    def face_average(mask: list[list[float]]) -> float:
        return (
            mask[ring][index]
            + mask[ring][next_index]
            + mask[previous_ring][index]
            + mask[previous_ring][next_index]
        ) * 0.25

    def face_peak(mask: list[list[float]]) -> float:
        return max(
            mask[ring][index],
            mask[ring][next_index],
            mask[previous_ring][index],
            mask[previous_ring][next_index],
        )

    def face_average_at(mask: list[list[float]], sample_ring: int, sample_index: int) -> float:
        sample_ring = max(1, min(field.rings, sample_ring))
        sample_index = sample_index % field.radial_segments
        sample_next_index = (sample_index + 1) % field.radial_segments
        sample_previous_ring = max(0, sample_ring - 1)
        return (
            mask[sample_ring][sample_index]
            + mask[sample_ring][sample_next_index]
            + mask[sample_previous_ring][sample_index]
            + mask[sample_previous_ring][sample_next_index]
        ) * 0.25

    path = face_average(field.path_mask)
    crater_loop = face_average(field.crater_loop_mask)
    lava = face_average(field.lava_mask)
    ravine = face_average(field.ravine_mask)
    slope = face_average(field.slope_mask)
    talus = face_average(field.talus_mask)
    strata = face_average(field.strata_mask)
    slope_peak = face_peak(field.slope_mask)
    talus_peak = face_peak(field.talus_mask)
    strata_peak = face_peak(field.strata_mask)
    volcano = face_average(field.volcano_mask)
    cliff = face_average(field.cliff_mask)
    lava_flow = face_average(field.lava_flow_mask)
    flow_accumulation = face_average(field.flow_accumulation_mask)
    radial_alpha = ring / field.rings if field.rings else 0.0
    face_angle = ((index + 0.5) / field.radial_segments) * math.tau

    material = "M_AshPlateau" if field.biome == "fire" else "M_TopGrass"
    path_threshold = 0.35
    crater_loop_threshold = 0.25
    lava_threshold = 0.34
    if field.biome == "fire" and field.rings >= 20:
        path_threshold = 0.72
        crater_loop_threshold = 0.46
        lava_threshold = 0.68

    route_material = path > path_threshold or crater_loop > crater_loop_threshold
    fire_steep_crater_wall = False
    if field.biome == "fire" and field.rings >= 20 and route_material:
        steep_crater_wall = crater_loop > crater_loop_threshold and path <= path_threshold and slope > 0.56
        steep_main_path_face = path > path_threshold and slope > 0.78
        fire_steep_crater_wall = steep_crater_wall
        if steep_crater_wall or steep_main_path_face:
            route_material = False

    if route_material:
        material = "M_PathDirt"
    fire_inner_strata_wall = (
        field.biome == "fire"
        and field.rings >= 20
        and radial_alpha < 0.42
        and path < 0.16
        and crater_loop < 0.22
        and lava <= lava_threshold
        and slope_peak > 0.66
        and strata_peak > 0.38
    )
    fire_crater_loop_wall_rock = (
        fire_steep_crater_wall
        and path < 0.32
        and lava <= lava_threshold
        and slope_peak > 0.70
        and strata_peak > 0.52
    )
    fire_volcano_strata_wall = (
        field.biome == "fire"
        and field.rings >= 20
        and 0.36 < radial_alpha < 0.54
        and path < 0.42
        and lava <= lava_threshold
        and volcano > 0.46
        and slope_peak > 0.68
        and strata_peak > 0.60
    )
    fire_lava_shoulder_rock = (
        field.biome == "fire"
        and field.rings >= 20
        and 0.52 < radial_alpha < 0.74
        and path < 0.24
        and crater_loop < 0.24
        and 0.26 < lava <= lava_threshold
        and slope_peak > 0.70
        and talus_peak > 0.16
    )
    fire_lava_material_bridge = False
    if (
        field.biome == "fire"
        and field.rings >= 20
        and 0.38 < radial_alpha < 0.92
        and path < 0.22
        and crater_loop < 0.22
        and 0.62 < lava <= lava_threshold
        and lava_flow > 0.58
        and flow_accumulation > 0.36
    ):
        lava_support = 0
        strong_flow_support = 0
        for support_ring, support_index in (
            (ring - 1, index),
            (ring + 1, index),
            (ring, index - 1),
            (ring, index + 1),
        ):
            if support_ring < 1 or support_ring > field.rings:
                continue
            neighbor_lava = face_average_at(field.lava_mask, support_ring, support_index)
            neighbor_flow = face_average_at(field.lava_flow_mask, support_ring, support_index)
            neighbor_accumulation = face_average_at(field.flow_accumulation_mask, support_ring, support_index)
            if neighbor_lava > lava_threshold or (
                neighbor_lava > 0.62
                and neighbor_flow > 0.58
                and neighbor_accumulation > 0.36
            ):
                lava_support += 1
            if neighbor_lava > 0.74 or neighbor_flow > 0.80:
                strong_flow_support += 1
        fire_lava_material_bridge = lava_support >= 2 and strong_flow_support >= 1
    fire_lava_cooling_crust_break = (
        field.biome == "fire"
        and field.rings >= 20
        and 0.815 < radial_alpha < 0.865
        and path < 0.22
        and crater_loop < 0.22
        and (
            lava > lava_threshold
            or (fire_lava_material_bridge and lava > 0.56)
            or (lava > 0.58 and lava_flow > 0.80 and flow_accumulation > 0.50)
        )
        and lava_flow > 0.54
        and flow_accumulation > 0.32
    )
    fire_lava_side_tongue = False
    fire_lava_side_levee = False
    fire_lava_cooling_finger = False
    fire_lava_cooling_island = False
    fire_lava_terminal_cooling_pocket = False
    fire_lava_mantle_cooling_slab = False
    fire_lava_outer_scallop = False
    fire_lava_cooling_over_tongue = False
    fire_lava_steep_cooling_wall = False
    fire_lava_isolated_between_cooling = False
    fire_lava_hot_bridge = False
    nearest_channel_offset = math.pi
    if field.biome == "fire" and field.rings >= 20 and 0.68 < radial_alpha <= 1.0 and path < 0.22 and crater_loop < 0.22:
        side_tongue_strength, side_levee_strength = _fire_lava_side_overflow_strengths(radial_alpha, face_angle, field.controls)
        fire_lava_side_tongue = (
            side_tongue_strength > 0.22
            and max(lava, lava_flow) > 0.24
            and flow_accumulation > 0.18
        )
        fire_lava_side_levee = (
            side_levee_strength > 0.14
            and (lava_flow > 0.16 or flow_accumulation > 0.18)
        )
        cooling_finger_strength = _fire_lava_cooling_finger_strength(radial_alpha, face_angle, field.controls)
        fire_lava_cooling_finger = (
            cooling_finger_strength > 0.20
            and max(lava, lava_flow) > 0.22
            and flow_accumulation > 0.16
        )
        cooling_island_strength = _fire_lava_cooling_island_strength(radial_alpha, face_angle, field.controls)
        fire_lava_cooling_island = (
            cooling_island_strength > 0.42
            and max(lava, lava_flow) > 0.20
            and flow_accumulation > 0.14
            and not (fire_lava_side_tongue and side_tongue_strength > 0.62)
        )
        outer_scallop_strength = _fire_lava_outer_scallop_strength(radial_alpha, face_angle, field.controls)
        fire_lava_outer_scallop = (
            outer_scallop_strength > 0.36
            and 0.94 < radial_alpha <= 1.0
            and max(lava, lava_flow) > 0.18
            and flow_accumulation > 0.12
            and not fire_lava_hot_bridge
            and not (fire_lava_side_tongue and side_tongue_strength > 0.66)
        )
        fire_lava_cooling_over_tongue = (
            fire_lava_side_tongue
            and fire_lava_cooling_finger
            and cooling_finger_strength > side_tongue_strength * 0.95
            and side_tongue_strength < 0.78
        )
        for sample_channel_angle in _lava_channel_angles(int(field.controls.get("lava_channel_count", 3))):
            signed_channel_angle = abs(math.atan2(math.sin(sample_channel_angle), math.cos(sample_channel_angle)))
            if signed_channel_angle < float(field.controls.get("path_width", _preset("fire")["path_width"])) * 1.25:
                continue
            nearest_channel_offset = min(
                nearest_channel_offset,
                abs(math.atan2(math.sin(face_angle - sample_channel_angle), math.cos(face_angle - sample_channel_angle))),
            )
        fire_lava_hot_bridge = (
            nearest_channel_offset < 0.046
            and (
                0.775 < radial_alpha < 0.802
                or 0.887 < radial_alpha < 0.906
            )
            and max(lava, lava_flow) > 0.38
            and flow_accumulation > 0.22
        )
        terminal_pocket_strength = _fire_lava_terminal_cooling_pocket_strength(radial_alpha, face_angle, field.controls)
        fire_lava_terminal_cooling_pocket = (
            terminal_pocket_strength > 0.32
            and max(lava, lava_flow) > 0.36
            and flow_accumulation > 0.18
            and slope_peak > 0.42
            and not fire_lava_hot_bridge
            and not fire_lava_side_levee
        )
        mantle_slab_strength = _fire_lava_mantle_cooling_slab_strength(radial_alpha, face_angle, field.controls)
        fire_lava_mantle_cooling_slab = (
            mantle_slab_strength > 0.30
            and (max(lava, lava_flow) > 0.18 or flow_accumulation > 0.16)
            and flow_accumulation > 0.10
            and not fire_lava_hot_bridge
            and not fire_lava_side_levee
            and not fire_lava_side_tongue
        )
        fire_lava_steep_cooling_wall = (
            0.72 < radial_alpha < 0.96
            and 0.048 < nearest_channel_offset < 0.25
            and max(lava, lava_flow) > 0.44
            and flow_accumulation > 0.24
            and slope_peak > 0.68
            and talus_peak > 0.32
            and not fire_lava_hot_bridge
            and not fire_lava_side_tongue
        )
        if (
            not fire_lava_side_tongue
            and not fire_lava_cooling_finger
            and 0.74 < radial_alpha < 0.91
            and max(lava, lava_flow) > 0.52
            and flow_accumulation > 0.30
        ):
            cooling_neighbor_support = 0
            for sample_ring, sample_index in (
                (ring - 1, index),
                (ring + 1, index),
                (ring, index - 1),
                (ring, index + 1),
            ):
                sample_ring = max(1, min(field.rings, sample_ring))
                sample_index %= field.radial_segments
                sample_radial_alpha = sample_ring / field.rings if field.rings else 0.0
                sample_angle = ((sample_index + 0.5) / field.radial_segments) * math.tau
                _sample_tongue, sample_levee = _fire_lava_side_overflow_strengths(sample_radial_alpha, sample_angle, field.controls)
                sample_cooling_finger = _fire_lava_cooling_finger_strength(sample_radial_alpha, sample_angle, field.controls)
                sample_lava = face_average_at(field.lava_mask, sample_ring, sample_index)
                sample_flow = face_average_at(field.lava_flow_mask, sample_ring, sample_index)
                sample_accumulation = face_average_at(field.flow_accumulation_mask, sample_ring, sample_index)
                sample_slope = face_average_at(field.slope_mask, sample_ring, sample_index)
                sample_talus = face_average_at(field.talus_mask, sample_ring, sample_index)
                sample_cooling_crust = (
                    0.815 < sample_radial_alpha < 0.865
                    and sample_lava > 0.52
                    and sample_flow > 0.46
                    and sample_accumulation > 0.28
                )
                sample_weathered_rock = (
                    sample_lava > 0.42
                    and sample_flow > 0.48
                    and sample_slope > 0.58
                    and sample_talus > 0.46
                )
                if sample_cooling_finger > 0.18 or sample_levee > 0.14 or sample_cooling_crust or sample_weathered_rock:
                    cooling_neighbor_support += 1
            cooling_chip_window = (
                (0.770 < radial_alpha < 0.800 and 0.095 < nearest_channel_offset < 0.132)
                or (0.865 < radial_alpha < 0.888 and nearest_channel_offset < 0.046)
            )
            fire_lava_isolated_between_cooling = (
                cooling_neighbor_support >= 4
                or (cooling_neighbor_support >= 3 and cooling_chip_window and slope_peak > 0.74 and talus_peak > 0.58)
            )
    if (
        field.biome == "ice"
        and (
            _ice_resource_cluster_strength(radial_alpha, face_angle, field.controls) > 0.34
            or (_ice_broken_plate_edge_strength(radial_alpha, face_angle, field.controls) > 0.48 and slope > 0.32)
        )
    ):
        material = "M_CliffRock"
    if (
        (lava > lava_threshold and not fire_lava_cooling_crust_break and not fire_lava_side_levee and not fire_lava_cooling_finger and not fire_lava_cooling_island and not fire_lava_terminal_cooling_pocket and not fire_lava_mantle_cooling_slab and not fire_lava_outer_scallop and not fire_lava_steep_cooling_wall and not fire_lava_isolated_between_cooling)
        or (fire_lava_material_bridge and not fire_lava_cooling_crust_break and not fire_lava_side_levee and not fire_lava_cooling_finger and not fire_lava_cooling_island and not fire_lava_terminal_cooling_pocket and not fire_lava_mantle_cooling_slab and not fire_lava_outer_scallop and not fire_lava_steep_cooling_wall and not fire_lava_isolated_between_cooling)
        or (fire_lava_side_tongue and not fire_lava_cooling_over_tongue and not fire_lava_terminal_cooling_pocket and not fire_lava_mantle_cooling_slab and not fire_lava_outer_scallop and not fire_lava_steep_cooling_wall)
        or (fire_lava_hot_bridge and not fire_lava_cooling_island and not fire_lava_terminal_cooling_pocket and not fire_lava_mantle_cooling_slab and not fire_lava_outer_scallop and not fire_lava_steep_cooling_wall and not fire_lava_isolated_between_cooling and not fire_lava_cooling_finger and not fire_lava_side_levee)
        or (ravine > _preset(field.biome)["ravine_threshold"] and not fire_lava_mantle_cooling_slab and not fire_lava_outer_scallop and not fire_lava_steep_cooling_wall)
        or (
            2.15 <= ((index + 0.5) / field.radial_segments) * math.tau <= 2.55
            and ring >= field.rings - 2
            and field.biome != "ice"
            and not fire_lava_outer_scallop
        )
    ):
        material = "M_ElementCrack"
    elif (
        fire_lava_cooling_crust_break
        or fire_lava_side_levee
        or fire_lava_cooling_finger
        or fire_lava_cooling_island
        or fire_lava_terminal_cooling_pocket
        or fire_lava_mantle_cooling_slab
        or fire_lava_outer_scallop
        or fire_lava_cooling_over_tongue
        or fire_lava_steep_cooling_wall
        or fire_lava_isolated_between_cooling
    ):
        material = "M_CliffRock"
    elif (
        material in TOP_SURFACE_MATERIALS
        and field.biome == "fire"
        and field.rings >= 20
        and (
            slope > 0.68
            or (radial_alpha > 0.54 and slope_peak > 0.72 and talus_peak > 0.30)
            or fire_inner_strata_wall
            or fire_crater_loop_wall_rock
            or fire_volcano_strata_wall
            or fire_lava_shoulder_rock
        )
        and (
            strata > 0.34
            or volcano > 0.22
            or cliff > 0.46
            or (slope > 0.76 and 0.24 < lava <= lava_threshold)
            or (radial_alpha > 0.54 and slope > 0.82 and talus > 0.34 and max(strata, lava) > 0.22)
            or (radial_alpha > 0.54 and slope_peak > 0.72 and talus_peak > 0.30)
            or fire_inner_strata_wall
            or fire_crater_loop_wall_rock
            or fire_volcano_strata_wall
            or fire_lava_shoulder_rock
        )
    ):
        material = "M_CliffRock"

    if material == "M_CliffRock" and field.biome == "fire" and field.rings >= 20:
        signed_face_angle = abs(math.atan2(math.sin(face_angle), math.cos(face_angle)))
        ash_pocket_wave = 0.5 + 0.5 * math.sin(
            face_angle * 6.0
            + _smooth_fbm(math.cos(face_angle) * 2.3, math.sin(face_angle) * 2.3, 927, 2) * 2.0
        )
        outer_strata_candidate = (
            0.46 < radial_alpha < 0.54
            and path <= 0.22
            and lava <= 0.18
            and volcano > 0.88
            and slope_peak > 0.68
            and strata_peak > 0.60
        )
        blackrock_talus_candidate = (
            field.path_mask[ring][index] <= 0.20
            and field.crater_loop_mask[ring][index] <= 0.18
            and field.lava_mask[ring][index] <= 0.20
            and field.slope_mask[ring][index] > 0.72
            and field.talus_mask[ring][index] > 0.32
        )
        non_front_ash_deposition_pocket = (
            0.515 < radial_alpha < 0.582
            and signed_face_angle > 0.34
            and max(path, lava, crater_loop) < 0.22
            and lava < 0.16
            and flow_accumulation < 0.45
            and talus < 0.34
            and not outer_strata_candidate
            and not blackrock_talus_candidate
            and ash_pocket_wave > 0.65
        )
        if non_front_ash_deposition_pocket:
            material = "M_AshPlateau"

    return material


def _refined_fire_material_cache(field: TerrainField) -> dict[tuple[int, int], str]:
    materials = {
        (ring, index): _material_for_terrain_field_face_base(field, ring, index)
        for ring in range(1, field.rings + 1)
        for index in range(field.radial_segments)
    }

    def element_crack_components() -> list[list[tuple[int, int]]]:
        seen: set[tuple[int, int]] = set()
        components: list[list[tuple[int, int]]] = []
        for cell, material in list(materials.items()):
            if material != "M_ElementCrack" or cell in seen:
                continue

            stack = [cell]
            seen.add(cell)
            component: list[tuple[int, int]] = []
            while stack:
                ring, index = stack.pop()
                component.append((ring, index))
                for next_ring, next_index in (
                    (ring - 1, index),
                    (ring + 1, index),
                    (ring, (index - 1) % field.radial_segments),
                    (ring, (index + 1) % field.radial_segments),
                ):
                    if next_ring < 1 or next_ring > field.rings:
                        continue
                    neighbor = (next_ring, next_index)
                    if neighbor in seen or materials.get(neighbor) != "M_ElementCrack":
                        continue
                    seen.add(neighbor)
                    stack.append(neighbor)
            components.append(component)
        return components

    def row_runs(cells: set[tuple[int, int]], ring: int) -> list[tuple[int, int]]:
        flags = [(ring, index) in cells for index in range(field.radial_segments)]
        if not any(flags):
            return []
        if all(flags):
            return [(0, field.radial_segments)]

        anchor = next(index for index, flag in enumerate(flags) if not flag)
        runs: list[tuple[int, int]] = []
        run_start = -1
        run_length = 0
        for step in range(1, field.radial_segments + 1):
            index = (anchor + step) % field.radial_segments
            if flags[index]:
                if run_length == 0:
                    run_start = index
                run_length += 1
            elif run_length > 0:
                runs.append((run_start, run_length))
                run_length = 0
        if run_length > 0:
            runs.append((run_start, run_length))
        return runs

    for component in element_crack_components():
        if len(component) < 8:
            for component_cell in component:
                materials[component_cell] = "M_CliffRock"

    outer_start = max(1, round(field.rings * 0.56))
    outer_end = min(field.rings, round(field.rings * 0.96))
    for component in element_crack_components():
        if len(component) < 80:
            continue

        cells = set(component)
        broad_rows: list[tuple[int, int, list[tuple[int, int]]]] = []
        for ring in range(outer_start, outer_end + 1):
            runs = row_runs(cells, ring)
            longest = max((length for _start, length in runs), default=0)
            if longest >= 18:
                broad_rows.append((ring, longest, runs))

        if not broad_rows:
            continue

        rows_to_break = {ring for ring, longest, _runs in broad_rows if longest > 34}
        for ring, longest, _runs in sorted(broad_rows, key=lambda item: item[1], reverse=True):
            if len(broad_rows) - len(rows_to_break) <= 18:
                break
            rows_to_break.add(ring)

        for ring, _longest, runs in broad_rows:
            if ring not in rows_to_break:
                continue
            for run_start, run_length in runs:
                if run_length < 18:
                    continue
                for cut_offset in range(16, run_length, 17):
                    materials[(ring, (run_start + cut_offset) % field.radial_segments)] = "M_CliffRock"

    for component in element_crack_components():
        if len(component) < 8:
            for component_cell in component:
                materials[component_cell] = "M_CliffRock"

    return materials


def material_for_terrain_field_face(field: TerrainField, ring: int, index: int) -> str:
    ring = max(1, min(field.rings, ring))
    index = index % field.radial_segments
    if field.biome == "fire" and field.rings >= 20:
        cache = getattr(field, "_fire_refined_material_cache", None)
        if cache is None:
            cache = _refined_fire_material_cache(field)
            setattr(field, "_fire_refined_material_cache", cache)
        return cache[(ring, index)]

    return _material_for_terrain_field_face_base(field, ring, index)


def generate_island_mesh(radius_m: float, seed: int, radial_segments: int = 48, rings: int = 14, biome: str = "forest") -> Mesh:
    """Generate a deterministic floating island mesh in Unreal centimeters."""
    return _generate_island_mesh(radius_m, seed, radial_segments, rings, biome)


def generate_island_mesh_from_layout(layout, radial_segments: int | None = None, rings: int | None = None, bake_quality: str = "draft") -> Mesh:
    """Generate a mesh from a semantic layout, currently bridging fire controls first."""
    mesh, _terrain_field = generate_island_mesh_and_field_from_layout(layout, radial_segments, rings, bake_quality)
    return mesh


def generate_island_mesh_and_field_from_layout(
    layout,
    radial_segments: int | None = None,
    rings: int | None = None,
    bake_quality: str = "draft",
) -> tuple[Mesh, TerrainField]:
    """Generate a mesh and the matching semantic field in one pass for web preview diagnostics."""
    quality_profile = bake_quality_profile(bake_quality)
    radial_segments = radial_segments or int(quality_profile["segments"])
    rings = rings or int(quality_profile["rings"])
    controls = _layout_controls(layout, quality_profile)
    terrain_field = _build_semantic_terrain_field(layout.radius_m, layout.seed, radial_segments, rings, layout.biome, controls)
    return _generate_island_mesh_from_field(layout.radius_m, layout.seed, terrain_field, controls), terrain_field


def _generate_island_mesh(radius_m: float, seed: int, radial_segments: int, rings: int, biome: str, controls: dict[str, object] | None = None) -> Mesh:
    controls = controls or {}
    terrain_field = _build_semantic_terrain_field(radius_m, seed, radial_segments, rings, biome, controls)
    return _generate_island_mesh_from_field(radius_m, seed, terrain_field, controls)


def _generate_island_mesh_from_field(radius_m: float, seed: int, terrain_field: TerrainField, controls: dict[str, object] | None = None) -> Mesh:
    controls = controls or terrain_field.controls or {}
    rng = random.Random(seed)
    mesh = Mesh()
    mesh.materials = materials_for_biome(terrain_field.biome)
    radius_cm = radius_m * 100.0
    radial_segments = terrain_field.radial_segments
    rings = terrain_field.rings
    biome = terrain_field.biome

    edge_scales = [
        max(0.72, _edge_scale((i / radial_segments) * math.tau, rng))
        for i in range(radial_segments)
    ]
    edge_scales = _smooth_circular_values(edge_scales, max(1, min(4, radial_segments // 96)))

    top_rings: list[list[int]] = []
    center_idx = _add_vertex(mesh, (0.0, 0.0, 0.0))
    top_rings.append([center_idx for _ in range(radial_segments)])

    for ring in range(1, rings + 1):
        radial_alpha = ring / rings
        ring_indices: list[int] = []
        for i in range(radial_segments):
            angle = (i / radial_segments) * math.tau
            local_radius = radius_cm * radial_alpha * edge_scales[i]
            x = math.cos(angle) * local_radius
            y = math.sin(angle) * local_radius
            z = terrain_field.heights[ring][i]
            ring_indices.append(_add_vertex(mesh, (x, y, z)))
        top_rings.append(ring_indices)

    _relax_top_heightfield(mesh, top_rings, radial_segments, rings, biome, controls or {})

    for ring in range(1, rings + 1):
        previous = top_rings[ring - 1]
        current = top_rings[ring]
        for i in range(radial_segments):
            j = (i + 1) % radial_segments
            material = material_for_terrain_field_face(terrain_field, ring, i)

            if ring == 1:
                mesh.faces.append((material, (center_idx, current[i], current[j])))
            else:
                mesh.faces.append((material, (previous[i], current[i], current[j], previous[j])))

    outer_top = top_rings[-1]
    underside_ring: list[int] = []
    preset = _preset(biome)
    for i in range(radial_segments):
        x, y, z = mesh.vertices[outer_top[i] - 1]
        underside_ring.append(_add_vertex(mesh, (x * 0.62, y * 0.62, z - radius_cm * preset["underside_depth"])))

    collapse_transfer = [0.0 for _ in range(radial_segments)]
    cliff_skirt_rings: list[list[int]] = []
    if biome == "fire" and radial_segments >= 32:
        collapse_window_size = max(12, min(24, radial_segments // 16))
        for start in range(0, radial_segments, collapse_window_size):
            window_columns: list[tuple[int, int]] = []
            for offset in range(collapse_window_size):
                index = (start + offset) % radial_segments
                candidates = []
                for ring in range(round(rings * 0.46), round(rings * 0.70)):
                    semantic_guard = max(
                        terrain_field.path_mask[ring][index],
                        terrain_field.lava_mask[ring][index],
                        terrain_field.crater_loop_mask[ring][index],
                        terrain_field.path_mask[ring + 1][index],
                        terrain_field.lava_mask[ring + 1][index],
                        terrain_field.crater_loop_mask[ring + 1][index],
                    )
                    if semantic_guard > 0.20:
                        continue
                    candidates.append((abs(terrain_field.heights[ring + 1][index] - terrain_field.heights[ring][index]), ring))
                if candidates:
                    _drop, break_ring = max(candidates)
                    window_columns.append((index, break_ring))

            if len(window_columns) < collapse_window_size * 0.55:
                continue

            break_rings = [break_ring for _index, break_ring in window_columns]
            ring_spread = max(break_rings) - min(break_rings)
            if ring_spread < 3:
                continue

            ring_mid = sum(break_rings) / len(break_rings)
            for column_offset, (index, break_ring) in enumerate(window_columns):
                angular_phase = column_offset / max(1.0, float(collapse_window_size))
                stagger = math.sin(angular_phase * math.tau * 2.0 + seed * 0.017)
                normalized_break = (break_ring - ring_mid) / max(1.0, float(ring_spread))
                collapse_transfer[index] = max(-0.42, min(0.42, normalized_break * 0.36 + stagger * 0.12))

        for step, t in enumerate((0.34, 0.67)):
            skirt_ring: list[int] = []
            for i in range(radial_segments):
                angle = (i / radial_segments) * math.tau
                visual_window = i // collapse_window_size
                shear_offset = 0
                if step == 1:
                    shear_offset = 5 + ((visual_window * 7 + seed) % 9)
                pattern_i = (i + shear_offset) % radial_segments
                pattern_angle = (pattern_i / radial_segments) * math.tau
                top_x, top_y, top_z = mesh.vertices[outer_top[i] - 1]
                under_x, under_y, under_z = mesh.vertices[underside_ring[i] - 1]
                ledge_noise = 0.5 + 0.5 * math.sin(pattern_angle * (6.0 + step * 3.0) + seed * (0.009 + step * 0.004))
                chip_noise = 0.5 + 0.5 * math.sin(pattern_angle * (13.0 + step * 2.0) + seed * (0.005 + step * 0.003))
                cell_count = 24.0
                cell_phase = ((pattern_i / radial_segments) * cell_count + (seed % 97) * 0.011 + step * 0.37) % cell_count
                cell = math.floor(cell_phase)
                cell_t = cell_phase - cell
                cell_blend = _smoothstep(0.28, 0.72, cell_t)
                block_a = _value_noise(cell, 19.0 + step * 7.0, seed + 421)
                block_b = _value_noise(cell + 1, 19.0 + step * 7.0, seed + 421)
                block_slump = block_a * 0.72 + _lerp(block_a, block_b, cell_blend) * 0.28
                edge_weight = max(
                    1.0 - _smoothstep(0.0, 0.20, cell_t),
                    1.0 - _smoothstep(0.0, 0.20, 1.0 - cell_t),
                )
                edge_sign = 1.0 if _value_noise(cell, 31.0 + step * 5.0, seed + 733) >= 0.0 else -1.0
                seam_slump = 0.0
                for seam_index, seam_center in enumerate((11, 45, 82, 118, 153, 188, 224, 263, 301, 337, 371)):
                    shifted_center = (seam_center + seed % 19) % radial_segments
                    seam_distance = abs(pattern_i - shifted_center)
                    seam_distance = min(seam_distance, radial_segments - seam_distance)
                    if seam_distance > 3:
                        continue
                    seam_weight = 1.0 - _smoothstep(0.0, 3.0, seam_distance)
                    seam_sign = 1.0 if _value_noise(seam_index, 43.0 + step * 3.0, seed + 977) >= 0.0 else -1.0
                    seam_slump += seam_weight * seam_sign * (0.220 + step * 0.028)
                    if seam_distance < 0.5:
                        seam_slump += seam_sign * (0.330 + step * 0.050)
                visual_start = visual_window * collapse_window_size
                visual_t = ((i - visual_start + shear_offset) % collapse_window_size) / max(1.0, float(collapse_window_size - 1))
                event_center = 0.18 + 0.64 * (0.5 + 0.5 * math.sin(visual_window * 1.917 + seed * 0.0061))
                event_distance = abs(visual_t - event_center)
                event_weight = 1.0 - _smoothstep(0.012, 0.105, event_distance)
                event_sign = 1.0 if math.sin(visual_window * 2.713 + seed * 0.013 + step * 1.37) >= 0.0 else -1.0
                macro_collapse_slump = event_weight * event_sign * (0.335 + step * 0.060)
                collapse_sample_i = pattern_i if step == 1 else i
                collapse_slump = collapse_transfer[collapse_sample_i] * (0.24 + step * 0.055)
                collapse_edge = (collapse_transfer[collapse_sample_i] - collapse_transfer[collapse_sample_i - 1]) * (0.14 + step * 0.035)
                fractured_slump = (
                    block_slump * (0.088 + step * 0.018)
                    + edge_weight * edge_sign * 0.115
                    + seam_slump
                    + macro_collapse_slump
                    + collapse_slump
                    + collapse_edge
                )
                shear_wave = 0.0
                if step == 1:
                    shear_wave = (
                        math.sin((visual_t * 3.0 + visual_window * 0.37 + seed * 0.002) * math.tau) * 0.64
                        + math.sin((visual_t * 6.5 + visual_window * 0.19 + seed * 0.0037) * math.tau) * 0.36
                    )
                local_t = max(0.08, min(0.92, t + (ledge_noise - 0.5) * 0.035 + fractured_slump + shear_wave * 0.050))
                ledge_push = (
                    (0.018 + chip_noise * 0.018) * (1.0 if step == 0 else -0.55)
                    + fractured_slump * (0.30 if step == 0 else -0.22)
                    + shear_wave * (0.0 if step == 0 else 0.076)
                )
                x = top_x * (1.0 - local_t) + under_x * local_t
                y = top_y * (1.0 - local_t) + under_y * local_t
                z = top_z * (1.0 - local_t) + under_z * local_t
                x *= 1.0 + ledge_push
                y *= 1.0 + ledge_push
                z += (
                    (ledge_noise - 0.5) * radius_cm * 0.018
                    + fractured_slump * radius_cm * (0.34 if step == 0 else -0.22)
                    + collapse_transfer[collapse_sample_i] * radius_cm * (0.026 if step == 0 else -0.018)
                    + shear_wave * radius_cm * (0.0 if step == 0 else 0.046)
                )
                skirt_ring.append(_add_vertex(mesh, (x, y, z)))
            cliff_skirt_rings.append(skirt_ring)

    bottom_tip = _add_vertex(mesh, (0.0, 0.0, -radius_cm * preset["bottom_depth"]))
    lower_underside_ring: list[int] = []
    bottom_cap_ring: list[int] = []
    if biome == "fire" and radial_segments >= 32:
        for i in range(radial_segments):
            angle = (i / radial_segments) * math.tau
            x, y, _z = mesh.vertices[outer_top[i] - 1]
            lower_noise = 0.5 + 0.5 * math.sin(angle * 5.0 + seed * 0.013)
            lower_noise = lower_noise * 0.58 + (0.5 + 0.5 * math.sin(angle * 11.0 + seed * 0.007)) * 0.42
            collapse_bite = collapse_transfer[i]
            collapse_edge = collapse_transfer[i] - collapse_transfer[i - 1]
            visual_window = i // collapse_window_size
            visual_start = visual_window * collapse_window_size
            visual_t = (i - visual_start) / max(1.0, float(collapse_window_size - 1))
            undercut_break = 0.0
            for notch_index, notch_center in enumerate((0.24, 0.68)):
                notch_distance = abs(visual_t - notch_center)
                notch_weight = 1.0 - _smoothstep(0.012, 0.082, notch_distance)
                if notch_weight <= 0.0:
                    continue
                notch_sign = 1.0 if math.sin(visual_window * 2.41 + notch_index * 1.73 + seed * 0.008) >= 0.0 else -1.0
                undercut_break += notch_weight * notch_sign
            undercut_break = max(-1.0, min(1.0, undercut_break))
            lower_scale = 0.23 + lower_noise * 0.085
            lower_scale *= 1.0 + collapse_bite * 0.16 + collapse_edge * 0.10 + undercut_break * 0.045
            lower_scale = max(0.18, min(0.40, lower_scale))
            lower_z = -radius_cm * (preset["bottom_depth"] - 0.18 - lower_noise * 0.055)
            lower_z += radius_cm * (collapse_bite * 0.016 + collapse_edge * 0.012 + undercut_break * 0.010)
            lower_underside_ring.append(_add_vertex(mesh, (x * lower_scale, y * lower_scale, lower_z)))
            cap_noise = 0.5 + 0.5 * math.sin(angle * 7.0 + seed * 0.011)
            cap_scale = 0.055 + cap_noise * 0.030
            cap_scale *= 1.0 + collapse_bite * 0.20 + collapse_edge * 0.34 + undercut_break * 0.34
            cap_scale = max(0.045, min(0.128, cap_scale))
            cap_z = -radius_cm * (preset["bottom_depth"] - cap_noise * 0.020)
            cap_z += radius_cm * (collapse_bite * 0.018 + collapse_edge * 0.024 + undercut_break * 0.016)
            bottom_cap_ring.append(_add_vertex(mesh, (x * cap_scale, y * cap_scale, cap_z)))

    for i in range(radial_segments):
        j = (i + 1) % radial_segments
        angle = ((i + 0.5) / radial_segments) * math.tau
        if cliff_skirt_rings:
            skirt_rings = [outer_top, *cliff_skirt_rings, underside_ring]
            for upper_ring, lower_ring in zip(skirt_rings, skirt_rings[1:]):
                mesh.faces.append(("M_CliffRock", (upper_ring[i], lower_ring[i], lower_ring[j], upper_ring[j])))
        elif biome != "forest" or _forest_cave_strength(angle) <= 0.45:
            mesh.faces.append(("M_CliffRock", (outer_top[i], underside_ring[i], underside_ring[j], outer_top[j])))
        if lower_underside_ring:
            mesh.faces.append(("M_UndersideRock", (underside_ring[i], lower_underside_ring[i], lower_underside_ring[j], underside_ring[j])))
            mesh.faces.append(("M_UndersideRock", (lower_underside_ring[i], bottom_cap_ring[i], bottom_cap_ring[j], lower_underside_ring[j])))
            mesh.faces.append(("M_UndersideRock", (bottom_cap_ring[i], bottom_tip, bottom_cap_ring[j])))
        else:
            mesh.faces.append(("M_UndersideRock", (underside_ring[i], bottom_tip, underside_ring[j])))

    return mesh


def _normalized_vector(vector: tuple[float, float, float]) -> tuple[float, float, float]:
    x, y, z = vector
    length = math.sqrt(x * x + y * y + z * z)
    if length <= 0.0001:
        return (0.0, 0.0, 1.0)
    return (x / length, y / length, z / length)


def _face_normal(mesh: Mesh, indices: tuple[int, ...]) -> tuple[float, float, float]:
    nx = 0.0
    ny = 0.0
    nz = 0.0
    vertices = [mesh.vertices[index - 1] for index in indices]
    for index, current in enumerate(vertices):
        next_vertex = vertices[(index + 1) % len(vertices)]
        nx += (current[1] - next_vertex[1]) * (current[2] + next_vertex[2])
        ny += (current[2] - next_vertex[2]) * (current[0] + next_vertex[0])
        nz += (current[0] - next_vertex[0]) * (current[1] + next_vertex[1])
    return _normalized_vector((nx, ny, nz))


def _compute_vertex_normals(mesh: Mesh) -> list[tuple[float, float, float]]:
    accumulators = [(0.0, 0.0, 0.0) for _ in mesh.vertices]
    for _material, indices in mesh.faces:
        normal = _face_normal(mesh, indices)
        for vertex_index in indices:
            x, y, z = accumulators[vertex_index - 1]
            accumulators[vertex_index - 1] = (x + normal[0], y + normal[1], z + normal[2])
    return [_normalized_vector(normal) for normal in accumulators]


def write_obj(mesh: Mesh, output_path: Path) -> None:
    output_path.parent.mkdir(parents=True, exist_ok=True)
    lines: list[str] = ["o SM_ProcIsland"]

    for vertex in mesh.vertices:
        lines.append(f"v {vertex[0]:.3f} {vertex[1]:.3f} {vertex[2]:.3f}")

    for normal in _compute_vertex_normals(mesh):
        lines.append(f"vn {normal[0]:.6f} {normal[1]:.6f} {normal[2]:.6f}")

    lines.append("s 1")
    current_material = None
    for material, indices in mesh.faces:
        if material != current_material:
            lines.append(f"usemtl {material}")
            current_material = material
        lines.append("f " + " ".join(f"{index}//{index}" for index in indices))

    output_path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser(description="Generate a procedural floating island OBJ for UE prototyping.")
    parser.add_argument("--radius-m", type=float, default=30.0)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--segments", type=int, default=48)
    parser.add_argument("--biome", choices=sorted(BIOME_PRESETS), default="forest")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    mesh = generate_island_mesh(args.radius_m, args.seed, args.segments, biome=args.biome)
    write_obj(mesh, args.output)
    print(f"Wrote {args.output} with {len(mesh.vertices)} vertices and {len(mesh.faces)} faces")


if __name__ == "__main__":
    main()
