# Fire Crater Wall Arc Mindset

> Scope: Fire volcano island macro wall layout, grey whitebox credibility, and Meshy/PBR handoff before texture.

## 一句话

火山岛下一阶段的 Gaea/Houdini 化，关键不是继续把尖刺磨圆，而是让黑色火山口外壁不再读成一个规则极坐标圆环。它必须像被多次喷发、崩塌、熔岩外溢和灰烬沉积切过的火山体。

## 本轮视觉痛点

当前 Fire HERO 已经有 crater、route、lava channel、ash plateau、basalt shelf 和 material slot 因果，但多角度侧后视图仍有一个明显问题：

- 外壁最强 cliff drop 仍大量集中在同一个 ring。
- 局部 16-32 个 segment 的窗口里，很多段几乎整段都在同一条环线上断落。
- 这会让侧光下的黑色火山墙读成“百叶窗/圆锥切片”，不是自然火山口墙。
- 单纯平滑会降低毛刺，却也会削弱 crater wall 的力量；这不是正确方向。

## 正确方向

要做的是 first-class macro landform，不是 late cleanup。

火山口外壁应由几类大形共同组成：

- buttress arcs：局部外鼓的支撑岩脊，像冷却玄武岩墙体残留。
- breach scar arcs：熔岩外溢或崩塌形成的缺口伤疤，外壁 drop 向外或向内偏移。
- slump benches：坍塌后的阶地，不完整、不闭环、不均匀。
- ash-draped saddles：灰烬覆盖的低鞍部，连接 route 或 lava shoulder。
- oblique bands：斜向滑塌带，打断纯 radial column。

关键是让 cliff break 的 ring 在不同角度窗口里自然游走，并且同一个局部窗口内部也有 2-4 个 ring 的变化。自然火山不是每一度角都在同一圈上断裂。

## 约束

必须保留：

- main route 安全和可读性。
- crater loop 可读性。
- lava core/channel 身份。
- Fire 5-slot Meshy-safe material contract：
  - `M_AshPlateau`
  - `M_PathDirt`
  - `M_CliffRock`
  - `M_UndersideRock`
  - `M_ElementCrack`
- 现有 field/manifest/quality_report/OBJ 输出契约。

不得做：

- 全局 smoothing。
- 把 crater wall 磨成低频土坡。
- 添加第六个材质槽。
- 把 Meshy 当作修地形逻辑的后处理器。

## 新的可测试指标

旧指标已经约束了三类问题：

- dominant outer-wall break ring coverage 不能过高。
- coherent polar curtain boundary 不能过强。
- long vertical boundary column 不能太长。

下一步需要更局部的宏观窗口指标：

- 在 outer wall band 中，每个可用 angular macro window 不能被单个 break ring 完全统治。
- 一个 24-segment 窗口里，最强 drop ring 应至少在多个 ring 之间游走。
- 这不是噪声指标，而是“局部火山墙弧段是否有自然错位”的指标。

目标不是让 ring 完全随机，而是让宏观弧段有可读的移位：

```text
bad:   R31 R31 R31 R31 R31 R31 R31 R31
good:  R29 R30 R31 R31 R32 R33 R32 R31
```

## 实现原则

新增 pass 应是 Fire-only，并且放在 outer wall cleanup 前：

```text
existing fire process layers
  -> outer basalt shelves
  -> outer apron chatter
  -> crater wall arc layout       <- 本轮新增/强化，负责宏观弧段
  -> asymmetric break arcs
  -> polar curtain cleanup
  -> diagonal breakup
  -> local ring-lock settling     <- 后置窄补刀，只处理仍被单 ring 统治的窗口
```

推荐做法：

1. 在 volcano_radius 附近定义 outer wall band。
2. 用少量确定性 angular arc fields 生成 sector center、width、ring shift、arc polarity。
3. 对每个 sector 只改 non-semantic guarded 区域。
4. 将原本同 ring 的强 cliff drop 分散到相邻 ring，并在目标 ring 轻微建立新 drop。
5. 用 oblique drift 让 arc 随角度斜向移动，而不是整段平行圆环。
6. 强度受 terrain_settle_intensity、erosion_age、deposition_weight 和 hero_resolution 控制。
7. 如果后续 cleanup 又把局部窗口压回单 ring，只允许一个极窄 final pass 解锁该窗口；final pass 不能整面重塑。

## 验收心智

这一轮结束后，Fire HERO 应该满足：

- 8-angle contact sheet 的侧/后视图，黑色外壁不再第一眼像规则圆锥百叶窗。
- 火山墙仍高、陡、有力，但断裂线变成不完整弧段和斜向坍塌带。
- 24-segment 局部窗口中，rigid single-ring break window 数量为 0。
- Route/lava/crater loop 不被宏观弧段破坏。
- quality report 不靠牺牲 routeHealth 换外观。
- Meshy 接到的 GLB/OBJ 会看到更可信的几何因果，而不是只靠 PBR 贴图遮丑。

## 距离判断

如果这个 macro wall arc pass 做好，Fire 白膜会从“局部细节很多的程序火山”推进到“中尺度地貌因果开始成立的火山”。这仍未等于 Gaea/Houdini，但会填上当前最刺眼的约 8-10% 差距。

下一轮再继续看：

- lava flow branching 是否还像角度射线。
- non-front ash plateau 是否还有过度噪声。
- material compactness 是否足够给 Meshy 一次性 retexture。
- side/back silhouette 是否有真正的破碎岛屿质量。
