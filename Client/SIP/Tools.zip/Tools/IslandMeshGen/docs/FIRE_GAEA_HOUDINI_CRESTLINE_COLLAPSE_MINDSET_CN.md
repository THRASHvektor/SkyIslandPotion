# Fire Gaea/Houdini Crestline Collapse Mindset

Date: 2026-07-07

这份文档记录当前 Fire 白膜向 Gaea/Houdini 靠近时最关键的一道坎：火山口上墙不能只是被横向 shelf 修饰，也不能只是把局部竖槽磨平，而要让大形 crestline 本身出现非同心的塌陷湾、滑移墙体和沉积肩部。

## 核心判断

真正接近 Gaea/Houdini 的火山口，不会读成一个规整的极坐标筒壁。它应该有几种同时存在的历史痕迹：

- 主火山锥仍然成立，远看有清楚的大形和 crater 逻辑。
- 上墙 crestline 不是同一圈高度，而是被几次塌陷事件拉开，形成前后错位的高点、缺口和湾。
- 塌陷不是刀切。每个 bay 必须有肩部、回填、坡脚沉积和局部风化。
- 横切 shelf、斜向错层、下方 cliff skirt 和底部 undercut 要像不同年代的事件叠在一起，而不是同一个 pattern 复制到不同高度。
- 纯 clay 模式必须先成立。材质和 Meshy PBR 只能奖励这个几何，不负责拯救它。

## 当前红线

`test_fire_demo_hero_upper_wall_crestline_has_nonconcentric_collapse_bays` 已经证明大形 crestline 可以被打破，但它带出了 6 条保护测试回归：

- inner wall 单步径向落差过大，说明 collapse bay 的力量穿透到了不该硬切的内壁。
- front ash plateau 局部范围过大，说明正面灰台地被墙体事件打成机器幕帘。
- non-front ash plateau 有效沉积样本变少，说明材质/几何状态被挤出了灰台地判定。
- ash hotspot residual 过高，说明灰台地局部仍有热点刀痕。
- weathering cleanup p99 过高，说明整体中外圈存在孤立尖点。
- mid blackrock/talus residual 过高，说明坡脚黑岩没有读成宽沉积带，而是读成硬折线。

所以本轮的正确方向不是撤销 crestline bay，也不是全局 smooth。正确方向是给 crestline collapse 增加二维的风化肩部和沉积回填，让“大形非同心”和“局部岁月痕迹”同时成立。

## 实现纪律

每一轮修改必须遵守：

- 不新增第 6 个材质槽，Fire 仍然只有 `M_AshPlateau`、`M_PathDirt`、`M_CliffRock`、`M_UndersideRock`、`M_ElementCrack`。
- 不削弱 route、crater loop、lava channel、terminal fan 的语义可读性。
- 不用全局 smoothing 抹掉 lava/path/crater，只在 Fire 的 wall/ash/talus 风化窗口内做特征保护的局部沉降。
- 新 crestline bay 必须继续通过：不能为了低 residual 又退回同心火山筒。
- 先跑目标测试，再跑 upper/inner/skirt、bottom/skirt、syntax、Node、全量 Python，最后 hero bake 和 8-angle clay/material。

## 停手标准

Fire 白膜可以暂时停下来的条件不是“测试全绿”而是：

- 8 个 clay 角度都不再明显读成极坐标筒壁、百叶窗、裙边帘幕或底部三角扇。
- 200m 尺度远看有主火山体积，50m 中看有 collapse bay、lava channel、ash deposition、talus apron，5m 近看没有恼人的孤立刀尖。
- material 预览只是增强分区，不靠红色裂缝和 PBR 噪声掩盖白膜问题。
- quality report 的健康度稳定，同时人工视觉不再觉得“这是程序噪声岛”。

一句话：现在要做的是把“非同心火山口”从几何事件升级成地质事件。塌陷要有年代，刀口要有风化，坡脚要有沉积。
