# Fire Gaea/Houdini Extreme Target Mindset

Date: 2026-07-06

This document defines the current stop condition for the Fire island whitebox loop. The goal is not merely to pass health metrics. The goal is a grey/white hero mesh that already reads like a volcanic terrain shaped by believable forces before Meshy, PBR, UE materials, or VFX are allowed to make it beautiful.

## Core Judgment

An "extremely close to Gaea/Houdini" Fire result means:

- At 200m, the island silhouette reads as a volcanic mass, not a polar mesh.
- At 50m, crater, rim, lava channels, cooled shelves, ash deposition, route, basalt shelves, and cliff skirt all read as separate but causally connected landforms.
- At 5m, local detail looks like erosion, cooling, fracture, talus, and deposition, not random procedural noise.
- In pure grey, the mesh is already credible. Meshy should reward the structure, not rescue it.

The strongest danger is not lack of smoothness. It is fake causality: material regions, height changes, and semantic masks disagreeing with each other. Whenever that happens, the result may look detailed, but it will not look like Gaea or Houdini.

## Current Non-Negotiable Contracts

Fire must keep exactly five material slots:

```text
M_AshPlateau
M_PathDirt
M_CliffRock
M_UndersideRock
M_ElementCrack
```

Do not add a sixth material. Region control for Meshy must come from better geometry, compact existing material regions, and better prompts, not from exploding the material contract.

Do not break these gameplay/export contracts:

- main route
- crater loop
- lava channels and lava cores
- terminal fans
- field / manifest / quality_report / OBJ outputs
- Meshy-safe material compactness

## The Correct Loop

Each serious Fire pass should follow this order:

```text
visual symptom
  -> one measurable regression
  -> watch it fail
  -> one process-layer fix
  -> targeted regression suite
  -> full verification
  -> HERO bake
  -> multi-angle evidence
  -> update mindset
```

The loop must stay feature-preserving. Global smoothing is not a solution. If the crater, lava, route, or material regions get less readable, the change is wrong even if it reduces spikes.

## Stop Condition

Do not call Fire "near final Gaea/Houdini" until all of these are true in the latest HERO bake:

- The 8-angle sheet has no obvious polar curtain, castle-rib wall, or repeated radial fan rhythm.
- Side/back views show block-scale collapse and cooled basalt shelves, not continuous shadow curtains.
- Lava channels have geometry: channel incision, raised cooled crust lips, downstream spill shelves, terminal fans, and asymmetric tongues.
- `M_ElementCrack` is compact, not scattered into tiny islands, and red material never reads as one unbroken curtain from rim to edge.
- `M_CliffRock` cooling breaks correspond to actual raised or fractured geometry, not just a texture/material swap.
- Route quality remains strong enough for gameplay; Fire must stay a usable island, not only a sculpture.
- Quality summary remains in the current healthy band or better: route around 94%, over-detail below 10%, thin-edge below 5%, radial artifact below 5%.

## Current Best Reading

The current Fire whitebox is no longer early procedural noise. It has readable crater, rim, route, lava channels, black basalt, talus, ash, outer skirt, and underside. The recent gains reduced:

- side/back cliff skirt continuous shadow rhythm;
- upper wall persistent castle ribs;
- lava material curtains without cooling breaks.

But it is still not time to stop. The remaining gap is mostly in block-scale causality:

- lava still needs more geometry-led cooling and spill structure;
- black upper walls still need broader collapse masses and less repeated inspect-face rhythm;
- side/back silhouette needs more "aged volcanic cliff" confidence from multiple camera angles;
- material regions must keep matching heightfield causes so Meshy can read them cleanly.

## 2026-07-06 Loop: Cooling Crust Must Be Geometry

The previous lava pass cut continuous `M_ElementCrack` material runs with `M_CliffRock` cooling-crust breaks. That helped Meshy/PBR handoff, but it was still too material-driven. A cooled crust break that exists only as material is not a Gaea/Houdini landform.

The new rule:

```text
If a lava channel exports an M_CliffRock cooling-crust break,
that break must also have a raised geometric lip relative to its radial neighbors.
```

New regression:

```text
sample non-entry lava channels from R0.805 to R0.875
find centerline M_CliffRock cooling cells
measure height - average(inner radial neighbor, outer radial neighbor)
require at least 3 channels with cooling crust lips
require the weakest lip >= 115cm
```

Initial RED:

```text
only 2 channels had M_CliffRock cooling crust cells
the weakest geometric lip was below target
```

Implementation direction:

- Added a Fire-only cooling-crust sill process in the heightfield layer.
- Lowered support threshold for high-flow lava that has strong accumulation but moderate lava mask.
- Added downstream spill shelves so the raised crust does not become a single hard ring step.
- Kept the five-slot material contract unchanged.

This is the right kind of Gaea movement: material, process mask, and geometry now agree more closely. Meshy will receive a clearer "cooled crust over lava flow" signal instead of a purely painted interruption.

## 2026-07-06 Loop: Upper Wall Must Break Below The Old Comfort Line

After the cooling-crust loop, the 8-angle sheet still exposed a familiar Fire weakness: the upper black volcano wall could pass the old regression but still read as a columnar castle wall in side/back inspect. The old line was:

```text
persistent castle-rib boundaries < 60
```

That was no longer enough. The current extreme target adds a stricter regression:

```text
same upper-wall band, same semantic guards
medium rib: angular delta > 110cm
strong rib: angular delta > 160cm
persistent if medium >= 7 rings or strong >= 4 rings
require persistent boundaries < 54
```

Initial RED:

```text
persistent castle ribs: 58
```

Implementation direction:

- Strengthened the existing Fire outer-wall polar-curtain weathering pass.
- Did not add a new smoothing layer.
- Kept path, lava, and crater-loop semantic guards.
- Increased response to medium-but-persistent ribs so the wall loses more repeated polar-column rhythm.

Measured movement:

```text
persistent castle ribs: 58 -> 53
worst upper-wall p80: 229.4cm -> 224.7cm
worst vertical strong-rib run: stays 5
```

This loop reinforces a central rule: once the obvious maximum spikes are gone, the next enemy is not a single bad vertex. It is a family of moderate, repeated, similarly aligned wall features. Gaea/Houdini credibility comes from breaking those families into collapse masses, diagonal fracture weathering, and cooled wall plates.

## 2026-07-06 Loop: Broad Collapse Windows Must Not Be Rigid Bands

After the upper-wall rib count improved, the remaining wall defect became larger than a single boundary. Some 24-column wall windows still had most of their strongest radial break on the same one or two rings. The mesh passed the old "not one circular ring" test, but in side/back views it could still read like a broad wall band cut by the same procedural knife.

New regression:

```text
for each 24-column upper-wall window:
  find the strongest radial break ring per valid column
  mark rigid if ring spread < 3 and dominant ring coverage > 72%
require rigid broad-collapse windows <= 2
```

Initial RED:

```text
rigid broad-collapse windows: 4
```

Implementation direction:

- Reused the existing outer-wall local break redistribution in the crater-wall arc process.
- Broadened the rigid-window trigger from only "almost perfectly one ring" to "still too much one-band dominance".
- Reduced the original dominant-ring break more strongly for selected columns.
- Moved more break energy into neighboring rings so the wall reads as staggered collapse plates.
- Kept the same semantic guards for path, lava, and crater loop.

Measured movement:

```text
rigid broad-collapse windows: 4 -> 2
persistent castle ribs: 53 -> 51
worst upper-wall p80: 224.7cm -> 233.7cm, still below the 260cm safety gate
```

This is a useful trade: a little more local relief is acceptable when it breaks a synthetic same-ring band into a believable collapse rhythm. The goal is not a quieter wall; it is a wall with more plausible volcanic history.

## 2026-07-06 Loop: Cliff Skirt Must Continue Upper-Wall Collapse History

After the broad-collapse window pass, the next side/back defect was a continuity problem. The upper black volcano wall had started to form staggered collapse plates, but parts of the lower cliff skirt still behaved like a separate shadow system: smooth angular columns under an upper wall that was already breaking apart.

New regression:

```text
for each 24-column window:
  if upper wall has broad collapse variation (strongest break ring spread >= 3)
  inspect generated M_CliffRock skirt columns in the same angular window
  count columns whose skirt height/radial profiles are still too smooth
require mismatch windows <= 6
```

Initial RED:

```text
upper collapse windows: 10
upper/skirt mismatch windows: 8
```

Implementation direction:

- During Fire cliff-skirt mesh extraction, derive a `collapse_transfer` signal from the semantic heightfield's upper-wall break rings.
- Apply that signal only to generated Fire skirt vertices, not to top route/crater/lava masks.
- Use the transfer to alter local skirt ledge position, radial push, and z offset so the lower black skirt inherits the angular collapse rhythm.
- Keep the existing three-layer cliff skirt and five-material Meshy contract.

Measured movement:

```text
upper/skirt mismatch windows: 8 -> 5
skirt longest smooth height run: 32
skirt longest smooth radial run: 31
```

This loop matters because a Gaea/Houdini island should not look like a good top mesh glued to a different underside system. The wall, cliff skirt, and underside need to feel like one volcanic body that fractured and slumped through the same history.

## 2026-07-06 Loop: Bottom Cap Must Break The Smooth Triangular Fan

After the cliff-skirt transfer, the lower side/back silhouette improved, but the bottom cap still had a hidden procedural smell: the central underside fan was short enough, but too smooth for too long. In face-normal previews this can become a regular triangular shadow fan under an otherwise more geological wall.

New regression:

```text
infer the generated Fire bottom-cap ring from vertex order
compare neighboring cap radius and cap height
count the longest run where both deltas stay under the smooth threshold
require longest smooth triangular-fan run < 84 columns
```

Initial RED:

```text
bottom-cap longest smooth fan run: 106
```

Implementation direction:

- Reused the same upper-wall-derived `collapse_transfer` signal already feeding the cliff skirt.
- Applied it to Fire lower-underside and bottom-cap scale/z offsets.
- Kept the central underside fan compact; this is a silhouette-history pass, not an underside size increase.

Measured movement:

```text
bottom-cap longest smooth fan run: 106 -> 31
bottom-cap max radius: 0.103R
lower-underside longest smooth run: 9
HERO quality unchanged: Route 94% / detail 8% / edge 4% / radial 4%
```

The important distinction: the bottom cap should remain short for gameplay/export sanity, but it must not be mathematically smooth. A compact underside can still carry bite marks and asymmetric collapse rhythm.

## 2026-07-07 Loop: Inner Wall Must Stop Reading As Vertical Machine Teeth

After the lava morphology pass, the remaining Fire defect became more obvious in the 8-angle sheet: the central black volcano wall still had long vertical rib columns. Previous tests reduced local angular p95, but they did not forbid the same angular boundary from staying strong across many consecutive rings. That is why the wall could be numerically less spiky while still reading like a polar generator or castle wall.

New regression:

```text
sample the inner volcano wall band R0.28-R0.46
for each angular boundary:
  count consecutive rings where angular delta > 132cm
  skip route/lava/crater-loop protected cells
require worst vertical run <= 4
require persistent strong boundaries < 24
```

Initial RED:

```text
valid inner-wall boundaries: 114
worst vertical run: 9
persistent strong boundaries: 27
```

Implementation direction:

- Added a second-stage column breaker inside `_weather_fire_inner_wall_breach_ribs`.
- It only activates on long contiguous strong angular-boundary runs in the inner wall band.
- It does not globally smooth the crater wall. Instead it staggers selected rings toward a local midpoint, turning a single vertical tooth into broken slump plates.
- It keeps path, lava, and crater-loop semantic guards.

Measured movement:

```text
valid inner-wall boundaries: 114
worst vertical run: 9 -> 4
persistent strong boundaries: 27 -> 15
targeted wall/lava/material regression suite: 12 tests OK
```

This is an important Gaea/Houdini distinction: a believable volcano can have steep walls and strong strata, but those breaks should not persist as perfect vertical columns across many rings. Long columns read as topology. Staggered collapse plates read as time, cooling, and rock failure.

## Next Highest-Value Loops

1. Lava morphology pass 2: add side overflow tongues and local levee erosion so red/rock transitions look like cooled flow history.
2. Contact-sheet scoring: turn the visual 8-angle read into a repeatable "Gaea sheet" gate for side/back/front/top silhouettes.
3. Meshy handoff rehearsal: once Fire grey holds up, export GLB/OBJ and verify that the five material regions are compact enough for prompt-guided PBR.
4. Final silhouette audit: compare pure grey front/back/side contact sheets against Gaea/Houdini references before calling the Fire whitebox near-final.

## Plain-Language Rule

Do not stop when the island looks "less bad". Stop only when the grey model already makes the viewer believe a volcano, lava, ash, collapse, cooling, and time shaped it.
