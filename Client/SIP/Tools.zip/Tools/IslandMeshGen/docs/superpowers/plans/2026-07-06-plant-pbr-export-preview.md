# Plant PBR Export Preview Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add an in-browser preview for the four exported plant PBR semantic parts so users can validate regrouping without opening Unreal.

**Architecture:** The server exposes read-only, whitelisted preview access for exported `03_pbr_parts` folders under `output/plant_regroup` and `mesh_inbox/_analysis_runs`. The plant page adds a second WebGL viewport that loads the exported `gltf + bin + textures` packages, supports semantic/textured rendering, part toggles, camera controls, and explode inspection.

**Tech Stack:** Node HTTP server, vanilla JavaScript, WebGL 1, glTF 2.0 external buffers, Node test runner.

---

### Task 1: Server Preview Utilities

**Files:**
- Modify: `web/server_utils.mjs`
- Modify: `web/server_utils.test.mjs`

- [ ] Add tests for `.gltf/.bin/.jpg` content types and plant preview path containment.
- [ ] Implement plant export group constants and safe preview path resolution.
- [ ] Run `node --test web/server_utils.test.mjs`.

### Task 2: Server Preview Endpoints

**Files:**
- Modify: `web/server.mjs`

- [ ] Add `GET /api/plant/export-preview` to return latest or requested `03_pbr_parts` metadata.
- [ ] Add `GET /api/plant/export-preview/file?path=...` to serve only whitelisted preview files.
- [ ] Return group metadata for `Core`, `PrimarySilhouette`, `OrbitSet`, and `BodyShell`.

### Task 3: Web UI And Loader

**Files:**
- Modify: `web/plant.html`
- Modify: `web/plant_styles.css`
- Modify: `web/plant_regroup.js`

- [ ] Add a PBR parts preview panel below the regroup viewport.
- [ ] Add a glTF external package loader for exported group packages.
- [ ] Add a second WebGL renderer with semantic/textured modes, toggles, fit, orbit, zoom, and explode.
- [ ] Load exported preview automatically after `Export PBR Parts`, and manually through `Load Latest Export`.

### Task 4: Verification

**Files:**
- Test: `web/server_utils.test.mjs`
- Test: rendered `plant.html`

- [ ] Run `node --check web/plant_regroup.js web/server.mjs`.
- [ ] Run `node --test web/server_utils.test.mjs web/view_model.test.mjs`.
- [ ] Start local server and verify `plant.html` can load latest export preview.
- [ ] Capture a browser screenshot and confirm no relevant console errors.
