# AIGC Plant Visual Smoke And PCG Wrapper Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Verify the AIGC plant PCG contract visually in the UE editor, then add the smallest PCG-friendly wrapper only if the visual smoke confirms the actor contract is worth wiring into PCG graphs.

**Architecture:** Reuse `ASIPResourcePlantActor::ConfigureFromPCG` and the persistent `USIPResourcePlantRecipe` DataAssets. The visual smoke script spawns temporary actors and never saves map or AIGC assets. If needed, a later wrapper will expose property-driven PCG inputs without moving mesh/PBR ownership out of the actor.

**Tech Stack:** Unreal Engine 5.4 editor, `soft_ue_cli`, UE Python, existing SIP C++ actor and Recipe DataAssets.

---

### Task 1: Visual Smoke In Editor

**Files:**
- Use: `C:/Users/12542/Documents/Unreal Projects/SkyIslandPotion/Tools/IslandMeshGen/ue_spawn_aigc_resource_plant_pcg_smoke.py`

- [ ] **Step 1: Launch editor and wait for bridge**

Run:

```powershell
Start-Process 'C:/Program Files/Epic Games/UE_5.4/Engine/Binaries/Win64/UnrealEditor.exe' -ArgumentList '"C:/Users/12542/Documents/Unreal Projects/SkyIslandPotion/Client/SIP/SIP.uproject"'
$env:PYTHONPATH='C:/Users/12542/Documents/Unreal Projects/SkyIslandPotion/Client/SIP/soft-ue-cli'
C:/Users/12542/AppData/Local/Programs/Python/Python312/python.exe -m soft_ue_cli wait-for-ready
```

- [ ] **Step 2: Spawn the visual smoke actors**

Run:

```powershell
$env:PYTHONPATH='C:/Users/12542/Documents/Unreal Projects/SkyIslandPotion/Client/SIP/soft-ue-cli'
C:/Users/12542/AppData/Local/Programs/Python/Python312/python.exe -m soft_ue_cli run-python-script --script-path 'C:/Users/12542/Documents/Unreal Projects/SkyIslandPotion/Tools/IslandMeshGen/ue_spawn_aigc_resource_plant_pcg_smoke.py'
```

Expected JSON:

```json
{
  "spawned_actor_count": 8,
  "missing_recipe_count": 0,
  "mesh_mismatch_count": 0,
  "material_override_count": 0
}
```

- [ ] **Step 3: Capture a viewport screenshot**

Set the camera so the selected 8 actors are visible, then capture a viewport image under the SoftUEBridge temp directory.

### Task 2: Decision Gate

**Files:**
- Modify only if needed: `C:/Users/12542/Documents/Unreal Projects/SkyIslandPotion/Client/SIP/Source/SIP/World/SIPResourcePlantActor.*`
- Create only if needed: a PCG wrapper actor/Blueprint automation helper.

- [ ] **Step 1: Evaluate screenshot**

Check:

```text
CrownLily / AetherVine families are readable
Stable_C0 to Unstable_C3 progression is visible
slot transforms do not explode beyond useful visual chaos
imported PBR remains visible
```

- [ ] **Step 2: Pick next action**

If visual smoke is decent, implement a property-driven PCG wrapper entry. If visual smoke is not decent, tune Recipe assembly hints or actor slot transforms first.

### Self-Review

- This plan does not edit AIGC StaticMesh, Material, or Texture assets.
- The first task is verification-only and map-safe.
- The wrapper is gated behind visual evidence, not speculation.
