# AIGC Plant PCG Bridge Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Make the AIGC plant actor usable from a UE 5.4 PCG-style spawn loop by passing only recipe/family, collapse band, seed, and scale.

**Architecture:** PCG owns placement and high-level random inputs. `ASIPResourcePlantActor` owns collapse-vector sampling, four-slot mesh assembly, and imported material preservation. Python/soft-ue scripts verify the runtime contract without modifying AIGC mesh, material, or texture assets.

**Tech Stack:** Unreal Engine 5.4 C++, UE automation tests, UE Python, `soft_ue_cli`, existing `Tools/IslandMeshGen` plant recipe/catalog modules.

---

### Task 1: Actor PCG Configuration Contract

**Files:**
- Modify: `C:/Users/12542/Documents/Unreal Projects/SkyIslandPotion/Client/SIP/Source/SIP/Tests/SIPResourcePlantCollapseTests.cpp`
- Modify: `C:/Users/12542/Documents/Unreal Projects/SkyIslandPotion/Client/SIP/Source/SIP/World/SIPResourcePlantActor.h`
- Modify: `C:/Users/12542/Documents/Unreal Projects/SkyIslandPotion/Client/SIP/Source/SIP/World/SIPResourcePlantActor.cpp`

- [ ] **Step 1: Write the failing test**

Add an automation test that creates a transient `ASIPResourcePlantActor`, calls `ConfigureFromPCG(nullptr, ESIPResourcePlantPreviewFamily::AetherVine, ESIPResourcePlantCollapseBand::Fractured_C2, 9917, 1.35f, 1.2f, false)`, and checks:

```cpp
TestEqual(TEXT("PCG seed is assigned"), Actor->PlantSeed, 9917);
TestEqual(TEXT("PCG scale is assigned"), Actor->PlantScale, 1.35f);
TestEqual(TEXT("PCG family fallback is assigned"), Actor->PreviewFamily, ESIPResourcePlantPreviewFamily::AetherVine);
TestEqual(TEXT("PCG band is assigned"), Actor->CollapseBand, ESIPResourcePlantCollapseBand::Fractured_C2);
TestFalse(TEXT("PCG mode samples from seed rather than explicit vector"), Actor->bUseExplicitCollapseVector);
TestFalse(TEXT("PCG mode honors the supplied band by default"), Actor->bUseRecipeDefaultCollapseBand);
TestTrue(TEXT("resolved vector stays readable"), Actor->GetActiveCollapseMetrics().bPassedHardConstraints);
```

- [ ] **Step 2: Run the editor build to verify the test fails**

Run:

```powershell
& 'C:/Program Files/Epic Games/UE_5.4/Engine/Build/BatchFiles/Build.bat' SIPEditor Win64 Development -Project='C:/Users/12542/Documents/Unreal Projects/SkyIslandPotion/Client/SIP/SIP.uproject' -WaitMutex
```

Expected: compile failure because `ASIPResourcePlantActor::ConfigureFromPCG` is not declared yet.

- [ ] **Step 3: Implement the minimal actor API**

Add:

```cpp
UFUNCTION(BlueprintCallable, Category = "SIP|Resource Plant|PCG")
FSIPResourcePlantCollapseVector ConfigureFromPCG(
	USIPResourcePlantRecipe* InRecipe,
	ESIPResourcePlantPreviewFamily InFamily,
	ESIPResourcePlantCollapseBand InCollapseBand,
	int32 InSeed,
	float InScale,
	float InCollapseTemperatureScale = 1.0f,
	bool bInUseRecipeDefaultCollapseBand = false);
```

Implementation assigns recipe/family/band/seed/scale/temperature, disables explicit collapse vector, calls `RebuildPlantPreview`, and returns `ResolvedCollapseVector`.

- [ ] **Step 4: Run build and automation smoke**

Run the same build command. If editor automation is available, run the focused `SIP.ResourcePlant` tests.

### Task 2: PCG-Style Scene Verification Script

**Files:**
- Create: `C:/Users/12542/Documents/Unreal Projects/SkyIslandPotion/Tools/IslandMeshGen/ue_spawn_aigc_resource_plant_pcg_smoke.py`

- [ ] **Step 1: Write the script against the desired contract**

Script behavior:

```text
load persistent DA_AIGC_CrownLily and DA_AIGC_AetherVine
spawn ASIPResourcePlantActor instances for each family and collapse band
call configure_from_pcg(recipe, family, band, seed, scale, temperature, false)
read actor.get_active_collapse_vector()
verify the four visible slot meshes match /Game/AIGC/Plants/{Family}/C{VectorSlot}/{Slot}
verify each recipe slot component has no material override so imported PBR is preserved
print JSON summary with missing_recipe_count, mesh_mismatch_count, material_override_count
```

- [ ] **Step 2: Run through soft-ue-cli**

Run:

```powershell
$env:PYTHONPATH='C:/Users/12542/Documents/Unreal Projects/SkyIslandPotion/Client/SIP/soft-ue-cli'
C:/Users/12542/AppData/Local/Programs/Python/Python312/python.exe -m soft_ue_cli run-python-script --script-path 'C:/Users/12542/Documents/Unreal Projects/SkyIslandPotion/Tools/IslandMeshGen/ue_spawn_aigc_resource_plant_pcg_smoke.py'
```

Expected: JSON reports zero missing recipes, zero mesh mismatches, zero material overrides.

### Task 3: Production Mind Doc

**Files:**
- Create or modify: `C:/Users/12542/Documents/Unreal Projects/SkyIslandPotion/Tools/IslandMeshGen/docs/AIGC_PLANT_PCG_PRODUCTION_LOOP_CN.md`

- [ ] **Step 1: Capture the contract**

Document:

```text
PCG owns: placement, recipe/family choice, collapse band, seed, scale.
Actor owns: collapse sampling, four-slot assembly, PBR preservation, runtime tags.
Recipe DataAssets own: AIGC asset references and assembly hints.
Tools own: asset audit, recipe creation/update, scene smoke verification.
Imported AIGC assets are read-only.
```

- [ ] **Step 2: Add verification commands**

Include the build command, focused Python tests, recipe asset creation script, and PCG smoke script.

### Self-Review

- Spec coverage: actor PCG input, CrownLily/AetherVine recipes, four-slot assembly, material preservation, scene verification, and mind doc are covered.
- Placeholder scan: no deferred behavior is required for this bridge; future PCG graph authoring is explicitly outside this minimal production contract.
- Type consistency: method parameters use existing `USIPResourcePlantRecipe`, `ESIPResourcePlantPreviewFamily`, `ESIPResourcePlantCollapseBand`, and existing actor properties.
