# Semantic VFX Region Mindset

日期：2026-07-06

范围：`Tools/IslandMeshGen`、岛屿语义输出、区域 VFX 导演层、`SlashFX_SoftTofu` 资产包、未来 Unreal 接入边界。

## 核心判断

当前重点不是立刻改 PCG，也不是把 Niagara 随机撒到岛上。

真正有价值的方向是：

```text
IslandMeshGen 输出语义。
Unreal 材质负责稳定视觉层。
Niagara 负责局部生命感、反应反馈和崩坏异常。
PCG 以后负责大规模摆放。
```

也就是说，工具侧不应该直接决定最终场景里每一个粒子怎么摆，而应该输出一层更高阶的“VFX 导演提示”。

推荐心智：

```text
manifest / field / quality_report
-> semantic VFX intent
-> vfx_manifest.json
-> Unreal VFX Mapper / DataAsset / Blueprint
-> ambient anchors + reaction bursts
```

这层契约的价值在于：工具知道“这里是什么”，美术知道“这里该长什么味道”，Unreal 知道“这里该什么时候触发什么效果”。

## 为什么不是 PCG 主导

PCG 适合解决大规模摆放问题，但它不天然理解区域语义。

如果现在直接让 PCG 处理 VFX，容易变成：

- 火岛到处撒火花。
- 冰岛到处撒蓝光。
- 森林岛到处撒孢子。
- 崩坏区域到处开 distortion。

这会失去地形工具已经建立起来的语义优势。

更好的分工是：

```text
工具侧：哪里允许出现 VFX，为什么出现，强度如何，避开哪里。
美术侧：选择 Niagara、颜色、速度、尺寸、循环方式。
UE 侧：按距离、触发、反应、LOD 和运行时状态实际播放。
```

PCG 可以稍后作为执行器之一，但不应该成为语义来源。

## 已有语义来源

一次岛屿 bake 已经不只是 OBJ 网格，而是带有一整组语义侧车数据。

### `*.manifest.json`

适合提供设计语义：

- `biome`
- `biome_tag`
- `zones`
- `walkable_zones`
- `hazard_zones`
- `resource_zones`
- `landmarks`
- `attachment_landmarks`
- `connector_anchors`
- `paths`
- `material_masks`
- `material_slots`

这些字段回答的问题是：

```text
这块区域在玩法和构图上是什么？
```

例如：

- `lava_hazard`
- `crater_arena`
- `outer_blackrock_shelves`
- `resource_crystals`
- `deep_cracks`
- `glowing_root_cave`
- `mushroom_pocket`
- `vine_bridge_anchor`

### `*.field.json`

适合提供空间采样语义：

- `path`
- `lava`
- `ravine`
- `volcano`
- `crater_loop`
- `cliff`
- `slope`
- `talus`
- `lava_flow`
- `flow_accumulation`
- `curvature`
- `strata`

这些 mask 回答的问题是：

```text
具体在哪里发生？
```

例如：

- 火花不应该铺满火山岛，而应该采样 `lava_flow`、`lava`、`M_ElementCrack`。
- 冷雾不应该铺满冰岛，而应该优先出现在 `ravine`、`deep_cracks`、高 `curvature` 区。
- 森林孢子不应该跟 path 重叠太多，而应该落在 `mushroom_pocket` 或低强度 PCG 区。

### `*.quality_report.json`

质量报告不只用于修算法，也可以成为崩坏美术语言的一部分。

特别有用的指标：

- `overDetail`
- `thinEdge`
- `radialArtifact`
- top issue 的 `region`
- top issue 的 `material`
- top issue 的 `score`

这些不一定都代表“坏结果”。在世界观里，它们也可以被解释为：

```text
世界结构正在失稳。
几何细节不自然的地方，可能就是崩坏泄漏的地方。
```

但要注意：质量问题不能被 VFX 永远遮羞。算法该修还是要修。VFX 只能把少量不可避免的不稳定区域转化成美术语言。

## VFX 意图，而不是 VFX 资产

工具输出不应该直接硬编码“这里一定用某个 Niagara”。

工具应该先输出意图：

| Intent | 中文理解 | 典型用途 |
| --- | --- | --- |
| `AmbientLeak` | 区域自然泄漏 | 裂缝火花、根脉微光、晶体微粒 |
| `BoundaryPulse` | 边界脉冲 | 路径边缘、火山口环、断冰环 |
| `HazardBreath` | 危险区呼吸 | 火山孔、深裂隙、毒雾区 |
| `ReactionBurst` | 元素反应爆发 | 药水命中、技能触发 |
| `ResourceGlimmer` | 资源可读性闪光 | 晶簇、蘑菇、根脉节点 |
| `CollapseAnomaly` | 崩坏异常 | 空间扭曲、世界裂缝、C3/C4 植物周围 |
| `AlchemyPulse` | 炼金/工坊脉冲 | 工坊岛、传送门、药盏植物、实验区域 |

这样以后即使换 VFX 包，工具输出也不需要重写。

## 两层 VFX 模型

`SlashFX_SoftTofu` 是一个战斗特效包，形状语言很强，有大量 slash、hit、projectile、distortion。

它能用，但不能当普通环境氛围包乱铺。

必须拆成两层：

### 1. 弱环境层

用于持续存在，但低频、低强度、低密度。

适合资产：

- `NS_BottomSpark_*`
- 少量 `Cosmic`
- 少量 `Wind`
- 少量 `Distortion`
- spark / orb / refraction 类材质

用途：

- 地缝泄漏。
- 火山口呼吸。
- 冰裂折射。
- 根脉微光。
- 资源点闪烁。
- 崩坏边缘轻微扭曲。

原则：

```text
弱环境 VFX 应该让地形显得活着，而不是抢走地形本身。
```

### 2. 强反应层

只在玩家触发、药水命中、岛屿状态变化或剧情事件时播放。

适合资产：

- `NS_Hit_Slash_*`
- `NS_Hit_Slash_Direction_*`
- `NS_Hit_Slash_Loop_*`
- `NS_Slash_Projectile_*`
- `NS_Slash_Claw_*`
- `JudgementCut`

用途：

- 药水命中元素区。
- 裂缝被点燃。
- 冰层被融化。
- 雷击触发传导。
- 岛屿稳定度骤降。
- 传送门异常。

原则：

```text
强特效必须有事件理由。
没有触发，就不要让 slash 类视觉常驻。
```

## SlashFX_SoftTofu 的项目内角色

资产包位置：

```text
Client/SIP/Content/SlashFX_SoftTofu
```

关键 Niagara 家族：

```text
/Game/SlashFX_SoftTofu/Niagara/Basic
/Game/SlashFX_SoftTofu/Niagara/Cosmic
/Game/SlashFX_SoftTofu/Niagara/Distortion
/Game/SlashFX_SoftTofu/Niagara/Fire
/Game/SlashFX_SoftTofu/Niagara/Lightning
/Game/SlashFX_SoftTofu/Niagara/Scifi
/Game/SlashFX_SoftTofu/Niagara/Stylized
/Game/SlashFX_SoftTofu/Niagara/Wind
/Game/SlashFX_SoftTofu/JudgementCut
```

推荐使用方式：

| 资产族 | 推荐用途 | 风险 |
| --- | --- | --- |
| `BottomSpark` | 地面裂缝、资源点、火山孔、根脉节点 | 过量会像战斗残留 |
| `Hit_Slash` | 药水命中后的瞬时爆发 | 常驻会太像攻击技能 |
| `Hit_Slash_Direction` | 有方向的元素扩散 | 方向不对会破坏空间感 |
| `Hit_Slash_Loop` | 短时激活的裂缝/通道 | 长时间循环会很吵 |
| `Projectile_Horizontal` | 沿路径或能量通道流动 | 随机飞会显得不受控 |
| `Projectile_rotate` | 环形节点、传送门、星轨藤式轨道 | 容易过度科幻 |
| `Distortion` | 崩坏、裂隙、空间错误 | 大面积使用会影响可读性 |
| `Cosmic` | 星界、炼金、神秘学、资源闪光 | 用多了会把所有岛都宇宙化 |
| `JudgementCut` | 稀有大事件 | 不能当普通环境特效 |

## 三种岛屿的初步映射

### 火山岛

已有语义：

- `M_ElementCrack`
- `lava`
- `lava_flow`
- `volcano`
- `crater_loop`
- `lava_hazard`
- `central_volcano`
- `lava_channels`

推荐 VFX：

| 语义源 | Intent | VFX 方向 |
| --- | --- | --- |
| `M_ElementCrack` + `lava_flow` | `AmbientLeak` | 低密度 `NS_BottomSpark_Fire_` |
| `lava_hazard` | `HazardBreath` | 火星 + 轻微 distortion，周期性呼吸 |
| `volcano` | `HazardBreath` | 火山口低频喷气，不要连续喷 |
| `crater_loop` | `BoundaryPulse` | 火山口环的边缘脉冲 |
| 药水命中火裂缝 | `ReactionBurst` | `NS_Hit_Slash_Fire_` / `NS_Hit_Slash_Direction_Fire_` |
| lava channel 激活 | `ReactionBurst` | `NS_Slash_Projectile_Horizontal_Fire_` 沿通道方向短促流动 |

重要限制：

- `path` 中心要避开强火花。
- 火花主要在裂缝、边缘、通道，不在整块 ash plateau 上平铺。
- 火山口可以呼吸，但不要变成持续喷泉，除非是剧情事件。

### 冰岛

已有语义：

- `M_ElementCrack`
- `deep_cracks`
- `resource_crystals`
- `primary_crystal_wall`
- `secondary_spire_clusters`
- `broken_ice_ring`

SlashFX 没有专门 Ice 家族，因此建议借用：

- `Cosmic`，调成蓝白、青蓝、冷紫。
- `Distortion`，用于折射和冰裂空间感。
- `Basic`，用于低调 spark。

推荐 VFX：

| 语义源 | Intent | VFX 方向 |
| --- | --- | --- |
| `deep_cracks` | `HazardBreath` | 冷雾、轻微 distortion、蓝白裂隙闪烁 |
| `M_ElementCrack` | `AmbientLeak` | 低密度 cosmic spark |
| `resource_crystals` | `ResourceGlimmer` | 晶簇微光、周期性小脉冲 |
| `broken_ice_ring` | `BoundaryPulse` | 冰环边缘弱光，不铺满道路 |
| 药水命中冰裂 | `ReactionBurst` | `NS_Hit_Slash_Cosmic_` 或 Distortion 变体 |

重要限制：

- 冰岛的 VFX 应该清透，不要厚重。
- distortion 要轻，否则会影响地形判断。
- 资源晶簇可以更亮，但路径区域要保持干净。

### 森林岛

已有语义：

- `mushroom_pocket`
- `glowing_root_cave`
- `canopy_platform`
- `root_arch`
- `tree_stump_cave`
- `vine_bridge_anchor`
- `M_ElementCrack` 作为 glow cave marker

SlashFX 没有专门 Nature 家族，因此建议借用：

- `Wind`，做空气流动和叶脉能量。
- `Cosmic`，做炼金/根脉/发光孢子。
- `Basic`，做弱 spark。

推荐 VFX：

| 语义源 | Intent | VFX 方向 |
| --- | --- | --- |
| `glowing_root_cave` | `AmbientLeak` | 绿金根脉微光、低速粒子 |
| `mushroom_pocket` | `ResourceGlimmer` | 孢子漂浮，避免 slash 轮廓 |
| `vine_bridge_anchor` | `BoundaryPulse` | 风线或微弱 cosmic 引导 |
| `root_arch` / `tree_stump_cave` | `AlchemyPulse` | 节点式流光，不要满屏发光 |
| Bloom 反应 | `ReactionBurst` | Wind/Cosmic 的短时扩散 |

重要限制：

- 森林岛最容易被 VFX 弄脏。
- 孢子和根脉微光应该服务于探索和采集提示。
- `Slash` 类资产在森林岛必须非常谨慎，除非是玩家触发反应。

## 崩坏 VFX 的独立语法

崩坏不是某一种元素，而是世界状态。

它可以由这些来源驱动：

- `curvature` 高。
- `thinEdge` 风险高。
- `radialArtifact` 风险高。
- `overDetail` 局部异常高。
- 岛屿边缘和断面。
- C3/C4 植物崩坏状态。
- 传送门、工坊实验区、药水失败事件。

推荐 VFX：

- `Distortion`
- `Cosmic`
- `Scifi`
- 稀有使用 `JudgementCut`

推荐语法：

```text
C1：局部微闪，几乎不扭曲。
C2：边缘出现不稳定粒子，偶尔折射。
C3：空间有可见撕裂和反向流动。
C4：短时强事件，允许 JudgementCut / post process / 大范围冲击。
```

限制：

```text
崩坏 VFX 不能变成常驻噪声。
它应该像病灶一样出现，而不是像天气一样覆盖全岛。
```

## `vfx_manifest.json` 草案

未来每次 bake 可以额外导出：

```text
SM_ProcIsland_Fire_VolcanoLayout_200m.vfx_manifest.json
```

建议结构：

```json
{
  "schema": "SkyIslandPotion.SemanticVFXManifest.v0",
  "island": "SM_ProcIsland_Fire_VolcanoLayout_200m",
  "biome": "fire",
  "scale": {
    "radius_m": 100.0,
    "unreal_units": "centimeters"
  },
  "regions": [
    {
      "id": "fire_lava_channel_sparks",
      "source": ["material:M_ElementCrack", "mask:lava_flow"],
      "intent": "AmbientLeak",
      "element": "Element.Fire",
      "spawn_mode": "mask_sample",
      "activation_policy": "distance_gated",
      "density": 0.25,
      "intensity": 0.45,
      "avoid": ["mask:path"],
      "niagara_hint": "/Game/SlashFX_SoftTofu/Niagara/Fire/NS_BottomSpark_Fire_",
      "notes": "Sample lava channel peaks and edges. Keep path center readable."
    },
    {
      "id": "fire_lava_reaction_burst",
      "source": ["zone:lava_hazard"],
      "intent": "ReactionBurst",
      "element": "Element.Fire",
      "spawn_mode": "reaction_location",
      "activation_policy": "reaction_triggered",
      "density": 1.0,
      "intensity": 1.0,
      "niagara_hint": "/Game/SlashFX_SoftTofu/Niagara/Fire/NS_Hit_Slash_Direction_Fire_",
      "notes": "Only play when potion or ability hits the semantic zone."
    }
  ]
}
```

字段含义：

| 字段 | 含义 |
| --- | --- |
| `source` | 来自哪个 zone、material、mask 或 quality issue |
| `intent` | VFX 设计意图 |
| `element` | 元素 tag |
| `spawn_mode` | 如何放置，例如 mask sample、edge sample、reaction location |
| `activation_policy` | 常驻、距离裁剪、反应触发、脚本触发、编辑器预览 |
| `density` | 每单位面积/区域的推荐密度，不是硬命令 |
| `intensity` | 视觉强度建议 |
| `avoid` | 必须避开的 mask，例如 path |
| `niagara_hint` | 推荐资产，不是强制资产 |
| `notes` | 给美术和 UE 实现看的说明 |

## 采样原则

VFX 采样应该来自 mask 组合，而不是纯随机点。

一个可用的通用心智：

```text
spawn_score =
  source_mask ^ source_gamma
  * (1 - path_mask) ^ path_avoidance
  * biome_weight
  * local_variation
  * designer_density
```

不同 intent 可以使用不同权重：

### `AmbientLeak`

```text
source = crack / lava_flow / root_glow / crystal
avoid = path
prefer = high source mask, medium curvature
```

### `BoundaryPulse`

```text
source = edge of path / crater_loop / broken ring
prefer = mask gradient, ring boundary, landmark boundary
```

### `HazardBreath`

```text
source = hazard zone
prefer = non-walkable interior, high lava/ravine/volcano
avoid = main path and arena center
```

### `ReactionBurst`

```text
source = runtime hit location
validate = hit belongs to semantic zone
play = Niagara selected by reaction tag
```

### `CollapseAnomaly`

```text
source = quality issue + curvature + thin edge + radial artifact
prefer = rare high-score clusters
avoid = constant full-map coverage
```

## Unreal 接入边界

项目里已经存在一个近期可用的强反应入口：

```text
ASIPElementalZoneActor
-> ReactionVFXMap
-> PlayReactionVFX(ReactionTag, Location)
```

文件：

```text
Client/SIP/Source/SIP/World/SIPElementalZoneActor.h
Client/SIP/Source/SIP/World/SIPElementalZoneActor.cpp
```

这意味着第一阶段不需要新造复杂系统。

近期可以这样接：

```text
语义区域 Actor
-> ZoneElementTag
-> ReactionVFXMap
-> SlashFX Niagara
```

环境层以后可以另起一个轻量承接者：

```text
BP_SemanticVFXAnchor
或
BP_SemanticVFXRegion
```

它只负责：

- 读取位置或区域。
- 播放低强度 Niagara。
- 距离裁剪。
- 控制循环开关。
- 给美术暴露强度、颜色、频率。

不要让它一开始就承担 PCG、反应、材质、数据导入所有责任。

## 与 Meshy 的关系

Meshy 可以给视觉参考、PBR 探索、donor assets、植物部件，但不应该决定语义 VFX。

语义 VFX 的来源必须是本地：

```text
manifest
field
quality_report
gameplay tags
```

Meshy 生成的模型即使很好看，也不能告诉 UE：

- 哪条路可走。
- 哪个裂缝能反应。
- 哪个区域危险。
- 哪个地方该刷 resource glimmer。
- 哪个地方该触发崩坏。

因此：

```text
Meshy owns visual proposals.
IslandMeshGen owns semantic VFX intent.
Unreal owns runtime playback and interaction.
```

## 性能和可读性原则

200m 岛屿尺度很大，VFX 不能按“局部小场景”的密度去铺。

硬规则：

- 主路径中心不放强 VFX。
- 常驻 VFX 只做弱环境层。
- 强 slash 只在触发时出现。
- Distortion 只用于少数崩坏病灶。
- JudgementCut 只用于大事件。
- 一切环境 VFX 必须有距离裁剪。
- 远处看轮廓和材质，近处才看粒子。
- PBR 和材质负责长期视觉，Niagara 负责生命感和事件感。

推荐激活策略：

| 策略 | 用途 |
| --- | --- |
| `always_on_low` | 极低密度常驻，例如资源微光 |
| `distance_gated` | 大多数环境 VFX |
| `reaction_triggered` | 药水、技能、交互 |
| `scripted_event` | 岛屿稳定度、剧情、传送门 |
| `editor_preview_only` | 调试语义 mask 和采样 |

## 近期最小切片

现在不要急着打通全部。

最小有意义切片是：

```text
输入：已有 fire / ice / forest manifest + field + quality_report
输出：只读的 *.vfx_manifest.json
不改 UE 资产
不改 PCG
不改 Niagara
```

先让工具能说清楚：

- 哪些区域该有 VFX。
- 为什么该有。
- 强度多少。
- 避开哪里。
- 倾向用哪个 SlashFX 家族。
- 是常驻还是触发。

第一块推荐火山岛，因为它语义最清晰：

```text
M_ElementCrack + lava_flow + volcano + crater_loop + lava_hazard
```

火山岛跑通后，再扩展冰岛和森林岛。

## 成功标准

这条线成功，不是因为粒子很多，而是因为玩家能感到：

- 地形区域有不同“呼吸”。
- 裂缝、资源、危险区、路径边界能被自然读出来。
- 药水命中区域时反馈明确。
- 崩坏不是噪声，而是有位置、有等级、有事件理由。
- 美术可以替换 Niagara，而工具语义不用重写。
- UE 可以按性能预算逐步启用，不会一上来把场景炸满。

一句话总结：

```text
工具不是在生成粒子。
工具是在生成“这个世界哪里正在泄漏、哪里正在反应、哪里正在崩坏”的导演说明。
```
