# IslandMeshGen 图形数据流心智

> 范围：本文件只讨论 IslandMeshGen 的平台化与图形数据流。AIGC 生成、语义提示词、内容创作策略放在独立对话和文档里推进。

## 核心判断

IslandMeshGen 不是一个单次脚本导出器，而是一个面向 UE/PCG 管线的图形数据平台原型。它同时承担三件事：

- 快速 authoring：用户拖参数时必须立刻看到语义轮廓、路径、mask、风险提示。
- 高精度 inspection：用户需要在 `production` / `hero` 档位看到真实拓扑和细节，但这不应该跟每一次拖动绑定。
- 正式 artifact export：最终写入 `output/` 的 OBJ、manifest、field、quality report，才是交付给 UE/PCG 的稳定产物。

这三件事必须解耦。性能问题不是“浏览器不行”，而是把三种不同延迟预算的数据流混成了一条。

## 三条数据流

### 1. Realtime Preview

目标是反馈速度，不是最终精度。

- 触发：加载布局、拖动控制、参数小步变化。
- API：`POST /api/preview/:biome`
- 输出目录：`output/.preview/`
- 质量策略：`draft` 保留 `draft`，`preview` / `production` / `hero` 都压到 `preview` 拓扑。
- 用户承诺：看语义变化、看过程 mask、看风险趋势，不承诺最终高精度细节。

### 2. High-res Inspect

目标是让用户按需看到最终档位的真实效果。

- 触发：用户显式点击 `Inspect <QUALITY>`。
- API：`POST /api/inspect/:biome`
- 输出目录：`output/.inspect/`
- 质量策略：严格使用当前 `Final Bake` 档位，包括 `production` 和 `hero`。
- 用户承诺：这是当前布局和当前质量档位的一张高精度快照。布局或质量变化后，快照变为 stale，不自动重跑。

### 3. Final Generate

目标是生成可交付 artifact。

- 触发：用户点击 `Generate Biome`。
- API：`POST /api/generate/:biome`
- 输出目录：`output/`
- 质量策略：严格使用当前 `Final Bake` 档位。
- 用户承诺：这是写给 UE/PCG 管线的正式输出，包括 OBJ、manifest、field、quality report。

## UI 心智

不要把“质量档位”和“渲染后端”混成一个按钮。

- `Final Bake` 是输出质量选择。
- `Inspect <QUALITY>` 是按需高精度快照。
- realtime preview 永远优先响应速度。
- GPU renderer 是视口后端，不是质量档位。

因此 UI 应该表达为：

```text
Final Bake: Production / Hero
Inspect HERO: 按需查看最终档位快照
Preview: 自动保持轻量
Generate: 写正式产物
```

## 渲染后端路线

当前第一刀先建立独立 inspect 数据流，避免继续用 realtime preview 承担高精度职责。

后续图形后端按这个顺序演进：

1. 保留 Canvas 2D 作为 authoring overlay、minimap、mask probe、质量诊断视图。
2. 为主 3D mesh 视口建立 `PreviewRenderer` 边界。
3. 第一版 GPU 后端优先接 Three.js + `WebGLRenderer`，本地 vendor 或正式依赖后再落，不使用 CDN 作为工具运行时依赖。
4. WebGPU 只作为未来增强：当 terrain field、mask 合成、erosion、LOD 或 compute 工作真正要上 GPU 时再引入。

## 成功标准

- 拖参数时不卡，且 preview 不会因为选择 `hero` 自动跑高密度拓扑。
- 用户选择 `hero` 后，可以显式点击 inspect 看到真实 `hero` 快照。
- inspect 不写正式 `output/`，不会污染 UE 导出产物。
- 参数变化后，高精度快照显示 stale，而不是偷偷自动重烤。
- 最终导出仍由 `Generate Biome` 控制。

