# Fire Lava Flow Branching Mindset

> Scope: Fire volcano lava channel causality, low-potential branching, material compactness, and Meshy handoff.

## 一句话

Fire 的熔岩不能只是几条按角度摆出来的红色射线。真正接近 Gaea/Houdini 的 lava flow 应该被坡度、局部低势能、旧沟槽和冷却沉积共同牵引。

## 问题

上一阶段 Fire 已经解决了大量毛刺、外壁圆环和 ash plateau 砂纸噪声，但 lava 仍有一个核心问题：

- 下游分叉虽然存在，但主要由 `channel_angle + branch_direction + radial_progress` 决定。
- 轨迹会显得像数学曲线，而不是被地形抓住。
- `lava_flow_mask` 峰值有时漂在局部低点上方数米，说明语义流向和真实高度场没有完全合上。
- Meshy/PBR 会奖励红色区域，但它不会替我们解释“为什么熔岩在这里流”。

## 正确方向

Lava branching 应该由两层共同决定：

1. **Layout intent**：保留 lava channel count、主通道位置、入口避让和玩法语义。
2. **Heightfield capture**：在每条下游通道附近寻找局部低势能走廊，让 mask 和 carve 跟着地形走。

这不是随机打弯。它必须满足：

- 分叉仍从 volcano / crater 区域自然外流。
- 非入口通道有下游转折，不是一直同一个 offset。
- lava_flow 峰值应靠近局部低势能，而不是压在旧直线 trunk 上。
- captured corridor 可以削弱旧直线分支，但不能破坏 main route / crater loop。
- `M_ElementCrack` 仍表示元素/熔岩核心区，不要泛滥成一大片红色贴图。

## 本轮实现心智

新增两段 Fire-only 过程：

```text
initial semantic lava mask
  -> low-potential corridor capture
  -> flow accumulation / lava flow derivation
  -> terrain process carving
  -> late Fire wall / ash passes
  -> narrow lava low-potential carve
  -> final flow accumulation / lava flow recompute
```

第一段 `_capture_fire_lava_low_potential_corridors`：

- 在每条非入口 lava channel 下游搜索局部候选。
- 使用局部低点、内外坡差、连续性和少量侧向扰动打分。
- 将捕获到的走廊写回 `lava_mask`。
- 对同窗口内旧直线分支降权，让 captured corridor 成为主流路。

第二段 `_carve_fire_lava_low_potential_corridors`：

- 在最终 heightfield 过程末端再次检查 lava corridor。
- 如果 lava corridor 仍高于邻域低点，就向局部低势能和外流方向刻低。
- 只处理 downstream lava band，保护 route 和 crater loop。

最后用最终高度重算 `flow_accumulation_mask` 和 `lava_flow_mask`，避免预览/诊断继续显示早期 heightfield 的旧流向。

## 新验收指标

本轮新增测试关注真实地貌因果：

- lava flow 峰值相对局部低点的平均高度差必须下降。
- 至少一条非入口通道必须有下游转折。
- 分叉仍要通过既有 asymmetric downstream tongue 测试。
- lava center/shoulder separation、route、crater loop、ash deposition、outer wall arc 测试必须继续通过。

当前 Fire HERO 结果：

- 下游 lava 峰值相对局部低点平均高度差：约 `586cm -> 407cm`。
- 非入口通道转折：`3 / 3` 条都有多次下游 bend。
- Meshy-safe 5 material slots 不变。

## 下一步

Lava branching 进入可用阶段后，下一个问题不是继续加红色通道，而是做 material compactness：

- `M_ElementCrack` 是否过度分散？
- `M_CliffRock` 是否和 lava shoulder / blackrock shelf 因果一致？
- `M_AshPlateau` 是否仍吞掉了本该是 cliff/talus 的区域？
- Meshy retexture 是否能从 5 个槽读懂：ash / path / cliff / underside / lava。
