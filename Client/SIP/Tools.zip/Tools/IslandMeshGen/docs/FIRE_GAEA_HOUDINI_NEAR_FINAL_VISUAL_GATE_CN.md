# Fire 极近 Gaea/Houdini 视觉门槛

Date: 2026-07-07

这份文档不是参数说明，而是审美和工程的共同判官。Fire 白膜什么时候可以停？不是测试全绿就停，不是红区紧凑就停，不是 WebGL 能转起来就停。只有当纯灰白 hero 在 200m 尺度下，连续 8 个角度都能读成“火山、熔岩、冷却、崩塌、沉积共同塑造的地貌”，才允许进入 Meshy/PBR 正式上皮。

## 最终画面标准

极近 Gaea/Houdini 的 Fire 白膜必须同时成立：

- 远看：岛的剪影不是圆形程序盘，而是有火山锥、破口、侧向溢流、外缘崩塌和底部悬崖的整体地貌。
- 中看：crater rim、inner breach wall、lava channel、terminal fan、cooling shell、talus shelf 的关系能互相解释。
- 近看：小裂纹、冷却肋、扇缘 scallop、黑岩 levee 是过程痕迹，不是随机噪声。
- 方向性：熔岩沿低势能下泄，冷却壳从边缘侵入，崩塌发生在高坡和坡脚，沉积留在平台/肩部。
- 白膜优先：纯灰 clay 模式已经可信，材质和 PBR 只能增强，不负责拯救几何。

## Fire 的三层因果

### 大形

Fire 的大形可以保留中心性，因为火山天然有中心。但中心性不能暴露为等距极坐标纹。合格的大形应该是：

- crater loop 有完整功能读法，但边缘不是数学圆。
- inner wall 有主破口和次破口，破口之间有塌落阶地。
- outer wall 有非径向崩塌段，不是整圈裙边。
- underside cliff 有重量感，不像垂直拉伸的边界墙。

### 中形

这是当前离 Gaea/Houdini 最近也最危险的层。中形决定“自然”还是“程序”：

- lava channel 要分叉、合流、被坡度引导，而不是只沿放射线。
- terminal fan 要有热核、冷却壳、扇缘破碎，不是红色板。
- side tongue 要像溢出的熔岩舌，有肩部、壳、肋、边缘冷却。
- inner breach wall 要有错层和岁月磨损，不能是长竖向机器齿。

### 小形

小形只允许服务大形和中形：

- 冷却 rib 是硬壳皱褶，不是均匀条纹。
- fracture lip 是断裂边，不是刺。
- roughness 要沿坡、沿壳、沿崩塌边出现。
- 任何无法解释的小形都应被磨掉。

## 停止线

Fire 可以暂时停手并送 Meshy 的条件：

1. 8-angle material contact sheet：没有大红板、红色高坡帘、碎红噪点。
2. 8-angle clay contact sheet：不靠材质也能读出火山口、破口、熔岩槽、扇缘、崩塌和坡脚沉积。
3. yaw 000/045/315：前景熔岩体量不再像厚披风，而像冷却壳包裹的地貌。
4. yaw 180/225/270：外壁和底部不是极坐标柱面，而是有非径向崩塌事件。
5. inner wall：没有长竖向机器齿，也没有整窗主断线锁在同一 ring。
6. `M_ElementCrack`：主流连通，tiny components 被清掉，不超过 5 个材质槽。
7. route/crater loop/PCG/manifest/quality_report/OBJ/GLB 导出都稳定。

任意一条失败，都不能说“极近 Gaea”。只能说“又近了一步”。

## 当前主敌

截至 2026-07-07，本轮主敌不是毛刺，而是“规则性残影”：

- inner wall 的主 breakline 会在局部窗口锁到同一 ring。
- 打散 breakline 容易引入 angular teeth 和 persistent vertical boundary。
- 保护前方主破口时，容易把径向落差磨软。
- 恢复主破口落差时，又容易制造横向硬齿。

因此正确解法不是继续全局 smooth，而是局部过程分工：

- de-lock：只处理锁死窗口，把唯一主断线削成错层阶地。
- preserve breach：前方主破口要保留 300+ 的径向落差。
- angular weathering：任何恢复落差的操作后面都要补角向 cap，避免机器齿。
- late-stage guard：末段过程要重新检查，因为后续 lava/scallop/settle 可能把早段修复覆盖掉。

## 下一轮循环顺序

每一轮按这个顺序走，不跳步：

1. 写一个只描述视觉病灶的 RED test。
2. 确认它失败，且失败原因是地貌问题，不是测试写错。
3. 在 heightfield/process layer 修，材质层只做语义清理。
4. 跑最小组，确认目标 test 和相邻保护 test 同时绿。
5. 跑 Fire 回归组。
6. hero bake。
7. 输出 diagnostics、preview、material 8-angle、clay 8-angle。
8. 先看 clay，再看 material。
9. 写下“进步点/未达标点/下一主敌”。

## 本轮新增心智

这一轮的关键悟道是：

> 打散规则性时，不能把规则性从径向搬到角向。

也就是说，不能为了破除“同一 ring 的主断线”，制造“同一列的竖向硬边”。Gaea/Houdini 的可信感来自错层、塌落、沉积和风化的互相制衡，而不是某一个指标被打爆。

前方破口同理。它需要保留大落差，因为玩家视角会从这里读到火山体量；但这个大落差必须横向磨损，不能变成锯齿墙。

本轮工程策略因此确定为：

- inner wall late breakline de-lock：处理锁死窗口。
- front breach wall-drop restore：恢复入口破口体量。
- front arc angular cap：恢复落差后立即磨掉横向硬齿。

这三者必须成组出现，少一个都会偏。

## 2026-07-07 本轮实现记录

本轮先解决 inner wall 的局部主断线锁死。新增验收 `test_fire_demo_hero_inner_wall_primary_breakline_is_not_radially_locked`，它不再只看是否有细节，而是检查每个 24 列窗口的主 radial drop 是否全部锁在同一 ring。初始红灯说明局部窗口仍然像极坐标机器墙。

修复分三段：

- `_weather_fire_inner_wall_breach_ribs` 中把单柱硬迁移改成宽 5 列的 slump scar，避免把径向规则性搬成角向机器齿。
- `_settle_fire_inner_wall_late_breakline_locks` 放在 Fire 末段过程，专门处理后续 lava/scallop/settle 又覆盖回来的主断线锁死。
- `_restore_fire_front_inner_breach_wall_drop` + front arc angular cap 保护前方入口破口：保留 300+ 径向落差，同时压住横向锯齿。

随后针对 clay contact sheet 里仍然明显的 underside/outer skirt 极坐标裙边，新增 `test_fire_demo_hero_cliff_skirt_has_collapse_events_in_each_visual_window`。这个测试要求每个 24 列视觉窗口至少有一次高度或半径破坏事件，避免整段裙边平滑成程序幕布。

修复策略是在 OBJ cliff skirt 生成阶段加入 per-window macro collapse bite。它不改地表 heightfield、不改材质槽，只让侧壁裙边的几何明暗有局部崩塌节奏。对应底部/裙边回归组保持通过，说明 bottom cap 没有重新拉成长中央 fan。

本轮测试结果：

- inner wall/front breach 最小组：4 tests OK。
- Fire 重点组：18 tests OK。
- Hero bake：Route 94% / detail risk 7% / edge risk 4% / radial risk 5%。

本轮视觉判断：

- 进步：inner wall 主 breakline 不再整窗锁死，前方破口体量保住，底部/侧壁裙边多了局部崩塌事件。
- 仍未达标：clay 模式的 crater/upper wall 仍有“竖向百叶窗”观感；material 模式 000/225/270 的大块红色熔岩帘仍偏厚。下一主敌应是 crater/upper wall 的横向/斜向风化带，而不是继续堆小噪声。

## 2026-07-07 追加循环：上墙百叶窗与热核红帘

本轮继续咬两个视觉残影。

第一，上墙百叶窗。clay contact sheet 里 crater/upper wall 不是单纯有高频尖刺，而是连续很多角向列都保持 7+ 个陡径向台阶，远看像竖向百叶窗。新增验收 `test_fire_demo_hero_upper_wall_radial_blinds_are_broken_by_lateral_shelves`，初始最长连续 steep column run 为 77。修复后通过 `_settle_fire_upper_wall_lateral_weathering_shelves` 把长 run 切成横向/斜向 weathered shelves，最长 run 降到 6。这个经验很重要：Gaea 感不是把火山墙磨平，而是让垂直沟槽被横向风化带打断。

第二，终端热核红帘。material contact sheet 中仍有局部 7x9 窗口红色占比过高，最坏窗口为 0.778。新增验收 `test_fire_demo_hero_terminal_lava_fans_keep_cooling_pockets_inside_hot_core`，要求终端热核内部也必须有 cooling pockets，不能整块红色披风。修复新增 `_fire_lava_terminal_cooling_pocket_strength` 和 `_shape_fire_lava_terminal_cooling_pockets`：同一强度函数同时驱动 heightfield 抬硬壳和 material 转 `M_CliffRock`。最后收窄 pocket 作用范围，只处理 ring40 附近的上游热核，避免破坏已有 terminal cooling finger / cooling island 读法。

本轮新增约束：

- cooling pocket 不能变成一整块中心冷壳，否则会减少红/黑交错 transitions，反而不像冷却裂纹。
- 上游热核 pocket 只解决大红核，不接管中下游 terminal fan；中下游仍交给 cooling finger、cooling island、outer scallop。
- 上墙 lateral shelf 必须打断连续 steep columns，但不能削掉火山体量和前方主破口落差。

本轮验证：

- 新 RED `upper_wall_radial_blinds`：77 -> 6，测试通过。
- 新 RED `terminal_lava_fans_keep_cooling_pockets`：0.778 -> < 0.74，测试通过。
- Fire 重点组合：17 tests OK。
- Hero bake：Route 94% / detail risk 7% / edge risk 4% / radial risk 5%。

本轮视觉判断：

- 进步：upper wall 的连续竖向锁定被切断；terminal fan 的最坏大红窗口被压住，且 cooling finger 回归未破。
- 仍未达标：clay 图里 crater wall 仍有不少竖向沟槽，只是从“连续百叶窗”变成“断续风化槽”；material 图中 225/270/315 的大红体量还偏厚。下一轮应继续处理“红色体量的厚披风感”：优先从几何上的 lava thickness/side tongue shoulder 入手，而不是继续收缩 `M_ElementCrack` 材质区。
