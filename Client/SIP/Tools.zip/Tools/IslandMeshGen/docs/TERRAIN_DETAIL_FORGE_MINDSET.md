# Terrain Detail Forge Mindset

## Why This Exists

The current island mesh is a semantic whitebox, not a final terrain sculpt. That distinction is useful: the tool already owns gameplay scale, paths, landmarks, masks, material slots, and Unreal-side manifest contracts. The next stage should not throw that away by handing the whole island to a black-box generator.

The first pain point is mesh scale. A 200 m island baked at the current draft topology can express the volcano, approach route, crater loop, cliff mass, and broad lava channels, but it cannot carry small terrain tension. The sampling grid is too coarse for fracture lips, eroded shoulders, basalt strata, ash wear, cooling crust plates, or path-edge gravel.

## Core Belief

Houdini-like terrain detail should grow from our semantic baker first. Meshy can later assist with PBR skins, normal detail, remeshed donor assets, and semantic prop kits, but it should not replace the terrain skeleton.

In short:

- Our baker owns shape, scale, collision intent, semantic masks, and playability.
- Meshy later owns texture exploration, detail asset donors, and optional remesh cleanup.
- Unreal receives a stable contract: main terrain mesh, collision proxy, material slots, semantic masks, and PCG attachment hints.

## The Three-Layer Model

### 1. Terrain Skeleton

This is the gameplay-safe island form. It must preserve:

- crater and landmark silhouettes
- walkable route readability
- material slot boundaries
- side and underside closure
- deterministic output from layout parameters
- stable manifest references

The skeleton can have multiple bake qualities. Draft is fast and interactive. Production carries enough topology for real terrain detail. Hero can be used later for screenshots or Nanite-facing experiments.

### 2. Semantic Terrain Detail

Fine structure should be driven by semantic regions, not one global noise field.

- Volcano rim: jagged lip, radial chipping, broken basalt teeth.
- Approach route: compressed tread, smoother center, rougher shoulders.
- Lava channels: branching fissures, cooling crust breakup, emissive crack masks.
- Cliff band: vertical strata, chipped silhouette, talus-like edge rhythm.
- Underside: broader forms only, not noisy surface chatter.

This layer should be deterministic and parameterized. It should be cheap enough to rebake locally, but only enabled at higher bake quality.

### 3. AI Assist

Meshy should enter after the skeleton can carry detail.

Good uses:

- retexture semantic material slots into PBR skins
- generate basalt chunks, lava crust plates, vents, crystals, roots, and other donor assets
- remesh donor assets for Unreal import
- create style references for material authoring

Risky uses:

- replacing the full island mesh
- generating a whole island from screenshot
- remeshing the main terrain without preserving material masks
- making collisions or route topology depend on remote AI output

## First Implementation Slice

Do not integrate Meshy yet.

Build bake quality profiles first:

- Draft: current fast topology, used for realtime preview and slider feedback.
- Preview: reserved for later medium-quality viewport previews.
- Production: formal bake with higher topology and semantic detail intensity.
- Hero: reserved for future high-density output.

The first UI should expose final bake quality without slowing the existing interactive preview.

## Success Criteria

- Designers can keep fast parameter interaction.
- Formal bake can output a denser terrain mesh than the live preview.
- The manifest and output status report the selected bake quality.
- The terrain baker has an explicit hook for quality-driven detail intensity.
- Meshy integration remains optional and downstream.

## Non-Goals For This Slice

- No Meshy API calls.
- No Unreal import automation.
- No full terrain remesh through AI.
- No displacement or texture pipeline yet.
- No destruction of existing semantic material slots.

