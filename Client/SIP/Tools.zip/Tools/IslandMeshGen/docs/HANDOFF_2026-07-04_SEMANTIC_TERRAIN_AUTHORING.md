# IslandMeshGen Handoff - Semantic Terrain Authoring

Date: 2026-07-04

Scope: `PCGFeature/Tools/IslandMeshGen`

This document captures the working memory from the recent Codex iteration thread: what changed, why it changed, what the tool currently is, and where development should go next. It is intended for a host / model handoff, not for end-user marketing.

## One-Sentence North Star

IslandMeshGen is evolving from a semantic whitebox OBJ generator into a procedural terrain authoring desk: fast enough to steer interactively, semantic enough to preserve gameplay intent, and eventually detailed enough to approach Houdini / Gaea-style terrain surfaces.

## Current Product Thesis

The tool should not become a generic asset generator and should not hand the full island to a black-box AI mesh system.

The core terrain skeleton must remain ours because it owns:

- gameplay scale and walkable routes
- crater / landmark / biome silhouettes
- material slots and semantic masks
- deterministic parameter-to-bake behavior
- Unreal import contracts and manifest data
- fast local rebake for iteration

Meshy or other AI systems may later help with PBR skins, donor rocks, vents, crystals, roots, lava plates, or prop kits, but they should not replace the main terrain baker.

## Current System State

### Main Local Surface

The main web editor lives here:

```text
Tools/IslandMeshGen/web
```

Known good local URL from the latest session:

```text
http://127.0.0.1:4182/
```

Because the workspace path contains `[3]FinalProject`, always use PowerShell `-LiteralPath` when changing directories:

```powershell
Set-Location -LiteralPath "C:\Users\zzg\Desktop\mazmobile\[3]FinalProject\Project_ZZG\SkyIslandPotion\PCGFeature"
```

The local web server can be started with the bundled Node runtime:

```powershell
$env:PORT='4182'
Set-Location -LiteralPath "C:\Users\zzg\Desktop\mazmobile\[3]FinalProject\Project_ZZG\SkyIslandPotion\PCGFeature\Tools\IslandMeshGen\web"
& "C:\Users\zzg\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe" ".\server.mjs"
```

Do not blindly kill port `4182`. If a restart is needed, first verify the process belongs to `server.mjs`.

### Key Files

Core terrain generation:

- `Tools/IslandMeshGen/island_mesh_generator.py`
- `Tools/IslandMeshGen/semantic_layout.py`
- `Tools/IslandMeshGen/export_layout.py`
- `Tools/IslandMeshGen/semantic_manifest.py`

Web tool:

- `Tools/IslandMeshGen/web/index.html`
- `Tools/IslandMeshGen/web/styles.css`
- `Tools/IslandMeshGen/web/app.js`
- `Tools/IslandMeshGen/web/view_model.mjs`
- `Tools/IslandMeshGen/web/server.mjs`
- `Tools/IslandMeshGen/web/server_utils.mjs`

Tests:

- `Tools/IslandMeshGen/tests/test_island_mesh_generator.py`
- `Tools/IslandMeshGen/tests/test_semantic_layout.py`
- `Tools/IslandMeshGen/web/server_utils.test.mjs`
- `Tools/IslandMeshGen/web/view_model.test.mjs`

Previous terrain mindset document:

- `Tools/IslandMeshGen/docs/TERRAIN_DETAIL_FORGE_MINDSET.md`

This handoff document extends that mindset rather than replacing it.

## What This Iteration Achieved

### 1. Web Editor Became a Real Authoring Desk

The earlier UI felt like a data viewer. The latest thread pushed it toward a terrain authoring tool.

Important shifts:

- 2D minimap now uses the generated OBJ footprint / top-down projection rather than an abstract SVG-like semantic drawing.
- 2D minimap follows 3D yaw so the two views can be compared spatially.
- 3D preview supports orbit and zoom through the existing Canvas2D renderer.
- The tool intentionally does not use Three.js yet. The current 2D canvas pseudo-3D path is accepted for now because it is lightweight, deterministic, and adequate for this stage.
- View mode buttons became a process layer rail: `BASE`, `CONE`, `PATH`, `FLOW`, `ERODE`, `TALUS`, `DETAIL`, `CHECK`, `FINAL`.
- Legend moved into the preview stage and now labels semantic badges such as `CV`, `AP`, `CL`, `LC`.
- Layout was rebalanced so the top is the preview stage and the bottom is the workbench.
- The latest cache version in `index.html` is `depth-20260703`.

The most recent layout adjustment fixed a "too flat / too thin" feeling:

- Preview height is now `height: clamp(390px, 44vh, 540px)`.
- The Process group's `3D process traces` toggle is compacted into the group title row instead of consuming a full horizontal row.
- Control cards use subtle lift so the parameter area feels less like a flat table.

### 2. Realtime Bake Feedback Was Made Less Jarring

Several strategies were explored:

- local geometry prediction during slider drag
- frequent preview bake at `0.01` parameter spans
- morphing between server previews
- highlighting potentially affected vertices / faces

The conclusion: local geometry prediction felt misleading because the predicted vertex movement did not match the server bake. The chosen behavior is:

- do not locally deform geometry as if it were a real bake
- highlight likely affected faces / vertices while dragging
- trigger server preview bake after meaningful parameter changes
- morph between same-topology server previews instead of hard-swapping

Relevant implementation and tests:

- `view_model.mjs`: `morphMeshes`, `meshAtTransitionFrame`
- `view_model.test.mjs`: `current preview render never applies local geometry prediction`
- `view_model.test.mjs`: `morphMeshes interpolates same-topology server previews instead of hard swapping vertices`

### 3. Quality / Nudge Loop Exists, But Is Not the Next Priority

The tool now has a quality repair queue:

- quality reports are generated next to baked meshes
- top issues appear in the web UI
- `Nudge` applies conservative parameter adjustments
- Nudge preview highlights linked controls
- after preview bake, the queue reports before / after risk movement

This is useful, but the latest user direction is clear: pause UX micro-work and focus on Houdini / Gaea-like terrain surface quality.

### 4. Terrain Baker Already Has a Semantic Process Foundation

The terrain generation is not just random noise anymore.

Current concepts in `island_mesh_generator.py`:

- `BAKE_QUALITY_PROFILES`: draft / preview / production / hero
- `TerrainField`: heights plus masks
- semantic masks: path, lava, ravine, volcano, crater loop, cliff
- derived process masks: slope, talus, lava flow
- process controls from layout:
  - `detail_energy`
  - `erosion_age`
  - `deposition_weight`
- quality-driven detail intensity
- formal bake can output higher topology than the realtime draft preview

The current pipeline is roughly:

```text
semantic layout
-> layout controls
-> polar terrain field heights
-> semantic masks
-> slope / talus / lava_flow masks
-> process height pass
-> top mesh rings
-> material classification
-> side / underside mesh closure
-> OBJ + field JSON + manifest
```

This is a strong base, but still not Houdini / Gaea-level terrain logic.

## Current Mental Model

### What The Tool Is

It is a semantic terrain baker with an artist-facing web editor.

It should produce:

- a gameplay-safe terrain skeleton
- stable material slots
- field masks for downstream material / PCG / diagnostics
- deterministic rebakes from semantic parameters
- progressively richer terrain detail at higher bake qualities

### What The Tool Is Not

It is not:

- a landing page
- a screenshot-to-mesh AI wrapper
- a final sculpting package
- a full Unreal automation pipeline yet
- a place to hide semantic ambiguity behind pretty colors

### Current Taste / Direction

The user cares about:

- semantic clarity
- Gaea / World Creator / Houdini-like mental models
- controllable procedural terrain, not random noise
- visual density that feels authored rather than jagged
- direct manipulation and fast iteration
- meaningful process layers

The user dislikes:

- unclear color legends
- crowded UI
- duplicated controls
- hidden functionality
- local predictions that diverge from actual bake
- terrain detail that looks like arbitrary毛刺 rather than geological process

## Most Important Strategic Pivot

The next phase is not UI polish.

The next phase is:

```text
Fine Terrain Field v1
```

Goal:

```text
Make terrain detail come from process-driven landform logic, not from noise pasted onto the mesh.
```

In practical terms, move from:

```text
height = macro form + noise + lava/talus add/subtract
```

to:

```text
heightfield
-> flow routing
-> curvature analysis
-> erosion incision
-> deposition accumulation
-> strata / exposed rock detail
-> protected gameplay routes
-> mesh sampling
```

## Houdini / Gaea Gap Analysis

Current system has:

- deterministic heightfield
- broad biome presets
- fire volcano macro form
- route flattening
- semantic masks
- slope / talus / lava_flow masks
- bake quality profiles
- hero topology option

Missing for Houdini / Gaea feel:

- high-resolution internal field independent of mesh topology
- flow accumulation
- curvature / convexity / concavity masks
- erosion that follows down-slope structure
- deposition that collects in plausible basins / slope feet
- strata / rock layer exposure driven by slope and curvature
- material/detail masks exported as first-class data
- separation between mesh displacement and small normal/detail maps

## Recommended Next Implementation: Fine Terrain Field v1

### Principle

Do not start with new UI.

Start with the baker and tests. If the terrain field becomes richer, the existing process layer UI can later expose it naturally.

### New Masks To Add

Add fields to `TerrainField`:

- `flow_accumulation_mask`
- `curvature_mask`
- `strata_mask`
- possibly `thermal_deposition_mask` if needed after the first pass

Also serialize them in `terrain_field_preview_payload()`.

### New Functions To Add

Suggested functions in `island_mesh_generator.py`:

```python
def _derive_flow_accumulation_mask(heights, path_mask, lava_mask, radial_segments, rings) -> list[list[float]]:
    ...

def _derive_curvature_mask(heights, radial_segments, rings) -> list[list[float]]:
    ...

def _derive_strata_mask(heights, slope_mask, curvature_mask, cliff_mask, radial_segments, rings) -> list[list[float]]:
    ...

def _apply_erosion_field_pass(
    heights,
    flow_accumulation_mask,
    curvature_mask,
    talus_mask,
    path_mask,
    crater_loop_mask,
    process_intensity,
    erosion_age,
    deposition_weight,
) -> list[list[float]]:
    ...
```

Keep the functions deterministic and local. Avoid dependency downloads.

### Behavior Targets

Erosion should:

- cut more strongly where flow accumulation is high
- preserve the main approach route enough to remain playable
- deepen lava / ravine corridors in fire biome
- avoid random per-vertex pitting

Deposition should:

- collect at slope feet and concave zones
- avoid filling the playable path too aggressively
- be controlled by `deposition_weight`

Strata should:

- appear on cliff / high-slope / exposed convex regions
- be stronger in fire and cliff bands
- remain secondary to the macro silhouette

### Tests To Write First

Add tests in `Tools/IslandMeshGen/tests/test_island_mesh_generator.py`.

Recommended test names:

```python
def test_fine_terrain_field_exports_flow_curvature_and_strata_masks(self):
    ...

def test_flow_accumulation_follows_lava_channels_more_than_side_shelves(self):
    ...

def test_erosion_age_cuts_continuous_flow_corridors_without_destroying_path(self):
    ...

def test_deposition_weight_builds_slope_foot_material_instead_of_uniform_lift(self):
    ...

def test_strata_mask_prefers_exposed_cliffs_and_rim_shoulders(self):
    ...
```

Keep tests numerical but concept-driven. Avoid overfitting exact values; compare relative bands and regions.

### Suggested Sequence

1. Add new masks to `TerrainField` and payload serialization.
2. Add failing tests for mask presence and region behavior.
3. Implement flow accumulation as a simple deterministic field:
   - each cell routes to the lowest neighbor among radial / angular neighbors
   - iterate or accumulate from high to low
   - normalize to 0..1
   - bias fire lava channels and ravines
4. Add curvature:
   - compare center height to neighbor average
   - positive / negative can be collapsed to an absolute or signed normalized mask first
5. Add strata:
   - combine slope, cliff, rim, curvature, and a controlled sinusoidal layer signal
6. Replace or extend `_apply_process_height_pass` with a richer erosion/deposition pass.
7. Update web `view_model.mjs` only after the field JSON exposes the masks.

## Current Verification Commands

Known good command set:

```powershell
Set-Location -LiteralPath "C:\Users\zzg\Desktop\mazmobile\[3]FinalProject\Project_ZZG\SkyIslandPotion\PCGFeature"

& "C:\Users\zzg\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe" --test ".\Tools\IslandMeshGen\web\server_utils.test.mjs" ".\Tools\IslandMeshGen\web\view_model.test.mjs"

& "C:\Users\zzg\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe" --check ".\Tools\IslandMeshGen\web\app.js"
& "C:\Users\zzg\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe" --check ".\Tools\IslandMeshGen\web\server.mjs"
& "C:\Users\zzg\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe" --check ".\Tools\IslandMeshGen\web\server_utils.mjs"
& "C:\Users\zzg\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe" --check ".\Tools\IslandMeshGen\web\view_model.mjs"

& "C:\Users\zzg\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe" -m unittest discover -s "Tools\IslandMeshGen\tests"
& "C:\Users\zzg\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe" -m py_compile "Tools\IslandMeshGen\semantic_layout.py" "Tools\IslandMeshGen\island_mesh_generator.py" "Tools\IslandMeshGen\export_layout.py"
```

Latest known verification from the previous session:

- Node web tests: 69 pass / 0 fail
- Node syntax checks: pass
- Python tests: 43 tests OK
- Python py_compile: pass
- HTTP smoke against `4182`: pass
- Chrome rendered layout check: console clean after adding data favicon

## Known Issues / Risks

### Browser Automation Path Issue

The in-app browser control can fail because the workspace path contains `[3]FinalProject`. Use HTTP smoke tests and direct Playwright with system Chrome if the in-app browser tool fails.

Temporary browser QA scripts should stay outside the repo, for example under user temp. Do not commit them.

### C:\tmp Write Quirk

The permission profile says `C:\tmp` is writable, but in this environment direct writes to `C:\tmp` were denied in at least one shell path. User temp worked:

```text
C:\Users\zzg\AppData\Local\Temp
```

### Do Not Over-Polish UI Right Now

The UI is decent enough for the next phase. More UI work risks distracting from the core terrain quality problem.

### Do Not Reintroduce Local Geometry Prediction

Local prediction made interaction feel smooth but visually dishonest. The user noticed that predicted vertex motion diverged too much from real bake. Prefer:

- highlight intent while dragging
- server preview bake
- morph between real same-topology previews

### Avoid Full Terrain Meshy Replacement

Meshy premium/API may be useful later, but not for the main terrain skeleton. It can assist downstream with:

- basalt chunks
- lava crust plates
- vents
- crystals
- roots
- texture / material references
- optional donor assets

It should not own:

- route topology
- material slot continuity
- collision shape
- full island remesh

## Design Language Notes

The tool should feel like:

- Gaea / Houdini process layers
- World Creator-like terrain authoring
- a quiet, dense, operational tool
- semantic and inspectable rather than decorative

Avoid:

- marketing landing page structure
- oversized hero sections
- vague gradients as meaning
- duplicate controls
- hidden legends
- UI text explaining obvious features
- visual noise that does not encode process or terrain state

## Current UI Layout State

Top:

- title
- biome presets
- diameter / seed / output
- final bake quality
- bake button

Preview panel:

- process layer rail above preview
- 2D OBJ footprint / semantic minimap
- 3D Canvas2D orbit preview
- semantic legend inside preview
- preview state pill
- summary strip below preview

Workbench:

- top action row
- control tabs and parameter cards on the left
- coherence / design health / quality repair queue on the right

Cache version:

```text
depth-20260703
```

## Useful Implementation Details

### Bake Quality Profiles

Defined in both Python and web utilities:

- `island_mesh_generator.py`
- `web/server_utils.mjs`

The profiles currently separate:

- `draft`
- `preview`
- `production`
- `hero`

Preview export follows selected bake quality so viewport topology can match mesh granularity.

### Process Controls

Default fire layout process controls live in `semantic_layout.py`:

```python
process={
    "detail_energy": 1.0,
    "erosion_age": 0.45,
    "deposition_weight": 0.55,
}
```

The web UI maps these to artist-facing controls:

- Detail energy
- Erosion age
- Deposition weight

These should remain high-level artist terms. Avoid exposing raw field names as UI labels.

### Process Masks Currently Exposed

Field JSON currently includes:

- `path`
- `lava`
- `ravine`
- `volcano`
- `crater_loop`
- `cliff`
- `slope`
- `talus`
- `lava_flow`

Fine Terrain Field v1 should extend this list.

## Handoff Recommendation

Next agent / host should begin with:

1. Read this file.
2. Read `Tools/IslandMeshGen/docs/TERRAIN_DETAIL_FORGE_MINDSET.md`.
3. Read `Tools/IslandMeshGen/island_mesh_generator.py`.
4. Read the terrain tests in `Tools/IslandMeshGen/tests/test_island_mesh_generator.py`.
5. Do not start with UI.
6. Write failing tests for Fine Terrain Field v1.
7. Implement new field masks and process pass in small increments.
8. Only after tests pass, expose new masks in the web process layer UI.

The strongest next move is not "make the page prettier." The strongest next move is to make the baked terrain itself more geologically legible.

## Final Development Mantra

Preserve semantic control. Add terrain process. Keep preview honest.

The island should not become more detailed because random noise got louder. It should become more detailed because flow, slope, curvature, erosion, deposition, and strata have started arguing with each other in a controlled way.
