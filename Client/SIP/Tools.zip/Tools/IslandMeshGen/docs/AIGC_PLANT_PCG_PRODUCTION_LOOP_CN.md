# AIGC 植物 PCG 生产闭环心智

更新时间：2026-07-07

## 核心判断

现在这套植物管线不要再让 PCG 或蓝图直接管理 16 个静态网格体。生产闭环应该是：

```text
PCG / 岛屿语义层
  只决定：种在哪里、是哪一族植物、崩坏带、随机种子、整体缩放

USIPResourcePlantRecipe DataAsset
  持有：CrownLily / AetherVine 的四槽 C0-C3 AIGC 静态网格引用、装配 hint、运行时 tag

ASIPResourcePlantActor
  负责：按 seed + collapse band 采样崩坏向量、选择四槽 mesh、应用装配 transform、保留导入材质/PBR

Tools / soft-ue 验证脚本
  负责：资产审计、Recipe DataAsset 生成/更新、场景烟测、输出 JSON 证据
```

这意味着 PCG 不应该知道 `BodyShell C2` 或 `OrbitSet C3` 的具体资产路径。PCG 只传“高层生态语义”，Actor 自己把语义落到四槽装配上。

## 四槽契约

当前正式插槽固定为四个：

```text
BodyShell
PrimarySilhouette
Core
OrbitSet
```

每个插槽有 C0-C3 四个崩坏状态。崩坏向量不是完全随机的 4D 骰子，而是带约束的离散能量采样：

```text
Stable_C0      倾向低 severity，整体完整
Weathered_C1   小幅风化，适合普通资源点
Fractured_C2   明显破损，适合危险/稀有区域
Unstable_C3    高崩坏但避免全槽同质 C3 噪声
```

保留“混乱感”的关键不是无限随机，而是让 `PrimarySilhouette / Core / OrbitSet` 可以产生离散差异，同时让 `BodyShell` 和主轮廓不要失去可读性。

## PCG 输入契约

PCG 或 PCG 派生蓝图只需要提供：

```text
Recipe: USIPResourcePlantRecipe，可为空
Family: CrownLily / AetherVine，当 Recipe 为空时作为 preview fallback
CollapseBand: Stable_C0 / Weathered_C1 / Fractured_C2 / Unstable_C3
Seed: int32
Scale: float
CollapseTemperatureScale: float，默认 1.0
```

C++ 入口：

```cpp
FSIPResourcePlantCollapseVector ASIPResourcePlantActor::ConfigureFromPCG(
	USIPResourcePlantRecipe* InRecipe,
	ESIPResourcePlantPreviewFamily InFamily,
	ESIPResourcePlantCollapseBand InCollapseBand,
	int32 InSeed,
	float InScale,
	float InCollapseTemperatureScale,
	bool bInUseRecipeDefaultCollapseBand);
```

默认生产用法应让 `bInUseRecipeDefaultCollapseBand = false`，因为 PCG/岛屿语义层通常应该显式决定该点位的崩坏带。只有在“这个 Recipe 自己带默认生态强度”的情况下才打开 recipe default。

## Actor 责任

`ASIPResourcePlantActor` 在 PCG 配置后必须保证：

```text
PlantRecipe = InRecipe
PreviewFamily = InRecipe ? InRecipe->Family : InFamily
CollapseBand = InCollapseBand
PlantSeed = InSeed
PlantScale = clamp >= 0.1
CollapseTemperatureScale = clamp 0.05-2.5
bUseExplicitCollapseVector = false
RebuildPlantPreview()
```

`RebuildPlantPreview()` 会生成 `ResolvedCollapseVector`，然后用 Recipe 内的 slot variants 选择：

```text
/Game/AIGC/Plants/{Family}/C{SlotLevel}/{Slot}
```

例如：

```text
Family = CrownLily
Vector.PrimarySilhouette = 2
=> /Game/AIGC/Plants/CrownLily/C2/PrimarySilhouette
```

## PBR / 材质只读原则

导入的 AIGC 静态网格、材质、贴图资产是资产源，不是运行时脚本的修改对象。

Actor 使用 Recipe mesh 时必须走：

```text
ConfigureSlot(..., bApplyPreviewMaterial = false)
Component->EmptyOverrideMaterials()
```

这样 UE 会使用 StaticMesh 自带材质槽和导入 PBR，而不是覆盖成预览材质。预览材质只给没有 Recipe 的 basic-shape fallback 用。

## 场景验证标准

PCG smoke 脚本的目标不是保存地图，而是在当前编辑器场景生成一组可见测试 Actor，并打印 JSON 证据：

```text
missing_recipe_count == 0
mesh_mismatch_count == 0
material_override_count == 0
spawned_actor_count == families * bands
```

推荐脚本：

```powershell
$env:PYTHONPATH='C:/Users/12542/Documents/Unreal Projects/SkyIslandPotion/Client/SIP/soft-ue-cli'
C:/Users/12542/AppData/Local/Programs/Python/Python312/python.exe -m soft_ue_cli run-python-script --script-path 'C:/Users/12542/Documents/Unreal Projects/SkyIslandPotion/Tools/IslandMeshGen/ue_spawn_aigc_resource_plant_pcg_smoke.py'
```

这一步验证的是生产交接面：

```text
Persistent Recipe DataAsset
  -> ConfigureFromPCG 高层参数
  -> Actor 内部采样崩坏向量
  -> 四槽 mesh 自动选择
  -> 原始 AIGC 材质/PBR 保留
```

## 必跑验证命令

工具侧 Python 测试：

```powershell
C:/Users/12542/AppData/Local/Programs/Python/Python312/python.exe 'C:/Users/12542/Documents/Unreal Projects/SkyIslandPotion/Tools/IslandMeshGen/tests/test_plant_collapse_sampler.py'
C:/Users/12542/AppData/Local/Programs/Python/Python312/python.exe 'C:/Users/12542/Documents/Unreal Projects/SkyIslandPotion/Tools/IslandMeshGen/tests/test_plant_aigc_asset_catalog.py'
C:/Users/12542/AppData/Local/Programs/Python/Python312/python.exe 'C:/Users/12542/Documents/Unreal Projects/SkyIslandPotion/Tools/IslandMeshGen/tests/test_plant_actor_spawn_plan.py'
C:/Users/12542/AppData/Local/Programs/Python/Python312/python.exe 'C:/Users/12542/Documents/Unreal Projects/SkyIslandPotion/Tools/IslandMeshGen/tests/test_plant_recipe_asset_plan.py'
```

C++ 构建：

```powershell
& 'C:/Program Files/Epic Games/UE_5.4/Engine/Build/BatchFiles/Build.bat' SIPEditor Win64 Development -Project='C:/Users/12542/Documents/Unreal Projects/SkyIslandPotion/Client/SIP/SIP.uproject' -WaitMutex
```

Recipe DataAsset 更新：

```powershell
$env:PYTHONPATH='C:/Users/12542/Documents/Unreal Projects/SkyIslandPotion/Client/SIP/soft-ue-cli'
C:/Users/12542/AppData/Local/Programs/Python/Python312/python.exe -m soft_ue_cli run-python-script --script-path 'C:/Users/12542/Documents/Unreal Projects/SkyIslandPotion/Tools/IslandMeshGen/ue_create_aigc_plant_recipe_assets.py'
```

PCG smoke：

```powershell
$env:PYTHONPATH='C:/Users/12542/Documents/Unreal Projects/SkyIslandPotion/Client/SIP/soft-ue-cli'
C:/Users/12542/AppData/Local/Programs/Python/Python312/python.exe -m soft_ue_cli run-python-script --script-path 'C:/Users/12542/Documents/Unreal Projects/SkyIslandPotion/Tools/IslandMeshGen/ue_spawn_aigc_resource_plant_pcg_smoke.py'
```

## 当前边界

这一步仍然不是完整 PCG 图编辑，也不是最终美术摆放规则。它先把“PCG 能用的 Actor API”和“场景可验证的生产装配路径”立住。

后续 PCG 图只需要在点位上选择：

```text
Recipe / Family
CollapseBand
Seed
Scale
```

然后调用或设置 Actor 即可。这样美术规则、岛屿语义、VFX 语义可以慢慢加，底层 AIGC 植物装配不会被推倒重来。
