# Fire Gaea Strong Mindset

> Scope: Fire volcano island whitebox generation, preview judgment, and Meshy handoff readiness.

## One-Sentence Doctrine

Fire must become a credible grey whitebox before Meshy touches it. Meshy can reward good landform causality with PBR, but it cannot rescue a terrain that still reads as radial noise, thin spikes, or decorative masks.

## Current North Star

The target is not "more detail" and not "smoother". The target is a fire island that reads, in pure grey/white material, as a terrain shaped by volcanic process:

- large form: volcanic cone, crater basin, asymmetric rim, broken island silhouette
- mid form: breached rim saddles, lava spillways, cooled terminal fans, basalt shelves, talus apron, crater loop, readable approach route
- small form: aged chips, strata, ash settling, cooling crust, but no random needle spikes
- directionality: lava and erosion follow slope and process logic, not evenly spaced math rays
- material causality: lava material sits in channel cores, cliff material sits on steep exposed rock, path material stays on walkable route centers

## The Three Data Flows Must Stay Separate

### 1. Realtime Preview

Purpose: fast authoring feedback while dragging controls.

Rule:

- `draft` stays draft.
- `preview`, `production`, and `hero` realtime feedback may be capped to `preview`.
- Realtime preview is allowed to be lighter than final output, but the UI must say so plainly.

User promise:

- Shows semantic intent, movement, masks, quality trends.
- Does not promise final hero topology.

### 2. High-Res Inspect

Purpose: explicit visual judgment for the selected final bake quality.

Rule:

- `Inspect HERO` must actually use hero topology.
- `Inspect PRODUCTION` must actually use production topology.
- Inspect writes only to `output/.inspect/`, never to official UE export artifacts.
- If layout or quality changes, inspect becomes stale.

User promise:

- This is the right place to judge "does it look like Gaea/Houdini yet?"

### 3. Final Generate

Purpose: official artifact export for UE/PCG and Meshy handoff.

Rule:

- Writes OBJ, field JSON, manifest JSON, and quality report to `output/`.
- Uses the selected final bake quality exactly.
- The app should surface the generated artifact quality so users do not mistake an old hero OBJ for a production preview or vice versa.

User promise:

- This is the asset contract for Unreal and downstream AIGC experiments.

## Fire Gaea Loop

Every iteration should do one process-level improvement, not an aesthetic blur:

1. choose a visible landform weakness
2. add a regression metric that fails on the weakness
3. implement a Fire-only process pass
4. protect gameplay semantics: main route, crater loop, lava core, material boundaries
5. run targeted tests, full tests, syntax checks
6. bake hero, refresh preview and diagnostics
7. decide whether the next blocker is preview judgment or terrain causality

## Harder Gaea/Houdini Loop

The higher target is not to imitate one tool literally. It is to combine the best parts of both:

- Gaea strength: terrain reads as natural process, with crater collapse, lava transport, talus deposition, ash drape, strata, and age.
- Houdini strength: every process is inspectable, parameterized, local, and safe to rerun without destroying gameplay semantics.
- Game-tool strength: route, PCG masks, material slots, and downstream Meshy handoff stay stable under iteration.

Each hard loop should include four gates:

1. Landform gate: does the grey whitebox reveal a believable volcanic force, not merely noise?
2. Material-causality gate: would Meshy understand each region from the exported material slots without reading sidecar JSON?
3. Performance gate: can this be fixed with classification, cached masks, or a narrow local pass before adding another whole-field pass?
4. Regression gate: does a new test prevent the exact artifact from returning?

Preferred order of fixes:

1. Correct material semantics when the geometry is already good.
2. Add localized Fire-only weathering when the geometry has teeth or chatter.
3. Add a new process layer only when several local fixes point to the same missing landform cause.
4. Refactor/consolidate passes only after profiling or repeated loop cost says the process stack is becoming too expensive.

Current Fire material-causality rule:

- Steep, layered, non-route volcanic walls must export as `M_CliffRock`, even if the face-average slope barely misses the broad cliff threshold.
- Use face peaks for slope/strata when a quad straddles a wall boundary; this matches what the renderer and Meshy will actually see.
- Fire top terrain must export as `M_AshPlateau`, not `M_TopGrass`. The 5-slot Meshy-safe Fire contract is `M_AshPlateau`, `M_PathDirt`, `M_CliffRock`, `M_UndersideRock`, and `M_ElementCrack`.
- Do not let `M_AshPlateau` become a catch-all for crater wall shoulders, lava shoulders, or exposed blackrock shelves.

## Current Fire Process Layers

Already useful:

- crater collapse terraces
- talus apron settling
- feature-preserving aged edge weathering
- crater ash basin settling
- lava rim spillway breach
- terminal lava cooling fan
- volcano wall strata weathering
- incomplete secondary collapse shelves
- terminal lava shoulder weathering
- outer basalt block shelves
- outer apron chatter weathering
- high-slope lava shoulder material causality
- ash plateau material contract for Meshy/PBR handoff
- inner wall breach rib slump
- inner strata wall material causality
- blackrock talus shoulder material causality
- front breach ash drape
- moderate inner strata wall material causality
- steep crater-loop wall material causality
- volcano strata transition wall material causality
- outer volcano strata shoulder material causality
- moderate lava shoulder material causality
- front entry crater-shoulder ash drape
- front ash-toe approach curtain softening
- front ash-plateau local curtain slump
- final outer-wall polar curtain cleanup
- diagonal outer-wall breakup for long vertical boundary columns
- asymmetric outer-wall break arcs that move some strongest cliff breaks away from one circular ring
- macro crater wall arc layout for buttress/breach/slump arcs
- narrow final local ring-lock settling for outer wall windows still dominated by one break ring
- non-front ash plateau deposition bands for R26-R35 over-detail settling
- slope/low-potential lava corridor capture and downstream carving
- Meshy-safe lava material compactness bridge that removes tiny isolated `M_ElementCrack` islands without adding a sixth Fire material slot
- ash plateau hotspot settling that separates random over-detail from protected secondary collapse shelves
- Fire-only broken underside lower ring and bottom cap that shorten `M_UndersideRock` radial fan faces in side/back views
- Fire-only broken cliff skirt rings that shorten long `M_CliffRock` curtain faces in side/back views

Next candidates:

- radial artifact scoring in quality report
- material-causality audits for steep exposed fire shoulders
- localized ash-drape metrics for crater wall breach teeth
- local worst-window metrics for machine-like wall ribs
- Gaea/Houdini composite score: landform causality, material causality, radial artifact, over-detail, route health, and generation cost
- front approach material semantics for ash/talus shoulders that are too steep for generic top terrain
- hero/production preview clarity in the browser UI
- face-normal preview awareness: OBJ exports vertex normals and `s 1`, but inspect/offline face-normal lighting can still exaggerate polar faceting
- broader crater/path/cliff material-region compactness audits after the lava pass, so Meshy receives cleaner semantic PBR regions
- side/back cliff skirt shadow-rhythm audits after both underside bottom fan and long cliff faces have been shortened

## Distance To Gaea / Houdini

Current Fire is past the "procedural noise" stage: crater, route, lava channels, basalt shelves, talus, ash drape, and material zones are now readable from the hero bake. The `M_AshPlateau` contract also makes Fire materially honest for Meshy/PBR. The latest macro crater-wall loop reduced the dominant outer-wall break ring coverage from about 58% to about 44%, kept rigid 24-segment local wall windows at 0, and preserved secondary collapse shelf coverage after reasserting shelves late in the process stack. The follow-up non-front ash deposition loop reduced R26-R35 ash plateau angular p95 from about 217cm to about 184cm and local residual p95 from about 152cm to about 139cm. The low-potential lava loop reduced downstream lava-flow peak height above local low points from about 586cm to about 407cm, and all three non-entry channels now have downstream bends while terminal fans remain guarded. The material-compactness loop removed the remaining tiny `M_ElementCrack` islands under 8 faces, shifting Fire toward cleaner Meshy/PBR region semantics. The ash-hotspot loop tightened broader `M_AshPlateau` over-detail while explicitly excluding secondary collapse shelves from the smoothing metric. The underside loop split Fire's single long bottom fan into a broken lower ring plus small bottom cap, reducing side/back `M_UndersideRock` radial fan exposure without changing the material contract. The cliff-skirt loop then split long `M_CliffRock` skirt faces through two broken intermediate rings, reducing cliff radial span p95 to about 0.151R. Side/back views should now read less like one circular polar cone, less like sandpaper noise, less like lava rays laid over terrain, less like scattered emissive noise, less like one long black radial underside fan, and less like a single-piece cliff curtain. It is closer, but still not true Gaea/Houdini grade.

Approximate current distance:

- Whitebox credibility: about 83-85% of the way to a convincing Gaea-like volcanic island.
- Meshy/PBR handoff readiness: about 84%; material slots are readable, Fire no longer asks Meshy to interpret grass as ash, and tiny `M_ElementCrack` islands have been eliminated. Larger material-region causality still needs visual proof from generated HERO artifacts.
- Houdini-style process clarity: about 77%; crater wall arcs, ash deposition, and low-potential lava capture are now named processes with regression metrics.
- Hero naturalness gap: about 11-13% remains, mostly in final silhouette mass distribution, remaining side/back cliff-skirt shadow rhythm, broader material-region causality, and process-stack consolidation/performance.

The next serious gains should not be "more smoothing." They should be:

1. material-region compactness audits for Meshy-safe PBR retexture
2. a composite Gaea score that includes landform causality, material compactness, radial artifact, over-detail, route health, and generation cost
3. final silhouette mass distribution from 8-angle contact sheets, especially side/back black wall readability
4. performance consolidation if another full-field Fire pass becomes necessary
5. optional Meshy smoke test only after local material compactness is acceptable

## What Counts As Better

Useful improvements:

- lower isolated knife-point residuals without flattening semantic features
- lower volcano wall angular rib score while preserving radial collapse steps
- stronger lava center/shoulder height separation
- terminal fans that settle downstream without abrupt cliffs
- route center remains readable and safer than rough shoulders
- material slots still match terrain logic
- high-slope lava shoulders export as rock/crack material rather than broad top platform material
- local worst-window wall ribs slump below machine-tooth thresholds while radial collapse steps remain readable
- stratified inner crater walls and blackrock talus shoulders export as rock, not generic top platform
- front breach ash-drape reduces vertical teeth while preserving the wall drop
- multi-angle inspection includes front, left, back, right, and diagonal yaw angles; front-only approval hides polar wall artifacts
- outer black wall side/back views lose the continuous "window-blind" polar columns while keeping crater-wall mass and shelf steps
- OBJ/GLB handoff keeps vertex normals smooth enough for UE/Meshy, while inspect keeps enough depth lighting to reveal true geometry defects

False improvements:

- global smoothing that erases crater/lava/path readability
- more noise on top of weak mid-form
- higher mesh density with the same radial artifact
- Meshy/PBR tests before the grey whitebox is credible

## Meshy Boundary

Meshy enters only after the whitebox already works.

Meshy can help with:

- PBR retexture on existing material slots
- basalt, lava crust, vents, ash, and prop donor assets
- hero visual skin experiments

Meshy must not own:

- terrain topology logic
- route safety
- PCG semantic masks
- collision proxy
- crater/lava/path causality

The correct handoff is:

```text
semantic layout
  -> Fire-specific heightfield process layers
  -> feature-preserving cleanup
  -> OBJ/GLB with material regions
  -> quality report and grey-white validation
  -> Meshy retexture / PBR as a visual reward
```

## Acceptance Gate Before Meshy

Do not send a candidate to Meshy as a serious hero test unless:

- pure grey view already reads as a volcanic island at 200m scale
- crater, rim, lava channels, cooled fans, route, and blackrock shelves are readable from orbit
- no obvious random spikes or thin teeth dominate the silhouette
- material regions are compact and causally placed
- final hero inspect, not realtime preview, has been used for judgment

## 2026-07-06 Loop: Side/Back Cliff Skirt Rhythm

This loop clarified a subtle but important Fire whitebox rule: after long skirt faces are shortened, the next defect is not face span but **continuous shadow rhythm**. A side/back cliff wall can have acceptably short quads and still read as a procedural polar curtain if 40-50 neighboring angular columns share nearly the same height/radius profile.

The new regression isolates generated `M_CliffRock` skirt faces, groups them into angular columns, compares the three-layer profile between neighboring columns, and caps the longest run where profile deltas stay below `0.015R`.

Measured movement:

```text
height longest run < 0.015R: 53 -> 32 columns
radial longest run < 0.015R: 54 -> 31 columns
M_CliffRock skirt faces: 1152
material slots: unchanged 5-slot Meshy contract
```

The production move is Fire-only mesh extraction breakup: macro block slump plus narrow fracture seams on the cliff skirt. It does not alter route/crater/lava field semantics, does not add a material slot, and does not rely on global smoothing.

Current visual truth after the 8-angle sheet: the lower/outer skirt is less continuous, but the upper crater/outer wall still shows too much vertical rib regularity under face-normal inspect. The next serious Gaea/Houdini gain is **upper crater / outer wall vertical rib de-patterning**, not more underside fan work.

## 2026-07-06 Loop: Upper Wall Castle-Rib De-Patterning

The next Fire defect was not a single spike or a single long face. It was a family of medium-strength angular boundaries that stayed aligned across many radial rings, making the upper volcano wall read like a castle wall under side/back inspect lighting.

The new regression counts persistent upper-wall rib boundaries:

```text
upper wall band ~= R26-R39
medium rib: angular delta > 110cm
strong rib: angular delta > 160cm
persistent boundary: medium >= 7 rings or strong >= 4 rings
```

Measured movement:

```text
persistent castle ribs: 78 -> 58 boundaries
worst upper-wall boundary p80: ~267cm -> 229cm
HERO summary: Route 94% / detail risk 8% / edge risk 4% / radial risk 4%
```

The implementation expands Fire's `_weather_fire_outer_wall_polar_curtains` process. It now treats two cases:

- isolated high-p80 boundaries;
- medium-strength boundaries that persist across too many rings.

The important lesson: Gaea/Houdini credibility is not only about removing worst-case spikes. A terrain can pass max-spike tests and still look synthetic when many moderate features line up with polar topology. Future Fire metrics should keep looking for aligned families of artifacts, not just isolated extremes.

Remaining gap after this loop: upper wall ribs are reduced but not gone; lava curtains and black-wall silhouette still need stronger block-scale causality before the asset can honestly be called near-final Gaea/Houdini quality.

## 2026-07-06 Loop: Lava Cooling Crust Must Have Geometry

上一轮把连续 `M_ElementCrack` 红色 lava curtain 切出了 `M_CliffRock` 冷却壳断带，这对 Meshy/PBR 交接有帮助，但还不够 Gaea/Houdini。原因很简单：如果冷却壳只发生在 material assignment 层，而 heightfield 没有对应的抬起、断坎、溢流台阶，那它仍然是“贴图解释”，不是“地貌因果”。

新的判断规则是：

```text
导出为 M_CliffRock 的 lava cooling-crust break
必须在灰白模型里也表现为抬起的冷却岩壳 / 坝肩 / 唇边。
```

新增回归检查非入口 lava channel 的 `R0.805-R0.875` 中心线：

```text
找到 M_CliffRock cooling cells
计算 height - average(inner radial neighbor, outer radial neighbor)
要求至少 3 条非入口 lava channel 都有几何冷却壳
要求最弱的 lip >= 115cm
```

初始 RED 暴露了两个问题：

- 只有 2 条 channel 在该断带导出了 `M_CliffRock`；
- 已导出的冷却壳有些只是材质换色，几何唇边不足。

实现上新增了 Fire-only 的 cooling-crust sill heightfield pass，并把它放在低势能 lava corridor carve 与 ash deposition 之后，作为最终地貌的一部分。它做三件事：

- 在高 flow / high accumulation 的 lava 通道中心承认冷却壳，即使 lava mask 本身只有中等强度；
- 把冷却壳抬成真实几何唇边；
- 在唇边外侧补 downstream spill shelf，避免单环硬坎破坏 terminal fan 连续性。

这轮的核心心智是：**Meshy 需要的不是更多语义说明，而是更少语义自相矛盾。** 当 `M_CliffRock`、lava flow mask、flow accumulation 和 heightfield 同时指向“这里是冷却壳”，AIGC 才更可能给出稳定的 PBR 惊喜。否则它只是在解释一块被我们临时涂黑的红色通道。

下一轮如果继续 lava，不应只加材质断带，而应推进 lava block-scale morphology：侧向溢流舌、冷却台阶、局部 levee erosion、黑岩肩部坍塌都要和中心红色流面共同构成“流动历史”。

## 2026-07-06 Loop: Upper Wall Extreme Rib Target

冷却壳几何化之后，8-angle contact sheet 仍然暴露了上部黑色火山墙的旧问题：它已经不再是最早那种离谱尖刺，但 side/back 下仍有一组中等强度、持续跨 ring 的竖向肋，读起来像城墙或柱状帘幕。

旧回归要求：

```text
persistent castle ribs < 60
```

旧状态已经是 58，技术上过线，但视觉上不够。新的 extreme target 把同一指标压到：

```text
persistent castle ribs < 54
```

这轮 RED：

```text
persistent castle ribs: 58
```

实现没有新增一套 smoothing，而是加强既有 `_weather_fire_outer_wall_polar_curtains` 的中强度持久肋处理：

- 增强 wall-band 内的 coherence response；
- 降低局部 rib 进入二次 settle 的门槛；
- 继续保护 path / lava / crater loop；
- 不改变 Fire 五材质槽合同。

更新后：

```text
persistent castle ribs: 58 -> 53
worst upper-wall boundary p80: 229.4cm -> 224.7cm
worst strong vertical run: still 5
```

这不是最终答案，但它让上部火山墙又少了一层“程序化柱面”的味道。下一步仍然应该从“减少肋”推进到“创造更大的崩塌块面”：也就是让黑岩墙出现更明确的塌陷扇、冷却板、斜向 fracture，而不是只把每条竖线磨平。

## 2026-07-06 Loop: Broad Collapse Window 不应是刚性同环带

`persistent castle ribs` 降到 53 之后，新的肉眼缺口变大了：不是单条 boundary，而是一整段 24-column 的墙面仍然把最强 radial break 集中在同一两个 ring 上。旧测试已经能防止“全岛同一个圆环”，但不能阻止局部墙段像被同一把程序刀切过。

新的回归把这个问题定义为：

```text
每个 24-column upper-wall window:
  找每个有效 column 的 strongest radial break ring
  如果 ring_spread < 3 且 dominant_ring_coverage > 72%
  就算 rigid broad-collapse window
要求 rigid_windows <= 2
```

初始 RED：

```text
rigid broad-collapse windows: 4
```

实现仍然复用既有外墙 break redistribution，没有新增全局 smoothing。变化是：

- 把 rigid-window 触发条件从“几乎完美同环”扩展到“宽段仍过度同环”；
- 对选中的 dominant-ring column 更强地削弱原断裂；
- 把断裂能量迁移到邻近 ring，让墙面形成交错 collapse plates；
- 继续保护 path / lava / crater loop。

结果：

```text
rigid broad-collapse windows: 4 -> 2
persistent castle ribs: 53 -> 51
worst upper-wall p80: 224.7cm -> 233.7cm，仍低于 260cm 安全线
```

这轮的心智是：Gaea/Houdini 感不是越安静越好，而是“哪里破、怎么破、破碎是否有历史”。为了打散同环程序味，允许局部 relief 稍微抬高，只要它仍在 safety gate 内，并且服务于更可信的崩塌节奏。

## 2026-07-06 Loop: Cliff Skirt 必须继承 Upper Wall 的坍塌历史

上一轮把 upper wall 的 broad collapse window 从“同环程序切带”往 staggered collapse plates 推了一步，但 side/back 仍然有一个更微妙的问题：上部黑岩墙已经开始错台坍塌，下部 `M_CliffRock` skirt 却有些角区仍然像另一套平滑阴影系统。视觉上就是“好一点的火山墙”下面接了一个不完全相关的黑色裙边。

新的回归把这个问题定义为：

```text
对每个 24-column 窗口：
  如果 upper wall strongest break ring spread >= 3
  则认为该角区已经有宽段坍塌历史
  同角区的 generated cliff skirt 不能仍然高度和半径 profile 都过于平滑
要求 upper/skirt mismatch windows <= 6
```

初始 RED：

```text
upper collapse windows: 10
upper/skirt mismatch windows: 8
```

实现方式是在 Fire cliff-skirt mesh extraction 里从 semantic heightfield 的 upper-wall break rings 派生 `collapse_transfer`：

- 只作用于 Fire 生成裙边顶点；
- 不改 top route / crater / lava 语义；
- 用上墙 break ring 的局部错位去影响 skirt 的 local_t、radial push 和 z offset；
- 保留三层 cliff skirt 和五材质 Meshy 合同。

结果：

```text
upper/skirt mismatch windows: 8 -> 5
skirt longest smooth height run: 32
skirt longest smooth radial run: 31
```

这轮的心智是：Gaea/Houdini 感不能只看 top surface。浮岛是一个整体物体，上墙、侧壁、下裙边、underside 都必须像同一个火山体经历了同一段冷却、断裂、坍塌、侵蚀历史。否则 side/back 再怎么局部精修，仍然会像两个系统拼起来。

## 2026-07-06 Loop: Bottom Cap 不能保留平滑三角扇

把 upper wall collapse 传给 cliff skirt 后，side/back 的上下黑岩系统更统一了，但底部仍有一个隐藏问题：central underside fan 足够短，却太平滑。inspect 或斜侧光下，这种平滑会变成规则三角扇阴影，像是程序封底，而不是火山体被撕裂后的底部。

新的回归：

```text
从 Fire mesh vertex order 推断 bottom cap ring
比较相邻 cap 的半径和高度
统计同时低于平滑阈值的最长连续段
要求 longest smooth triangular-fan run < 84 columns
```

初始 RED：

```text
bottom-cap longest smooth fan run: 106
```

实现仍然复用同一个 `collapse_transfer` 信号：

- upper wall 的 broad collapse history 传给 cliff skirt；
- 同一信号继续传给 lower underside 和 bottom cap；
- 影响底部 scale / z offset；
- 不扩大 central underside fan，不破坏短底部合同。

结果：

```text
bottom-cap longest smooth fan run: 106 -> 31
bottom-cap max radius: 0.103R
lower-underside longest smooth run: 9
HERO quality unchanged: Route 94% / detail 8% / edge 4% / radial 4%
```

这轮的心智是：底部可以短，但不能假。短是工程合同，破碎节奏是视觉可信度。Gaea/Houdini 的 floating island 不会在底部突然露出一个完美数学扇形。
