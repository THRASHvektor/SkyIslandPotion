# Meshy Agent Brief

Date: 2026-07-04

Purpose: A short brief to ask the Meshy agent about API boundaries for semantic terrain retexture/remesh and modular plant parts.

## Project Context

We generate Unreal-friendly floating-island whitebox meshes from semantic layout data.

Each bake can produce:

- a mesh file: currently OBJ, future GLB/FBX preferred
- `field.json`: heights and masks such as path, lava, ravine, volcano, cliff, slope, talus, lava_flow, future flow/curvature/strata
- `manifest.json`: biome, material slots, zones, paths, hazards, resources, Unreal import contract
- `quality_report.json`: diagnostics and gatekeeping data

We understand that Meshy mainly accepts model files, images, prompts, and task IDs. It likely does not directly understand our semantic JSON sidecars.

Our goal is to translate our semantic data into Meshy-readable model regions and prompts.

## Main Questions

### 1. Region Control For Retexture

If we upload a GLB/FBX/OBJ with multiple material slots such as:

- `M_TopGrass`
- `M_PathDirt`
- `M_CliffRock`
- `M_UndersideRock`
- `M_ElementCrack`

Can Meshy Retexture preserve and treat those material regions separately?

Questions:

- Does Retexture preserve input material slot boundaries?
- Does it preserve material slot names?
- Can the prompt refer to material slot names directly?
- Can the output contain separate PBR textures per material region?
- Can emissive lava fissures be limited to one material region?
- Does Meshy ever merge material slots during Retexture?

### 2. Colored Semantic Masks

If the input model uses temporary colored materials as semantic masks:

- red/orange = lava fissures
- ochre/yellow = ash path
- blue-gray = basalt cliff
- neutral gray = top terrain
- dark purple/black = underside

Can Meshy use those colors as region guidance if the prompt says:

```text
The input colors are semantic masks, not final colors.
Preserve the region layout and replace colors with natural PBR materials.
```

Questions:

- Is this a recommended workflow?
- Will Meshy treat colors as final appearance or as controllable guidance?
- Is image-style guidance better than colored materials for this case?
- Would a separate rendered mask image help Retexture follow regions?

### 3. Remesh Preservation

If we use Remesh on a semantic terrain mesh:

- Can Remesh preserve scale exactly?
- Can it preserve material assignments?
- Can it preserve object groups or mesh parts?
- Can it preserve UVs?
- Can it preserve vertex colors?
- Can it preserve named objects or node hierarchy in GLB/FBX?
- Does it change pivots/origin?
- Does it support "smooth but do not shrink/round off silhouette" behavior?

We need to know whether a Meshy-remeshed island can be used only as a visible skin while our original semantic mesh remains the collision and PCG proxy.

### 4. Best Input Format

For a multi-material semantic terrain mesh, which input is best?

- OBJ + MTL
- GLB
- FBX
- STL

Questions:

- Which format best preserves material slots?
- Which format best preserves UVs and normals?
- Which format works best with Retexture?
- Which format works best with Remesh?
- Does API data URI upload work reliably for large GLB/FBX files?
- What are current file size limits and polygon count limits?

### 5. PBR Output Details

For Retexture with PBR enabled:

- What exact texture maps are returned?
- Are normal / roughness / metallic / emissive maps separate downloadable files?
- Can emissive be requested for only one semantic region?
- Can we disable baked lighting?
- Can we request tileable material behavior, or are outputs always UV-baked to the input model?
- Can outputs be used as Unreal material inputs without further conversion?

### 6. Modular Plant Parts

We are considering Meshy for plant-part donor assets:

- root
- stem
- leaf
- flower / crown
- seam collar / node ornament

Questions:

- Can Meshy reliably generate parts with pivot at bottom or at a specified socket point?
- Can it preserve or create sockets/anchors?
- Can it generate vertical stem-like parts with consistent orientation?
- Can it generate mesh parts intended for modular assembly instead of complete plants?
- Can prompts constrain scale and connection surfaces?
- Is it better to generate complete plants first and manually cut parts, or prompt individual parts directly?

### 7. Recommended Workflow

Which workflow is most reliable?

Option A:

```text
Semantic terrain GLB with colored material masks
-> Meshy Retexture
-> PBR hero skin
```

Option B:

```text
Split terrain into path / cliff / crack / top / underside meshes
-> Retexture each separately
-> recombine locally
```

Option C:

```text
Use Meshy only for donor rocks, lava crusts, crystals, roots, and plant parts
-> keep terrain material generation in Unreal
```

Option D:

```text
Remesh the hero terrain as a visible skin
-> keep original semantic terrain as collision / PCG proxy
```

We need to know which is closest to Meshy's actual strengths.

## Example Retexture Prompt

```text
The input mesh uses colored material regions as semantic masks, not final colors.
Preserve the model shape, scale, and region layout.
Red/orange regions are glowing lava fissures with emissive PBR.
Ochre/yellow regions are compressed volcanic ash paths with fine gravel normal.
Blue-gray vertical regions are dark basalt cliffs with vertical strata.
Neutral top regions are cooled black volcanic soil with ash dust.
Dark underside regions are porous shadow rock.
Preserve material separation if possible.
Do not merge regions.
No baked lighting.
Stylized realistic Unreal Engine game asset.
```

## Desired Answer From Meshy

Please answer in terms of actual API behavior, not general AI capability:

- guaranteed behavior
- likely behavior but not guaranteed
- unsupported behavior
- best input format
- recommended endpoint
- recommended parameters
- known failure modes
- a minimal test plan

