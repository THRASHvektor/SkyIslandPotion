# Terrain Detail Bake Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add the first Terrain Detail Forge slice: documented mindset, bake quality profiles, production-quality topology, and a UI selector for final bake quality.

**Architecture:** Keep realtime preview on the existing fast topology, and add a separate final-bake quality path. Server utilities own web-facing quality profiles, the Python exporter owns quality-to-topology/detail settings, and the UI only sends the chosen quality to the formal generate endpoint.

**Tech Stack:** Python `unittest`, Node `node:test`, vanilla JS/CSS/HTML, existing OBJ exporter and local web server.

---

### Task 1: Document The Mindset

**Files:**
- Create: `Tools/IslandMeshGen/docs/TERRAIN_DETAIL_FORGE_MINDSET.md`
- Create: `docs/superpowers/plans/2026-07-02-terrain-detail-bake.md`

- [x] **Step 1: Write the Terrain Detail Forge mindset doc**

The doc states that Houdini-like detail should come from the semantic terrain baker first, while Meshy remains a later AI assist for PBR skins, donor assets, and remesh cleanup.

- [x] **Step 2: Write this implementation plan**

The plan keeps the implementation narrow: no Meshy API, no UE automation, no broad refactor.

### Task 2: Add Quality Profiles To Server Utilities

**Files:**
- Modify: `Tools/IslandMeshGen/web/server_utils.test.mjs`
- Modify: `Tools/IslandMeshGen/web/server_utils.mjs`

- [ ] **Step 1: Write failing tests**

Add tests for:

```js
assert.deepEqual(exportArgsForQuality('production'), {
  quality: 'production',
  segments: 192,
  rings: 32,
});
assert.equal(normalizeBakeQuality('unknown'), 'production');
assert.equal(bakeQualityOptions()[0].id, 'draft');
```

- [ ] **Step 2: Run tests and verify failure**

Run:

```powershell
& "C:\Users\zzg\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe" --test ".\Tools\IslandMeshGen\web\server_utils.test.mjs"
```

Expected: failure because the new exports do not exist.

- [ ] **Step 3: Implement server utility functions**

Add `BAKE_QUALITY_PROFILES`, `normalizeBakeQuality`, `exportArgsForQuality`, and `bakeQualityOptions`.

- [ ] **Step 4: Run tests and verify pass**

Run the same Node test command. Expected: all `server_utils` tests pass.

### Task 3: Add Python Quality-Aware Export

**Files:**
- Modify: `Tools/IslandMeshGen/tests/test_island_mesh_generator.py`
- Modify: `Tools/IslandMeshGen/island_mesh_generator.py`
- Modify: `Tools/IslandMeshGen/export_layout.py`

- [ ] **Step 1: Write failing tests**

Add tests proving production quality returns a denser mesh and exposes detail intensity:

```python
draft = generate_island_mesh_from_layout(layout, radial_segments=96, rings=14, bake_quality="draft")
production = generate_island_mesh_from_layout(layout, bake_quality="production")
self.assertGreater(len(production.vertices), len(draft.vertices) * 3)
```

- [ ] **Step 2: Run tests and verify failure**

Run:

```powershell
& "C:\Users\zzg\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe" -m unittest "Tools.IslandMeshGen.tests.test_island_mesh_generator.IslandMeshGeneratorTests.test_fire_layout_production_quality_uses_denser_detail_topology"
```

Expected: failure because `bake_quality` is not accepted yet.

- [ ] **Step 3: Implement quality presets**

Add Python quality presets and let `generate_island_mesh_from_layout(..., bake_quality="draft")` choose default topology and detail intensity when segments/rings are not explicitly provided.

- [ ] **Step 4: Add CLI argument**

Add `--quality` to `export_layout.py`. Explicit `--segments` and `--rings` still override topology, while `--quality` still controls detail intensity.

- [ ] **Step 5: Run Python tests**

Run full IslandMeshGen Python tests. Expected: all pass.

### Task 4: Wire Final Bake Quality Through The Web Server

**Files:**
- Modify: `Tools/IslandMeshGen/web/server.mjs`
- Modify: `Tools/IslandMeshGen/web/server_utils.test.mjs`

- [ ] **Step 1: Add tests for client-visible quality profiles**

Extend `server_utils` tests so client options include ids and labels:

```js
assert.deepEqual(bakeQualityOptions().map((option) => option.id), ['draft', 'preview', 'production', 'hero']);
```

- [ ] **Step 2: Implement `/api/bake-profiles`**

Return `bakeQualityOptions()` from a new GET route.

- [ ] **Step 3: Use quality in `/api/generate/:biome`**

Read `quality` from the query string, pass `exportArgsForQuality(quality)` to `runExportLayout`, and include `quality` in the JSON response.

### Task 5: Add The UI Selector

**Files:**
- Modify: `Tools/IslandMeshGen/web/index.html`
- Modify: `Tools/IslandMeshGen/web/app.js`
- Modify: `Tools/IslandMeshGen/web/styles.css`
- Modify: `Tools/IslandMeshGen/web/view_model.test.mjs`
- Modify: `Tools/IslandMeshGen/web/view_model.mjs`

- [ ] **Step 1: Add a compact final bake quality control**

Place a select control near the topbar metrics. It controls only final bake quality.

- [ ] **Step 2: Fetch profiles**

Load `/api/bake-profiles`, default to `production`, and fall back to hardcoded profiles if the endpoint is unavailable.

- [ ] **Step 3: Generate with quality**

Call `/api/generate/${currentBiome}?quality=${selectedBakeQuality}` and show quality in output status.

- [ ] **Step 4: Keep preview fast**

Do not change `/api/preview/:biome` behavior in this slice.

### Task 6: Verify

**Files:**
- No new files.

- [ ] **Step 1: Run Node tests**

```powershell
& "C:\Users\zzg\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe" --test ".\Tools\IslandMeshGen\web\server_utils.test.mjs" ".\Tools\IslandMeshGen\web\view_model.test.mjs"
```

- [ ] **Step 2: Run Python tests**

```powershell
& "C:\Users\zzg\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe" -m unittest discover -s "Tools\IslandMeshGen\tests"
```

- [ ] **Step 3: Run JS syntax checks**

```powershell
& "C:\Users\zzg\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe" --check "Tools\IslandMeshGen\web\server.mjs"
& "C:\Users\zzg\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe" --check "Tools\IslandMeshGen\web\server_utils.mjs"
& "C:\Users\zzg\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe" --check "Tools\IslandMeshGen\web\view_model.mjs"
& "C:\Users\zzg\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe" --check "Tools\IslandMeshGen\web\app.js"
```

- [ ] **Step 4: Verify local API**

Call `/api/bake-profiles` and a production generate/preview path if the server is running.

