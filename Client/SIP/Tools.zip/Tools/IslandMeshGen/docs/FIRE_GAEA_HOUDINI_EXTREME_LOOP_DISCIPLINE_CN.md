# Fire Gaea/Houdini Extreme Loop Discipline

Date: 2026-07-07

这份文档只回答一个问题：什么时候 Fire 白膜可以暂时停手，什么时候必须继续自回归。

结论很苛刻：不是 quality report 绿了就停，也不是红色材质少了就停。只有当 200m hero 尺度下，纯灰白白膜在 8 个角度里都能让人相信它是被火山、重力、冷却、崩塌和沉积共同塑造出来的地貌，才允许进入 Meshy/PBR 正式上皮阶段。

## 核心心智

Fire 的目标不是“平滑”，而是“岁月痕迹”。毛刺要磨掉，地貌因果不能磨掉。

Gaea/Houdini 的可信感来自多尺度过程：

- 大形：volcano cone、crater rim、breach wall、terminal fan、underside cliffs。
- 中形：lava channels、side overflow tongues、black-rock levees、cooling islands、talus shelves。
- 小形：cooling crust breaks、weathered ribs、fan-edge scallops、fracture lips。
- 方向性：熔岩沿低势能下泄，冷却壳从边缘侵入，崩塌发生在高坡与坡脚。
- 语义一致性：热流低槽是 `M_ElementCrack`，冷却壳/崖壁是 `M_CliffRock`，路径和 crater loop 不能被过程层吃掉。

## 当前张力

Fire 已经越过“程序噪声 + 径向功能块”的早期阶段，但还没有到“极其接近 Gaea/Houdini”。

已经成立的部分：

- 火山锥、crater loop、熔岩主槽、侧向溢流舌、黑岩 levee、终端冷却指、冷却岛、陡坡红帘切割都有了。
- `M_ElementCrack` 开始具备 Meshy 可读的语义区域，而不是单纯红色装饰。
- Hero 指标稳定在较健康区间，路线和薄边风险没有明显回退。

仍然拖后腿的部分：

- yaw 225 / yaw 270 仍可能读成大块红色熔岩帘。
- 外沿 terminal fan 的扇缘破碎还不够像真实冷却壳崩裂。
- 中央墙和外沿局部仍有少量规则柱面感。
- 材质已经很会说话，但几何大形还要更强。

## 禁区

以下做法短期看会“变好”，长期会把系统带歪：

- 不允许只靠材质层大面积减少红色。
- 不允许用全局 smoothing 抹平 crater、lava channel、cooling shell、levee。
- 不允许新增第 6 个材质槽。
- 不允许把 `M_ElementCrack` 切成 tiny components。
- 不允许让 Meshy 替我们修几何，Meshy 只能奖励已经足够好的白膜。

Fire 材质合同固定为：

- `M_AshPlateau`
- `M_PathDirt`
- `M_CliffRock`
- `M_UndersideRock`
- `M_ElementCrack`

## 本轮工程纪律

这一轮优先修“外沿终端扇冷却破碎”和 “Meshy red region compactness” 的冲突。

正确方向：

- 黑岩冷却切口必须从已有 cooling finger、levee、cooling island、steep cooling wall 这些结构生长出来。
- 它可以咬入热流边缘，但不能切断主流脊。
- 它必须在 heightfield 上形成可见抬壳或崩裂，而不是只在 material 层涂黑。
- 每次削红都必须同时检查 `M_ElementCrack` 最大连通块与 tiny components。

错误方向：

- 直接在外沿开一排等距黑口。
- 把 R0.94+ 全部切得过碎。
- 为了通过外沿 scallop 测试牺牲 cooling finger、side tongue、compactness。

## 停手线

Fire 进入“可以送 Meshy 正式 PBR”的条件：

1. 8-angle contact sheet 中没有连续大红板和高坡红帘。
2. yaw 225 / yaw 270 至少读成“冷却壳包裹的熔岩扇”，而不是“红色程序材质幕布”。
3. 纯灰白模式仍能读出火山口、破口、熔岩槽、冷却岛、扇缘、坡脚沉积和底部崖壁。
4. `M_ElementCrack` 无 tiny components，主热流仍连通。
5. route、crater loop、PCG 区、manifest、quality_report、OBJ/GLB 导出都不回退。
6. Web preview 和 Canvas/WebGL inspect 在 hero 质量下能稳定查看，不靠 UE 材质二次补救。

## 下一步循环

1. 复现当前红灯：外沿 scallop 不足和 `M_ElementCrack` tiny components。
2. 定位 tiny components 的来源，是 outer scallop 本身太碎，还是 material override 切断主流。
3. 用最小 TDD 修复：保留 heightfield 外沿破碎，但让材质输出必须有冷却邻域支撑。
4. 跑 targeted Fire tests。
5. 跑全量 Python tests、Web Node tests、syntax compile。
6. 重新 hero bake。
7. 输出 preview、diagnostics、8-angle contact sheet。
8. 自评距离 Gaea/Houdini：如果还像程序生成器，继续下一轮。

这份文档的精神很简单：不要追求“干净”，追求“可信”。Gaea 味不是没有尖刺，而是每一处尖刺、断裂、磨损和沉积都像有原因。

## 2026-07-07 Implementation Record

本轮实际推进了两件事。

第一，新增 Fire material refinement cache。基础材质判定仍然来自地貌过程，但 Fire hero 会在第一次查询材质时构建全局 material cache，并把小于 8 cell 的 `M_ElementCrack` tiny components 合并回 `M_CliffRock`。这解决的是 Meshy/PBR 入口最怕的“红色语义碎屑”问题。注意它不是材质偷懒减红，而是 region topology cleanup：主热流仍然连通，5-slot 合同不变。

第二，新增 side lava tongue cooling ribs 的 heightfield 过程。它只在侧向熔岩舌肩部产生几何抬壳，不再参与材质分区，避免破坏 `M_ElementCrack` 的主流语义。这个过程的定位是灰模上的岁月痕迹：宽熔岩舌不再只是低槽幕布，而是在中段有轻微冷却硬壳/皱褶。测试也随之改为验证几何 rib，而不是强迫材质红黑碎切。

本轮新增或调整的验收心智：

- `M_ElementCrack` compactness 是 Meshy 前置合同，不允许 tiny red components。
- outer fan scallop 不再奖励红黑高频交替，而是检查热核、冷却壳、scallop 支撑和几何抬升。
- side tongue cooling ribs 只作为白膜几何痕迹存在，不切材质槽，避免把 Meshy 语义弄碎。

最新验证结果：

- Python unittest discover：140 tests OK。
- Web Node tests：101 pass。
- Syntax compile：5 files OK。
- Hero bake：Route 94% / detail risk 8% / edge risk 4% / radial risk 5%。

当前视觉判断仍然不能宣布“极其接近 Gaea/Houdini”。进步点是分区更稳、红区更紧凑、灰模侧舌多了一点硬壳节奏；主要差距仍在大形自然性：central wall 的少量规则柱面感、yaw 000/045/315 前景熔岩体量偏厚、底部和外墙还需要更强的非径向崩塌事件。
