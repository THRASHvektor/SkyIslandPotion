# Fire Gaea/Houdini Visual Convergence Loop CN

Date: 2026-07-07

这份心智文档只服务一件事：Fire 白膜什么时候可以暂时停手，什么时候必须继续磨。答案不是“指标绿了就停”，而是“纯灰/白模在 200m hero 尺度、多角度观察时，已经让人相信它是被火山、重力、冷却、崩塌和沉积共同塑造出来的地貌”。

## 当前判断

Fire 已经从“程序噪声 + 径向功能块”推进到“有火山锥、环路、熔岩主槽、侧向溢流、黑岩肩、终端冷却指、崖壁和底部破碎带”的阶段。现在真正拖后腿的不是细节数量，而是少数视角里仍然能看见程序生成器的痕迹：

- 终端熔岩扇在 yaw 225 / yaw 270 一类角度里仍可能读成大红色板块；
- 中央和外圈黑岩墙已经打散了长竖柱，但仍有少量“极坐标墙面”的味道；
- `M_ElementCrack` 有了语义，但局部还需要更像冷却历史，而不是纯红色材质区域；
- Meshy/PBR 只能奖励这些几何因果，不能替我们修正它们。

## 停手线

Fire 进入“可以交给 Meshy 做一次正式 PBR”的门槛：

1. 8 角度 contact sheet 里，红色熔岩不再出现连续的大板片感。
2. 终端熔岩扇必须同时具备主流连通、黑岩冷却指、侧向溢流舌、抬高 levee。
3. 内壁和外壁不能出现长距离竖直机器齿，强边界必须被风化、坍塌和斜向裂隙打断。
4. 纯灰/白模关闭材质后，仍能读出火山口、崖壁、沉积扇、流槽、坡脚碎石。
5. 五材质合同保持不变：`M_AshPlateau`、`M_PathDirt`、`M_CliffRock`、`M_UndersideRock`、`M_ElementCrack`。
6. 路线、crater loop、PCG 区、manifest、quality_report、field、OBJ 导出合同全部保留。

## 下一轮主攻

不要重复“宽切缝减少红色”的失败尝试。那种做法会让 `M_ElementCrack` 变成碎片，破坏 Meshy 分区和侧舌/冷却指语义。下一轮应该做“连通性保护的冷却侵入”：

- 只在终端扇 R0.76-R0.92、非入口 lava channel 附近工作；
- 先检测局部红色大板块，再从已有冷却指、黑岩 levee、冷却壳边缘向内侵入；
- 侵入区域输出 `M_CliffRock`，但不能切断主熔岩脊；
- 高度场上要形成微抬的冷却脊和轻微下切的热流低槽；
- 每一次削红都必须检查 `M_ElementCrack` 仍然没有 tiny components。

## 测试心智

指标不是审美本身，但它必须抓住审美问题：

- Broad slab metric：在每条非入口熔岩通道的终端扇附近扫描 5x7 或 7x7 小窗，限制 `M_ElementCrack` 占比和最长径向连续红 run。
- Connectivity guard：新增冷却侵入后，`M_ElementCrack` 最大连通块仍然足够大，且不存在小于 8 cell 的孤立红碎片。
- Existing contract guard：侧向舌、黑岩 levee、冷却指、inner wall column breaker、route health 都不能回退。
- Visual evidence：每个 meaningful loop 后刷新 HERO bake、OBJ preview、diagnostics 和 8-angle contact sheet。

## 方向感

Gaea/Houdini 的味道来自“地貌因果”，不是来自把噪声磨平。Fire 的因果链应该是：

volcano cone -> crater rim -> breached wall -> lava follows low potential -> side overflow tongues -> black-rock levees -> terminal cooling fingers -> ash/talus deposition -> broken underside cliffs。

任何新逻辑如果不能插进这条因果链，就不要加。任何 smoothing 如果让这条链更难读，就不要做。

## 失败经验记录

上一轮尝试过用 broad seam cut 直接把红色板块切开，短期能降低局部红色占比，但会破坏三个核心合同：

- 侧向溢流舌的 `M_ElementCrack` 语义会被切碎；
- 终端冷却指不再像从黑岩壳侵入，而像任意贴了一条线；
- Meshy 需要的 compact region 会退化成很多小红碎片。

所以本轮不再做任意切缝。我们只允许“从已有冷却结构生长出来”的黑岩侵入，并且每次侵入都必须保护主流连通。

## 本轮循环

1. 先写 RED：捕捉终端红色大板块。
2. 确认 RED 真的失败在当前 Fire hero。
3. 做最小实现：连通性保护的 cooling intrusion，而不是全局重写 lava material。
4. 跑 targeted fire tests。
5. 跑全量 Python + Web Node + syntax verification。
6. 重新 bake hero，输出 preview/diagnostics/contact sheet。
7. 如果 8 角度仍有明显板块感，继续下一轮，不宣布完成。

## 2026-07-07 实施记录：红板、红幕和内壁竖柱

本轮新增三个验收信号：

- `test_fire_demo_hero_terminal_lava_fans_do_not_form_broad_red_slabs`
- `test_fire_demo_hero_terminal_high_slope_lava_curtains_are_cut_by_rock`
- 收紧 `test_fire_demo_hero_inner_wall_breaks_long_vertical_machine_columns`

### 终端红板

初始 RED 抓到终端扇局部 5x7 小窗仍有接近整片红色的问题。最终没有采用“任意切缝”，而是让已经存在的 cooling finger 在和 side tongue 边缘重叠时获得更高优先级：如果冷却指强于侧舌边缘，就输出 `M_CliffRock`。这让红色板块被已有冷却结构侵入，而不是被凭空切碎。

关键原则：红色主流仍然要连通，side tongue 核心仍然要红，黑岩只吃掉冷却边缘。

### 高坡红幕

第二个问题是 8 角度图里仍有高坡红色幕布。这里的坑是：很多红色不是 lava 条件给的，而是 `ravine` 兜底刷回了 `M_ElementCrack`。本轮加入 `fire_lava_steep_cooling_wall`，只在非入口 lava channel 附近、非 side tongue、高坡、talus 明显的终端区域生效，并且让它覆盖 ravine 兜底。

失败经验：一开始让高坡冷却墙覆盖 side tongue，立刻打碎了 `M_ElementCrack` compact region，并让 side tongue / cooling finger 合同回退。最终规则必须是“非侧舌红幕可黑，侧舌核心不可黑”。

### 内壁竖柱

上一轮已经把最坏竖向 run 从 9 压到 4，但 persistent strong boundary 仍偏多。本轮加了 batched column breaker：先收集相邻边界的风化目标，再统一应用，避免边界顺序写入互相覆盖。尝试过额外 ring-cluster 风化，但它把正面 breach 的墙体落差 p50 从 300cm 以上吃到 290cm 左右，说明过度平滑会破坏火山口体积感，已经撤回。

当前更合理的判断是：允许局部短 run=4，但 persistent boundary 必须低于 4。换句话说，短促裂痕可以存在，长距离机器柱不能存在。

## 当前差距

这一轮让 Fire 更稳，但还没有到“极其接近 Gaea/Houdini”。contact sheet 里仍能看到：

- yaw 225 / yaw 270 的红色体量仍偏大；
- 中央火山壁的宏观剪影有进步，但还可以更像自然崩塌，而不是规则切削；
- 黑岩、灰烬、熔岩之间的材质边界已经更有因果，但几何大形仍要继续加强。

下一轮不要再优先改材质判定，而应该回到 heightfield 大形：让终端熔岩扇有更明显的黑岩岛、分叉冷却脊、扇缘沉积破碎，而不是只在 material 层减少红色。

## 2026-07-07 追加实施记录：终端冷却岛必须有高度因果

上一轮解决了部分红板/红幕，但仍偏“材质切换”。这一轮把测试目标推进到 heightfield 层：

```text
test_fire_demo_hero_terminal_lava_fans_have_raised_cooling_islands
```

这个测试不只看 `M_CliffRock` 是否出现，而是要求每条非入口熔岩通道在终端扇 R0.79-R0.93 范围内出现至少 3 个黑岩冷却岛/脊，并且这些黑岩点要比邻近红色热流高出可见高度。也就是说，它必须是“冷却壳/黑岩岛抬起来”，不是把红色面随便涂成黑色。

实现方式：

- 新增 `_fire_lava_cooling_island_strength`，在非入口 lava channel 终端扇生成更宽的黑岩冷却岛信号；
- 新增 `_shape_fire_lava_cooling_islands`，在 heightfield 阶段抬高这些冷却岛，让它们高于邻近红色低槽；
- 材质层复用同一信号输出 `M_CliffRock`，但阈值收紧到 `0.42`，避免把 cooling finger 横截面吃成整片黑；
- 保护 side tongue 核心：如果侧舌信号很强，冷却岛不能把它抢成黑岩。

本轮也验证了一个重要边界：冷却岛不能过强。第一次 material 阈值过低时，`test_fire_demo_hero_terminal_lava_fans_have_cooling_finger_breaks` 回退，说明横截面红/黑交错被黑岩吞掉了。最终策略是让 heightfield 岛存在，但材质输出更克制，保留红色主流和 cooling finger 的节奏。

当前视觉判断：

- 终端扇内部的黑岩几何抓手增加了；
- HERO 质量指标保持稳定；
- 8 角度图里仍有较大红色体量，说明下一轮还要继续从“大形分叉、扇缘破碎、红色体量切分”推进，而不是停在这个级别。
