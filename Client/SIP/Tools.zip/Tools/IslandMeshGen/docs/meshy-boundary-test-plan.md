# Meshy Boundary Test Plan

Date: 2026-07-04

Scope: `Tools/IslandMeshGen` only. This plan is for Agent B's Meshy capability-boundary probe. It intentionally does not modify `island_mesh_generator.py`, WebGL/editor infrastructure, Unreal C++, collision, PCG, or local terrain-detail algorithms.

## Goal

Build a small, reproducible Sprint 0 test harness that measures what Meshy actually preserves when it receives our semantic terrain mesh.

The test is not "does Meshy make a pretty island?" The test is:

1. Does Retexture preserve 4-5 material slots / regions?
2. Are colored semantic masks more controllable than ordinary material slots?
3. Does Remesh preserve scale, pivot/origin, and material assignment, and does it shrink the silhouette?
4. Is GLB actually better than OBJ+MTL for this workflow?
5. Should Meshy output be limited to visible skin while the original semantic mesh remains collision / PCG proxy?

## Non-Goals

- No Meshy API call by default.
- No high-cost remote generation without explicit user approval.
- No new third-party dependencies.
- No GLB exporter implementation in this slice.
- No terrain algorithm edits.
- No web editor edits.
- No Unreal import automation.

## Current Local Findings

The current repo already has local artifacts suitable for a dry-run boundary fixture:

- `Tools/IslandMeshGen/output/SM_ProcIsland_Fire_VolcanoLayout_200m.obj`
- `Tools/IslandMeshGen/output/SM_ProcIsland_Fire_VolcanoLayout_200m.manifest.json`
- `Tools/IslandMeshGen/output/SM_ProcIsland_Fire_VolcanoLayout_200m.field.json`
- `Tools/IslandMeshGen/output/SM_ProcIsland_Fire_VolcanoLayout_200m.quality_report.json`

The existing fire artifact has five semantic material slots in the manifest:

- `M_TopGrass`
- `M_PathDirt`
- `M_CliffRock`
- `M_UndersideRock`
- `M_ElementCrack`

There is an existing FBX result artifact under `Tools/IslandMeshGen/output/20260630155519_a3a93e16.fbx`, plus a `.fbm` texture folder. That proves FBX assets can exist in the output directory, but it is not a local IslandMeshGen GLB exporter.

No local GLB/GLTF exporter was observed in the current `Tools/IslandMeshGen` scripts. Treat GLB as a test gap for now: export/convert manually through Blender/Unreal later, or add a dedicated exporter in a separate task if the boundary test proves GLB is worth formalizing.

## Fixture

Use:

```powershell
node Tools\IslandMeshGen\meshy_boundary_fixture.mjs
```

Default behavior:

- Reads the existing semantic OBJ / manifest / field / quality report.
- Parses source OBJ vertices, faces, material usage, bbox, and max XY radius.
- Writes a semantic-mask MTL.
- Writes draft Meshy payload JSON for:
  - `retexture-material-slots`
  - `retexture-colored-mask`
  - `remesh-visible-skin`
- Writes prompt text files.
- Writes a manual checklist.
- Does not call the network.

Default output directory:

```text
Tools/IslandMeshGen/output/meshy-boundary-fixture/
```

Generated files:

- `baseline.json`
- `meshy_semantic_mask.mtl`
- `retexture-material-slots.payload.json`
- `retexture-material-slots.prompt.txt`
- `retexture-colored-mask.payload.json`
- `retexture-colored-mask.prompt.txt`
- `remesh-visible-skin.payload.json`
- `remesh-visible-skin.prompt.txt`
- `manual-checklist.md`

Optional: write an OBJ copy that references the semantic-mask MTL:

```powershell
node Tools\IslandMeshGen\meshy_boundary_fixture.mjs --write-masked-obj
```

This produces:

```text
SM_ProcIsland_Fire_VolcanoLayout_200m.semantic_mask.obj
```

That file is useful for OBJ+MTL upload tests, but it duplicates geometry, so the default command does not create it.

## Local Artifact Generation Check

If Python is available, regenerate the test asset from the existing layout exporter:

```powershell
py -3 Tools\IslandMeshGen\export_layout.py `
  --layout Tools\IslandMeshGen\layouts\fire_volcano_demo.json `
  --output Tools\IslandMeshGen\output\SM_ProcIsland_Fire_VolcanoLayout_200m.obj `
  --manifest Tools\IslandMeshGen\output\SM_ProcIsland_Fire_VolcanoLayout_200m.manifest.json `
  --field-json Tools\IslandMeshGen\output\SM_ProcIsland_Fire_VolcanoLayout_200m.field.json `
  --quality hero
```

Quality report generation currently appears to be owned by the web/server path, not `export_layout.py`. If a fresh quality report is required, use the web final-generate flow or the existing report already checked into `output/` for Sprint 0 dry-run prep.

In this agent environment, `py`, `python`, and the project-documented `C:\Users\zzg\AppData\Local\Programs\Python\Python311\python.exe` were not available. Therefore the fixture was validated against existing artifacts instead of regenerating them.

## Sprint 0 Test Matrix

| Test | Input | Meshy Operation | Hypothesis | Evidence To Collect |
| --- | --- | --- | --- | --- |
| R1 | Source mesh with 5 named regions | Retexture | 4-5 material slots may remain visually distinct, but names may not be addressable | returned material/texture count, visual region screenshots, lava bleed notes |
| R2 | Source mesh plus semantic mask colors | Retexture | Colored masks may steer regions better than names, but Meshy may preserve colors as final albedo | side-by-side R1/R2 screenshots, whether flat mask colors remain, region bleed notes |
| M1 | Source semantic mesh duplicate | Remesh | Scale/pivot may roughly survive; UVs/topology may rebuild; silhouette may shrink | bbox size ratio, origin shift, material assignment count, max XY radius ratio |
| F1 | OBJ+MTL vs GLB/FBX | Retexture + Remesh | GLB/FBX should preserve material info better than bare OBJ, but this must be measured | upload success, material preservation, returned format, pipeline friction |
| P1 | Best Meshy result | Local import / DCC inspect | Meshy result is suitable as visible skin only | decision note: original semantic mesh remains collision/PCG proxy |

## Acceptance Thresholds

### Retexture: Material Slots / Regions

Pass:

- Lava/path/cliff/top/underside are visually distinct.
- Lava emissive stays mostly in `M_ElementCrack`.
- Path remains readable as path.
- Cliff reads as basalt/strata.
- No baked lighting.

Warn:

- Material slot names are not preserved, but visual regions are usable as a reference.
- Output is one baked texture set, but the visual skin is still useful.

Fail:

- Lava bleeds broadly into paths or cliffs.
- Path/cliff/top collapse into one generic rock look.
- Flat mask colors remain as final albedo in the colored-mask test.
- Output cannot be mapped back to the five semantic regions even manually.

### Remesh: Scale / Pivot / Silhouette

Pass:

- Bbox X/Y/Z ratio is within roughly 1-2% of source.
- Origin/pivot shift is negligible for UE placement.
- Material regions are still usable.
- Max XY radius ratio is at least `0.985`.

Warn:

- Scale is close, but material names or UVs are rebuilt.
- Small silhouette smoothing exists but is acceptable for visible skin.

Fail:

- Max XY radius ratio below `0.985`, suggesting visible shrink.
- Pivot/origin moves enough to break overlay with source semantic mesh.
- Material assignments collapse into one region.
- Crater, path, or lava channels are rounded away.

## After Meshy Returns

If Meshy returns OBJ, compare the result locally:

```powershell
node Tools\IslandMeshGen\meshy_boundary_fixture.mjs --compare-result <downloaded-result.obj>
```

The fixture writes:

```text
Tools/IslandMeshGen/output/meshy-boundary-fixture/compare-result.json
```

Check:

- `bboxSizeRatio`
- `centerDelta`
- `maxXYRadiusRatio`
- `possibleSilhouetteShrink`
- `missingMaterialsFromResult`
- `newMaterialsInResult`

If Meshy returns GLB/FBX, inspect in Blender or Unreal because this fixture deliberately avoids third-party parsers. Record the same facts manually in the Sprint 0 decision table.

## Explicit API Call Guard

The fixture can make a generic guarded POST, but only when all of these are true:

- `--call-api` is present.
- `--job` names exactly one job.
- `MESHY_API_KEY` exists.
- `MESHY_ENDPOINT` or `--endpoint` exists.
- `--model-url` is provided and is not a placeholder.

Example:

```powershell
$env:MESHY_API_KEY = "<your key>"
$env:MESHY_ENDPOINT = "<current Meshy endpoint from official docs>"
node Tools\IslandMeshGen\meshy_boundary_fixture.mjs `
  --job retexture-colored-mask `
  --model-url "<uploaded model URL>" `
  --call-api
```

The script never prints the API key.

This agent did not perform a real Meshy call because `MESHY_API_KEY` is missing and because Sprint 0 should first produce local payloads/checklists before spending a remote generation.

## Decision Record Template

Copy this table after each Meshy run:

| Run | Input Format | Operation | Regions Preserved? | Slot Names Preserved? | PBR Maps Returned | Emissive Isolated? | Bbox Ratio | Pivot Shift | Silhouette Shrink? | Use Decision |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| R1 | OBJ+MTL | Retexture material slots |  |  |  |  | n/a | n/a | n/a |  |
| R2 | OBJ+MTL | Retexture colored mask |  |  |  |  | n/a | n/a | n/a |  |
| M1 | OBJ+MTL | Remesh visible skin |  |  | n/a | n/a |  |  |  |  |
| F1 | GLB/FBX | Retexture/Remesh |  |  |  |  |  |  |  |  |

Final Sprint 0 rule:

```text
If Meshy cannot preserve semantics reliably, use it for donor assets or visible skins only.
The original IslandMeshGen semantic mesh remains collision, PCG, walkability, and gameplay proxy.
```
