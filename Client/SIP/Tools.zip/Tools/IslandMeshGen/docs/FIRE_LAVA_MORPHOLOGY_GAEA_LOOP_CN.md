# Fire Lava Morphology Gaea Loop CN

Date: 2026-07-06

这份心智文档记录下一轮 Fire 白膜自回归的重点：不再只把熔岩通道做成一条红色可读区域，而是让它变成真正被重力、冷却、溢流和黑岩肩塑形过的火山地貌。

## 核心判断

火山岛继续逼近 Gaea/Houdini 时，当前最大的剩余张力不是“有没有熔岩”，而是“熔岩是否像流体曾经走过这里”。如果 `M_ElementCrack` 只是沿极坐标一路铺到边缘，它在 preview 里会像红色材质帘子；即使 Meshy 后续给它上 PBR，也只是把这个问题渲染得更华丽。

真正的火山熔岩通道应该有这些几何信号：

- 中心低槽：热流沿低势能路径走，不是硬直射线。
- 黑岩肩：两侧被冷却壳和火山岩顶起，局部高于红色中心。
- 侧向溢流舌：流体不会永远待在中心线，会在中下游发生不对称外溢。
- 冷却指状壳：红色区域应被黑色冷却壳切开，且切开处有高度唇边。
- 终端扇：靠近外缘时有沉积/铺展，不是突然断掉或无限下挂。

所以本轮不追求“把红色变少”这么粗暴的目标。红色熔岩仍要连通、可读、能给 Meshy 明确语义；但它必须被黑岩肩、冷却壳和侧向流舌组织起来。

## 本轮工程目标

在不改变五材质合同的前提下：

```text
M_AshPlateau
M_PathDirt
M_CliffRock
M_UndersideRock
M_ElementCrack
```

新增 Fire-only lava morphology 过程层，让非入口熔岩通道在 R0.70-R0.92 区间出现更多可测的侧向形态：

- 至少 3 条非入口 lava channel 有中下游侧向溢流舌；
- 溢流舌必须与主通道保持语义连通，不能变成零散红点；
- 溢流舌的低槽旁边要有黑岩/冷却肩，不能只是扩大 `lava_mask`；
- 中心熔岩最长连续红 run 仍受旧测试约束，不能回到红色大帘子；
- route / crater loop / terminal fan / Meshy compact material region 全部保留。

## 失败测试应该抓什么

新增测试不应该只看材质数量，而要看“形态因果”：

```text
for each non-entry lava channel:
  sample R0.70-R0.92
  find lateral cells near the channel where lava_flow leaves centerline
  require asymmetric side tongue count
  compare tongue height against local black-rock shoulder
  require shoulder higher than tongue floor by a visible amount
```

这个测试的含义是：只要某个角区还是“中心红条 + 两边平墙”，它就不应该通过。只有当火山流动有不对称外溢、两侧冷却肩、中心低槽时，才算继续向 Gaea/Houdini 靠近。

## 允许的实现方式

优先在 heightfield 阶段加 Fire-only 过程层，而不是在 mesh extraction 或材质层补救：

- 在 `_build_semantic_terrain_field` 的 Fire process stack 中，放在低势能 lava carve 和 cooling crust sill 之后；
- 使用 lava channel angle、radial band、确定性噪声和路径/环路 guard；
- 对侧向 tongue 区域做轻微下切，让它像外溢低槽；
- 对 tongue 外肩做抬高和粗化，让黑岩/冷却壳有几何抓手；
- 不新增语义 sidecar，不新增材质 slot，不修改 Meshy 合同。

## 停手线

这一轮不以“测试过了”作为审美终点。测试只是防回归。真正的停手线是刷新 HERO 后，8 角度 contact sheet 里：

- 红色不再像一整张熔岩帘；
- 中下游能看出不对称溢流和冷却壳；
- 黑岩肩与红色低槽互相解释；
- 侧背面仍保持上一轮的崩塌墙体和破碎底帽；
- 纯灰/法线视角下仍能读出火山地貌因果。

一句话：熔岩不能只是“红”。它必须像有温度、有重量、有冷却历史的东西。

## 2026-07-06 实施记录：侧向熔岩舌必须有黑岩肩

本轮新增回归：

```text
test_fire_demo_hero_lava_side_tongues_have_black_rock_levees
```

初始 RED：

```text
3 条非入口通道中，0 条能稳定达到“至少 3 个侧舌 + 黑岩肩”采样点
```

实施方向：

- 新增 Fire-only `_fire_lava_side_overflow_strengths`，把中下游侧向流舌和外侧 levee 分成两个可复用形态信号；
- 新增 `_shape_fire_lava_side_overflow_tongues`，在 heightfield 阶段下切侧舌、抬高外侧黑岩肩；
- 在材质分配中让 side tongue 输出 `M_ElementCrack`，让外侧 levee 输出 `M_CliffRock`；
- 修正一个孤立红色小岛：levee 边缘的高 lava cell 如果没有 tongue 连通，就归入黑岩肩，保持 Meshy 分区紧凑。

当前测量：

```text
side_tongues_by_channel: [9, 8, 3]
levee_lift_min: 224.6cm
levee_lift_p20: about 314.0cm
qualified samples: 20
targeted lava/material regression suite: 11 tests OK
```

这轮把 Fire 的剩余问题往正确方向推进了一步：红色熔岩不再只靠中心线和材质断带表达，而开始有“外溢低槽被冷却黑岩肩夹住”的几何因果。下一轮视觉上仍要重点看 8 角度 contact sheet：如果红色区域在某些角度仍像宽帘子，就继续做 cooled crust fingers 和 terminal fan 的非均匀铺展。

## 2026-07-06 追加实施：终端熔岩扇必须有冷却指

侧向熔岩舌解决了“红条两侧没有黑岩肩”的问题，但 8 角度图仍能看到局部终端扇像一整片红色 molten sheet。第二个小 loop 的目标是：在不切碎 `M_ElementCrack` 主体连通性的前提下，让红色扇面内部出现可读的黑岩冷却指。

新增回归：

```text
test_fire_demo_hero_terminal_lava_fans_have_cooling_finger_breaks
```

初始 RED：

```text
3 条非入口通道中，0 条能稳定达到“至少 3 个红/黑交错横截面”
```

实施方向：

- 新增 `_fire_lava_cooling_finger_strength`，在终端扇的横截面里生成内部黑岩冷却指；
- 新增 `_shape_fire_lava_cooling_fingers`，在 heightfield 阶段把这些冷却指轻微抬成几何脊；
- 材质层把 cooling finger 输出为 `M_CliffRock`，但保留中心 hot bridge，避免把熔岩主流切断；
- 增加极窄的 cooling chip 处理：被冷却指夹出的单点红碎片归入黑岩，保持 Meshy 分区紧凑。

当前测量：

```text
side_tongues_by_channel: [9, 8, 3]
cooling_finger_sections_by_channel: [5, 3, 3]
levee_lift_min: 234.1cm
targeted lava/material/talus regression suite: 13 tests OK
```

这轮的关键不是“红色更少”，而是“红色有了冷却历史”。如果后续 Meshy 做 PBR，`M_ElementCrack` 应该更像热流，`M_CliffRock` 应该更像冷却壳和黑曜岩，而不是随机插入的材质碎块。
