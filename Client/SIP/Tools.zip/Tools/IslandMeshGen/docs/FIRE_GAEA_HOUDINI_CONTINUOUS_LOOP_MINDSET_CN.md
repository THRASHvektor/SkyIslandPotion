# Fire Gaea/Houdini 连续逼近心智

Date: 2026-07-07

这份文档是给后续每一轮 Fire 白膜迭代看的。目标不是让指标漂亮，也不是让 Meshy/PBR 遮丑，而是让纯灰白 clay 在 200m 尺度下已经能读成一个可信的火山地貌。只有白膜本身站住，Meshy 才能锦上添花。

## 停手标准

Fire 暂时停手的标准必须同时满足：

- 8 个 clay 角度都能读出火山口、破口、外流、冷却岩壳、崩塌裙边和坡脚沉积。
- 8 个 material 角度没有大红板、红色厚毯、极坐标柱面和随机红噪点。
- `M_ElementCrack` 仍是少量、紧凑、连续的热核区域，而不是铺满外圈的红皮。
- `M_CliffRock` 像冷却岩壳和崩塌岩壁，不像简单替换掉的材质块。
- route、crater loop、lava channels、terminal fans、field、manifest、quality_report、OBJ/GLB 导出全部稳定。

任意一条没达到，就只能说“更近了”，不能说“极近 Gaea/Houdini”。

## 过程优先级

每一轮都按这个顺序推进：

1. 先看 clay，再看 material。材质只能解释几何，不能拯救几何。
2. 把视觉病灶翻译成一个 RED test。测试必须描述地貌问题，不是描述实现细节。
3. 在 heightfield/process layer 修。材质层只做同一语义过程的输出映射。
4. 跑目标测试，再跑相邻保护测试。
5. hero bake，输出 diagnostics、preview、material 8-angle、clay 8-angle。
6. 诚实写下“进步了什么、还不像什么、下一轮主敌是什么”。

## 当前主敌

截至本轮，Fire 已经明显超过“程序噪声岛”的阶段，但还没到真正 Gaea/Houdini 级别。主要残影有三类：

- crater/upper wall 仍有竖向百叶窗感。前几轮已经切断了最长连续 steep column run，但局部仍会读出极坐标采样的影子。
- 外圈 underside/cliff skirt 仍有局部裙边感。已经加入 per-window collapse bite，但 180/225/270 视角还要继续做非径向崩塌。
- 熔岩外流仍偶尔形成红色厚毯。上一轮 terminal hot core cooling pocket 解决了部分大红核，本轮继续用 mantle cooling slab 切开 flow/ravine 型热毯。

## 本轮悟道：热毯不是熔岩河

本轮新增的红线是：

`test_fire_demo_hero_lava_mantles_are_cut_by_cooling_slabs`

它要求非正面熔岩通道在 0.70-0.96 外圈范围内，任意 61 列视觉窗口里的连续 `M_ElementCrack` 热核长度不能超过 14。初始失败值是 `[20, 16, 7]`，说明至少两个视角仍有大块红色热毯。

关键发现：

- 问题段并不总是 `lava_mask` 高。有些红毯来自 `lava_flow_mask` / ravine / flow accumulation，把外侧裙边染成了热核。
- 如果只按 `lava_mask` 做冷却，切不到这类 flow/ravine 热毯。
- 如果 slab 太宽，会误伤 side tongue 主体，破坏 black rock levee 和 internal cooling ribs。

因此本轮实现了更明确的分工：

- `_fire_lava_mantle_cooling_slab_strength`：只在非正面通道、特定外圈径向带、特定角向 slab 位置产生冷却硬壳强度。
- `_shape_fire_lava_mantle_cooling_slabs`：先把几何抬出冷却岩壳，让 clay 也能看到硬壳切口。
- `material_for_terrain_field_face`：用同一 slab 强度把对应区域输出为 `M_CliffRock`。
- slab 明确避开 `side_tongue` 和 `side_levee` 主体，保证已有的熔岩舌、黑岩堤、内部冷却肋不会被涂没。

本轮 TDD 过程：

- RED：`[20, 16, 7]`，最长红毯 20。
- 初次 GREEN：`[16, 14, 7]`，说明只解决了外圈一部分。
- 补 0.78 与 0.70/0.75 径向带，识别 flow/ravine 型热毯。
- 收窄边界，避开 side tongue 主体，修复保护测试回归。
- 当前目标测试通过，熔岩保护组 8 tests OK。

## 下一轮方向

下一轮不要继续盲目缩红区。优先看 clay：

- 如果 clay 仍像竖向百叶窗，继续做 upper wall 的横向/斜向风化 shelf。
- 如果 material 仍像厚红毯，但 clay 已有冷壳，则继续收紧 `M_ElementCrack` 的 semantic 输出。
- 如果 underside 仍像极坐标裙边，继续给 cliff skirt 做更强的局部崩塌和底部不规则断裂。

最重要的一句话：

> Gaea/Houdini 感不是“平滑”，而是每一个形状都像被某种力量塑造过。

## 追加循环：上墙百叶窗必须被横向岁月切开

看完新一版 8-angle clay 后，主敌从红毯切换到 crater/upper wall 的竖向百叶窗。原先已有的 `upper_wall_radial_blinds` 测试只能证明最长连续 steep-column run 被压短，但画面里仍然会出现很多竖向槽并排的“城堡齿墙”感。

因此新增：

`test_fire_demo_hero_upper_wall_visual_windows_have_crosscut_shelves`

它不再只数单列，而是按 24 列视觉窗口检查：

- 如果一个窗口有 6 行以上的强竖向落差，就认为它有百叶窗风险。
- 这样的窗口必须至少有 2 条横向/阶地 crosscut 行。
- 初始失败值是 4 个坏窗口：`[(120, 8, 1), (144, 10, 0), (168, 9, 1), (192, 8, 0), ...]`。

实现上新增：

- `_settle_fire_upper_wall_visual_crosscut_shelves`
- 只在检测到强竖向槽的视觉窗口内工作。
- 只处理 upper wall 外段，避免误伤 inner wall primary breakline。
- 每个坏窗口补 2-3 条横向风化 shelf，把竖向沟槽切成更像“岁月台阶”的形态。

这轮的重要教训：

- upper-wall crosscut 如果伸进 inner wall，会把已经修好的 primary breakline 再次锁回同一 ring。
- 所以过程层必须有明确地貌分区：inner wall de-lock 和 upper wall crosscut 不是同一个操作。
- 所有 upper-wall 操作之后，还要再跑一次 `_settle_fire_inner_wall_late_breakline_locks` 和 `_restore_fire_front_inner_breach_wall_drop`，作为最终守门。

当前相关验证：

- `upper_wall_visual_windows_have_crosscut_shelves` OK。
- upper/inner 保护组 7 tests OK。
- lava mantle/cooling 保护组 8 tests OK。

## 追加循环：底部三角扇阴影必须被下切断裂打碎

继续看 clay 后，底部/侧壁裙边成为下一处程序味来源。已有测试能证明：

- underside 不是一个单一巨大中心 fan。
- cliff skirt 每个视觉窗口都有 collapse event。
- long smooth triangular fan 的整体最长连续段没有超标。

但画面里 180/225/270 视角仍会出现底部极坐标三角扇阴影。问题不是整体最长 run，而是某些 24 列视觉窗口内部太顺：一个窗口里 22/23 个步长都没有明显下切变化，远看就是连续扇面。

因此新增：

`test_fire_demo_hero_bottom_cap_has_undercut_breaks_in_each_visual_window`

它按 24 列窗口检查 bottom cap profile：

- 每个窗口至少需要 4 个 broken steps。
- broken step 同时考虑底部 cap 的半径变化和高度变化。
- 初始失败值是 4 个弱窗口，说明底部仍有大片连续阴影。

实现策略：

- 不新增材质槽，不新增拓扑环。
- 在 bottom cap / lower underside 顶点生成阶段，为每个视觉窗口加入两处 deterministic undercut notches。
- notch 同时影响 `lower_scale/lower_z` 与 `cap_scale/cap_z`，让底部阴影在 clay 模式也能被打碎。
- cap 半径仍被限制在短中心扇范围内，避免破坏 `bottom_cap_keeps_central_underside_fan_short`。

这轮的核心判断：

> 底部不像 Houdini/Gaea，不是因为不够复杂，而是因为它太连续。真正的悬崖底部应该有局部下切、断裂、咬边和重量变化，而不是从边缘平滑收束到中心点。

当前相关验证：

- `bottom_cap_has_undercut_breaks_in_each_visual_window` OK。
- bottom/skirt 保护组 8 tests OK。

## 追加循环：两层崖裙不能同步成同一排竖向窗帘

继续看 8-angle clay 后，底部不是只有中心三角扇的问题。更隐蔽的程序味来自两层 cliff skirt ledge 在同一角向列同时鼓出或同时塌下。单看每一层都有 collapse event，但两层事件如果垂直对齐，远看仍然会变成一排同步的帘幕肋骨。

因此新增：

`test_fire_demo_hero_cliff_skirt_ledges_shear_instead_of_vertical_sync`

它按 24 列视觉窗口检查两层 skirt profile：

- 只统计两层都出现强半径或高度台阶的列。
- 如果同一窗口里过多强台阶同向同步，就认为这不是多年代崩塌，而是极坐标生成痕迹。
- 初始 RED 看到 `bad_sync_windows = 6`，说明侧壁虽然有缺口，但上下两层的破碎节奏还太一致。

实现策略：

- 第二层 ledge 不再直接复用第一层的角向采样，而是使用 deterministic shear offset。
- 第二层的 collapse transfer、seam、block、event 采样转到偏移后的 `pattern_i`，让它像后一次崩塌沿旧崖壁错位发生。
- 第二层对 `fractured_slump` 的高度贡献改成反相，避免上下两层在同一列同时升降。
- 再加入小幅 `shear_wave`，只作用于第二层的 `local_t`、`ledge_push` 和 `z`，制造横向剪切，而不是随机噪声。

这轮的核心判断：

> Gaea/Houdini 的侧壁不是把同一条裂缝复制两遍，而是不同年代的塌陷互相覆盖、错位、咬合。上下层 ledge 必须有地质时间差。

当前相关验证：

- `cliff_skirt_ledges_shear_instead_of_vertical_sync` OK。
- 下一步必须跑 bottom/skirt 保护组、全量 Python、Node web 测试和 hero bake 后，再用 8-angle clay 判断它是否真的削弱了 180/225/270 视角的帘幕感。

## 追加循环：火山口上墙不能只有横杠，必须有斜向错层

侧壁错位后重新看 8-angle clay，最刺眼的问题回到 crater/upper wall。已有测试能证明最长竖向 run 被压短，也能证明危险窗口里有横向 shelf。但画面仍会在 0/90/135/180/270 视角读出竖向柱槽，因为横向 shelf 太像同一批水平刀口，不能真正打掉极坐标百叶窗。

因此新增：

`test_fire_demo_hero_upper_wall_crosscuts_stagger_diagonally_inside_visual_windows`

它不再只数“有没有 crosscut rows”，而是检查每个 24 列视觉窗口里最强断层所在的 ring 是否沿角向发生错位：

- 只统计每列强到足以形成视觉断层的上墙 drop。
- 如果最强断层 ring 被同一层支配，说明这仍是程序化竖槽。
- 初始 RED 是 `rigid_windows = 4`，坏窗口集中在 144/168/192/216，其中 168/216 的 dominant ring coverage 达到 0.83/0.92。

实现策略：

- 在 `_settle_fire_upper_wall_visual_crosscut_shelves` 后半段加入 diagonal stagger guard。
- 当窗口的最强断层 ring 太集中时，先削弱当前支配 ring 的垂直落差。
- 再按 deterministic stagger pattern 把新的强断层挪到随角向变化的目标 ring，让它读成斜向年代层，而不是同一层复制出的竖槽。
- 最后再补一次 crosscut recovery，保证 diagonal 之后仍满足“危险窗口至少两条横切 shelf”的旧保护测试。

这轮的核心判断：

> 真正像 Gaea/Houdini 的火山口墙，不是横向台阶和竖向裂槽二选一，而是横切、斜切、塌陷年代互相覆盖。墙体必须像被多次事件改写过。

当前相关验证：

- `upper_wall_crosscuts_stagger_diagonally_inside_visual_windows` RED: `rigid_windows = 4`。
- 目标测试 GREEN 后，`upper_wall_visual_windows_have_crosscut_shelves` 曾回归失败，随后用 final crosscut recovery 修回。
- upper/inner/outer wall 保护组 15 tests OK。

## 追加循环：最终守门要切尖刺，不能磨掉地质年代

本轮新问题不是大形方向错，而是几个后期过程层互相覆盖：`secondary_collapse_shelf_readability` 和 `front_ash_toe_angular_curtain` 之后，outer wall 少数角向边界重新出现 coherent polar curtain ribs。全量测试暴露的数值是：

- `test_fire_demo_hero_outer_wall_breaks_coherent_polar_curtain_ribs` 初始失败：`worst_boundary_p80 = 397.0`，阈值 `< 260.0`。
- 直接把 full `_cap_fire_outer_wall_angular_boundaries` 放到最后可以把 p80 压到约 `175`，但会过度磨平，导致 `outer_wall_breaks_have_local_arc_variation` 和 `volcano_wall_has_incomplete_secondary_collapse_shelves` 回归。
- 正确修法不是“最后再全局磨一遍”，而是新增 late spike cap，只处理已经超标的边界和局部 `230+` 的角向断差，保留 `178-230` 区间的正常崩塌台阶。

本轮新增：

- `_cap_fire_outer_wall_late_boundary_spikes`
- 最终调用位置放在所有 late Fire 形态 pass 之后、`slope_mask`/`strata_mask` 派生之前。
- 早期 full cap 保持原样，最终 late cap 只做守门，不重新定义地貌。

同时修复了一个语义张力：

- outer volcano strata shoulders 需要更多 rock slope 读数，否则外肩岩壁不稳。
- non-front ash plateau 不能被 rock slope 读数吞掉，否则灰台地沉积带消失。
- 本轮做法是给 26-28 环的火山外肩补 slope readable mask，同时在 29-32 环给非正面低 talus、非 outer-strata、非 blackrock-talus 的位置恢复 ash deposition pocket。

当前验证：

- 目标互斥组：outer strata / non-front ash 双测试 OK。
- 外墙、灰台、黑岩、二级 shelf、主路径、坡脚高风险组 OK。
- Syntax OK。
- Node web tests：101/101 OK。
- Python discover：168/168 OK。
- Fire hero bake：overall 93%，route 94%，detail risk 10%，edge risk 3%，radial risk 5%。

当前诚实判断：

- 已经比早期程序噪声岛强很多：主火山体积、collapse bay、外墙崩塌、灰台地、黑岩坡脚、裂缝分区都更稳定。
- 但还没到“极其接近 Gaea/Houdini”的停手线。8-angle clay 里 90/135/180/225/270 仍能看到上墙竖向百叶窗和底部极坐标收束阴影；material 里部分侧墙红色仍偏大块热毯。
- 下一轮主敌不是指标，而是 upper wall 的纵向采样残影和 lava/material 的红毯感。要继续把竖向柱槽转译成斜向错层、崩塌肩部、冷却壳和沉积回填。
