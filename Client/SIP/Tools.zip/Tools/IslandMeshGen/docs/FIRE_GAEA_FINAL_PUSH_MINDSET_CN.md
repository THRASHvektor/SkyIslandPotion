# Fire Gaea Final Push Mindset

> Scope: Fire volcano whitebox final-push loop, Meshy-safe material compactness, and the stop gate for "close enough to Gaea/Houdini".

## 一句话

Fire 的终局目标不是继续堆参数，而是让纯灰白 HERO 白膜在 200m 尺度下已经有 Gaea 的地貌因果、Houdini 的过程可控性、以及 Meshy 一次性 PBR 能读懂的材质区块。

## 什么时候才可以停

不能因为某个指标好看就停。Fire 至少要同时过五道门：

1. **远看剪影门**：8 个角度里，火山体、破碎外壁、crater rim、主入口、侧背部黑岩质量都成立；不能有明显极坐标窗帘、圆环墙、数学射线。
2. **中尺度因果门**：熔岩沟、冷却扇、ash deposition、talus apron、basalt shelf、crater loop 都能解释“为什么在那里”；不能只是噪声和 mask 叠图。
3. **小尺度岁月门**：尖刺和硬棱被风化成 chipped strata、slump、沉积、裂隙边；但 crater/lava/path 不能被全局 smoothing 抹掉。
4. **材质语义门**：5 个 Fire material slots 保持稳定，`M_ElementCrack` 不出现 Meshy 会误读的微小孤岛，`M_CliffRock` 承接黑岩肩部和峭壁，`M_AshPlateau` 不吞掉悬崖。
5. **工程回归门**：每一次视觉改进都要有至少一个红灯回归，HERO bake、multi-angle evidence、field diagnostics 都刷新后才算这一轮完成。

当前的心理目标：

- 90% 以前：继续白膜生成器主战场，不把希望押给 Meshy。
- 90-92%：可以挑候选送 Meshy 做 PBR 奖励，但原始灰白模型仍是判断核心。
- 95%：才算“极其接近 Gaea/Houdini”的 demo 级白膜，不再需要大方向重构，只剩局部调参和性能收敛。

## 本轮悟道：材质紧致度也是地貌

Meshy 不读 `field.json`、`manifest.json`、`quality_report.json`。它只能从模型、材质槽、UV/PBR 和 prompt 里悟道。

因此 Fire 的 `M_ElementCrack` 不能只是所有 lava/ravine 阈值点的集合。过小的红色孤岛会让 Meshy 误判：

- 把黑岩肩部贴成零碎发光熔岩；
- 在 PBR 里扩散 emissive；
- 让火山白膜看起来像材质噪点，而不是地貌过程。

正确策略不是盲目删除红色，也不是盲目扩大红色，而是做 **局部熔流补桥**：

```text
主 lava mask
  -> 检查 lava 略低于阈值的窄缝
  -> 要求 lava_flow / flow_accumulation 支持
  -> 要求邻域至少两侧仍属于强熔流
  -> 不碰 path / crater loop
  -> 只在 Fire 高分辨率语义里启用
```

这个策略的美术含义是：如果红色小片其实是被一格冷却壳切断的熔流，那就把语义桥补上；如果它没有过程支持，就应该退回黑岩/灰台地，让 PBR 去表现表面熔痕，而不是另起一个材质岛。

## 不允许牺牲的契约

Fire 的 Meshy-safe material contract 仍然只有 5 个：

- `M_AshPlateau`
- `M_PathDirt`
- `M_CliffRock`
- `M_UndersideRock`
- `M_ElementCrack`

不新增第六槽，不用 sidecar JSON 期待 Meshy 理解语义，不把材质名当 prompt 可精确引用的区域锁。

Gameplay/export 契约也不能动：

- main route 必须保留；
- crater loop 必须保留；
- lava channel core 必须保留；
- terminal fan 不能被红色 curtain 破坏；
- field / manifest / quality_report / OBJ 继续同步导出。

## 下一轮循环优先级

1. **HERO 画面证据**：每次改动后刷新 OBJ preview、field diagnostics、8-angle contact sheet。
2. **复合 Gaea score**：把 radial artifact、over-detail、route health、material compactness、mid-scale relief、generation cost 合在一起，让工具能抓住“像不像 Gaea”的问题。
3. **侧背部 silhouette mass**：继续盯外壁、黑岩肩、背面 crater wall，防止正面好看、背面像规则窗帘。
4. **性能合并**：如果 Fire-only pass 继续增加，就把相邻的材质/局部采样逻辑合并，避免 HERO bake 越来越慢。
5. **Meshy 小样**：只有当灰白 HERO 继续站住，才拿稳定 GLB/OBJ 做 PBR 实验；Meshy 是奖励，不是救场。

## 当前锚点

这轮 material compactness 回归前，`M_ElementCrack` HERO 组件存在两个 tiny islands：

```text
component sizes: [1030, 1022, 641, 186, 134, 71, 62, 35, 17, 4, 2]
tiny < 8: [2, 4]
```

局部熔流补桥后，tiny islands 被消除，同时没有改变 5-slot contract：

```text
component sizes: [1046, 1038, 641, 194, 147, 76, 72, 41, 18]
tiny < 8: []
```

这不是终点，只是 Meshy/PBR 接入前必须补上的一块语义地基。

## 追加悟道：ash plateau 不能惩罚合法 shelf

Fire 的灰褐色 ash plateau 有两类完全不同的起伏：

- **应该沉掉的砂纸噪声**：无路线、无 lava、无 crater loop、无二级塌陷意义，只是在中外环灰台地上产生高频 residual。
- **应该保留的岁月阶地**：crater wall / outer ash apron 上的二级塌陷 shelf、径向沉积阶、黑岩肩部过渡。

这两者在简单 residual 指标里都可能显得“局部不平”，但美术含义相反。正确做法是：

```text
ash deposition audit
  -> 先排除 path / crater loop / lava
  -> 再排除 secondary shelf preservation samples
  -> 对非 shelf ash 噪点做 p90 / p95 约束
  -> 对整体 hotspot 另设宽域回归，防止砂纸面回潮
```

生成侧同样不能用全局 smoothing。当前策略是在 `_settle_fire_non_front_ash_deposition_bands` 中增加：

- 更宽的高分辨率 ash deposition band；
- local median 参与目标高度，减少单点尖刺；
- residual hotspot 对邻域沉积面做受限靠拢；
- final hotspot settle，只处理高 residual、无语义、非 secondary shelf 的 ash 点。

这会让灰台地更像沉积带，同时不牺牲二级塌陷 shelf。Gaea 感的关键就是这种“磨掉随机毛刺，留下有因果的伤痕”。

## 追加悟道：浮岛 underside 拓扑也会暴露数学味

侧背部黑色外壁的“窗帘感”不全是 heightfield 问题。Fire 作为浮岛资产时，`M_UndersideRock` 如果直接从一圈 underside ring 扇到一个中心底点，就会天然出现长三角放射线。哪怕顶面 crater / lava 做得再像 Gaea，侧背图也会突然露出“极坐标建模”的味道。

因此 Fire HERO 的 underside 不能是单底点长扇面。当前策略是 Fire-only：

```text
outer top ring
  -> cliff skirt ring
  -> broken lower underside ring
  -> small bottom cap ring
  -> tiny bottom tip
```

这样做的含义：

- 外侧黑岩仍然保持浮岛垂坠质量；
- 长 `M_UndersideRock` 扇面被拆成更短的分段面；
- 中心底点 fan 只发生在很小的 bottom cap 内，不再从半径 0.3R 以上拉到中心；
- 不新增材质槽，仍然保持 Meshy-safe 5-slot contract。

当前量化锚点：

```text
M_UndersideRock faces: 1152
radial span p50 / p95 / max: 0.205R / 0.395R / 0.418R
central fan outer p50 / p95 / max: 0.070R / 0.093R / 0.103R
```

这轮解决的是“长底部扇面”问题，不等于完全消除侧背部规则感。下一步如果继续啃 side/back，应更多处理外侧 cliff skirt 的竖向节奏和阴影线，而不是只压中心底帽。

## 追加悟道：cliff skirt 不能是一整张长黑岩帘

修掉 underside bottom fan 之后，侧背图仍然会暴露另一种程序味：`M_CliffRock` 从 outer top 直接连到 underside ring 的单段长四边面。它不像 Gaea/Houdini 的崩塌岩壁，更像一圈规则裙边。

这不是 heightfield 能完全解决的问题。正确位置仍然在 mesh extraction 阶段：

```text
outer top ring
  -> broken upper cliff skirt ring
  -> broken lower cliff skirt ring
  -> underside ring
```

每个中间 skirt ring 都带轻微 angular ledge noise / chip noise，让外壁从“长帘”变成更短的火山岩崩塌面。它不改变顶面语义，也不新增材质槽，仍然全部归入 `M_CliffRock`。

当前量化锚点：

```text
M_CliffRock radial span p50 / p95 / max: 0.024R / 0.151R / 0.218R
```

这比单段 skirt 时的长面 p95 明显短，side/back 的黑岩裙边会更接近“分段崩塌岩壁”。但这仍不是终点：下一步应该从“短面”继续走向“非规则阴影节奏”，也就是让 cliff skirt 的明暗和 silhouette 更像岩体块面，而不是只靠同心分段。

## 追加悟道：短面之后还要打断侧背阴影节奏

把 `M_CliffRock` 单段长帘拆成三段之后，只是解决了“面太长”的问题，不等于解决“看起来像一圈程序裙边”的问题。侧背视角真正刺眼的是连续几十个角度柱都在同一套高度/半径节奏里缓慢变化，浏览器 inspect 用 face normals 渲染时会把这种连续节奏放大成竖向黑墙条带。

这轮新增的回归不是再测 face span，而是测 skirt-only 三层柱状 profile：

```text
outer top -> upper skirt -> lower skirt -> underside
  -> 每个 angular column 得到 3 个 M_CliffRock skirt faces
  -> 比较相邻 column 的 height / radial profile delta
  -> 统计 delta 长期低于 0.015R 的最长连续段
```

旧状态下，最长顺滑段大约是：

```text
height longest run < 0.015R: 53 columns
radial longest run < 0.015R: 54 columns
```

这意味着 side/back 至少有四五十个连续角度柱还在读成同一条阴影带。新的 Fire-only mesh extraction 增加了两层 breakup：

- macro block slump：24 个不完全均匀的火山崩塌块面，负责让 cliff skirt 不再只有平滑正弦 ledge；
- narrow fracture seams：十来条窄的侧壁错台柱，负责切断长距离连续明暗带。

更新后的量化锚点：

```text
height longest run < 0.015R: 32 columns
radial longest run < 0.015R: 31 columns
M_CliffRock skirt faces: 1152
material slots: still 5
```

这次改动的边界很重要：它不碰顶面 route / crater / lava 语义，不增加第六材质槽，也不靠全局 smoothing 假装自然。它只承认一件事：浮岛侧壁不是 heightfield 的附属品，而是 hero 资产的一部分。Gaea/Houdini 感不是“平滑”，而是每一段阴影都像某种崩塌、冷却、错台或沉积造成的。

新的视觉判断也更清楚了：外裙连续感比上一轮少，但 8-angle contact sheet 仍暴露出上部火山墙的规律竖肋。下一刀不应该回头磨 underside fan，而应该进入 **upper crater / outer wall vertical rib de-patterning**：把黑色火山壁从“城墙肋”推进到“侵蚀沟、冷却柱、塌陷板块混合的山体墙”。

## 追加悟道：上部火山墙不能只消灭最强竖肋

`outer wall` 之前已经有两类回归：

- 最坏 `boundary_p80` 不能太高；
- 单条 boundary 不能有太长的连续强 delta run。

但 8-angle 图暴露了第三种程序味：很多 boundary 并不是“极端强”，而是 **110-160cm 的中强 delta 持续跨过很多 radial rings**。单看 p80 不一定爆表，单看强 delta run 也可能合格；可是 side/back 视角会把这些中强对齐线读成城墙肋。

这轮把 upper wall rib 指标改成：

```text
upper wall band = R26-R39 roughly
for each angular boundary:
  medium_ribs = count(delta > 110cm)
  strong_ribs = count(delta > 160cm)
  persistent if medium_ribs >= 7 or strong_ribs >= 4
```

旧状态：

```text
persistent castle ribs: 78 boundaries
```

第一刀只把 persistent 压到 66，但视觉上仍偏保守；第二刀把目标提高，并同时兼顾既有 worst p80 回归：

```text
persistent castle ribs: 78 -> 58
worst boundary p80: about 267cm -> 229cm
quality: Route 94% / detail risk 8% / edge risk 4% / radial risk 4%
```

实现上没有做全局 smoothing，而是扩展 `_weather_fire_outer_wall_polar_curtains` 的检测逻辑：

- 高 `boundary_p80` 仍触发强处理；
- 中强但持久的 rib 也触发 coherence；
- 只在 Fire upper wall band 内处理；
- 继续避开 path / lava / crater loop 语义保护区。

这说明 Gaea 化的指标不能只盯“最坏尖刺”。自然感经常死在一批“每个都不太坏，但共同排成规则图案”的中强结构上。Houdini/Gaea 的好看，很多时候来自这种批量对齐被过程层打散。

当前仍未终点：上墙比之前少了城墙肋，但大形 silhouette 和 lava curtain 的块面节奏还可以更自然。下一轮更适合处理：

- upper wall silhouette 的大块塌陷节奏；
- lava cliff 从连续红帘变成更分叉、更有冷却台阶的流面；
- 黑岩墙和灰台地交界处的沉积/崩塌因果。

## 追加悟道：lava curtain 不能是一整条连续红材质跑道

前几轮一直在修黑岩墙和火山壁的几何节奏，但 Fire 的另一个 Meshy/PBR 风险是 `M_ElementCrack` 本身过于连续。即使 lava channel 的高度剖面已有台阶，如果材质上从中环一路红到外缘，Meshy 很容易把它理解成一整张连续熔岩帘，而不是“流动熔岩 + 冷却壳 + 岩肩”的组合。

这轮新增的回归不是改 lava mask 语义，而是检查材质输出：

```text
for each non-entry lava channel:
  sample centerline from R0.58 to R0.97
  count longest radial run of M_ElementCrack
  require longest run <= 10 rings
```

旧状态：

```text
longest radial M_ElementCrack run: 12 rings
```

新的处理只发生在 material assignment 层，增加 Fire-only `fire_lava_cooling_crust_break`：

- 放在约 `0.84R` 的冷却壳带；
- 只作用于高 lava / 高 lava_flow / 高 flow_accumulation 的通道中心；
- 避开 path / crater loop；
- 不修改 heightfield、lava_mask 或 gameplay 语义；
- 不新增材质槽，而是把冷却壳归入既有 `M_CliffRock`。

修完后：

```text
longest radial M_ElementCrack run: 12 -> 9 rings
M_ElementCrack tiny components < 8: []
largest components remain compact
HERO quality still: Route 94% / detail risk 8% / edge risk 4% / radial risk 4%
```

这里有一个重要边界：不能为了打断红帘而制造一堆 1-cell 红色孤岛。第一版 cooling break 正是犯了这个风险，留下 4 个 tiny `M_ElementCrack`。正确修法不是放弃冷却壳，而是让冷却壳同时吃掉 `fire_lava_material_bridge` 在该带里留下的低 lava / 高 flow 残片。这样红帘被切断，同时 Meshy-safe region compactness 不回退。

下一轮如果继续处理 lava，不应再只是切材质带，而应该推进 **lava block-scale morphology**：让红色流面本身有更明显的分叉舌头、冷却台阶和局部崩断边，而不是只靠材质黑线切开。
