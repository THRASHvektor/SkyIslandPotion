# 植物崩坏向量装配心智

日期：2026-07-06

范围：`Tools/IslandMeshGen/web/plant.html`、`plant_regroup.js`、Meshy auto split/regroup、PBR parts export、UE 5.4 里的资源植物 Actor 自动装配。

## 一句话

植物不是一堆随机拼起来的散件，而是一套可被 AIGC 生成、可被 Web 工作台语义分组、可被 UE 按规则重建的崩坏器官系统。

最稳的生产心智是：

```text
Meshy 生成形体。
Web 工作台定义语义。
Manifest 记录空间。
UE 根据空间和崩坏向量装配。
Niagara 与材质负责把“不严丝合缝”解释成世界观。
```

## 当前四部件模型

现阶段先固定为四个 mesh 语义部件：

| Slot | 中文心智 | 职责 |
| --- | --- | --- |
| `BodyShell` | 根盘 / 主茎 / 主藤 / 壳体骨架 | 定义贴地关系、整体高度、主体坐标系 |
| `PrimarySilhouette` | 花冠 / 星轨弧 / 伞盖 / 主叶片 | 定义一眼可读的植物族群轮廓 |
| `Core` | 灯芯 / 星核 / 药液核心 | 定义采集价值、交互焦点、元素能量源 |
| `OrbitSet` | 碎片 / 星点 / 孢囊 / 符文片 | 定义弱链接、漂浮、崩坏和神秘学节奏 |

FX、Niagara、材质参数、发光裂缝、粒子胶水不应该算作第五个 mesh slot。它们是视觉层和状态层。

这个划分对 `CrownLily` 和 `AetherVine` 都成立：

- `CrownLily`：BodyShell 是根盘与灯茎，PrimarySilhouette 是浮空花冠，Core 是灯芯，OrbitSet 是火星 / 碎瓣 / 轨道粒。
- `AetherVine`：BodyShell 是根结与主藤，PrimarySilhouette 是星轨主弧，Core 是星核，OrbitSet 是星点 / 符文片 / 辅助轨道。

因此不要为每种植物新建一套 Blueprint 装配逻辑。每个家族只需要一个 `AssemblyProfile`，它描述四个 slot 的空间解释、约束和偏移风格。

## 崩坏向量

如果每个部件都有 C0-C3 四个崩坏状态，整株植物不应该只用一个标量 `CollapseLevel` 表示。

更准确的是一个向量：

```text
x = [x_BodyShell, x_PrimarySilhouette, x_Core, x_OrbitSet]
x_i ∈ {0, 1, 2, 3}
```

含义：

- C0：完好，结构稳定，漂浮部件有序。
- C1：风化，轻微裂纹、磨损、边缘缺口。
- C2：破裂，器官出现可读断裂、局部错位、发光缝。
- C3：失稳，能量泄露、浮空偏移增大、粒子与轨道更活跃。

C4 可以作为未来 rare / anomaly / hero 层级保留，但当前 UE 生产先按 C0-C3 收束，避免资产组合数量爆炸。

## Severity、Dispersion、Temperature

崩坏世界允许混乱，但混乱要有边界。关键不是禁止不同部件的崩坏等级混搭，而是控制它的离散度。

定义权重：

```text
w_BodyShell          = 0.20
w_PrimarySilhouette  = 0.35
w_Core               = 0.25
w_OrbitSet           = 0.20
```

PrimarySilhouette 权重最高，因为它决定家族识别。Core 次高，因为它决定玩法和交互焦点。

定义整株崩坏强度：

```text
S(x) = Σ w_i x_i
```

定义崩坏离散度：

```text
D(x) = Σ w_i (x_i - S(x))^2
```

直觉：

- `S` 高：整株更破、更危险、更亮、更不稳定。
- `D` 高：各部件之间崩坏程度差异更大，更像“世界规则正在松动”。
- `Temperature` 高：采样更随机，更容易出现奇异但仍可控的组合。

建议按全局 Collapse Band 设目标：

| Band | Severity Target | Dispersion Target | Temperature | 例子 |
| --- | ---: | ---: | ---: | --- |
| `Stable_C0` | 0.0-0.4 | 很低 | 很低 | `[0,0,0,0]`, `[0,1,0,0]` |
| `Weathered_C1` | 0.7-1.2 | 低 | 低 | `[1,1,1,0]`, `[0,1,1,1]` |
| `Fractured_C2` | 1.5-2.1 | 中 | 中 | `[1,2,2,2]`, `[2,2,1,3]` |
| `Unstable_C3` | 2.2-2.8 | 中高 | 高 | `[1,3,3,2]`, `[2,3,3,0]`, `[0,3,2,3]` |

注意：C3 不等于 `[3,3,3,3]`。全 3 反而容易变成一团同质噪声。更好的 C3 是主体还能读，局部已经失控。

## 采样能量函数

运行时或编辑器期可以用一个能量函数来 roll 崩坏组合：

```text
E(x | L) =
  a * (S(x) - S*_L)^2
+ b * (D(x) - D*_L)^2
+ c * IdentityPenalty(x)
+ d * GameplayPenalty(x)
+ e * ScalePenalty(x)
+ f * FamilyCompatibilityPenalty(x)

P(x | L) = exp(-E(x | L) / T_L) / Z
```

其中：

- `S*_L` 是该区域 / 生态 / 岛屿稳定度给出的目标崩坏强度。
- `D*_L` 是目标离散度。
- `T_L` 是随机温度。
- `IdentityPenalty` 防止 PrimarySilhouette 失去族群轮廓。
- `GameplayPenalty` 防止 Core 不可读或交互点被遮挡。
- `ScalePenalty` 防止部件比例荒谬。
- `FamilyCompatibilityPenalty` 防止星轨藤长成灯莲、灯莲长成荆棘。

这是数学心智，不代表 P0 必须完整实现。P0 可以先用表驱动权重和白名单组合，后续再升级为真正采样器。

## 必守不变量

即使世界观允许崩坏，也要保住三条底线：

1. `PrimarySilhouette` 必须让玩家远看知道这是哪个植物族群。
2. `Core` 必须让玩家近看知道哪里能交互、能采集、能反应。
3. `BodyShell` 必须让 UE 和 PCG 知道它如何站在岛屿表面上。

建议约束：

```text
abs(x_PrimarySilhouette - x_BodyShell) <= 2
abs(x_Core - x_PrimarySilhouette) <= 2
Core 不允许被 PrimarySilhouette 完全遮挡
OrbitSet 可以最自由，但不能把主体轮廓噪声化
```

## 为什么当前四 slot 是合理边界

之前的 Root / Stem / Petal / Spore / Crystal / ReactionShell 方案很细，但它隐含了硬拼接思路，容易把问题带回 pivot、socket、接缝、比例和每家族定制装配。

四 slot 更适合当前 Meshy + Web regroup + UE 5.4 的现实：

- Meshy 输出的 part 很难保证 socket-ready。
- Web 工作台已经能把 20-30 个 auto split 碎片重新绑定到四个语义组。
- UE 5.4 里做 DataAsset + StaticMeshComponent + Niagara 的轻量装配足够。
- 族群差异放进 `AssemblyProfile`，不要放进 Actor 继承树。
- 崩坏差异放进 collapse vector，避免每个家族写一套逻辑。

## 从 Web 工作台提取相对位置

当前 `plant.html` / `plant_regroup.js` 已经具备自动装配需要的第一层信息：

```text
semanticGroups = Core / PrimarySilhouette / OrbitSet / BodyShell
part.bbox.min / part.bbox.max
part.center
part.extent
part.normalizedCenter
part.normalizedExtent
part.heightRatio
part.radialRatio
part.triCount
```

当前 manifest 已经输出每个 part 的：

```json
{
  "id": "part-15",
  "name": "mesh_15",
  "material": "model_part15",
  "triangles": 12962,
  "height_ratio": 0.7437,
  "radial_ratio": 0.0368,
  "bbox": {
    "min": [-0.014875, 0.087383, -0.013848],
    "max": [0.016445, 0.091097, 0.017062]
  }
}
```

这足够让我们先不碰 PBR 切分算法，也能派生出 UE 装配参考坐标。

## 组级空间统计

对每个 semantic group 计算：

```text
group_bbox.min = min(part.bbox.min)
group_bbox.max = max(part.bbox.max)
group_bbox.center = (min + max) / 2
group_bbox.extent = max - min

part_bbox_center_j = (part.bbox.min + part.bbox.max) / 2
group_weighted_centroid = Σ weight_j * part_bbox_center_j / Σ weight_j
```

第一版 weight 可以用 `triangles`，因为 manifest 已经有。注意它会被高细分部件偏置，所以只能叫 `triangle_weighted_bbox_centroid`，不能假装它是物理重心。

更稳的长期方案：

- 如果 Web 工作台保留 face geometry，使用 surface-area-weighted centroid。
- 对 OrbitSet 这种离散碎片，使用 median / trimmed centroid，避免单个大碎片把中心拖偏。
- 对 PrimarySilhouette，bbox center 往往比三角面加权 centroid 更能表达摆放中心。
- 对 BodyShell，底部中心比 centroid 更适合作为 UE pivot anchor。

## 推荐 Anchor

不要只用“重心”。植物装配需要多个 anchor：

| Anchor | 计算方式 | 用途 |
| --- | --- | --- |
| `body_bottom_center` | BodyShell union bbox 的 `[centerX, minY, centerZ]` | UE Actor 原点 / 贴地基准 |
| `body_centroid` | BodyShell weighted centroid | 主体内部空间参考 |
| `core_center` | Core bbox center 或 robust centroid | Niagara、OrbitSet、交互焦点 |
| `primary_center` | PrimarySilhouette bbox center | 主轮廓摆放 |
| `orbit_center` | OrbitSet trimmed centroid 或 orbit fit center | 轨道碎片参考 |

P0 建议：

```text
UE Actor Origin = body_bottom_center
BodyShell LocalTransform = identity
Core LocalOffset = core_center - body_bottom_center
PrimarySilhouette LocalOffset = primary_center - body_bottom_center
OrbitSet LocalOffset = orbit_center - body_bottom_center
```

如果导出的四个 group mesh 仍然保留原始模型坐标，也可以在 UE 中让 mesh asset pivot 不完美，但组件 LocalTransform 用 manifest 纠偏。这样比要求 Meshy 或 Blender 立刻修好所有 pivot 更现实。

## CrownLily 当前样本

从当前 `CrownLily_flamebound-scepter-auto-split` manifest 派生的组级统计：

| Group | Parts | Triangles | Centroid |
| --- | ---: | ---: | --- |
| BodyShell | 7 | 121794 | `[-0.005355, 0.028665, 0.000586]` |
| Core | 2 | 83624 | `[-0.002895, 0.064864, -0.002747]` |
| PrimarySilhouette | 14 | 345742 | `[-0.000313, 0.090294, -0.005638]` |
| OrbitSet | 11 | 42154 | `[0.001691, 0.081932, 0.020154]` |

相对 BodyShell centroid：

```json
{
  "Core": [0.002460, 0.036199, -0.003333],
  "PrimarySilhouette": [0.005042, 0.061629, -0.006224],
  "OrbitSet": [0.007046, 0.053267, 0.019568],
  "BodyShell": [0.0, 0.0, 0.0]
}
```

这说明灯莲样本已经具有可读的垂直层级：Core、OrbitSet、PrimarySilhouette 都在 BodyShell 上方，适合自动提取装配偏移。

## AetherVine 当前样本

从当前 `AetherVineC0_user_regroup` manifest 派生的组级统计：

| Group | Parts | Triangles | Centroid |
| --- | ---: | ---: | --- |
| BodyShell | 5 | 100982 | `[0.005769, 0.014850, 0.014819]` |
| Core | 1 | 95248 | `[-0.001120, 0.067764, -0.009280]` |
| PrimarySilhouette | 7 | 329560 | `[-0.005091, 0.066943, 0.008299]` |
| OrbitSet | 12 | 663864 | `[0.000634, 0.075041, 0.000458]` |

相对 BodyShell centroid：

```json
{
  "Core": [-0.006889, 0.052914, -0.024099],
  "PrimarySilhouette": [-0.010860, 0.052093, -0.006520],
  "OrbitSet": [-0.005135, 0.060191, -0.014361],
  "BodyShell": [0.0, 0.0, 0.0]
}
```

星轨藤的张力在这里很明显：它不是简单“上下拼装”，而是一个主弧和轨道系统。但仍然不需要新 Actor。它需要的是 `AssemblyProfile_AetherVine`：

```text
Core 作为轨道中心。
PrimarySilhouette 作为主弧组，保留整体 mesh 内部形状。
OrbitSet 作为轨道点组，围绕 Core 做轻微旋转 / bob。
BodyShell 只负责根结和主藤基准。
```

如果 OrbitSet 已经被导出为一个 group mesh，则 UE 先按 group local offset 放置即可。以后若要粒度更细，再把 OrbitSet 拆成 fragment offsets。

## Manifest 扩展建议

不要现在破坏 `buildManifest()`。等 PBR 分解稳定后，可以以 additive 方式增加 `assembly` block：

```json
{
  "schema": "SkyIslandPotion.PlantRegroupManifest.v1",
  "assembly": {
    "schema": "SkyIslandPotion.PlantAssemblyHint.v0",
    "coordinate_space": "split_model_y_up",
    "anchor": {
      "name": "body_bottom_center",
      "group": "BodyShell",
      "position": [-0.007056, 0.0, 0.001687]
    },
    "groups": {
      "BodyShell": {
        "parts": 7,
        "bbox": {
          "min": [-0.029034, 0.0, -0.020682],
          "max": [0.014922, 0.115334, 0.024057],
          "center": [-0.007056, 0.057667, 0.001687],
          "extent": [0.043956, 0.115334, 0.044739]
        },
        "placement_center_method": "body_bottom_center",
        "placement_center": [-0.007056, 0.0, 0.001687],
        "relative_to_anchor": [0.0, 0.0, 0.0]
      },
      "Core": {
        "placement_center_method": "bbox_center_or_robust_centroid",
        "relative_to_anchor": [0.004438, 0.060392, -0.005233]
      },
      "PrimarySilhouette": {
        "placement_center_method": "bbox_center",
        "relative_to_anchor": [0.006548, 0.094312, -0.004775]
      },
      "OrbitSet": {
        "placement_center_method": "trimmed_centroid_or_orbit_fit",
        "relative_to_anchor": [0.019073, 0.082930, 0.001462]
      }
    },
    "ue_hint": {
      "axis_mapping": "verify_per_import; web/split is Y-up, UE is Z-up",
      "unit_scale_cm": "derive_from_import_scale",
      "recommended_actor_origin": "BodyShell.body_bottom_center",
      "recommended_interaction_focus": "Core.placement_center"
    }
  }
}
```

这份 `assembly` 是 UE 的提示，不是 Meshy 的输入。Meshy 不理解它，UE 和我们的导入脚本理解它。

## 坐标与单位警告

当前 split / PBR / UE 之间不能盲目假设同一坐标系。

已有 PBR export report 里出现过：

```json
"split_axis_permutation_to_pbr": [0, 2, 1],
"split_axis_signs": [1, 1, -1]
```

这说明 split mesh 到 PBR mesh 至少存在轴交换和符号翻转。UE 又是 Z-up，因此自动装配 manifest 里必须显式记录：

```text
coordinate_space
axis_mapping
unit_scale
source_bounds
import_bounds
```

不要在 UE 侧写死“web x/y/z 一定等于 UE x/y/z”。正确做法是每次导出时把 transform 契约写入 report。

## 自动装配工作流

推荐先走非破坏性离线流程：

```text
Meshy complete plant
-> Auto Split white OBJ/GLB
-> plant.html semantic regroup
-> regroup_manifest.json
-> offline assembly hint extractor
-> assembly_manifest.json
-> PBR part export
-> UE import / DataAsset generation
-> BP_ResourcePlantActor reads recipe and local offsets
```

P0 不要直接把提取逻辑塞进 PBR 分解主线。先让离线脚本读取保存好的 `regroup_manifest.json` 并输出独立 `assembly_manifest.json`，验证：

- 四个 group 的 anchor 是否稳定。
- UE 里是否能自动摆出 CrownLily 和 AetherVine。
- `Core` 是否落在交互范围内。
- `PrimarySilhouette` 是否远看仍然读得出族群。
- `OrbitSet` 是否能被 Niagara / bob 动画自然解释。

等稳定后，再把 `buildAssemblyMetadata()` 作为 additive 字段接回 `buildManifest()`。

## UE 数据心智

UE 侧不应该记住 Meshy 的碎片细节，只应该记住装配语义：

```text
PlantRecipe
  Family
  Element
  CollapseVector
  BodyShellMesh
  PrimarySilhouetteMesh
  CoreMesh
  OrbitSetMesh
  BodyShellTransform
  PrimarySilhouetteTransform
  CoreTransform
  OrbitSetTransform
  NiagaraSet
  MaterialParams
  GameplayTags
```

对 PCG 来说，一株植物仍然是一点：

```text
PCG Point
-> Spawn BP_ResourcePlantActor
-> pass Family / Element / CollapseBand / Seed / Biome
-> Actor chooses CollapseVector and recipe
-> Actor applies four local transforms from assembly hints
```

PCG 不直接撒四个部件。PCG 只决定哪里长一株植物。

## 对 AetherVine 的特殊解释

星轨藤看起来最担心“流线型装配复杂”，但它可以被四 slot 吃下：

```text
BodyShell = 根结 + 主藤。
Core = 星核。
PrimarySilhouette = 主星轨弧，作为整组 mesh 保留内部弧线。
OrbitSet = 小星点 / 符文片 / 断弧碎片。
```

自动装配不需要知道每一段弧线怎么拼，只要知道：

- 主弧组的整体 local offset。
- 星核位置。
- OrbitSet 相对星核的中心、半径、平面或 bbox。
- Niagara 沿 OrbitSet / Core 做轻微轨道运动。

换句话说，星轨藤不是“很多流线段逐个 socket”，而是“一组已经成形的主弧 mesh + 一组可漂浮的轨道碎片”。这很适合 UE 5.4 的轻量 Blueprint。

## 后续实现优先级

第一优先级是导出空间契约，不是增加 UI 功能：

1. 离线读取 `regroup_manifest.json`。
2. 计算 group bbox、bbox center、triangle weighted bbox centroid、BodyShell bottom center。
3. 输出 `assembly_manifest.json`。
4. 用现有 UE 植物 Actor 验证四个 LocalOffset。
5. 再考虑在 `plant.html` manifest 里加入 `assembly` block。
6. 最后才考虑 fragment-level OrbitSet、PCA 轨道拟合、自动 DataAsset 生成。

不要现在打断 PBR 分解算法。装配元数据可以和 PBR 元数据平行前进。

## 最终原则

```text
四部件是生产边界。
崩坏向量是随机边界。
BodyShell 是空间边界。
Core 是玩法边界。
PrimarySilhouette 是识别边界。
OrbitSet 是混乱边界。
Manifest 是 UE 和 Web 的契约边界。
```

这套方案的目标不是把 AIGC 变成完全可靠的语义引擎，而是把 AIGC 的不稳定结果收束成可被 UE 消费的四个稳定意图。
