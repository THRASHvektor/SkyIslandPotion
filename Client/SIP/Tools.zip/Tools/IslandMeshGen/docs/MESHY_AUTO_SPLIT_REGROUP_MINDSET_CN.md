# Meshy Auto Split 重分组设计心智

日期：2026-07-06

## 核心判断

Meshy Auto Split 很有价值，但它的默认目标不是游戏语义拆件，而是更偏 3D 打印的可制造分件。

因此我们不应该期待它直接输出：

- Root
- Stem
- Core
- PetalSet
- OrbitSet
- CrystalSet
- Connector

更合理的定位是：

```text
Meshy Auto Split = 粗粒度拓扑碎片生成器
我们的 Web 工具 = 语义重分组和资产标准化工作台
```

碎并不是坏事。一整坨完整模型很难自动理解语义；被 Auto Split 切成 10-30 个碎 part 后，反而提供了可编辑的拓扑边界。

## 下载格式约定

推荐下载组合：

```text
Auto Split 白膜：
  1. OBJ：主用，用来读取 o / g / usemtl / face groups
  2. GLB：备份，用来检查 node / mesh primitive / transform / split result structure

完整 PBR 模型：
  1. GLB：主用，保留 UV、贴图、PBR 材质、单文件路径完整性

切割后部件：
  1. GLB：进 UE、保材质、保 UV、便于后续 pivot/socket 标准化
```

一句话：

```text
Split white OBJ = 拿分组边界
Split white GLB = 查结构保险
Full PBR GLB = 拿最终材质
Part GLB = UE 资产输出
```

## 不可假设顶点索引一致

PBR 之后顶点数变多是正常现象。UV seam、硬法线、材质边界、tangent space 都可能让同一个空间点被拆成多个渲染顶点。

所以不能假设：

```text
white vertex index == pbr vertex index
```

但这不阻止我们映射。正确思路是围绕 face 或 surface 来做，而不是围绕 vertex index。

## 映射策略分三级

脚本应该自动检测并选择最稳模式。

### Mode 1: Direct Face Index

适用条件：

```text
white face count == pbr face count
white face centers[i] ~= pbr face centers[i]
white face normals[i] ~= pbr face normals[i]
```

做法：

```text
Auto Split OBJ group -> white face ids
same face ids -> PBR GLB faces
extract PBR faces -> part GLB
```

这是最快、最稳的模式。顶点数不同也没关系，因为我们切的是 PBR 自己的 face。

### Mode 2: Face Center / Normal / Area Match

适用条件：

```text
face count 相同或接近
face 顺序变了
几何位置基本一致
```

做法：

```text
white face feature = center + normal + area
pbr face feature = center + normal + area
KDTree 先按 center 找候选
再用 normal dot 和 area ratio 过滤
```

不要只用 center。植物模型里叶片、轨道、晶体经常有对称重复结构，只用中心点容易错配。

建议验证阈值：

```text
center distance < epsilon
normal dot > 0.85
area ratio in [0.5, 2.0]
```

### Mode 3: Part Surface Projection

适用条件：

```text
PBR face count 变了
Meshy 做了 remesh / decimate / cap / smooth / split
face index 或 face-to-face mapping 不再可靠
```

做法反过来：

```text
对每个 PBR face center
找到最近的 white split part surface
把 PBR face 归属到最近 part
```

这是近似模式，边界可能会有误差，但比硬套 face id 安全。

## Web 重分组工作台

工具目标：

```text
导入 Meshy Auto Split OBJ/GLB
显示所有碎 part
自动预聚类
人工合并、命名、锁定
导出 semantic part manifest
映射到 PBR GLB
导出 UE 可用部件 GLB
```

界面建议：

```text
左侧：Auto Split parts 列表
中间：3D 预览
右侧：Semantic Groups

Groups:
  Root
  Stem
  Core
  PetalSet
  OrbitSet
  CrystalSet
  Connector
  Ignore
```

必要交互：

- 点击 part 高亮
- Shift 多选
- 框选 / 套索选择
- Hide / Solo
- Merge to Group
- Rename Group
- Lock Group
- Auto Suggest
- Undo / Redo
- Export Manifest
- Export Split GLB

## 自动预聚类怎么做

自动只能作为建议，不应直接替代人眼判断。

可用特征：

```text
centroid：中心位置
bbox：包围盒
area / volume：面积和体积
principal axis：主方向
height band：高度层
radial distance：离主体中心距离
adjacency：是否接触或靠近
curvature：是否像晶体、叶片、轨道
color / group：Meshy 原始颜色或编号，只作弱信号
```

典型识别规则：

### OrbitSet

轨道可通过这些特征预聚类：

```text
绕中心分布
高度接近
半径接近
细长弧形
主方向近似切线
```

颜色不能硬信任。蓝色和紫色碎片可能都是轨道。

### PetalSet / LeafSet

叶片通常：

```text
面积较大
薄片形
围绕核心放射
高度中上
重复形态明显
```

### Stem

茎通常：

```text
竖向主轴
连接 Root 和 Core
位于中心附近
细长
```

### Core / Crown

核心通常：

```text
中心附近
体积紧凑
高度中上
接触叶片/轨道/茎
```

### CrystalSet

晶体通常：

```text
体积小
高曲率
离主体有一定距离
常分布在轨道附近
```

## Manifest 设计

第一阶段输出 semantic regroup manifest，不急着直接切模型。

示例：

```json
{
  "source": {
    "split_obj": "lotus_auto_split.obj",
    "split_glb": "lotus_auto_split.glb",
    "pbr_glb": "lotus_pbr.glb"
  },
  "semantic_groups": {
    "Root": ["part_9"],
    "Stem": ["part_7"],
    "Core": ["part_11"],
    "PetalSet": ["part_3", "part_4", "part_5"],
    "OrbitSet": ["part_1", "part_2", "part_6", "part_10", "part_14", "part_15"],
    "CrystalSet": ["part_12", "part_13", "part_16", "part_17"],
    "Ignore": []
  },
  "mapping": {
    "mode": "DirectFaceIndex | FaceFeatureMatch | PartSurfaceProjection",
    "verified": false,
    "notes": ""
  }
}
```

第二阶段根据 manifest 导出：

```text
Lotus_Root.glb
Lotus_Stem.glb
Lotus_Core.glb
Lotus_PetalSet.glb
Lotus_OrbitSet.glb
Lotus_CrystalSet.glb
Lotus_Connector.glb
```

## 验证清单

拿到文件后先不要急着切，先跑验证。

必须检查：

```text
1. split OBJ 是否保留 o / g / usemtl
2. split OBJ 每个 part 的 face 数、bbox、centroid
3. split GLB 是否保留 node / primitive / transform
4. full PBR GLB 的 face count / vertex count / material / texture
5. white 与 PBR 的 face order 是否一致
6. 如果 face order 不一致，center/normal/area matching 是否可靠
7. 如果 face count 不一致，surface projection 是否能给出稳定归属
```

通过后再进入人工重分组和切件。

## 生产边界

Meshy 负责：

```text
生成完整形体
生成 PBR 美术
生成打印向粗拆 part
```

我们负责：

```text
语义重分组
部件命名
pivot/socket 标准化
PBR face 映射切件
UE runtime assembly 资产化
```

最终判断：

```text
Auto Split 不是终点，是资产语义化的入口。
碎片越多，越需要我们的 regroup workbench。
机器给边界，人来定语义。
```
