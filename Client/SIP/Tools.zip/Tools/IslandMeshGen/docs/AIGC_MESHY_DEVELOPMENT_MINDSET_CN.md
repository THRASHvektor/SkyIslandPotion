# AIGC / Meshy 开发心智

日期：2026-07-04

范围：`Tools/IslandMeshGen`、语义地形烘焙、Meshy 辅助资产、未来植物部件生成。

## 核心规则

Meshy 接收几何、图片和 prompt。IslandMeshGen 拥有语义。

具体来说：

- IslandMeshGen 拥有 layout、可玩性、地形 mask、材质槽、PCG 意图、质量报告和 Unreal 导入契约。
- Meshy 可以辅助 PBR 探索、Retexture 实验、岩石 / 晶簇 / 根须 / 植物部件 / 接缝装饰件 / 可视皮肤 Remesh。
- Meshy 不能成为可行走路径、碰撞、玩法拓扑、PCG bounds、元素反应区域的权威来源。

有用的心智切分是：

```text
发给 Meshy 的是肉。
留在本地的是脑子。
```

## 当前地形问题

当前 hero bake 已经能表达火山、主路径、火山口环路、悬崖、熔岩沟，但和 Gaea / Houdini 地形相比仍然太吵、太刺。

核心问题不只是 mesh 分辨率低，而是高频细节仍然太接近“直接噪声变几何”：

- 随机微尖刺影响轮廓
- cliff / rim damage 会像锯齿噪声
- path / arena 保护不够强
- 所有区域容易以同一种方式变得“细”
- 地形还不像被 flow、slope、erosion、deposition、strata 塑造过

单纯提高 hero 分辨率可能只会让同一个问题更密。下一步算法应该改变细节来源，而不是只增加细节数量。

## 地形方向

主线仍然是自研语义地形。

推荐顺序：

1. 先做低风险导入质量修复：
   - smoothing groups 或显式 normals
   - 更强的 path / arena / crater interior 保护
   - 降低全局高频位移强度
2. 加 mask-aware height relaxation：
   - path：强平滑
   - arena：中等平滑
   - crater rim：保留大形，去掉小 sawtooth
   - lava channel：保留切割中心，平滑噪声边缘
   - cliff：保留陡峭，压制随机抖动
3. 做 Fine Terrain Field v1：
   - `flow_accumulation_mask`
   - `curvature_mask`
   - `strata_mask`
4. 用这些 mask 驱动 erosion / deposition：
   - erosion 跟随 flow accumulation 和 slope
   - deposition 聚集在 concave slope-foot 区域
   - strata 出现在 cliff、rim、外露凸肩区域
5. 导出 Unreal PBR 可用的语义材质 mask：
   - slope
   - talus
   - lava flow
   - curvature
   - strata
   - cavity
   - path wear
   - rim damage
   - ash deposit

不要把 Meshy Remesh 当成地形毛刺的第一答案。Meshy 可以平滑或重组织几何，但它不能可靠地从我们的语义意图里推断可玩地貌过程。

## Meshy 角色

Meshy 有价值，但它是 AIGC 资产工坊，不是地形大脑。

适合优先使用：

- Retexture 本地地形或局部地形，用来探索 PBR 方向。
- 生成 basalt chunks、lava crust plates、vents、crystals、roots、flowers、seam collars 等 donor assets。
- Remesh donor assets，让 Unreal 导入更干净。
- 产出 hero visual-skin 实验版本用于对比。

风险用法：

- Remesh 主岛屿后把它当成新 source of truth。
- 用 AI 生成 mesh 替代完整地形骨架。
- 依赖 Meshy 保留可行走路径、材质槽契约、PCG 区域或碰撞意图。
- 假设 Meshy 理解 `field.json`、`manifest.json`、`quality_report.json`。

## Meshy 智能体反馈后的硬边界

Meshy 智能体确认了核心边界：

```text
Meshy 是视觉资产工具，不是语义理解引擎。
```

重要实际行为：

- Retexture 可以被材质区域引导，但不能可靠锁定到命名语义区域。
- 输入材质槽边界大概率保留，但不保证精确。
- `M_TopGrass`、`M_ElementCrack` 这类材质槽名不能被当作 prompt 里可精确引用的控制项。
- slot 太多会削弱控制；Retexture 测试最好保持在 4-5 个材质区域。
- emissive lava 可以 prompt 引导，但可能扩散到视觉相近区域。
- colored semantic mask 可实验，但 Meshy 可能把颜色当最终外观；prompt 必须非常明确。
- 参考图比纯色 mask 更适合稳定引导视觉风格。
- Remesh 基本保留 scale 和 pivot，但会合并 hierarchy、重建 UV、丢 vertex color，并可能轻微收缩 silhouette。
- Retexture 输出是 UV-baked PBR，不是 tileable procedural material。
- Meshy 更适合生成完整植物 donor，而不是 socket-ready 模块化部件。

更新后的理解：

```text
Meshy 可以很快让东西好看。
它不能保证东西仍然保持语义组织。
```

因此：

- Option C 是首选：Meshy 生成单体视觉资产和 donor parts；Unreal 拥有正式地形材质。
- Option D 是次选：Meshy remesh hero 地形副本作为 visible skin；原始 semantic mesh 继续作为 collision / PCG / gameplay proxy。
- Option A 只是实验：colored-mask Retexture 可用于概念验证，但不能当生产契约。
- Option B 成本高：拆区域、分别 Retexture、再合并能提升控制，但工程成本高，风格一致性也无保证。

升级后的工作句：

```text
Meshy 负责让资产看起来像真的。
IslandMeshGen 负责让世界生成得有理由。
Unreal 负责让这些理由变成可玩的规则。
```

## Bake 输出与所有权

一次完整 bake 会产生若干 sidecar 文件。它们不应该全部上传给 Meshy。

| 文件 | Meshy 角色 | 本地角色 |
| --- | --- | --- |
| `*.obj` / 未来 `*.glb` / `*.fbx` | 可作为模型输入发送 | 源 mesh 和 Unreal 导入资产 |
| `*.field.json` | Meshy 不直接理解 | 高度数据与过程 mask |
| `*.manifest.json` | Meshy 不直接理解 | Biome tag、zones、paths、material slots、Unreal 契约 |
| `*.quality_report.json` | Meshy 不直接理解 | 门禁、诊断、验收检查 |

本地管线应该把 sidecar 语义翻译成 Meshy 友好的输入：

```text
field / manifest / quality report
-> semantic material slots
-> colored mask materials
-> generated prompt
-> optional preview mask image
-> Meshy model or image input
```

## 语义 Meshy 输入

第一版最好的输入格式是 semantic masked model，优先 GLB/FBX，不要优先裸 OBJ。

模型应保留材质区域：

- `M_TopGrass`
- `M_PathDirt`
- `M_CliffRock`
- `M_UndersideRock`
- `M_ElementCrack`

为了让 Meshy 看见语义，这些材质槽可以使用临时 mask 颜色：

- top：neutral ash / gray-green
- path：ochre / yellow
- cliff：blue-gray
- underside：dark purple / black
- cracks：red / orange

prompt 必须声明：输入颜色是语义 mask，不是最终颜色。

示例：

```text
The input mesh uses colored material regions as semantic masks, not final colors.
Preserve the model shape, scale, and region layout.
Red/orange regions are glowing lava fissures with emissive PBR.
Ochre regions are compressed volcanic ash paths with fine gravel normal.
Blue-gray vertical regions are dark basalt cliffs with vertical strata.
Neutral top regions are cooled black volcanic soil with ash dust.
Dark underside regions are porous shadow rock.
No baked lighting.
```

重要警告：

Meshy 可能看见材质区域、对象名、颜色或 prompt，但除非 API 明确保证 region preservation，否则这些都是引导，不是硬合同。Unreal master material 和我们自己的 mask 仍然是可靠生产路径。

Meshy 智能体反馈后，这条警告应升级为硬规则：

```text
Semantic masked Retexture 适合探索。
它不是生产级 region-locked 材质系统。
```

## Meshy 实验

Meshy 地形工作应被当成 side-by-side 实验。

### 实验 A：Visible-Skin Remesh

```text
Hero semantic mesh
-> Meshy remesh duplicate
-> Unreal side-by-side comparison
```

验收检查：

- scale preserved
- path 仍可读且足够平
- crater silhouette 保留
- material regions 没有被合并到不可用
- UE import 成功
- visual spikes 减少

如果接受，这个 mesh 可以作为 visible skin；原始 semantic mesh 仍然作为 collision / PCG / gameplay proxy。

### 实验 B：Retexture Exploration

```text
Semantic masked GLB
-> Meshy retexture
-> PBR visual proposal
```

验收检查：

- lava crack regions 仍然视觉独立
- path 读作 path
- cliff 读作 basalt / strata
- no baked lighting
- 输出贴图能作为参考或 prototype material input

如果接受，用作 hero visual pass 或材质参考。不要假设它能替代 Unreal master material authoring。

## 植物生成策略

不要让每一株 PCG 植物都变成 runtime-assembled Blueprint actor。

使用两层植物：

### Bulk Flora

大规模背景植被必须便宜：

```text
offline recipe
-> preassembled static mesh variants
-> PCG / HISM / ISM placement
```

这些植物可以使用 Meshy 生成的 donor parts，但在大规模摆放前应预烘焙成整株变体。

### Interactive Flora

玩法植物可以动态：

```text
BP_ElementalPlantActor
-> root / stem / leaf / flower components
-> recipe-driven assembly
-> GameplayTags
-> interaction / reaction events
```

只把这种方式用于资源植物、任务植物、元素反应植物或 hero objects。

Meshy 生成的植物部件进入 PartPool 前必须经过校正：

- pivot fixed
- scale normalized
- orientation normalized
- sockets or anchor metadata added
- material slots checked
- polygon budget checked
- biome affinity tagged
- seam hiding strategy assigned

## 植物部件边界

Meshy 可以生成植物部件，但它不会天然产出 socket-safe 的模块化标准件。

不要假设 Meshy 输出有：

- 正确 pivot
- top / bottom sockets
- 一致 scale
- 兼容接缝轮廓
- 稳定材质命名
- biome-consistent style

Meshy 智能体确认的边界：

- pivot placement 不保证
- sockets / anchors 不支持
- modular part generation 不如 whole-plant generation 可靠
- scale 和 connection-surface 约束只是视觉引导
- 推荐路线是先生成完整植物，再进 DCC 切割和校正

本地资产管线必须拥有：

- socket alignment
- seam collars 或 node ornaments
- scale constraints
- biome compatibility rules
- Recipe / PartPool validation
- Unreal import naming

## 工作原则

整体系统应保持分层：

```text
Semantic Layout owns intent.
Terrain Field owns landform process.
Unreal Material owns reliable visual layering.
PCG owns scale.
Blueprint owns sparse interaction.
Meshy owns optional AIGC asset proposals.
```

这样项目才能可解释、可调试、可演示。

