# IslandMeshGen Platform Baseline - 2026-07-04

> Scope: this document records what has actually landed in the IslandMeshGen platform layer as of 2026-07-04. It focuses on platformization, graphics data flow, realtime preview, high-res inspection, quality diagnostics, and authoring workflow. AIGC integration is intentionally out of scope here.

## One-line State

IslandMeshGen has moved from a one-off OBJ generator into a local semantic terrain authoring platform:

```text
semantic layout -> deterministic bake -> mesh + field -> realtime preview -> inspect snapshot -> quality report -> nudge -> final export
```

The important platform decision is that layout editing, realtime preview, high-resolution inspection, and final artifact generation are separate data flows. They share the same semantic source, but they do not share lifecycle promises.

## What Exists Now

### 1. Semantic Layout Layer

The tool has JSON-friendly semantic layouts for fire, ice, and forest islands.

- Source model: `semantic_layout.py`
- Layout presets: `layouts/*.json`
- Fire authoring controls currently expose volcano form, route shape, hazard distribution, and process/detail controls.
- The layout is the stable editable source of truth.
- Meshes, fields, manifests, and quality reports are derived artifacts.

Current fire controls include:

- `central_volcano.dominance`
- `central_volcano.radius`
- `main_approach.width`
- `lava_channels.count`
- `partial_crater_loop.coverage`
- process controls such as detail energy, erosion age, and deposition weight

This matters because all authoring behavior is now expressed as semantic intent first, not direct mesh editing.

### 2. Deterministic Bake Pipeline

The backend can bake the semantic layout into Unreal-friendly OBJ outputs.

- CLI generator: `island_mesh_generator.py`
- Layout export bridge: `export_layout.py`
- Web server: `web/server.mjs`
- Shared server helpers: `web/server_utils.mjs`

The server exposes three different bake routes:

```text
POST /api/preview/:biome   -> lightweight preview artifacts
POST /api/inspect/:biome   -> high-resolution inspect artifacts
POST /api/generate/:biome  -> final output artifacts
```

Preview and inspect write to isolated scratch folders:

```text
output/.preview/
output/.inspect/
```

Final generate writes to the normal output/artifact paths:

```text
output/
layouts/
```

This keeps exploration from polluting UE-facing final exports.

### 3. Three Data Flows

#### Realtime Preview

Purpose: fast authoring feedback.

- Triggered by loading layouts and editing controls.
- Uses `POST /api/preview/:biome`.
- Writes scratch artifacts under `output/.preview/`.
- Caps expensive quality levels down to interactive topology.
- Drives the current preview mesh, process field, process layer stack, 2D map, 3D preview, and quality panel.

Realtime preview promises responsiveness and semantic readability. It does not promise final topology density.

#### High-res Inspect

Purpose: explicit final-quality visual check without generating final artifacts.

- Triggered only by `Inspect <QUALITY>`.
- Uses `POST /api/inspect/:biome`.
- Writes scratch artifacts under `output/.inspect/`.
- Honors the selected final bake quality, including `production` and `hero`.
- Renders as a snapshot and becomes stale when the layout or quality changes.

Inspect is intentionally not the realtime preview path.

#### Final Generate

Purpose: write stable artifacts for the UE/PCG pipeline.

- Triggered only by `Generate Biome`.
- Uses `POST /api/generate/:biome`.
- Writes final OBJ, manifest, field, quality report, and layout artifacts.
- Honors the selected final bake quality.

Generate is the only path that should be treated as a deliverable export.

## Frontend Authoring Surface

The local editor runs from:

```powershell
node Tools\IslandMeshGen\web\server.mjs
```

Then open:

```text
http://127.0.0.1:4177
```

The current UI contains:

- biome preset chips
- final bake quality selector
- generate button
- 2D semantic footprint/minimap canvas
- right-side 3D mesh preview
- WebGL / Canvas renderer toggle
- high-res inspect button and stale/current status
- process layer rail
- fire control tabs
- quality issue panel with nudge actions
- semantic JSON preview

The UI is now an authoring workbench rather than a static mesh viewer.

## Renderer Architecture

### Left Viewport: Canvas 2D

The left viewport remains Canvas-based.

Responsibilities:

- top-down semantic footprint
- stable minimap frame
- yaw-matched comparison with the 3D view
- mask/process/quality overlays
- map probe hit regions
- compact semantic legend

This canvas is still the right tool for 2D authoring overlays and hit testing.

### Right Viewport: WebGL by Default

The right 3D mesh preview now defaults to WebGL.

Responsibilities:

- realtime 3D terrain mesh preview
- high-res GPU inspect snapshot
- orbit camera rendering
- face normal lighting
- material colors
- process trace tint
- quality overlay
- pending movement overlay
- mesh delta pulse

The WebGL renderer is demand-driven. It does not run a permanently hot render loop. It requests frames when state changes, when the user interacts, or while a short visual pulse/transition is active.

### Canvas Fallback

The old right-side Canvas 3D preview is still available through the renderer toggle.

Purpose:

- fallback if WebGL is unavailable
- debug comparison
- lower-risk escape hatch while the WebGL path matures

When WebGL is active, the hidden Canvas preview is not redrawn as the primary 3D backend.

## WebGL Data Flow

The WebGL path uploads terrain as triangle buffers.

Current GPU attributes:

```text
aPosition  -> vertex position
aNormal    -> face normal for lighting
aColor     -> base material/process color
aOverlay   -> per-face authoring overlay color and alpha
```

The overlay channel carries authoring feedback that used to live mostly in Canvas drawing:

- active quality issue face
- mesh delta pulse
- pending movement highlight
- process movement highlight
- quality risk color

The shader mixes overlay color into the lit material color, so the WebGL viewport remains an authoring surface, not just a static render.

## Preview vs Inspect State Boundary

A key bug fix landed around inspect state isolation.

The high-res inspect path now stores its field data separately:

```text
currentField    -> realtime preview/process field
gpuInspectField -> high-res inspect field
```

Why this matters:

- Inspect can bake `production` or `hero` field data.
- Realtime preview should stay lightweight.
- Dragging a slider after inspect must not reuse the high-res inspect field for realtime overlays.
- Starting a slider edit now exits GPU inspect before requesting realtime preview redraw.

The expected state transition is:

```text
Inspect snapshot active
  -> user starts editing
  -> leave inspect
  -> mark snapshot stale
  -> render realtime preview
  -> run preview bake
  -> preview fitted
```

This preserves both responsiveness and correctness.

## Quality Diagnostics

The platform now has a quality report and repair loop.

Backend:

- `qualityReportForMesh(mesh, field, options)`
- quality report JSON written next to preview, inspect, and final artifacts
- reports include route health, detail risk, edge risk, and issue lists

Frontend:

- process layer stack can show quality state
- quality issue panel lists actionable issues
- nudge buttons apply conservative parameter changes
- after preview bake, nudge results can summarize before/after risk movement

The quality system is not an art judge. It is a diagnostic guardrail for whitebox usability:

- route damage
- over-detail risk
- thin edge risk
- unstable/fragile terrain bands

## Performance Decisions

The main performance decisions already landed:

- Preview quality is capped to interactive topology.
- Inspect quality is explicit and user-triggered.
- WebGL is the default 3D preview backend.
- Canvas fallback remains available.
- Hidden Canvas redraws are skipped while WebGL is active.
- WebGL rendering is demand-driven rather than permanently hot.
- Inspect field data is isolated from realtime field data.

The current remaining performance cost is mostly outside the viewport renderer:

```text
Python bake -> OBJ/field/quality JSON writing -> server response -> OBJ parse -> buffer upload
```

If the tool feels slow again, inspect this pipeline before blaming WebGL.

## Tests Covering The Platform Boundary

Current web tests cover the platform-level contracts:

- demand-driven mesh preview render loop
- high-res inspect as explicit snapshot flow
- WebGL face normals and fill lighting
- GPU inspect requests skipping hidden Canvas redraws
- WebGL / Canvas renderer switching
- WebGL overlay attribute flow
- inspect field data separated from preview field data
- slider edits exiting GPU inspect before realtime redraw
- quality report writing and serving
- quality nudge plans and results
- process layer stack and mask coverage
- preview/inspect signature separation

Verification command:

```powershell
& 'C:\Users\12542\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe' --test 'Tools\IslandMeshGen\web\server_utils.test.mjs' 'Tools\IslandMeshGen\web\view_model.test.mjs'
```

Recent verified result:

```text
80 tests
80 pass
0 fail
```

Syntax checks used:

```powershell
& 'C:\Users\12542\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe' --check 'Tools\IslandMeshGen\web\app.js'
& 'C:\Users\12542\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe' --check 'Tools\IslandMeshGen\web\server.mjs'
& 'C:\Users\12542\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe' --check 'Tools\IslandMeshGen\web\server_utils.mjs'
& 'C:\Users\12542\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe' --check 'Tools\IslandMeshGen\web\view_model.mjs'
```

## Landed Milestones

### Semantic Terrain Authoring

- semantic layout data model
- fire/ice/forest sample layouts
- web editor for the fire volcano sample
- biome chips and output metrics
- semantic JSON view
- fire control grouping
- auto-link coherence mode
- design health checks

### Graphics Data Flow

- separate preview, inspect, and generate routes
- preview scratch artifacts
- inspect scratch artifacts
- final export artifacts
- preview quality cap
- inspect quality fidelity
- stale inspect state
- process field warmup
- process layer rail

### Visualization

- 2D semantic footprint canvas
- yaw-linked 2D/3D comparison
- 3D orbit camera
- WebGL realtime preview
- Canvas fallback renderer
- WebGL lighting and shadow lift
- WebGL authoring overlays
- dense inspect wire/visual readability improvements

### Quality Loop

- mesh/field quality metrics
- quality report generation
- quality issue panel
- map probe advisor
- conservative nudge plans
- nudge before/after summaries

### Stability Fixes

- realtime preview decoupled from high-density final bake quality
- inspect does not write final output artifacts
- WebGL hidden Canvas redraw avoidance
- inspect field data no longer pollutes realtime preview field data
- slider edits after inspect exit inspect before realtime redraw
- visible status strings checked for bad glyphs in browser QA

## Current Boundaries

### The Layout Is Editable

User controls and future automation should change semantic layout fields.

### The Field Is Derived

The process field comes from a bake. It should be read by the UI and diagnostics, not manually edited as source truth.

### The Mesh Is Derived

The mesh is a generated artifact. The editor previews it, inspects it, and exports it, but the authoring contract is still semantic layout first.

### The Quality Report Is Advisory

Quality reports and nudges guide the user. They should not silently rewrite layout without an explicit user action.

### Inspect Is A Snapshot

Inspect is not a mode for continued editing. Once the user edits, inspect becomes stale and the UI returns to realtime preview.

## Known Gaps

These are platform gaps, not blockers for the current baseline:

- There is no formal JSON Schema file for semantic layouts yet.
- The web app is still mostly a single large `app.js`.
- Preview/inspect responses still move OBJ text and parse it client-side.
- WebGL uses flat face normals, not smoothed normals or a full material system.
- There is no worker-based OBJ parse/buffer upload yet.
- Browser QA is manual through the local app; there is no full Playwright test suite committed for UI interaction flows.
- The 3D renderer is custom WebGL, not Three.js or WebGPU.

## Recommended Platform Freeze Line

For the platform baseline, stop expanding scope at this line:

- Keep WebGL as the default realtime 3D preview.
- Keep Canvas as 2D authoring + fallback.
- Keep preview/inspect/generate separated.
- Keep quality reports advisory and explicit.
- Keep semantic layout as the only editable source of truth.

The next platform work should be small and contract-focused:

- add a semantic layout schema
- add golden fixtures
- add payload/performance baselines
- split renderer/data-flow modules if `app.js` becomes painful

Avoid large renderer rewrites until the bake/payload pipeline proves that rendering is again the bottleneck.

## Quick Mental Model For Future Work

When adding a feature, ask which layer it belongs to:

```text
Authoring intent?       -> semantic layout / controls
Terrain computation?    -> deterministic bake
Process diagnostics?    -> field + quality report
Realtime feedback?      -> preview path + WebGL/Canvas overlays
Final verification?     -> inspect path
UE-facing artifact?     -> generate path
```

If a feature touches more than one layer, define the handoff explicitly. Most bugs in this tool have come from mixing layers that should stay separate.

---

# 中文版：IslandMeshGen 平台基座现状

> 范围：这一节是上面英文 baseline 的中文增量版，只沉淀 2026-07-04 已经落地的平台基座。这里不展开 AIGC，只讲平台化、图形数据流、实时预览、高精度检查、质量诊断和 authoring 工作流。

## 一句话状态

IslandMeshGen 现在已经不是一个单次 OBJ 导出脚本，而是一个本地语义地形 authoring 平台雏形。

核心链路是：

```text
语义布局 -> 确定性 bake -> mesh + field -> 实时预览 -> 高精度 inspect 快照 -> 质量报告 -> nudge 修复 -> 最终导出
```

最重要的平台判断是：**布局编辑、实时预览、高精度检查、最终导出是四条不同生命周期的数据流**。它们共享同一个语义布局源头，但不能混成一条流。

## 现在已经落地了什么

### 1. 语义布局层

工具已经有 fire、ice、forest 三类岛屿的 JSON 友好语义布局。

- 源模型：`semantic_layout.py`
- 布局样例：`layouts/*.json`
- 当前 Fire authoring 已经暴露火山形态、路线形态、危险区分布、地表过程/detail 控制。
- `layout` 是稳定的可编辑源头。
- `mesh`、`field`、`manifest`、`quality report` 都是派生产物。

当前 Fire 的核心控制包括：

- `central_volcano.dominance`
- `central_volcano.radius`
- `main_approach.width`
- `lava_channels.count`
- `partial_crater_loop.coverage`
- `detailEnergy`、`erosionAge`、`depositionWeight` 这一类过程控制

这意味着工具的 authoring 心智已经从“直接改 mesh”变成了“先改语义意图，再由确定性 baker 生成地形”。

### 2. 确定性 bake 管线

后端可以把语义布局 bake 成 Unreal 友好的 OBJ 和配套数据。

关键文件：

- `island_mesh_generator.py`
- `export_layout.py`
- `web/server.mjs`
- `web/server_utils.mjs`

服务端现在有三条 bake 路由：

```text
POST /api/preview/:biome   -> 轻量实时预览产物
POST /api/inspect/:biome   -> 高精度检查快照产物
POST /api/generate/:biome  -> 最终导出产物
```

Preview 和 Inspect 都写到临时目录：

```text
output/.preview/
output/.inspect/
```

Final Generate 才写正式产物：

```text
output/
layouts/
```

这个隔离很关键：用户探索、拖参数、看高精度快照，都不会污染正式给 UE/PCG 用的导出结果。

## 三条图形数据流

### Realtime Preview

目标：快速反馈，不追求最终精度。

- 由加载布局、拖动控件、参数变化触发。
- 走 `POST /api/preview/:biome`。
- 写入 `output/.preview/`。
- 即使用户选择了 `production` 或 `hero`，实时预览也会压到交互友好的 topology。
- 驱动当前 preview mesh、process field、process layer stack、2D map、3D preview 和质量面板。

Realtime preview 的承诺是“快”和“语义变化可读”，不是最终拓扑密度。

### High-res Inspect

目标：用户显式查看最终档位的真实效果。

- 只由 `Inspect <QUALITY>` 按钮触发。
- 走 `POST /api/inspect/:biome`。
- 写入 `output/.inspect/`。
- 严格使用当前 `Final Bake` 选择的质量档位，包括 `production` 和 `hero`。
- 它是一个快照。布局或质量档位变化后，它会变成 stale，不会自动重跑。

Inspect 不是实时编辑模式，它只是高精度确认。

### Final Generate

目标：写正式交付给 UE/PCG 的产物。

- 只由 `Generate Biome` 触发。
- 走 `POST /api/generate/:biome`。
- 写最终 OBJ、manifest、field、quality report 和 layout。
- 严格使用当前 `Final Bake` 质量档位。

Generate 是唯一应该被当成正式导出的路径。

## 前端 authoring 工作台

本地编辑器启动方式：

```powershell
node Tools\IslandMeshGen\web\server.mjs
```

打开：

```text
http://127.0.0.1:4177
```

当前 UI 已经具备：

- biome preset 切换
- final bake 质量档位
- generate 按钮
- 左侧 2D 语义 footprint / minimap
- 右侧 3D mesh preview
- `WebGL / Canvas` 渲染器切换
- `Inspect <QUALITY>` 高精度检查
- inspect current / stale 状态
- process layer rail
- Fire 控制分组
- quality issue 面板
- nudge 修复动作
- semantic JSON 预览

所以它现在不是“看 Python 输出”的页面，而是一个语义地形工作台。

## 渲染架构

### 左侧视口：Canvas 2D

左侧继续用 Canvas 是合理的。

职责：

- 俯视语义 footprint
- minimap 稳定 frame
- 与 3D 视口共享 yaw 方便对照
- mask / process / quality overlay
- map probe 命中区域
- 紧凑语义 legend

Canvas 在 2D authoring overlay 和 hit testing 上仍然很合适。

### 右侧视口：默认 WebGL

右侧 3D mesh preview 现在默认走 WebGL。

职责：

- 实时 3D 地形预览
- 高精度 GPU inspect 快照
- orbit camera 渲染
- face normal 光照
- material color
- process trace tint
- quality overlay
- pending movement overlay
- mesh delta pulse

WebGL 渲染是 demand-driven 的，不是永久热循环。只有状态变化、用户交互、短动画 pulse、transition 发生时才请求下一帧。

### Canvas fallback

右侧旧 Canvas 3D 预览还保留在 renderer toggle 里。

用途：

- WebGL 不可用时兜底
- debug 对比
- WebGL 路径继续成熟前的安全出口

WebGL 激活时，隐藏的 Canvas 3D 预览不会继续作为主 3D 后端重绘。

## WebGL 数据流

WebGL 当前把地形作为三角形 buffer 上传。

核心 attribute：

```text
aPosition  -> 顶点位置
aNormal    -> face normal，用于光照
aColor     -> 基础材质色 / process 色
aOverlay   -> 每个面上的 authoring overlay 颜色和 alpha
```

`aOverlay` 承载之前主要靠 Canvas 绘制的调参反馈：

- 当前激活的质量问题面
- mesh delta pulse
- pending movement highlight
- process movement highlight
- quality risk color

shader 会把 overlay 混进 lit material color，所以 WebGL 视口现在不是单纯看模型，而是 authoring feedback surface。

## Preview 和 Inspect 的状态边界

这轮落地里有一个很重要的 bug fix：inspect 数据不能污染 realtime preview。

现在 field 分成两份：

```text
currentField    -> 实时 preview / process field
gpuInspectField -> 高精度 inspect field
```

为什么要这样：

- Inspect 可能 bake `production` 或 `hero` 级别 field。
- Realtime preview 必须保持轻量。
- inspect 后拖参数，实时 overlay 不应该继续吃 hero / production field。
- 用户一开始拖 slider，就会先退出 GPU inspect，再请求 realtime preview redraw。

预期状态流：

```text
Inspect snapshot active
  -> 用户开始编辑
  -> 退出 inspect
  -> 标记 snapshot stale
  -> 回到 realtime preview
  -> 触发 preview bake
  -> preview fitted
```

这保证了 inspect 看得准，拖参数也不卡。

## 质量诊断与 nudge

平台现在有一条质量诊断和修复建议链路。

后端：

- `qualityReportForMesh(mesh, field, options)`
- preview / inspect / final generate 都会写 quality report JSON
- 报告包括 route health、detail risk、edge risk 和 issue list

前端：

- process layer stack 可以展示质量状态
- quality issue panel 列出可操作问题
- nudge 按钮会做保守参数调整
- preview bake 后可以显示风险改善情况

质量系统不是艺术评审，它是 whitebox 可用性的护栏，重点看：

- 路线是否被破坏
- detail 是否过度
- 边缘是否过薄
- 地形带是否容易碎或不稳定

## 性能决策

已经落地的性能决策：

- 实时 preview 会压到交互级 topology。
- inspect 是显式触发，不跟拖参数绑定。
- 右侧 3D 默认 WebGL。
- Canvas fallback 保留。
- WebGL 激活时跳过隐藏 Canvas 3D 重绘。
- WebGL 按需渲染，不开永久热循环。
- inspect field 和 realtime field 隔离。

当前主要性能成本已经不在视口 renderer，而在：

```text
Python bake -> OBJ / field / quality JSON 写入 -> server response -> OBJ parse -> WebGL buffer upload
```

如果后面又觉得卡，优先查这条 pipeline，不要第一反应怪 WebGL。

## 测试覆盖

当前 web tests 覆盖的平台 contract 包括：

- mesh preview 是 demand-driven，不是永久热循环
- high-res inspect 是显式 snapshot flow
- WebGL face normal 和补光
- WebGL 激活时跳过隐藏 Canvas redraw
- WebGL / Canvas renderer 可切换
- WebGL overlay attribute 数据流
- inspect field 与 preview field 隔离
- inspect 后拖 slider 会先退出 GPU inspect
- quality report 写入和读取
- quality nudge plan / result
- process layer stack 和 mask coverage
- preview / inspect signature 分离

验证命令：

```powershell
& 'C:\Users\12542\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe' --test 'Tools\IslandMeshGen\web\server_utils.test.mjs' 'Tools\IslandMeshGen\web\view_model.test.mjs'
```

最近一次验证结果：

```text
80 tests
80 pass
0 fail
```

## 已落地里程碑

### 语义地形 authoring

- semantic layout 数据模型
- fire / ice / forest 样例布局
- Fire volcano 本地 web editor
- biome chips 和 output metrics
- semantic JSON 视图
- Fire controls 分组
- auto-link coherence
- design health checks

### 图形数据流

- preview / inspect / generate 三路分离
- preview scratch artifacts
- inspect scratch artifacts
- final export artifacts
- preview quality cap
- inspect quality fidelity
- stale inspect state
- process field warmup
- process layer rail

### 可视化

- 2D semantic footprint canvas
- 2D / 3D yaw 联动
- 3D orbit camera
- WebGL realtime preview
- Canvas fallback renderer
- WebGL lighting 和 shadow lift
- WebGL authoring overlays
- dense inspect 可读性调整

### 质量闭环

- mesh / field quality metrics
- quality report generation
- quality issue panel
- map probe advisor
- conservative nudge plans
- nudge 前后风险总结

### 稳定性修复

- realtime preview 与 high-density final bake quality 解耦
- inspect 不写正式 output
- WebGL 激活时避免隐藏 Canvas redraw
- inspect field 不再污染 realtime preview field
- inspect 后拖 slider 会先退出 inspect，再回 realtime preview
- 浏览器 QA 检查了可见状态文案乱码

## 当前边界

### Layout 可编辑

用户控件和未来自动化都应该修改 semantic layout。

### Field 是派生物

process field 来自 bake。UI 和诊断可以读它，但它不是手动编辑的源头。

### Mesh 是派生物

mesh 是生成结果。编辑器可以 preview、inspect、export，但 authoring contract 仍然是 semantic layout first。

### Quality report 是建议

质量报告和 nudge 指导用户，不应该在没有明确用户动作时静默重写 layout。

### Inspect 是快照

Inspect 不是继续编辑的模式。用户一旦编辑，它就 stale，UI 回到 realtime preview。

## 已知缺口

这些是平台缺口，但不是当前 baseline 的阻塞：

- 还没有正式 JSON Schema 文件。
- web app 仍然主要集中在一个较大的 `app.js`。
- preview / inspect response 仍然传 OBJ text，并在客户端 parse。
- WebGL 现在是 flat face normals，不是 smooth normals 或完整材质系统。
- OBJ parse / buffer upload 还没有进 worker。
- 浏览器 QA 目前靠本地手动流程，没有提交完整 Playwright UI interaction suite。
- 3D renderer 是 custom WebGL，不是 Three.js 或 WebGPU。

## 建议的平台冻结线

作为当前平台 baseline，先停在这条线：

- WebGL 作为默认实时 3D preview。
- Canvas 作为 2D authoring 和 fallback。
- preview / inspect / generate 三路分离。
- quality report 保持 advisory 且显式。
- semantic layout 是唯一可编辑源头。

下一步平台工作应该小而偏 contract：

- 加 semantic layout schema。
- 加 golden fixtures。
- 加 payload / performance baseline。
- 如果 `app.js` 继续变痛，再拆 renderer / data-flow module。

不要急着大改 renderer。除非 bake / payload pipeline 证明 renderer 又变成主瓶颈。

## 未来改功能时的快速判断

先问这个功能属于哪一层：

```text
Authoring intent?       -> semantic layout / controls
Terrain computation?    -> deterministic bake
Process diagnostics?    -> field + quality report
Realtime feedback?      -> preview path + WebGL / Canvas overlays
Final verification?     -> inspect path
UE-facing artifact?     -> generate path
```

如果一个功能跨了多层，先写清楚 handoff。这个工具里大部分 bug 都来自把本该分开的层混到一起。
