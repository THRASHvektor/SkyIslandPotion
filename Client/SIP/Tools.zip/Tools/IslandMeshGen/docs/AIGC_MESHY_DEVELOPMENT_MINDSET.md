# AIGC / Meshy Development Mindset

Date: 2026-07-04

Scope: `Tools/IslandMeshGen`, semantic terrain baking, Meshy-assisted assets, and future plant-part generation.

## Core Rule

Meshy receives geometry, images, and prompts. IslandMeshGen owns semantics.

In practice:

- IslandMeshGen owns layout, playability, terrain masks, material slots, PCG intent, quality reports, and Unreal import contracts.
- Meshy may assist with PBR exploration, retexture experiments, donor rocks, crystals, roots, plant parts, seam collars, and optional visible-skin remeshes.
- Meshy must not become the authority for walkable paths, collision, gameplay topology, PCG bounds, or elemental reaction zones.

The useful mental split is:

```text
Send Meshy the flesh.
Keep the brain local.
```

## Current Terrain Problem

The current hero bake can express a volcano, approach route, crater loop, cliffs, and lava channels, but the result still reads too noisy compared with Gaea / Houdini terrain.

The main issue is not simply low mesh resolution. It is that high-frequency detail is still too close to direct noise-based geometry:

- random micro spikes affect the silhouette
- cliff and rim damage can look like sawtooth chatter
- path and arena protection is not strong enough
- all regions can become detailed in the same way
- the terrain does not yet feel like flow, slope, erosion, deposition, and strata have shaped it

Increasing hero resolution alone can make the same problem denser. The next algorithmic step should change the source of detail, not only the amount of detail.

## Terrain Direction

The main line remains self-authored semantic terrain.

Recommended order:

1. Add low-risk import-quality fixes:
   - smoothing groups or explicit normals
   - stronger path / arena / crater interior protection
   - reduce global high-frequency displacement intensity
2. Add mask-aware height relaxation:
   - path: strong smoothing
   - arena: medium smoothing
   - crater rim: preserve macro form, remove small sawtooth
   - lava channel: preserve incision center, smooth noisy shoulders
   - cliff: keep steepness, suppress random chatter
3. Build Fine Terrain Field v1:
   - `flow_accumulation_mask`
   - `curvature_mask`
   - `strata_mask`
4. Drive erosion / deposition from those masks:
   - erosion follows accumulated flow and slope
   - deposition collects in concave slope-foot regions
   - strata appears on cliffs, rims, and exposed convex shoulders
5. Export semantic material masks for Unreal PBR:
   - slope
   - talus
   - lava flow
   - curvature
   - strata
   - cavity
   - path wear
   - rim damage
   - ash deposit

Do not use Meshy remesh as the first answer to jagged terrain. Meshy can smooth or reorganize geometry, but it cannot reliably infer gameplay-safe landform process from our semantic intent.

## Meshy Role

Meshy is valuable as an AIGC asset forge, not as the terrain brain.

Good first uses:

- Retexture local terrain or terrain pieces to explore PBR direction.
- Generate basalt chunks, lava crust plates, vents, crystals, roots, flowers, seam collars, and other donor assets.
- Remesh donor assets for cleaner Unreal import.
- Produce hero visual-skin experiments for comparison.

Risky uses:

- Remeshing the main island and treating it as the new source of truth.
- Replacing the full terrain skeleton with an AI-generated mesh.
- Depending on Meshy to preserve walkable paths, material slot contracts, PCG zones, or collision intent.
- Assuming Meshy understands `field.json`, `manifest.json`, or `quality_report.json`.

## Meshy Agent Response Distillation

The Meshy agent confirmed the core boundary:

```text
Meshy is a visual asset tool, not a semantic understanding engine.
```

Important operational facts:

- Retexture can be guided by material regions, but it does not reliably lock output to named semantic regions.
- Input material slot boundaries are likely to survive, but this is not guaranteed with exact precision.
- Material slot names such as `M_TopGrass` or `M_ElementCrack` should not be treated as prompt-addressable controls.
- Too many slots weaken control; keep Retexture tests around 4-5 material regions.
- Emissive lava can be prompted, but it may bleed into visually similar areas.
- Colored semantic masks are possible but experimental; Meshy may treat colors as final appearance unless prompted very clearly.
- Reference images are more stable than pure color-mask semantics when trying to steer visual style.
- Remesh preserves scale and pivot reasonably well, but it merges hierarchy, rebuilds UVs, loses vertex colors, and can slightly shrink silhouettes.
- Retexture output is UV-baked PBR, not tileable procedural material.
- Meshy plant generation is better for full donor plants than socket-ready modular parts.

Updated interpretation:

```text
Meshy can make things look good quickly.
It cannot guarantee that things remain semantically organized.
```

Therefore:

- Option C is the first-choice workflow: Meshy generates standalone visual assets and donor parts; Unreal owns terrain materials.
- Option D is the second-choice workflow: Meshy remeshes a hero terrain duplicate as a visible skin; the original semantic mesh remains collision / PCG / gameplay proxy.
- Option A is only an experiment: colored-mask Retexture may work for concept validation, but not as a production contract.
- Option B is expensive: splitting regions, retexturing separately, and recombining may give control, but the engineering cost is high and style consistency is not guaranteed.

The upgraded working sentence is:

```text
Meshy makes assets look real.
IslandMeshGen makes the world generate for a reason.
Unreal turns those reasons into playable rules.
```

## Bake Outputs And Ownership

A full bake currently produces several sidecar files. They should not all be uploaded to Meshy.

| File | Meshy role | Local role |
| --- | --- | --- |
| `*.obj` / future `*.glb` / `*.fbx` | Can be sent as model input | Source mesh and Unreal import artifact |
| `*.field.json` | Not directly understood | Height data and process masks |
| `*.manifest.json` | Not directly understood | Biome tags, zones, paths, material slots, Unreal contract |
| `*.quality_report.json` | Not directly understood | Gatekeeping, diagnostics, acceptance checks |

The local pipeline should translate sidecar semantics into Meshy-friendly inputs:

```text
field / manifest / quality report
-> semantic material slots
-> colored mask materials
-> generated prompt
-> optional preview mask image
-> Meshy model or image input
```

## Semantic Meshy Input

The best first input format is a semantic masked model, preferably GLB/FBX rather than bare OBJ.

The model should preserve material regions:

- `M_TopGrass`
- `M_PathDirt`
- `M_CliffRock`
- `M_UndersideRock`
- `M_ElementCrack`

For Meshy, those material slots can be made visually explicit with temporary mask colors:

- top: neutral ash / gray-green
- path: ochre / yellow
- cliff: blue-gray
- underside: dark purple / black
- cracks: red / orange

The prompt must say that the input colors are semantic masks, not final colors.

Example:

```text
The input mesh uses colored material regions as semantic masks, not final colors.
Preserve the model shape, scale, and region layout.
Red/orange regions are glowing lava fissures with emissive PBR.
Ochre regions are compressed volcanic ash paths with fine gravel normal.
Blue-gray vertical regions are dark basalt cliffs with vertical strata.
Neutral top regions are cooled black volcanic soil with ash dust.
Dark underside regions are porous shadow rock.
No baked lighting.
```

Important caution:

Meshy may see material regions, object names, colors, or prompts, but unless the API explicitly guarantees region preservation, those are guidance, not a hard contract. Unreal master materials and our own masks remain the reliable production path.

After the Meshy agent response, treat this warning as a hard operating rule:

```text
Semantic masked Retexture is useful for exploration.
It is not a production-grade region-locked material system.
```

## Meshy Experiments

Treat Meshy terrain work as side-by-side experiments.

### Experiment A: Visible-Skin Remesh

```text
Hero semantic mesh
-> Meshy remesh duplicate
-> Unreal side-by-side comparison
```

Acceptance checks:

- scale preserved
- path still readable and flat enough
- crater silhouette preserved
- material regions not collapsed beyond use
- UE import succeeds
- visual spikes reduced

If accepted, this mesh can become a visible skin while the original semantic mesh remains collision / PCG / gameplay proxy.

### Experiment B: Retexture Exploration

```text
Semantic masked GLB
-> Meshy retexture
-> PBR visual proposal
```

Acceptance checks:

- lava crack regions remain visually distinct
- path reads as path
- cliff reads as basalt / strata
- no baked lighting
- output textures are usable as reference or prototype material inputs

If accepted, use it as a hero visual pass or material reference. Do not assume it replaces Unreal master material authoring.

## Plant Generation Policy

Do not make every PCG plant a runtime-assembled Blueprint actor.

Use two plant tiers.

### Bulk Flora

Large-scale background vegetation should be cheap:

```text
offline recipe
-> preassembled static mesh variants
-> PCG / HISM / ISM placement
```

These plants may use Meshy-generated donor parts, but they should be pre-baked into whole variants before mass placement.

### Interactive Flora

Gameplay plants can be dynamic:

```text
BP_ElementalPlantActor
-> root / stem / leaf / flower components
-> recipe-driven assembly
-> GameplayTags
-> interaction / reaction events
```

Use this only for resource plants, quest plants, elemental reaction plants, or hero objects.

Meshy-generated plant parts must pass a calibration step before entering a PartPool:

- pivot fixed
- scale normalized
- orientation normalized
- sockets or anchor metadata added
- material slots checked
- polygon budget checked
- biome affinity tagged
- seam hiding strategy assigned

## Plant Part Boundary

Meshy can generate plant parts, but it does not naturally produce modular socket-safe parts.

Do not assume Meshy output has:

- correct pivot
- top / bottom sockets
- consistent scale
- compatible seam profile
- stable material naming
- biome-consistent style

Meshy-agent-confirmed boundary:

- pivot placement is not guaranteed
- sockets / anchors are unsupported
- modular part generation is less reliable than whole-plant generation
- scale and connection-surface constraints are only visual guidance
- the recommended route is full plant generation, then DCC cutting and calibration

The local asset pipeline must own:

- socket alignment
- seam collars or node ornaments
- scale constraints
- biome compatibility rules
- Recipe / PartPool validation
- Unreal import naming

## Working Principle

The overall system should stay layered:

```text
Semantic Layout owns intent.
Terrain Field owns landform process.
Unreal Material owns reliable visual layering.
PCG owns scale.
Blueprint owns sparse interaction.
Meshy owns optional AIGC asset proposals.
```

This keeps the project explainable, debuggable, and demo-safe.
