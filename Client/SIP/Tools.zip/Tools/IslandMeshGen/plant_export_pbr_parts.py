#!/usr/bin/env python3
"""Export projection-assigned Meshy PBR parts as external glTF packages.

This is the first production-facing step after regrouping:

  Auto Split OBJ + regroup manifest + full PBR GLB
      -> semantic part glTF files preserving PBR material texture references

The exporter intentionally writes external `.gltf + .bin + textures/*` instead
of embedded GLB. That keeps the first cutter transparent and easy to inspect.
"""

from __future__ import annotations

import argparse
import copy
import json
import math
import re
import time
from collections import defaultdict
from pathlib import Path

import numpy as np

from plant_projection_diagnostics import (
    accessor_array,
    canonicalize,
    choose_axis_transform,
    deterministic_sample,
    load_manifest,
    parse_glb_tri_centers,
    parse_obj_tri_centers,
    read_glb,
    transform_normals,
    transform_points,
    transformed,
    world_matrices,
)


GROUP_ORDER = [
    "Core",
    "PrimarySilhouette",
    "OrbitSet",
    "BodyShell",
]

MIME_EXTENSION = {
    "image/jpeg": ".jpg",
    "image/png": ".png",
    "image/webp": ".webp",
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", required=True, help="Regroup manifest JSON.")
    split_source = parser.add_mutually_exclusive_group(required=True)
    split_source.add_argument("--split-obj", help="Meshy Auto Split OBJ.")
    split_source.add_argument("--split-glb", help="Meshy Auto Split/part-segmentation GLB.")
    parser.add_argument("--pbr-glb", required=True, help="Full PBR GLB.")
    parser.add_argument("--output-dir", required=True, help="Directory for exported part packages.")
    parser.add_argument("--report-output", help="Optional explicit export report JSON path.")
    parser.add_argument("--cell-size", type=float, default=0.028, help="Normalized spatial vote cell size.")
    parser.add_argument("--axis-split-sample", type=int, default=60_000, help="Split faces used for axis bootstrap.")
    parser.add_argument("--axis-pbr-sample", type=int, default=10_000, help="PBR faces used for axis bootstrap.")
    parser.add_argument("--min-faces", type=int, default=8, help="Do not export semantic groups below this face count.")
    parser.add_argument("--seed", type=int, default=23)
    return parser.parse_args()


def glb_first_triangle_primitive(path: Path):
    doc, bin_chunk = read_glb(path)
    matrices = world_matrices(doc)
    nodes = doc.get("nodes", [])
    meshes = doc.get("meshes", [])

    def read_primitive(primitive: dict, world: np.ndarray):
        attributes = primitive.get("attributes", {})
        if primitive.get("mode", 4) != 4 or "POSITION" not in attributes:
            return None
        positions = accessor_array(doc, bin_chunk, attributes["POSITION"]).astype(np.float32)
        positions = transform_points(positions, world)
        normals = accessor_array(doc, bin_chunk, attributes["NORMAL"]).astype(np.float32) if "NORMAL" in attributes else None
        if normals is not None:
            normals = transform_normals(normals, world)
        texcoords = accessor_array(doc, bin_chunk, attributes["TEXCOORD_0"]).astype(np.float32) if "TEXCOORD_0" in attributes else None
        tangents = accessor_array(doc, bin_chunk, attributes["TANGENT"]).astype(np.float32) if "TANGENT" in attributes else None
        if "indices" in primitive:
            indices = accessor_array(doc, bin_chunk, primitive["indices"]).astype(np.uint32).reshape(-1)
        else:
            indices = np.arange(len(positions), dtype=np.uint32)
        face_count = len(indices) // 3
        triangles = indices[: face_count * 3].reshape((-1, 3))
        centers = positions[triangles].mean(axis=1)
        return {
            "doc": doc,
            "bin_chunk": bin_chunk,
            "primitive": primitive,
            "positions": positions,
            "normals": normals,
            "texcoords": texcoords,
            "tangents": tangents,
            "triangles": triangles,
            "centers": centers.astype(np.float32),
            "material_index": int(primitive.get("material", 0)),
        }

    if nodes:
        for node_index, node in enumerate(nodes):
            if "mesh" not in node:
                continue
            mesh_index = int(node["mesh"])
            if not (0 <= mesh_index < len(meshes)):
                continue
            mesh = meshes[mesh_index]
            world = matrices.get(node_index, np.eye(4, dtype=np.float32))
            for primitive in mesh.get("primitives", []):
                result = read_primitive(primitive, world)
                if result is not None:
                    return result
    else:
        for mesh in meshes:
            for primitive in mesh.get("primitives", []):
                result = read_primitive(primitive, np.eye(4, dtype=np.float32))
                if result is not None:
                    return result
    raise ValueError("No triangle primitive with POSITION was found in PBR GLB.")


def build_cell_majority(points: np.ndarray, group_ids: np.ndarray, cell_size: float):
    cells = np.floor(points / cell_size).astype(np.int32)
    vote_map: dict[tuple[int, int, int], dict[int, int]] = defaultdict(lambda: defaultdict(int))
    for cell, group_id in zip(cells, group_ids):
        key = (int(cell[0]), int(cell[1]), int(cell[2]))
        vote_map[key][int(group_id)] += 1
    majority = {}
    for key, votes in vote_map.items():
        majority[key] = max(votes.items(), key=lambda item: item[1])[0]
    return majority


def assign_groups_by_cell_vote(points: np.ndarray, majority: dict[tuple[int, int, int], int], cell_size: float):
    offsets_by_radius = {
        radius: [
            (dx, dy, dz)
            for dx in range(-radius, radius + 1)
            for dy in range(-radius, radius + 1)
            for dz in range(-radius, radius + 1)
            if max(abs(dx), abs(dy), abs(dz)) == radius
        ]
        for radius in range(0, 5)
    }
    assigned = np.empty(len(points), dtype=np.int16)
    fallback_count = 0
    for i, point in enumerate(points):
        base = tuple(np.floor(point / cell_size).astype(np.int32).tolist())
        group_id = None
        for radius in range(0, 5):
            best_key = None
            best_distance = math.inf
            for dx, dy, dz in offsets_by_radius[radius]:
                key = (base[0] + dx, base[1] + dy, base[2] + dz)
                if key not in majority:
                    continue
                center = (np.asarray(key, dtype=np.float32) + 0.5) * cell_size
                distance = float(np.sum((center - point) ** 2))
                if distance < best_distance:
                    best_distance = distance
                    best_key = key
            if best_key is not None:
                group_id = majority[best_key]
                if radius > 0:
                    fallback_count += 1
                break
        if group_id is None:
            group_id = 0
            fallback_count += 1
        assigned[i] = int(group_id)
    return assigned, fallback_count


def extract_images(doc: dict, bin_chunk: bytes, texture_dir: Path, uri_prefix: str = "textures") -> tuple[list[dict], list[dict], list[dict]]:
    texture_dir.mkdir(parents=True, exist_ok=True)
    image_docs = []
    for index, image in enumerate(doc.get("images", [])):
        mime = image.get("mimeType", "image/jpeg")
        extension = MIME_EXTENSION.get(mime, ".bin")
        file_name = f"texture_{index}{extension}"
        if "bufferView" in image:
            buffer_view = doc["bufferViews"][image["bufferView"]]
            offset = int(buffer_view.get("byteOffset", 0))
            length = int(buffer_view["byteLength"])
            texture_dir.joinpath(file_name).write_bytes(bin_chunk[offset : offset + length])
        elif "uri" in image:
            file_name = Path(image["uri"]).name
        image_docs.append({"uri": f"{uri_prefix}/{file_name}", "mimeType": mime})
    return (
        copy.deepcopy(doc.get("samplers", [])),
        copy.deepcopy(doc.get("textures", [])),
        image_docs,
    )


def build_buffer_blob(parts: list[tuple[str, np.ndarray]]) -> tuple[bytes, list[dict], dict[str, int]]:
    blob = bytearray()
    buffer_views = []
    view_indices = {}
    for name, array in parts:
        while len(blob) % 4:
            blob.append(0)
        byte_offset = len(blob)
        data = np.ascontiguousarray(array).tobytes()
        blob.extend(data)
        view_indices[name] = len(buffer_views)
        target = 34963 if name == "indices" else 34962
        buffer_views.append({
            "buffer": 0,
            "byteOffset": byte_offset,
            "byteLength": len(data),
            "target": target,
        })
    return bytes(blob), buffer_views, view_indices


def accessor_doc(buffer_view: int, component_type: int, count: int, accessor_type: str, data: np.ndarray | None = None):
    doc = {
        "bufferView": buffer_view,
        "componentType": component_type,
        "count": int(count),
        "type": accessor_type,
    }
    if data is not None and data.size:
        doc["min"] = np.min(data, axis=0).astype(float).tolist()
        doc["max"] = np.max(data, axis=0).astype(float).tolist()
    return doc


def export_group_gltf(
    output_dir: Path,
    group_name: str,
    face_indices: np.ndarray,
    pbr: dict,
    material_docs: list[dict],
    sampler_docs: list[dict],
    texture_docs: list[dict],
    image_docs: list[dict],
) -> dict:
    safe_name = safe_file_name(group_name)
    group_dir = output_dir.joinpath(safe_name)
    group_dir.mkdir(parents=True, exist_ok=True)
    triangles = pbr["triangles"][face_indices]
    used_vertices, inverse = np.unique(triangles.reshape(-1), return_inverse=True)
    remapped_indices = inverse.astype(np.uint32).reshape((-1, 3))
    positions = pbr["positions"][used_vertices].astype(np.float32)
    binary_parts = [("positions", positions)]
    attributes = {"POSITION": 0}
    accessors = []

    if pbr["normals"] is not None:
        normals = pbr["normals"][used_vertices].astype(np.float32)
        binary_parts.append(("normals", normals))
    else:
        normals = None

    if pbr["texcoords"] is not None:
        texcoords = pbr["texcoords"][used_vertices].astype(np.float32)
        binary_parts.append(("texcoords", texcoords))
    else:
        texcoords = None

    if pbr["tangents"] is not None:
        tangents = pbr["tangents"][used_vertices].astype(np.float32)
        binary_parts.append(("tangents", tangents))
    else:
        tangents = None

    binary_parts.append(("indices", remapped_indices.reshape(-1).astype(np.uint32)))
    bin_blob, buffer_views, view_indices = build_buffer_blob(binary_parts)

    accessors.append(accessor_doc(view_indices["positions"], 5126, len(positions), "VEC3", positions))
    if normals is not None:
        attributes["NORMAL"] = len(accessors)
        accessors.append(accessor_doc(view_indices["normals"], 5126, len(normals), "VEC3"))
    if texcoords is not None:
        attributes["TEXCOORD_0"] = len(accessors)
        accessors.append(accessor_doc(view_indices["texcoords"], 5126, len(texcoords), "VEC2"))
    if tangents is not None:
        attributes["TANGENT"] = len(accessors)
        accessors.append(accessor_doc(view_indices["tangents"], 5126, len(tangents), "VEC4"))
    indices_accessor = len(accessors)
    accessors.append(accessor_doc(view_indices["indices"], 5125, remapped_indices.size, "SCALAR"))

    bin_name = f"{safe_name}.bin"
    gltf_name = f"{safe_name}.gltf"
    group_dir.joinpath(bin_name).write_bytes(bin_blob)
    gltf = {
        "asset": {
            "version": "2.0",
            "generator": "SkyIslandPotion plant_export_pbr_parts.py",
        },
        "scene": 0,
        "scenes": [{"nodes": [0]}],
        "nodes": [{"name": group_name, "mesh": 0}],
        "meshes": [{
            "name": group_name,
            "primitives": [{
                "attributes": attributes,
                "indices": indices_accessor,
                "mode": 4,
                "material": pbr["material_index"],
            }],
        }],
        "buffers": [{"uri": bin_name, "byteLength": len(bin_blob)}],
        "bufferViews": buffer_views,
        "accessors": accessors,
        "materials": material_docs,
        "samplers": sampler_docs,
        "textures": texture_docs,
        "images": image_docs,
    }
    group_dir.joinpath(gltf_name).write_text(json.dumps(gltf, indent=2) + "\n", encoding="utf-8")
    return {
        "group": group_name,
        "faces": int(len(face_indices)),
        "vertices": int(len(used_vertices)),
        "folder": str(group_dir),
        "gltf": str(group_dir.joinpath(gltf_name)),
        "bin": str(group_dir.joinpath(bin_name)),
    }


def safe_file_name(value: str) -> str:
    safe = re.sub(r"[^a-zA-Z0-9._-]+", "_", value).strip("_")
    return safe or "part"


def main() -> None:
    args = parse_args()
    started_at = time.perf_counter()
    manifest_path = Path(args.manifest)
    split_obj_path = Path(args.split_obj) if args.split_obj else None
    split_glb_path = Path(args.split_glb) if args.split_glb else None
    pbr_glb_path = Path(args.pbr_glb)
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    name_to_group, material_to_group, manifest = load_manifest(manifest_path)
    if split_glb_path:
        split_centers, split_group_ids, group_names, split_vertex_count = parse_glb_tri_centers(
            split_glb_path,
            name_to_group,
            material_to_group,
        )
        split_source_kind = "glb"
    elif split_obj_path:
        split_centers, split_group_ids, group_names, split_vertex_count = parse_obj_tri_centers(
            split_obj_path,
            name_to_group,
            material_to_group,
        )
        split_source_kind = "obj"
    else:
        raise ValueError("Provide either --split-obj or --split-glb.")
    pbr = glb_first_triangle_primitive(pbr_glb_path)
    split_normalized, split_bounds = canonicalize(split_centers)
    pbr_normalized, pbr_bounds = canonicalize(pbr["centers"])

    split_axis_idx = deterministic_sample(len(split_normalized), args.axis_split_sample, args.seed + 5)
    pbr_axis_idx = deterministic_sample(len(pbr_normalized), args.axis_pbr_sample, args.seed + 7)
    axis_transform = choose_axis_transform(
        split_normalized[split_axis_idx],
        pbr_normalized[pbr_axis_idx],
        split_group_ids[split_axis_idx],
        args.cell_size,
        args.seed,
    )
    split_projected = transformed(
        split_normalized,
        tuple(axis_transform["permutation"]),
        tuple(axis_transform["signs"]),
    )
    majority = build_cell_majority(split_projected, split_group_ids, args.cell_size)
    assigned_groups, fallback_count = assign_groups_by_cell_vote(pbr_normalized, majority, args.cell_size)

    sampler_docs, texture_docs, image_docs = extract_images(
        pbr["doc"],
        pbr["bin_chunk"],
        output_dir.joinpath("textures"),
        "../textures",
    )
    material_docs = copy.deepcopy(pbr["doc"].get("materials", []))

    exports = []
    for group_name in GROUP_ORDER:
        if group_name not in group_names:
            continue
        group_id = group_names.index(group_name)
        face_indices = np.nonzero(assigned_groups == group_id)[0]
        if len(face_indices) < args.min_faces:
            continue
        exports.append(export_group_gltf(
            output_dir,
            group_name,
            face_indices,
            pbr,
            material_docs,
            sampler_docs,
            texture_docs,
            image_docs,
        ))

    group_counts = {}
    for index, name in enumerate(group_names):
        group_counts[name] = int(np.sum(assigned_groups == index))

    report = {
        "schema": "SkyIslandPotion.PlantPbrPartExport.v1",
        "source": {
            "manifest": str(manifest_path),
            "split_obj": str(split_obj_path) if split_obj_path else None,
            "split_glb": str(split_glb_path) if split_glb_path else None,
            "split_source_kind": split_source_kind,
            "pbr_glb": str(pbr_glb_path),
            "manifest_source": manifest.get("source", {}),
        },
        "assignment": {
            "method": "axis_aligned_cell_majority_projection",
            "cell_size": args.cell_size,
            "axis_transform": {
                "split_axis_permutation_to_pbr": list(axis_transform["permutation"]),
                "split_axis_signs": list(axis_transform["signs"]),
                "selection_score": round(float(axis_transform["score"]), 6),
            },
            "fallback_faces": int(fallback_count),
            "fallback_ratio": round(float(fallback_count / max(len(pbr_normalized), 1)), 6),
        },
        "counts": {
            "split_vertices": int(split_vertex_count),
            "split_faces": int(len(split_centers)),
            "pbr_faces": int(len(pbr_normalized)),
            "pbr_vertices": int(len(pbr["positions"])),
            "pbr_material_slots": int(len(material_docs)),
            "pbr_images": int(len(image_docs)),
        },
        "bounds": {
            "split": split_bounds,
            "pbr": pbr_bounds,
        },
        "group_face_counts": group_counts,
        "exports": exports,
        "elapsed_ms": int(round((time.perf_counter() - started_at) * 1000)),
    }
    output_dir.joinpath("export_report.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    if args.report_output:
        report_output = Path(args.report_output)
        report_output.parent.mkdir(parents=True, exist_ok=True)
        report_output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
