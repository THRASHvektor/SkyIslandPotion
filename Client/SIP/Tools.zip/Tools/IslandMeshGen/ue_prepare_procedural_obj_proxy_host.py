import json

import unreal


DEFAULT_ARGS = {
    "label": "SIP_AIGC_CrownLily_C0_ProceduralProxy",
    "tag": "AIGCPlantC0ProceduralProxy",
    "location": [-1040.0, -520.0, 220.0],
    "rotation": [0.0, -18.0, 0.0],
}


def _args():
    if hasattr(unreal, "get_mcp_args"):
        incoming = unreal.get_mcp_args() or {}
        merged = dict(DEFAULT_ARGS)
        merged.update(incoming)
        return merged
    return DEFAULT_ARGS


def _clear_previous(tag, label):
    subsystem = unreal.get_editor_subsystem(unreal.EditorActorSubsystem)
    removed = 0
    for actor in subsystem.get_all_level_actors():
        if actor.get_actor_label() == label or any(str(actor_tag) == tag for actor_tag in actor.tags):
            subsystem.destroy_actor(actor)
            removed += 1
    return removed


def main():
    args = _args()
    location = unreal.Vector(float(args["location"][0]), float(args["location"][1]), float(args["location"][2]))
    rotation = unreal.Rotator(float(args["rotation"][0]), float(args["rotation"][1]), float(args["rotation"][2]))

    removed = _clear_previous(args["tag"], args["label"])
    subsystem = unreal.get_editor_subsystem(unreal.EditorActorSubsystem)
    actor = subsystem.spawn_actor_from_class(unreal.StaticMeshActor, location, rotation)
    actor.set_actor_label(args["label"])
    actor.tags = [
        args["tag"],
        "AIGCPreview",
        "AIGCPreview.CrownLily",
        "AIGCPreview.C0",
        "AIGCSmoke.ProceduralProxy",
    ]
    unreal.EditorLevelLibrary.set_selected_level_actors([actor])

    print(
        json.dumps(
            {
                "removed_previous_test_actors": removed,
                "spawned_actor": actor.get_actor_label(),
                "actor_name": actor.get_name(),
                "location": [location.x, location.y, location.z],
                "rotation": [rotation.roll, rotation.pitch, rotation.yaw],
            },
            indent=2,
        )
    )


main()
