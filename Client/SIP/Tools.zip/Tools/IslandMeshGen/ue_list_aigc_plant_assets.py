import json

import unreal


def main():
    registry = unreal.AssetRegistryHelpers.get_asset_registry()
    assets = registry.get_assets_by_path("/Game/AIGC/Plants", True)
    rows = []
    for asset in assets:
        class_name = str(asset.asset_class_path.asset_name) if hasattr(asset, "asset_class_path") else str(asset.asset_class)
        if class_name not in ("StaticMesh", "Material", "MaterialInstanceConstant", "Texture2D"):
            continue
        package = str(asset.package_name)
        parts = package.split("/")
        family = parts[4] if len(parts) > 4 else ""
        collapse = parts[5] if len(parts) > 5 else ""
        rows.append(
            {
                "family": family,
                "collapse": collapse,
                "name": str(asset.asset_name),
                "class": class_name,
                "path": package,
            }
        )
    rows.sort(key=lambda row: (row["family"], row["collapse"], row["class"], row["name"]))
    print(json.dumps(rows, indent=2))


main()
