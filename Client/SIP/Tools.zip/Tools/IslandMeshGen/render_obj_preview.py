from __future__ import annotations

import argparse
import math
from pathlib import Path

from PIL import Image, ImageDraw


MATERIAL_COLORS = {
    "M_AshPlateau": (73, 69, 58),
    "M_TopGrass": (73, 69, 58),
    "M_PathDirt": (178, 112, 41),
    "M_CliffRock": (47, 50, 54),
    "M_UndersideRock": (32, 36, 42),
    "M_ElementCrack": (222, 57, 24),
}


def _parse_obj(path: Path) -> tuple[list[tuple[float, float, float]], list[tuple[str, list[int]]]]:
    vertices: list[tuple[float, float, float]] = []
    faces: list[tuple[str, list[int]]] = []
    material = "M_TopGrass"
    for line in path.read_text(encoding="utf-8").splitlines():
        if line.startswith("v "):
            _tag, x, y, z = line.split()
            vertices.append((float(x), float(y), float(z)))
        elif line.startswith("usemtl "):
            material = line.split(maxsplit=1)[1]
        elif line.startswith("f "):
            indices = [int(part.split("/")[0]) - 1 for part in line.split()[1:]]
            faces.append((material, indices))
    return vertices, faces


def _normal(points: list[tuple[float, float, float]]) -> tuple[float, float, float]:
    if len(points) < 3:
        return (0.0, 0.0, 1.0)
    ax, ay, az = points[1][0] - points[0][0], points[1][1] - points[0][1], points[1][2] - points[0][2]
    bx, by, bz = points[2][0] - points[0][0], points[2][1] - points[0][1], points[2][2] - points[0][2]
    nx = ay * bz - az * by
    ny = az * bx - ax * bz
    nz = ax * by - ay * bx
    length = math.sqrt(nx * nx + ny * ny + nz * nz)
    if length <= 0.001:
        return (0.0, 0.0, 1.0)
    return (nx / length, ny / length, nz / length)


def _shade(color: tuple[int, int, int], points: list[tuple[float, float, float]]) -> tuple[int, int, int]:
    nx, ny, nz = _normal(points)
    lx, ly, lz = (-0.38, -0.46, 0.80)
    light = max(0.0, nx * lx + ny * ly + nz * lz)
    amount = 0.56 + light * 0.48
    return tuple(max(0, min(255, round(channel * amount))) for channel in color)


def render_obj_preview(obj_path: Path, output_path: Path, width: int = 1600, height: int = 900) -> None:
    vertices, faces = _parse_obj(obj_path)
    yaw = math.radians(-38.0)
    pitch_scale = 0.42

    projected = []
    for x, y, z in vertices:
        rx = x * math.cos(yaw) - y * math.sin(yaw)
        ry = x * math.sin(yaw) + y * math.cos(yaw)
        sx = rx
        sy = ry * pitch_scale - z * 0.92
        projected.append((sx, sy))

    min_x = min(x for x, _ in projected)
    max_x = max(x for x, _ in projected)
    min_y = min(y for _, y in projected)
    max_y = max(y for _, y in projected)
    scale = min((width * 0.88) / max(1.0, max_x - min_x), (height * 0.78) / max(1.0, max_y - min_y))
    offset_x = width * 0.5 - (min_x + max_x) * 0.5 * scale
    offset_y = height * 0.52 - (min_y + max_y) * 0.5 * scale

    draw_faces = []
    for material, indices in faces:
        points3 = [vertices[index] for index in indices]
        points2 = [(projected[index][0] * scale + offset_x, projected[index][1] * scale + offset_y) for index in indices]
        depth = sum((vertices[index][0] * 0.32 + vertices[index][1] * 0.48 + vertices[index][2] * 0.12) for index in indices) / len(indices)
        draw_faces.append((depth, material, points3, points2))

    image = Image.new("RGB", (width, height), (11, 13, 18))
    draw = ImageDraw.Draw(image)
    for _depth, material, points3, points2 in sorted(draw_faces, key=lambda item: item[0]):
        color = _shade(MATERIAL_COLORS.get(material, (120, 120, 120)), points3)
        draw.polygon(points2, fill=color)

    output_path.parent.mkdir(parents=True, exist_ok=True)
    image.save(output_path)


def main() -> None:
    parser = argparse.ArgumentParser(description="Render a quick isometric preview of an IslandMeshGen OBJ.")
    parser.add_argument("--obj", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    render_obj_preview(args.obj, args.output)
    print(f"Wrote {args.output}")


if __name__ == "__main__":
    main()
