from __future__ import annotations

import json
import sys

from soft_ue_cli.client import call_tool


def main() -> int:
    result = call_tool(
        "run-python-script",
        {"script_path": r"C:\Users\12542\Documents\Unreal Projects\SkyIslandPotion\Tools\IslandMeshGen\ue_python_smoke.py"},
        timeout=30,
    )
    print(json.dumps(result, indent=2, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
