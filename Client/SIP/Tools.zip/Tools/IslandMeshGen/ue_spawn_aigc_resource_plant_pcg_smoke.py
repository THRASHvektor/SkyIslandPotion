import json
import sys
from pathlib import Path

import unreal


def _tool_script_dir():
    script_path = globals().get("__file__")
    if script_path:
        return Path(script_path).resolve().parent

    project_dir = Path(unreal.Paths.project_dir()).resolve()
    candidates = [
        project_dir.parents[1] / "Tools" / "IslandMeshGen",
        project_dir.parent / "Tools" / "IslandMeshGen",
        Path.cwd(),
    ]
    for candidate in candidates:
        if (candidate / "plant_collapse_sampler.py").exists():
            return candidate
    return candidates[0]


TOOL_DIR = _tool_script_dir()
sys.path.insert(0, str(TOOL_DIR))

from plant_collapse_sampler import BANDS, FAMILIES, SLOTS, vector_slug
from plant_recipe_asset_plan import RECIPE_ASSET_ROOT


TEST_TAG = "AIGCResourcePlantPCGSmokeTest"
LABEL_PREFIX = "SIP_AIGC_PCG_ResourcePlant"

SLOT_COMPONENT_PROPERTY = {
    "BodyShell": "body_shell_root_slot",
    "PrimarySilhouette": "primary_silhouette_slot",
    "Core": "core_slot",
    "OrbitSet": "orbit_node_a_slot",
}

DEFAULT_ARGS = {
    "families": list(FAMILIES),
    "bands": list(BANDS),
    "seed": 8107,
    "origin": [-2100.0, -900.0, 120.0],
    "family_spacing_y": 1450.0,
    "band_spacing_x": 920.0,
    "scale": 1.0,
    "temperature_scale": 1.0,
    "recipe_asset_package_path": RECIPE_ASSET_ROOT,
    "configuration_mode": "property",
    "clear_previous": True,
    "select_spawned": True,
}


def _get_args():
    args = dict(DEFAULT_ARGS)
    if hasattr(unreal, "get_mcp_args"):
        supplied = unreal.get_mcp_args()
        if isinstance(supplied, dict):
            args.update(supplied)
    args["families"] = [str(value) for value in args["families"]]
    args["bands"] = [str(value) for value in args["bands"]]
    args["seed"] = int(args["seed"])
    args["origin"] = [float(value) for value in args["origin"]]
    args["family_spacing_y"] = float(args["family_spacing_y"])
    args["band_spacing_x"] = float(args["band_spacing_x"])
    args["scale"] = max(0.1, float(args["scale"]))
    args["temperature_scale"] = float(args["temperature_scale"])
    args["recipe_asset_package_path"] = str(args["recipe_asset_package_path"])
    args["configuration_mode"] = str(args["configuration_mode"]).strip().lower()
    return args


def _normalize_name(value):
    return "".join(ch for ch in str(value).lower() if ch.isalnum())


def _get_unreal_type(*names):
    for name in names:
        value = getattr(unreal, name, None)
        if value is not None:
            return value
    return None


def _enum_value(type_name, value):
    enum_type = _get_unreal_type(type_name, type_name[1:] if type_name.startswith("E") else type_name)
    if enum_type is None:
        raise RuntimeError("Missing reflected enum type {}".format(type_name))

    wanted = _normalize_name(value)
    for attr in dir(enum_type):
        if attr.startswith("_"):
            continue
        if _normalize_name(attr) == wanted:
            return getattr(enum_type, attr)

    for attr in dir(enum_type):
        if attr.startswith("_"):
            continue
        normalized = _normalize_name(attr)
        if wanted in normalized or normalized in wanted:
            return getattr(enum_type, attr)

    raise RuntimeError("Cannot resolve enum {}.{}".format(type_name, value))


def _get_editor_property(obj, names):
    errors = []
    for name in names:
        try:
            return obj.get_editor_property(name)
        except Exception as exc:
            errors.append("{}: {}".format(name, exc))
    raise RuntimeError("Could not get property on {}. Tried {}. Errors: {}".format(obj, names, errors))


def _set_editor_property(obj, names, value):
    errors = []
    for name in names:
        try:
            obj.set_editor_property(name, value)
            return name
        except Exception as exc:
            errors.append("{}: {}".format(name, exc))
    raise RuntimeError("Could not set property on {}. Tried {}. Errors: {}".format(obj, names, errors))


def _package_path(asset):
    if asset is None:
        return None
    return str(asset.get_path_name()).split(".")[0]


def _recipe_id_for_family(family):
    return "AIGC_{}".format(family)


def _recipe_asset_path(package_path, family):
    return "{}/DA_{}".format(package_path, _recipe_id_for_family(family))


def _load_recipe_assets(families, package_path):
    recipe_type = _get_unreal_type("SIPResourcePlantRecipe")
    if recipe_type is None:
        raise RuntimeError("Missing reflected USIPResourcePlantRecipe class. Rebuild the SIP editor module first.")

    loaded = {}
    missing = []
    for family in families:
        object_path = _recipe_asset_path(package_path, family)
        asset = unreal.EditorAssetLibrary.load_asset(object_path)
        if isinstance(asset, recipe_type):
            loaded[family] = asset
        else:
            missing.append(object_path)
    return loaded, missing


def _location(args, family_index, band_index):
    return unreal.Vector(
        args["origin"][0] + band_index * args["band_spacing_x"],
        args["origin"][1] + family_index * args["family_spacing_y"],
        args["origin"][2],
    )


def _clear_previous():
    subsystem = unreal.get_editor_subsystem(unreal.EditorActorSubsystem)
    removed = 0
    for actor in list(subsystem.get_all_level_actors()):
        label = actor.get_actor_label()
        has_test_tag = any(str(tag) == TEST_TAG for tag in actor.tags)
        if has_test_tag or label.startswith(LABEL_PREFIX):
            subsystem.destroy_actor(actor)
            removed += 1
    return removed


def _spawn_actor(actor_class, label, location):
    subsystem = unreal.get_editor_subsystem(unreal.EditorActorSubsystem)
    actor = subsystem.spawn_actor_from_class(actor_class, location, unreal.Rotator(0.0, 0.0, 0.0))
    actor.set_actor_label(label)
    actor.tags = [unreal.Name(TEST_TAG)]
    return actor


def _collapse_vector_to_dict(vector):
    return {
        "BodyShell": int(_get_editor_property(vector, ("body_shell", "BodyShell"))),
        "PrimarySilhouette": int(_get_editor_property(vector, ("primary_silhouette", "PrimarySilhouette"))),
        "Core": int(_get_editor_property(vector, ("core", "Core"))),
        "OrbitSet": int(_get_editor_property(vector, ("orbit_set", "OrbitSet"))),
    }


def _configure_actor_from_pcg(actor, recipe, family, band, seed, scale, temperature_scale):
    return _configure_actor_with_function(actor, recipe, family, band, seed, scale, temperature_scale)


def _configure_actor_with_function(actor, recipe, family, band, seed, scale, temperature_scale):
    if not hasattr(actor, "configure_from_pcg"):
        raise RuntimeError(
            "ASIPResourcePlantActor.configure_from_pcg is not reflected. "
            "Rebuild/relaunch the SIP editor module after adding ConfigureFromPCG."
        )

    returned_vector = actor.configure_from_pcg(
        recipe,
        _enum_value("SIPResourcePlantPreviewFamily", family),
        _enum_value("SIPResourcePlantCollapseBand", band),
        int(seed),
        float(scale),
        float(temperature_scale),
        False,
    )
    return _collapse_vector_to_dict(returned_vector)


def _configure_actor_with_properties(actor, recipe, family, band, seed, scale, temperature_scale):
    if not hasattr(actor, "apply_pcg_property_configuration"):
        raise RuntimeError(
            "ASIPResourcePlantActor.apply_pcg_property_configuration is not reflected. "
            "Rebuild/relaunch the SIP editor module after adding ApplyPCGPropertyConfiguration."
        )

    _set_editor_property(actor, ("configure_from_pcg_properties", "b_configure_from_pcg_properties", "bConfigureFromPCGProperties"), True)
    _set_editor_property(actor, ("plant_recipe", "PlantRecipe"), recipe)
    _set_editor_property(actor, ("preview_family", "PreviewFamily"), _enum_value("SIPResourcePlantPreviewFamily", family))
    _set_editor_property(actor, ("collapse_band", "CollapseBand"), _enum_value("SIPResourcePlantCollapseBand", band))
    _set_editor_property(actor, ("plant_seed", "PlantSeed"), int(seed))
    _set_editor_property(actor, ("plant_scale", "PlantScale"), float(scale))
    _set_editor_property(actor, ("collapse_temperature_scale", "CollapseTemperatureScale"), float(temperature_scale))
    _set_editor_property(actor, ("use_recipe_default_collapse_band", "b_use_recipe_default_collapse_band", "bUseRecipeDefaultCollapseBand"), False)

    returned_vector = actor.apply_pcg_property_configuration()
    return _collapse_vector_to_dict(returned_vector)


def _configure_actor(actor, recipe, family, band, seed, scale, temperature_scale, configuration_mode):
    if configuration_mode == "function":
        return _configure_actor_with_function(actor, recipe, family, band, seed, scale, temperature_scale)
    if configuration_mode == "property":
        return _configure_actor_with_properties(actor, recipe, family, band, seed, scale, temperature_scale)
    raise RuntimeError("Unsupported configuration_mode {!r}. Expected 'property' or 'function'.".format(configuration_mode))


def _component_material_overrides(component):
    try:
        overrides = component.get_editor_property("override_materials")
    except Exception:
        try:
            overrides = component.get_editor_property("OverrideMaterials")
        except Exception:
            return []

    return [
        str(material.get_path_name())
        for material in list(overrides)
        if material is not None
    ]


def _verify_actor(actor, family, vector):
    slot_results = {}
    mesh_mismatches = []
    material_overrides = []

    for slot, component_property in SLOT_COMPONENT_PROPERTY.items():
        component = _get_editor_property(actor, (component_property,))
        mesh = _get_editor_property(component, ("static_mesh", "StaticMesh"))
        actual = _package_path(mesh)
        level = int(vector[slot])
        expected = "/Game/AIGC/Plants/{}/C{}/{}".format(family, level, slot)
        overrides = _component_material_overrides(component)
        ok = actual == expected

        slot_results[slot] = {
            "expected": expected,
            "actual": actual,
            "collapse_level": level,
            "material_override_count": len(overrides),
            "material_overrides": overrides,
            "ok": ok and not overrides,
        }

        if not ok:
            mesh_mismatches.append({"slot": slot, "expected": expected, "actual": actual})
        for override in overrides:
            material_overrides.append({"slot": slot, "override": override})

    return slot_results, mesh_mismatches, material_overrides


def _select_spawned(actors):
    unreal.EditorLevelLibrary.set_selected_level_actors(actors)


def _validate_reflection_ready():
    required_types = [
        "SIPResourcePlantActor",
        "SIPResourcePlantRecipe",
        "SIPResourcePlantCollapseVector",
        "SIPResourcePlantPreviewFamily",
        "SIPResourcePlantCollapseBand",
    ]
    missing = [type_name for type_name in required_types if _get_unreal_type(type_name) is None]
    if missing:
        raise RuntimeError(
            "SIP plant reflection is stale or incomplete. Missing {}. "
            "Run a SIP editor rebuild/relaunch before the PCG smoke test.".format(missing)
        )


def main():
    args = _get_args()
    _validate_reflection_ready()

    actor_class = _get_unreal_type("SIPResourcePlantActor")
    recipes, missing_recipes = _load_recipe_assets(args["families"], args["recipe_asset_package_path"])
    removed = _clear_previous() if bool(args["clear_previous"]) else 0

    spawned = []
    results = []
    all_mesh_mismatches = []
    all_material_overrides = []

    for family_index, family in enumerate(args["families"]):
        recipe = recipes.get(family)
        if recipe is None:
            continue

        for band_index, band in enumerate(args["bands"]):
            seed = args["seed"] + family_index * 1000 + band_index * 100
            label = "{}_{}_{}_Seed{}".format(LABEL_PREFIX, family, band, seed)
            actor = _spawn_actor(actor_class, label, _location(args, family_index, band_index))
            actor.tags = [
                unreal.Name(TEST_TAG),
                unreal.Name("{}.{}".format(TEST_TAG, family)),
                unreal.Name("{}.Band.{}".format(TEST_TAG, band)),
            ]

            vector = _configure_actor(
                actor,
                recipe,
                family,
                band,
                seed,
                args["scale"],
                args["temperature_scale"],
                args["configuration_mode"],
            )
            slot_results, mesh_mismatches, material_overrides = _verify_actor(actor, family, vector)
            vector_name = vector_slug(vector)
            actor.set_actor_label("{}_{}_{}_{}".format(LABEL_PREFIX, family, band, vector_name))

            spawned.append(actor)
            all_mesh_mismatches.extend(
                [
                    {
                        "actor_label": actor.get_actor_label(),
                        **mismatch,
                    }
                    for mismatch in mesh_mismatches
                ]
            )
            all_material_overrides.extend(
                [
                    {
                        "actor_label": actor.get_actor_label(),
                        **override,
                    }
                    for override in material_overrides
                ]
            )
            results.append(
                {
                    "label": actor.get_actor_label(),
                    "family": family,
                    "band": band,
                    "seed": seed,
                    "recipe_asset": _recipe_asset_path(args["recipe_asset_package_path"], family),
                    "collapse_vector": vector,
                    "slot_verification": slot_results,
                }
            )

    if args["select_spawned"]:
        _select_spawned(spawned)

    print(
        json.dumps(
            {
                "schema": "SkyIslandPotion.AIGCPlantPCGSmoke.v0",
                "configuration_mode": args["configuration_mode"],
                "removed_previous_test_actors": removed,
                "spawned_actor_count": len(spawned),
                "selected_spawned": bool(args["select_spawned"]),
                "missing_recipe_count": len(missing_recipes),
                "missing_recipes": missing_recipes,
                "mesh_mismatch_count": len(all_mesh_mismatches),
                "mesh_mismatches": all_mesh_mismatches,
                "material_override_count": len(all_material_overrides),
                "material_overrides": all_material_overrides,
                "results": results,
            },
            indent=2,
            ensure_ascii=False,
        )
    )


main()
