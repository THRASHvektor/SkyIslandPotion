import json

import unreal


LABEL = "SIP_AIGC_CrownLily_C0_ProceduralProxy"


def main():
    subsystem = unreal.get_editor_subsystem(unreal.EditorActorSubsystem)
    actors = [actor for actor in subsystem.get_all_level_actors() if actor.get_actor_label() == LABEL]
    summary = {"actor_count": len(actors), "label": LABEL}
    if actors:
        components = actors[0].get_components_by_class(unreal.ProceduralMeshComponent)
        material = components[0].get_material(0) if components else None
        summary.update(
            {
                "component_count": len(components),
                "sections": components[0].get_num_sections() if components and hasattr(components[0], "get_num_sections") else None,
                "material": material.get_path_name() if material else None,
                "component_active": components[0].is_active() if components else None,
                "component_visible": components[0].is_visible() if components else None,
                "base_texture_exists": unreal.EditorAssetLibrary.does_asset_exist("/Game/AIGC/Plants/CrownLily/C0/Textures/T_CrownLily_C0_BaseColor"),
                "metal_rough_texture_exists": unreal.EditorAssetLibrary.does_asset_exist("/Game/AIGC/Plants/CrownLily/C0/Textures/T_CrownLily_C0_MetalRough"),
                "normal_texture_exists": unreal.EditorAssetLibrary.does_asset_exist("/Game/AIGC/Plants/CrownLily/C0/Textures/T_CrownLily_C0_Normal"),
                "emissive_texture_exists": unreal.EditorAssetLibrary.does_asset_exist("/Game/AIGC/Plants/CrownLily/C0/Textures/T_CrownLily_C0_Emissive"),
            }
        )
    print(json.dumps(summary, indent=2))


main()
