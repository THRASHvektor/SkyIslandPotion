import json
import sys
from pathlib import Path

import unreal


def _tool_script_dir():
    script_path = globals().get("__file__")
    if script_path:
        return Path(script_path).resolve().parent

    project_dir = Path(unreal.Paths.project_dir()).resolve()
    candidates = [
        project_dir.parents[1] / "Tools" / "IslandMeshGen",
        project_dir.parent / "Tools" / "IslandMeshGen",
        Path.cwd(),
    ]
    for candidate in candidates:
        if (candidate / "plant_actor_spawn_plan.py").exists():
            return candidate
    return candidates[0]


TOOL_DIR = _tool_script_dir()
sys.path.insert(0, str(TOOL_DIR))

from plant_actor_spawn_plan import build_actor_spawn_plan
from plant_aigc_asset_catalog import AIGC_PLANT_ROOT, build_asset_audit, build_recipe_plan
from plant_collapse_sampler import BANDS, FAMILIES, SLOTS
from plant_recipe_asset_plan import RECIPE_ASSET_ROOT


TEST_TAG = "AIGCResourcePlantActorRandomTest"
LABEL_PREFIX = "SIP_AIGC_ResourcePlant"
DEFAULT_RECIPE_PLAN = TOOL_DIR / "output" / "plant_recipe_plans" / "aigc_plant_asset_audit_recipe_plan.json"

SLOT_COMPONENT_PROPERTY = {
    "BodyShell": "body_shell_root_slot",
    "PrimarySilhouette": "primary_silhouette_slot",
    "Core": "core_slot",
    "OrbitSet": "orbit_node_a_slot",
}


DEFAULT_ARGS = {
    "recipe_plan_path": str(DEFAULT_RECIPE_PLAN),
    "samples_per_band": 2,
    "seed": 7307,
    "origin": [-2100.0, 700.0, 120.0],
    "family_spacing_y": 1450.0,
    "band_spacing_x": 920.0,
    "sample_spacing_y": 470.0,
    "scale": 1.0,
    "temperature_scale": 1.0,
    "use_live_asset_registry": True,
    "use_persistent_recipe_assets": True,
    "recipe_asset_package_path": RECIPE_ASSET_ROOT,
    "fallback_to_transient_recipe": True,
    "clear_previous": True,
    "select_spawned": True,
}


def _get_args():
    args = dict(DEFAULT_ARGS)
    if hasattr(unreal, "get_mcp_args"):
        supplied = unreal.get_mcp_args()
        if isinstance(supplied, dict):
            args.update(supplied)
    args["recipe_plan_path"] = Path(args["recipe_plan_path"])
    args["samples_per_band"] = max(1, int(args["samples_per_band"]))
    args["seed"] = int(args["seed"])
    args["origin"] = [float(value) for value in args["origin"]]
    args["scale"] = max(0.01, float(args["scale"]))
    args["temperature_scale"] = float(args["temperature_scale"])
    args["recipe_asset_package_path"] = str(args["recipe_asset_package_path"])
    return args


def _class_name(asset_data):
    if hasattr(asset_data, "asset_class_path"):
        return str(asset_data.asset_class_path.asset_name)
    return str(asset_data.asset_class)


def _collect_static_mesh_paths():
    registry = unreal.AssetRegistryHelpers.get_asset_registry()
    registry.scan_paths_synchronous([AIGC_PLANT_ROOT], True)
    return sorted(
        {
            str(asset.package_name)
            for asset in registry.get_assets_by_path(AIGC_PLANT_ROOT, True)
            if _class_name(asset) == "StaticMesh"
        }
    )


def _load_recipe_plan(args):
    if bool(args.get("use_live_asset_registry", True)):
        static_mesh_paths = _collect_static_mesh_paths()
        audit = build_asset_audit(static_mesh_paths)
        return (
            build_recipe_plan(audit, include_incomplete=True),
            "live_asset_registry_partial_recipe_plan",
            {
                "static_mesh_count": len(static_mesh_paths),
                "complete_families": audit["summary"]["complete_families"],
                "incomplete_families": audit["summary"]["incomplete_families"],
            },
        )

    return (
        json.loads(args["recipe_plan_path"].read_text(encoding="utf-8")),
        str(args["recipe_plan_path"]),
        None,
    )


def _normalize_name(value):
    return "".join(ch for ch in str(value).lower() if ch.isalnum())


def _get_unreal_type(*names):
    for name in names:
        value = getattr(unreal, name, None)
        if value is not None:
            return value
    return None


def _enum_value(type_name, value):
    enum_type = _get_unreal_type(type_name, type_name[1:] if type_name.startswith("E") else type_name)
    if enum_type is None:
        raise RuntimeError("Missing reflected enum type {}".format(type_name))

    wanted = _normalize_name(value)
    for attr in dir(enum_type):
        if attr.startswith("_"):
            continue
        if _normalize_name(attr) == wanted:
            return getattr(enum_type, attr)

    for attr in dir(enum_type):
        if attr.startswith("_"):
            continue
        if wanted in _normalize_name(attr) or _normalize_name(attr) in wanted:
            return getattr(enum_type, attr)

    raise RuntimeError("Cannot resolve enum {}.{} from reflected values {}".format(type_name, value, dir(enum_type)))


def _set_editor_property(obj, names, value):
    errors = []
    for name in names:
        try:
            obj.set_editor_property(name, value)
            return name
        except Exception as exc:
            errors.append("{}: {}".format(name, exc))
    raise RuntimeError("Could not set property on {}. Tried {}. Errors: {}".format(obj, names, errors))


def _get_editor_property(obj, names):
    errors = []
    for name in names:
        try:
            return obj.get_editor_property(name)
        except Exception as exc:
            errors.append("{}: {}".format(name, exc))
    raise RuntimeError("Could not get property on {}. Tried {}. Errors: {}".format(obj, names, errors))


def _load_static_mesh(asset_path):
    if not asset_path:
        return None

    asset = unreal.EditorAssetLibrary.load_asset(asset_path)
    if isinstance(asset, unreal.StaticMesh):
        return asset
    return None


class AssetResolver:
    def __init__(self):
        self.cache = {}
        self.events = []

    def resolve(self, family, slot, level):
        key = (family, slot, int(level))
        if key in self.cache:
            return self.cache[key]

        requested_path = "/Game/AIGC/Plants/{}/C{}/{}".format(family, level, slot)
        if _load_static_mesh(requested_path):
            self.cache[key] = requested_path
            return requested_path

        candidates = []
        for candidate_level in range(4):
            candidate_path = "/Game/AIGC/Plants/{}/C{}/{}".format(family, candidate_level, slot)
            if _load_static_mesh(candidate_path):
                candidates.append((candidate_level, candidate_path))

        if candidates:
            resolved_level, resolved_path = min(candidates, key=lambda item: (abs(item[0] - int(level)), item[0]))
            self.events.append(
                {
                    "family": family,
                    "slot": slot,
                    "requested_level": int(level),
                    "requested_path": requested_path,
                    "resolved_level": resolved_level,
                    "resolved_path": resolved_path,
                    "mode": "nearest_available_collapse_level",
                }
            )
            self.cache[key] = resolved_path
            return resolved_path

        self.events.append(
            {
                "family": family,
                "slot": slot,
                "requested_level": int(level),
                "requested_path": requested_path,
                "resolved_level": None,
                "resolved_path": None,
                "mode": "hide_slot_no_available_mesh",
            }
        )
        self.cache[key] = None
        return None


def _package_path(asset):
    if asset is None:
        return None
    return str(asset.get_path_name()).split(".")[0]


def _set_mesh_property(obj, asset_path):
    if not asset_path:
        return False

    mesh = _load_static_mesh(asset_path)
    if mesh is None:
        return False

    try:
        _set_editor_property(obj, ("mesh", "Mesh"), mesh)
        return True
    except Exception:
        _set_editor_property(obj, ("mesh", "Mesh"), unreal.SoftObjectPath(asset_path))
        return True


def _clear_previous():
    subsystem = unreal.get_editor_subsystem(unreal.EditorActorSubsystem)
    removed = 0
    for actor in list(subsystem.get_all_level_actors()):
        label = actor.get_actor_label()
        has_test_tag = any(str(tag) == TEST_TAG for tag in actor.tags)
        if has_test_tag or label.startswith(LABEL_PREFIX):
            subsystem.destroy_actor(actor)
            removed += 1
    return removed


def _make_assembly_hint(recipe):
    hint_type = _get_unreal_type("SIPResourcePlantAssemblyHint")
    slot_hint_type = _get_unreal_type("SIPResourcePlantSlotAssemblyHint")
    if hint_type is None or slot_hint_type is None:
        raise RuntimeError("Missing reflected assembly hint structs. Rebuild the SIP editor module first.")

    hint = hint_type()
    _set_editor_property(hint, ("axis_mapping", "AxisMapping"), _enum_value("SIPResourcePlantAssemblyAxisMapping", recipe["assembly_hint"]["axis_mapping"]))
    _set_editor_property(hint, ("source_to_unreal_scale", "SourceToUnrealScale"), float(recipe["assembly_hint"]["source_to_unreal_scale"]))
    _set_editor_property(hint, ("source_anchor", "SourceAnchor"), unreal.Vector(0.0, 0.0, 0.0))

    slot_hints = []
    for slot in SLOTS:
        slot_hint = slot_hint_type()
        _set_editor_property(slot_hint, ("slot", "Slot"), _enum_value("SIPResourcePlantSlot", slot))
        _set_editor_property(slot_hint, ("source_placement_center", "SourcePlacementCenter"), unreal.Vector(0.0, 0.0, 0.0))
        _set_editor_property(slot_hint, ("local_rotation", "LocalRotation"), unreal.Rotator(0.0, 0.0, 0.0))
        _set_editor_property(slot_hint, ("local_scale", "LocalScale"), unreal.Vector(1.0, 1.0, 1.0))
        slot_hints.append(slot_hint)

    _set_editor_property(hint, ("slots", "Slots"), slot_hints)
    return hint


def _make_mesh_slot_recipe(family, slot, slot_plan, resolver):
    slot_type = _get_unreal_type("SIPResourcePlantMeshSlotRecipe")
    variant_type = _get_unreal_type("SIPResourcePlantMeshCollapseVariant")
    if slot_type is None or variant_type is None:
        raise RuntimeError("Missing reflected recipe structs. Rebuild the SIP editor module first.")

    slot_recipe = slot_type()
    _set_editor_property(slot_recipe, ("slot", "Slot"), _enum_value("SIPResourcePlantSlot", slot))
    default_path = resolver.resolve(family, slot, 0)
    _set_mesh_property(slot_recipe, default_path)
    _set_editor_property(slot_recipe, ("runtime_slot_tag", "RuntimeSlotTag"), unreal.Name(slot_plan["runtime_slot_tag"]))
    _set_editor_property(slot_recipe, ("visible", "b_visible", "bVisible"), default_path is not None)

    variants = []
    for level in range(4):
        resolved_path = resolver.resolve(family, slot, level)
        variant = variant_type()
        _set_editor_property(variant, ("collapse_level", "CollapseLevel"), level)
        _set_mesh_property(variant, resolved_path)
        _set_editor_property(variant, ("runtime_slot_tag", "RuntimeSlotTag"), unreal.Name("{}.C{}".format(slot_plan["runtime_slot_tag"], level)))
        _set_editor_property(variant, ("visible", "b_visible", "bVisible"), resolved_path is not None)
        variants.append(variant)

    _set_editor_property(slot_recipe, ("collapse_variants", "CollapseVariants"), variants)
    return slot_recipe


def _make_transient_recipe(actor, recipe_plan, resolver):
    recipe_type = _get_unreal_type("SIPResourcePlantRecipe")
    if recipe_type is None:
        raise RuntimeError("Missing reflected USIPResourcePlantRecipe class. Rebuild the SIP editor module first.")

    recipe = unreal.new_object(recipe_type, outer=actor, name="Transient_{}".format(recipe_plan["recipe_id"]))
    _set_editor_property(recipe, ("recipe_id", "RecipeId"), unreal.Name(recipe_plan["recipe_id"]))
    _set_editor_property(recipe, ("family", "Family"), _enum_value("SIPResourcePlantPreviewFamily", recipe_plan["family"]))
    _set_editor_property(recipe, ("default_collapse_band", "DefaultCollapseBand"), _enum_value("SIPResourcePlantCollapseBand", recipe_plan["default_collapse_band"]))
    _set_editor_property(recipe, ("assembly_hint", "AssemblyHint"), _make_assembly_hint(recipe_plan))

    mesh_slots = [
        _make_mesh_slot_recipe(recipe_plan["family"], slot, recipe_plan["mesh_slots"][slot], resolver)
        for slot in SLOTS
    ]
    _set_editor_property(recipe, ("mesh_slots", "MeshSlots"), mesh_slots)
    return recipe


def _load_persistent_recipe_assets(recipe_plan, package_path):
    recipe_type = _get_unreal_type("SIPResourcePlantRecipe")
    if recipe_type is None:
        raise RuntimeError("Missing reflected USIPResourcePlantRecipe class. Rebuild the SIP editor module first.")

    loaded = {}
    missing = []
    for recipe in recipe_plan.get("recipes", []):
        asset_name = "DA_{}".format(recipe["recipe_id"])
        object_path = "{}/{}".format(package_path, asset_name)
        asset = unreal.EditorAssetLibrary.load_asset(object_path)
        if isinstance(asset, recipe_type):
            loaded[recipe["recipe_id"]] = asset
        else:
            missing.append(object_path)
    return loaded, missing


def _set_actor_configuration(actor, actor_spec, recipe):
    vector_type = _get_unreal_type("SIPResourcePlantCollapseVector")
    vector = vector_type()
    _set_editor_property(vector, ("body_shell", "BodyShell"), int(actor_spec["collapse_vector"]["BodyShell"]))
    _set_editor_property(vector, ("primary_silhouette", "PrimarySilhouette"), int(actor_spec["collapse_vector"]["PrimarySilhouette"]))
    _set_editor_property(vector, ("core", "Core"), int(actor_spec["collapse_vector"]["Core"]))
    _set_editor_property(vector, ("orbit_set", "OrbitSet"), int(actor_spec["collapse_vector"]["OrbitSet"]))

    _set_editor_property(actor, ("plant_recipe", "PlantRecipe"), recipe)
    _set_editor_property(actor, ("plant_seed", "PlantSeed"), int(actor_spec["seed"]))
    _set_editor_property(actor, ("plant_scale", "PlantScale"), float(actor_spec["plant_scale"]))
    _set_editor_property(actor, ("collapse_band", "CollapseBand"), _enum_value("SIPResourcePlantCollapseBand", actor_spec["band"]))
    _set_editor_property(actor, ("use_recipe_default_collapse_band", "b_use_recipe_default_collapse_band", "bUseRecipeDefaultCollapseBand"), False)
    _set_editor_property(actor, ("explicit_collapse_vector", "ExplicitCollapseVector"), vector)
    _set_editor_property(actor, ("use_explicit_collapse_vector", "b_use_explicit_collapse_vector", "bUseExplicitCollapseVector"), True)
    _set_editor_property(actor, ("collapse_temperature_scale", "CollapseTemperatureScale"), float(actor_spec["temperature_scale"]))

    if hasattr(actor, "rebuild_plant_preview"):
        actor.rebuild_plant_preview()


def _spawn_actor(actor_class, actor_spec):
    subsystem = unreal.get_editor_subsystem(unreal.EditorActorSubsystem)
    location = unreal.Vector(*actor_spec["location"])
    actor = subsystem.spawn_actor_from_class(actor_class, location, unreal.Rotator(0.0, 0.0, 0.0))
    actor.set_actor_label(actor_spec["label"])
    actor.tags = [
        unreal.Name(TEST_TAG),
        unreal.Name("AIGCResourcePlantActorRandomTest.{}".format(actor_spec["family"])),
        unreal.Name("AIGCResourcePlantActorRandomTest.Band.{}".format(actor_spec["band"])),
        unreal.Name("AIGCResourcePlantActorRandomTest.Vector.{}".format(actor_spec["vector_slug"])),
    ]
    return actor


def _verify_actor_meshes(actor, actor_spec):
    results = {}
    mismatches = []
    for slot, component_property in SLOT_COMPONENT_PROPERTY.items():
        component = _get_editor_property(actor, (component_property,))
        mesh = _get_editor_property(component, ("static_mesh", "StaticMesh"))
        actual = _package_path(mesh)
        expected = actor_spec["effective_slot_meshes"][slot]
        visible = component.is_visible() if hasattr(component, "is_visible") else True
        ok = (not visible) if expected is None else actual == expected
        results[slot] = {
            "expected": expected,
            "actual": actual,
            "visible": bool(visible),
            "ok": ok,
        }
        if not ok:
            mismatches.append({"slot": slot, "expected": expected, "actual": actual})
    return results, mismatches


def _select_spawned(actors):
    unreal.EditorLevelLibrary.set_selected_level_actors(actors)


def _validate_reflection_ready():
    required_types = [
        "SIPResourcePlantActor",
        "SIPResourcePlantRecipe",
        "SIPResourcePlantMeshSlotRecipe",
        "SIPResourcePlantMeshCollapseVariant",
        "SIPResourcePlantAssemblyHint",
        "SIPResourcePlantSlotAssemblyHint",
        "SIPResourcePlantCollapseVector",
        "SIPResourcePlantSlot",
        "SIPResourcePlantPreviewFamily",
        "SIPResourcePlantCollapseBand",
        "SIPResourcePlantAssemblyAxisMapping",
    ]
    missing = [type_name for type_name in required_types if _get_unreal_type(type_name) is None]
    if missing:
        raise RuntimeError(
            "SIP plant reflection is stale or incomplete. Missing {}. "
            "Run a SIP editor rebuild/relaunch before spawning real AIGC plant actors.".format(missing)
        )


def main():
    args = _get_args()
    _validate_reflection_ready()
    actor_class = _get_unreal_type("SIPResourcePlantActor")
    if actor_class is None:
        raise RuntimeError("Missing ASIPResourcePlantActor reflection. Rebuild the SIP editor module first.")

    recipe_plan, recipe_plan_source, live_audit_summary = _load_recipe_plan(args)
    spawn_plan = build_actor_spawn_plan(
        recipe_plan,
        families=FAMILIES,
        bands=BANDS,
        samples_per_band=args["samples_per_band"],
        seed=args["seed"],
        origin=args["origin"],
        family_spacing_y=args["family_spacing_y"],
        band_spacing_x=args["band_spacing_x"],
        sample_spacing_y=args["sample_spacing_y"],
        scale=args["scale"],
        temperature_scale=args["temperature_scale"],
    )

    removed = _clear_previous() if args["clear_previous"] else 0
    resolver = AssetResolver()
    persistent_recipes, missing_persistent_recipes = ({}, [])
    if bool(args["use_persistent_recipe_assets"]):
        persistent_recipes, missing_persistent_recipes = _load_persistent_recipe_assets(
            recipe_plan,
            args["recipe_asset_package_path"],
        )
        if missing_persistent_recipes and not bool(args["fallback_to_transient_recipe"]):
            raise RuntimeError("Missing persistent recipe assets: {}".format(missing_persistent_recipes))

    spawned = []
    results = []
    all_mismatches = []

    for actor_spec in spawn_plan["actors"]:
        actor_spec["effective_slot_meshes"] = {
            slot: resolver.resolve(actor_spec["family"], slot, actor_spec["collapse_vector"][slot])
            for slot in SLOTS
        }
        actor = _spawn_actor(actor_class, actor_spec)
        recipe = persistent_recipes.get(actor_spec["recipe_id"])
        recipe_mode = "persistent_data_asset" if recipe else "transient_recipe"
        if recipe is None:
            recipe = _make_transient_recipe(actor, actor_spec["recipe"], resolver)
        _set_actor_configuration(actor, actor_spec, recipe)
        verification, mismatches = _verify_actor_meshes(actor, actor_spec)
        spawned.append(actor)
        all_mismatches.extend(
            [
                {
                    "actor_label": actor_spec["label"],
                    **mismatch,
                }
                for mismatch in mismatches
            ]
        )
        results.append(
            {
                "label": actor_spec["label"],
                "family": actor_spec["family"],
                "band": actor_spec["band"],
                "seed": actor_spec["seed"],
                "recipe_mode": recipe_mode,
                "location": actor_spec["location"],
                "collapse_vector": actor_spec["collapse_vector"],
                "metrics": actor_spec["metrics"],
                "slot_verification": verification,
            }
        )

    if args["select_spawned"]:
        _select_spawned(spawned)

    print(
        json.dumps(
            {
                "removed_previous_test_actors": removed,
                "recipe_plan_source": recipe_plan_source,
                "live_audit_summary": live_audit_summary,
                "recipe_assignment_mode": "persistent_data_asset" if persistent_recipes and not missing_persistent_recipes else "mixed_or_transient",
                "missing_persistent_recipe_assets": missing_persistent_recipes,
                "placement_mode": spawn_plan["placement_mode"],
                "spawned_actor_count": len(spawned),
                "selected_spawned": bool(args["select_spawned"]),
                "skipped_missing_recipes": spawn_plan["skipped_missing_recipes"],
                "asset_resolution_warning_count": len(resolver.events),
                "asset_resolution_warnings": resolver.events,
                "mesh_mismatch_count": len(all_mismatches),
                "mesh_mismatches": all_mismatches,
                "results": results,
            },
            indent=2,
            ensure_ascii=False,
        )
    )


main()
