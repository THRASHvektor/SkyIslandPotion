import json
from pathlib import Path

import unreal


ACTOR_LABEL = "SIP_AIGC_CrownLily_C0_ProceduralProxy"
COMPONENT_NAME = "CrownLilyC0ProceduralMesh"
TEXTURED_OBJ = Path(
    "C:/Users/12542/Documents/Unreal Projects/SkyIslandPotion/Tools/IslandMeshGen/"
    "Meshy_AI_Flamebound_Scepter_0705185936_texture_obj/"
    "Meshy_AI_Flamebound_Scepter_0705185936_texture_obj/"
    "Meshy_AI_Flamebound_Scepter_0705185936_texture.obj"
)
TEXTURE_DIR = Path(
    "C:/Users/12542/Documents/Unreal Projects/SkyIslandPotion/Tools/IslandMeshGen/output/plant_regroup/"
    "CrownLily_local-upload-mr9cc1z8-Meshy_AI_Flamebound_Scepter_1783275149_part-segm-Meshy_AI_Fl/"
    "03_pbr_parts/textures"
)

ASSET_DIR = "/Game/AIGC/Plants/CrownLily/C0"
TEXTURE_ASSET_DIR = ASSET_DIR + "/Textures"
MATERIAL_PATH = ASSET_DIR + "/M_CrownLily_C0_PBR_Proc"
TARGET_HEIGHT_CM = 264.0


def _find_actor(label):
    subsystem = unreal.get_editor_subsystem(unreal.EditorActorSubsystem)
    for actor in subsystem.get_all_level_actors():
        if actor.get_actor_label() == label:
            return actor
    raise RuntimeError("Actor not found: {}".format(label))


def _find_component(actor):
    if not hasattr(unreal, "ProceduralMeshComponent"):
        raise RuntimeError("ProceduralMeshComponent is not available")

    components = actor.get_components_by_class(unreal.ProceduralMeshComponent)
    for component in components:
        if component.get_name() == COMPONENT_NAME:
            return component
    if components:
        return components[0]
    raise RuntimeError("ProceduralMeshComponent not found on {}".format(actor.get_actor_label()))


def _parse_index_triplet(token):
    parts = token.split("/")
    vertex_index = int(parts[0]) - 1
    uv_index = int(parts[1]) - 1 if len(parts) > 1 and parts[1] else vertex_index
    normal_index = int(parts[2]) - 1 if len(parts) > 2 and parts[2] else vertex_index
    return vertex_index, uv_index, normal_index


def _normalize(x, y, z):
    length = max((x * x + y * y + z * z) ** 0.5, 0.0001)
    return x / length, y / length, z / length


def _read_textured_obj(path):
    source_vertices = []
    source_normals = []
    source_uvs = []
    faces = []

    with path.open("r", encoding="utf-8") as handle:
        for line in handle:
            if line.startswith("v "):
                parts = line.split()
                x, y, z = float(parts[1]), float(parts[2]), float(parts[3])
                source_vertices.append((x, y, z))
            elif line.startswith("vn "):
                parts = line.split()
                x, y, z = float(parts[1]), float(parts[2]), float(parts[3])
                source_normals.append((x, y, z))
            elif line.startswith("vt "):
                parts = line.split()
                source_uvs.append((float(parts[1]), float(parts[2])))
            elif line.startswith("f "):
                tokens = line.split()[1:]
                if len(tokens) < 3:
                    continue
                face = [_parse_index_triplet(token) for token in tokens[:3]]
                faces.append(face)

    if not source_vertices or not source_uvs or not faces:
        raise RuntimeError("Textured OBJ is missing vertices, UVs, or faces: {}".format(path))

    min_x = min(v[0] for v in source_vertices)
    max_x = max(v[0] for v in source_vertices)
    min_y = min(v[1] for v in source_vertices)
    max_y = max(v[1] for v in source_vertices)
    min_z = min(v[2] for v in source_vertices)
    max_z = max(v[2] for v in source_vertices)
    center_x = (min_x + max_x) * 0.5
    center_z = (min_z + max_z) * 0.5
    scale = TARGET_HEIGHT_CM / max(max_y - min_y, 0.0001)

    vertices = []
    normals = []
    uvs = []
    triangles = []
    remap = {}

    for face in faces:
        for triplet in face:
            out_index = remap.get(triplet)
            if out_index is None:
                vertex_index, uv_index, normal_index = triplet
                x, y, z = source_vertices[vertex_index]
                vertices.append(
                    unreal.Vector(
                        (x - center_x) * scale,
                        -(z - center_z) * scale,
                        (y - min_y) * scale,
                    )
                )

                if 0 <= normal_index < len(source_normals):
                    nx, ny, nz = source_normals[normal_index]
                    nx, ny, nz = _normalize(nx, -nz, ny)
                    normals.append(unreal.Vector(nx, ny, nz))
                else:
                    normals.append(unreal.Vector(0.0, 0.0, 1.0))

                if 0 <= uv_index < len(source_uvs):
                    u, v = source_uvs[uv_index]
                    uvs.append(unreal.Vector2D(u, v))
                else:
                    uvs.append(unreal.Vector2D(0.0, 0.0))

                out_index = len(vertices) - 1
                remap[triplet] = out_index
            triangles.append(out_index)

    return {
        "vertices": vertices,
        "triangles": triangles,
        "normals": normals,
        "uvs": uvs,
        "source_vertices": len(source_vertices),
        "source_uvs": len(source_uvs),
        "source_normals": len(source_normals),
        "source_faces": len(faces),
        "bounds_source": {
            "min": [min_x, min_y, min_z],
            "max": [max_x, max_y, max_z],
            "scale_to_cm": scale,
        },
    }


def _import_texture(source_path, destination_name, srgb, compression_settings):
    asset_path = TEXTURE_ASSET_DIR + "/" + destination_name
    if not unreal.EditorAssetLibrary.does_asset_exist(asset_path):
        task = unreal.AssetImportTask()
        task.set_editor_property("filename", str(source_path))
        task.set_editor_property("destination_path", TEXTURE_ASSET_DIR)
        task.set_editor_property("destination_name", destination_name)
        task.set_editor_property("automated", True)
        task.set_editor_property("replace_existing", True)
        task.set_editor_property("save", True)
        if hasattr(unreal, "TextureFactory"):
            task.set_editor_property("factory", unreal.TextureFactory())
        unreal.AssetToolsHelpers.get_asset_tools().import_asset_tasks([task])

    texture = unreal.EditorAssetLibrary.load_asset(asset_path)
    if not texture:
        raise RuntimeError("Texture import failed: {}".format(asset_path))
    texture.set_editor_property("srgb", srgb)
    texture.set_editor_property("compression_settings", compression_settings)
    unreal.EditorAssetLibrary.save_asset(asset_path, only_if_is_dirty=False)
    return texture


def _make_material(textures):
    if unreal.EditorAssetLibrary.does_asset_exist(MATERIAL_PATH):
        unreal.EditorAssetLibrary.delete_asset(MATERIAL_PATH)

    factory = unreal.MaterialFactoryNew()
    material = unreal.AssetToolsHelpers.get_asset_tools().create_asset(
        "M_CrownLily_C0_PBR_Proc",
        ASSET_DIR,
        unreal.Material,
        factory,
    )
    if not material:
        raise RuntimeError("Failed to create material: {}".format(MATERIAL_PATH))

    material.set_editor_property("two_sided", True)
    try:
        material.set_editor_property("shading_model", unreal.MaterialShadingModel.MSM_UNLIT)
    except Exception:
        pass
    mel = unreal.MaterialEditingLibrary

    base = mel.create_material_expression(material, unreal.MaterialExpressionTextureSample, -700, -240)
    base.set_editor_property("texture", textures["base"])
    base.set_editor_property("sampler_type", unreal.MaterialSamplerType.SAMPLERTYPE_COLOR)
    base_lift = mel.create_material_expression(material, unreal.MaterialExpressionConstant, -470, -120)
    base_lift.set_editor_property("r", 1.22)
    lifted_base = mel.create_material_expression(material, unreal.MaterialExpressionMultiply, -270, -240)
    mel.connect_material_expressions(base, "RGB", lifted_base, "A")
    mel.connect_material_expressions(base_lift, "", lifted_base, "B")
    mel.connect_material_property(lifted_base, "", unreal.MaterialProperty.MP_BASE_COLOR)

    metal_rough = mel.create_material_expression(material, unreal.MaterialExpressionTextureSample, -700, 20)
    metal_rough.set_editor_property("texture", textures["metal_rough"])
    metal_rough.set_editor_property("sampler_type", unreal.MaterialSamplerType.SAMPLERTYPE_MASKS)
    mel.connect_material_property(metal_rough, "G", unreal.MaterialProperty.MP_ROUGHNESS)
    metallic_floor = mel.create_material_expression(material, unreal.MaterialExpressionConstant, -260, 80)
    metallic_floor.set_editor_property("r", 0.0)
    mel.connect_material_property(metallic_floor, "", unreal.MaterialProperty.MP_METALLIC)

    normal = mel.create_material_expression(material, unreal.MaterialExpressionTextureSample, -700, 260)
    normal.set_editor_property("texture", textures["normal"])
    normal.set_editor_property("sampler_type", unreal.MaterialSamplerType.SAMPLERTYPE_NORMAL)
    mel.connect_material_property(normal, "RGB", unreal.MaterialProperty.MP_NORMAL)

    emissive = mel.create_material_expression(material, unreal.MaterialExpressionTextureSample, -700, 500)
    emissive.set_editor_property("texture", textures["emissive"])
    emissive.set_editor_property("sampler_type", unreal.MaterialSamplerType.SAMPLERTYPE_COLOR)
    emissive_boost = mel.create_material_expression(material, unreal.MaterialExpressionConstant, -470, 620)
    emissive_boost.set_editor_property("r", 4.0)
    boosted_emissive = mel.create_material_expression(material, unreal.MaterialExpressionMultiply, -280, 500)
    mel.connect_material_expressions(emissive, "RGB", boosted_emissive, "A")
    mel.connect_material_expressions(emissive_boost, "", boosted_emissive, "B")

    base_glow_amount = mel.create_material_expression(material, unreal.MaterialExpressionConstant, -470, 760)
    base_glow_amount.set_editor_property("r", 1.0)
    base_glow = mel.create_material_expression(material, unreal.MaterialExpressionMultiply, -280, 700)
    mel.connect_material_expressions(base, "RGB", base_glow, "A")
    mel.connect_material_expressions(base_glow_amount, "", base_glow, "B")

    preview_emissive = mel.create_material_expression(material, unreal.MaterialExpressionAdd, -70, 560)
    mel.connect_material_expressions(boosted_emissive, "", preview_emissive, "A")
    mel.connect_material_expressions(base_glow, "", preview_emissive, "B")
    mel.connect_material_property(preview_emissive, "", unreal.MaterialProperty.MP_EMISSIVE_COLOR)

    mel.layout_material_expressions(material)
    mel.recompile_material(material)
    unreal.EditorAssetLibrary.save_asset(MATERIAL_PATH, only_if_is_dirty=False)
    return material


def _clear_preview_lights():
    subsystem = unreal.get_editor_subsystem(unreal.EditorActorSubsystem)
    for actor in subsystem.get_all_level_actors():
        if actor.get_actor_label().startswith("SIP_AIGC_CrownLily_C0_PreviewLight"):
            subsystem.destroy_actor(actor)


def _spawn_preview_light(label, location, color, intensity, radius):
    subsystem = unreal.get_editor_subsystem(unreal.EditorActorSubsystem)
    actor = subsystem.spawn_actor_from_class(unreal.PointLight, unreal.Vector(*location), unreal.Rotator(0.0, 0.0, 0.0))
    actor.set_actor_label(label)
    actor.tags = ["AIGCPreview", "AIGCPreview.CrownLily", "AIGCPreview.LightRig"]
    component = actor.get_component_by_class(unreal.PointLightComponent)
    if component:
        component.set_editor_property("intensity", intensity)
        component.set_editor_property("attenuation_radius", radius)
        component.set_editor_property("light_color", color)
        component.set_editor_property("cast_shadows", False)
    return actor


def _ensure_preview_lights(actor):
    _clear_preview_lights()


def _ensure_assets():
    unreal.EditorAssetLibrary.make_directory(ASSET_DIR)
    unreal.EditorAssetLibrary.make_directory(TEXTURE_ASSET_DIR)

    texture_paths = {
        "base": TEXTURE_DIR / "texture_0.jpg",
        "metal_rough": TEXTURE_DIR / "texture_1.jpg",
        "normal": TEXTURE_DIR / "texture_2.jpg",
        "emissive": TEXTURE_DIR / "texture_3.jpg",
    }
    for name, path in texture_paths.items():
        if not path.exists():
            raise RuntimeError("Missing PBR texture {}: {}".format(name, path))

    textures = {
        "base": _import_texture(texture_paths["base"], "T_CrownLily_C0_BaseColor", True, unreal.TextureCompressionSettings.TC_DEFAULT),
        "metal_rough": _import_texture(texture_paths["metal_rough"], "T_CrownLily_C0_MetalRough", False, unreal.TextureCompressionSettings.TC_MASKS),
        "normal": _import_texture(texture_paths["normal"], "T_CrownLily_C0_Normal", False, unreal.TextureCompressionSettings.TC_NORMALMAP),
        "emissive": _import_texture(texture_paths["emissive"], "T_CrownLily_C0_Emissive", True, unreal.TextureCompressionSettings.TC_DEFAULT),
    }
    material = _make_material(textures)
    return material, textures


def main():
    if not TEXTURED_OBJ.exists():
        raise RuntimeError("Missing textured OBJ: {}".format(TEXTURED_OBJ))

    actor = _find_actor(ACTOR_LABEL)
    component = _find_component(actor)
    mesh = _read_textured_obj(TEXTURED_OBJ)
    material, textures = _ensure_assets()
    _ensure_preview_lights(actor)

    component.clear_all_mesh_sections()
    component.create_mesh_section(
        0,
        mesh["vertices"],
        mesh["triangles"],
        mesh["normals"],
        mesh["uvs"],
        [],
        [],
        False,
    )
    component.set_material(0, material)
    component.set_collision_enabled(unreal.CollisionEnabled.NO_COLLISION)
    component.set_visibility(True, True)
    component.set_hidden_in_game(False)
    if hasattr(component, "activate"):
        component.activate(True)

    unreal.get_editor_subsystem(unreal.EditorActorSubsystem).set_actor_selection_state(actor, True)

    print(
        json.dumps(
            {
                "actor": actor.get_actor_label(),
                "component": component.get_name(),
                "material": MATERIAL_PATH,
                "textures": {name: texture.get_path_name() for name, texture in textures.items()},
                "vertices": len(mesh["vertices"]),
                "triangles": len(mesh["triangles"]) // 3,
                "sections": component.get_num_sections() if hasattr(component, "get_num_sections") else None,
                "source": {
                    "obj": str(TEXTURED_OBJ),
                    "source_vertices": mesh["source_vertices"],
                    "source_uvs": mesh["source_uvs"],
                    "source_normals": mesh["source_normals"],
                    "source_faces": mesh["source_faces"],
                    "bounds": mesh["bounds_source"],
                },
            },
            indent=2,
        )
    )


main()
