#!/usr/bin/env python3
"""Inspect Meshy segmentation/PBR GLB pairs without modifying source folders."""

from __future__ import annotations

import argparse
import itertools
import json
import math
import struct
import time
from pathlib import Path

import numpy as np


COMPONENT_DTYPE = {
    5120: np.int8,
    5121: np.uint8,
    5122: np.int16,
    5123: np.uint16,
    5125: np.uint32,
    5126: np.float32,
}

ACCESSOR_WIDTH = {
    "SCALAR": 1,
    "VEC2": 2,
    "VEC3": 3,
    "VEC4": 4,
    "MAT4": 16,
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--inbox", required=True, help="mesh_inbox folder.")
    parser.add_argument("--output", required=True, help="Output report JSON.")
    parser.add_argument("--sample-faces", type=int, default=12000)
    parser.add_argument("--seed", type=int, default=37)
    return parser.parse_args()


def read_glb(path: Path) -> tuple[dict, bytes]:
    data = path.read_bytes()
    if len(data) < 20:
        raise ValueError(f"{path} is too small to be a GLB.")
    magic, version, total_length = struct.unpack_from("<III", data, 0)
    if magic != 0x46546C67 or version != 2:
        raise ValueError(f"{path} is not a GLB 2.0 file.")
    offset = 12
    json_doc = None
    bin_chunk = None
    while offset < total_length:
        chunk_length, chunk_type = struct.unpack_from("<II", data, offset)
        offset += 8
        chunk = data[offset : offset + chunk_length]
        offset += chunk_length
        if chunk_type == 0x4E4F534A:
            json_doc = json.loads(chunk.decode("utf-8"))
        elif chunk_type == 0x004E4942:
            bin_chunk = chunk
    if json_doc is None:
        raise ValueError(f"{path} has no JSON chunk.")
    return json_doc, bin_chunk or b""


def accessor_array(doc: dict, bin_chunk: bytes, accessor_index: int) -> np.ndarray:
    accessor = doc["accessors"][accessor_index]
    buffer_view = doc["bufferViews"][accessor["bufferView"]]
    dtype = np.dtype(COMPONENT_DTYPE[accessor["componentType"]]).newbyteorder("<")
    width = ACCESSOR_WIDTH[accessor["type"]]
    count = int(accessor["count"])
    byte_offset = int(buffer_view.get("byteOffset", 0)) + int(accessor.get("byteOffset", 0))
    byte_stride = buffer_view.get("byteStride")
    if accessor.get("sparse"):
        raise ValueError("Sparse accessors are not supported by this inspector.")
    if byte_stride and byte_stride != dtype.itemsize * width:
        rows = []
        for i in range(count):
            start = byte_offset + i * byte_stride
            rows.append(np.frombuffer(bin_chunk, dtype=dtype, count=width, offset=start))
        array = np.vstack(rows)
    else:
        array = np.frombuffer(bin_chunk, dtype=dtype, count=count * width, offset=byte_offset)
        array = array.reshape((count, width))
    if accessor.get("normalized"):
        array = normalize_integer_accessor(array, accessor["componentType"])
    return np.asarray(array)


def normalize_integer_accessor(array: np.ndarray, component_type: int) -> np.ndarray:
    array = array.astype(np.float32)
    if component_type == 5120:
        return np.maximum(array / 127.0, -1.0)
    if component_type == 5121:
        return array / 255.0
    if component_type == 5122:
        return np.maximum(array / 32767.0, -1.0)
    if component_type == 5123:
        return array / 65535.0
    return array


def node_matrix(node: dict) -> np.ndarray:
    if "matrix" in node:
        return np.asarray(node["matrix"], dtype=np.float32).reshape((4, 4)).T
    translation = np.asarray(node.get("translation", [0, 0, 0]), dtype=np.float32)
    scale = np.asarray(node.get("scale", [1, 1, 1]), dtype=np.float32)
    rotation = np.asarray(node.get("rotation", [0, 0, 0, 1]), dtype=np.float32)
    matrix = quat_matrix(rotation)
    matrix[:3, :3] *= scale.reshape((1, 3))
    matrix[:3, 3] = translation
    return matrix


def quat_matrix(q: np.ndarray) -> np.ndarray:
    x, y, z, w = q
    xx, yy, zz = x * x, y * y, z * z
    xy, xz, yz = x * y, x * z, y * z
    wx, wy, wz = w * x, w * y, w * z
    return np.asarray([
        [1 - 2 * (yy + zz), 2 * (xy - wz), 2 * (xz + wy), 0],
        [2 * (xy + wz), 1 - 2 * (xx + zz), 2 * (yz - wx), 0],
        [2 * (xz - wy), 2 * (yz + wx), 1 - 2 * (xx + yy), 0],
        [0, 0, 0, 1],
    ], dtype=np.float32)


def scene_node_indices(doc: dict) -> list[int]:
    if doc.get("scenes"):
        scene_index = int(doc.get("scene", 0))
        nodes = doc["scenes"][scene_index].get("nodes", [])
        return [int(node) for node in nodes]
    return list(range(len(doc.get("nodes", []))))


def world_matrices(doc: dict) -> dict[int, np.ndarray]:
    nodes = doc.get("nodes", [])
    matrices: dict[int, np.ndarray] = {}

    def visit(index: int, parent: np.ndarray) -> None:
        local = node_matrix(nodes[index])
        world = parent @ local
        matrices[index] = world
        for child in nodes[index].get("children", []):
            visit(int(child), world)

    for root in scene_node_indices(doc):
        if 0 <= root < len(nodes):
            visit(root, np.eye(4, dtype=np.float32))
    for index in range(len(nodes)):
        matrices.setdefault(index, node_matrix(nodes[index]))
    return matrices


def transform_points(points: np.ndarray, matrix: np.ndarray) -> np.ndarray:
    ones = np.ones((len(points), 1), dtype=np.float32)
    hom = np.hstack([points.astype(np.float32), ones])
    return (hom @ matrix.T)[:, :3]


def inspect_glb(path: Path, sample_faces: int, seed: int) -> dict:
    doc, bin_chunk = read_glb(path)
    matrices = world_matrices(doc)
    mesh_use_count = mesh_node_use_count(doc)
    primitive_rows = []
    bounds_chunks = []
    center_chunks = []
    material_indices = []
    total_faces = 0
    total_vertices = 0
    primitive_count = 0
    texcoord_primitives = 0
    normal_primitives = 0
    tangent_primitives = 0
    unique_mesh_names = []
    for node_index, node in enumerate(doc.get("nodes", [])):
        if "mesh" not in node:
            continue
        mesh_index = int(node["mesh"])
        mesh = doc.get("meshes", [])[mesh_index]
        mesh_name = mesh.get("name") or node.get("name") or f"mesh_{mesh_index}"
        if mesh_name not in unique_mesh_names:
            unique_mesh_names.append(mesh_name)
        world = matrices.get(node_index, np.eye(4, dtype=np.float32))
        for primitive_index, primitive in enumerate(mesh.get("primitives", [])):
            attributes = primitive.get("attributes", {})
            if primitive.get("mode", 4) != 4 or "POSITION" not in attributes:
                continue
            positions = accessor_array(doc, bin_chunk, attributes["POSITION"]).astype(np.float32)
            transformed = transform_points(positions, world)
            vertex_count = int(len(transformed))
            if "indices" in primitive:
                indices = accessor_array(doc, bin_chunk, primitive["indices"]).astype(np.int64).reshape(-1)
                face_count = int(len(indices) // 3)
                tri_points = transformed[indices[: face_count * 3]].reshape((-1, 3, 3))
            else:
                face_count = int(vertex_count // 3)
                tri_points = transformed[: face_count * 3].reshape((-1, 3, 3))
            centers = tri_points.mean(axis=1)
            bounds_chunks.append(transformed)
            center_chunks.append(centers)
            material_index = int(primitive.get("material", -1))
            material_indices.extend([material_index] * face_count)
            primitive_rows.append({
                "node": node.get("name") or f"node_{node_index}",
                "mesh": mesh_name,
                "primitive": primitive_index,
                "vertices": vertex_count,
                "faces": face_count,
                "material": material_index,
                "has_normal": "NORMAL" in attributes,
                "has_texcoord0": "TEXCOORD_0" in attributes,
                "has_tangent": "TANGENT" in attributes,
            })
            primitive_count += 1
            total_faces += face_count
            total_vertices += vertex_count
            normal_primitives += int("NORMAL" in attributes)
            texcoord_primitives += int("TEXCOORD_0" in attributes)
            tangent_primitives += int("TANGENT" in attributes)
    if not bounds_chunks:
        raise ValueError(f"{path} has no triangle POSITION primitives.")
    points = np.vstack(bounds_chunks)
    face_centers = np.vstack(center_chunks).astype(np.float32)
    sample_indices = deterministic_sample(len(face_centers), sample_faces, seed)
    sampled_centers = face_centers[sample_indices]
    mins = points.min(axis=0)
    maxs = points.max(axis=0)
    extents = maxs - mins
    return {
        "path": str(path),
        "file_name": path.name,
        "bytes": path.stat().st_size,
        "nodes": len(doc.get("nodes", [])),
        "meshes": len(doc.get("meshes", [])),
        "mesh_node_use_count": mesh_use_count,
        "mesh_names_sample": unique_mesh_names[:12],
        "primitives": primitive_count,
        "materials": len(doc.get("materials", [])),
        "textures": len(doc.get("textures", [])),
        "images": len(doc.get("images", [])),
        "animations": len(doc.get("animations", [])),
        "skins": len(doc.get("skins", [])),
        "vertices": total_vertices,
        "faces": total_faces,
        "normal_primitives": normal_primitives,
        "texcoord0_primitives": texcoord_primitives,
        "tangent_primitives": tangent_primitives,
        "bounds": {
            "min": rounded_list(mins),
            "max": rounded_list(maxs),
            "center": rounded_list((mins + maxs) * 0.5),
            "extents": rounded_list(extents),
            "scale": round(float(max(extents.max(), 1e-8)), 8),
        },
        "material_face_counts": material_face_counts(material_indices),
        "primitive_sample": primitive_rows[:16],
        "_sampled_centers": sampled_centers,
        "_all_centers_count": int(len(face_centers)),
    }


def mesh_node_use_count(doc: dict) -> dict[str, int]:
    counts: dict[str, int] = {}
    meshes = doc.get("meshes", [])
    for node in doc.get("nodes", []):
        if "mesh" not in node:
            continue
        mesh_index = int(node["mesh"])
        mesh_name = meshes[mesh_index].get("name") or f"mesh_{mesh_index}"
        counts[mesh_name] = counts.get(mesh_name, 0) + 1
    return counts


def material_face_counts(material_indices: list[int]) -> dict[str, int]:
    counts: dict[str, int] = {}
    for material in material_indices:
        key = str(material)
        counts[key] = counts.get(key, 0) + 1
    return dict(sorted(counts.items(), key=lambda item: int(item[0]) if item[0].lstrip("-").isdigit() else 999999))


def deterministic_sample(count: int, limit: int, seed: int) -> np.ndarray:
    if limit <= 0 or count <= limit:
        return np.arange(count, dtype=np.int64)
    rng = np.random.default_rng(seed)
    return np.sort(rng.choice(count, size=limit, replace=False))


def rounded_list(values: np.ndarray) -> list[float]:
    return [round(float(value), 8) for value in values.tolist()]


def canonicalize(points: np.ndarray) -> tuple[np.ndarray, dict]:
    mins = points.min(axis=0)
    maxs = points.max(axis=0)
    center = (mins + maxs) * 0.5
    extents = maxs - mins
    scale = float(max(extents.max(), 1e-8))
    return ((points - center) / scale).astype(np.float32), {
        "center": rounded_list(center),
        "extents": rounded_list(extents),
        "scale": round(scale, 8),
    }


def transformed(points: np.ndarray, permutation: tuple[int, int, int], signs: tuple[int, int, int]) -> np.ndarray:
    return points[:, permutation] * np.asarray(signs, dtype=np.float32)


def build_grid(points: np.ndarray, cell_size: float) -> dict[tuple[int, int, int], np.ndarray]:
    cells = np.floor(points / cell_size).astype(np.int32)
    buckets: dict[tuple[int, int, int], list[int]] = {}
    for index, cell in enumerate(cells):
        key = (int(cell[0]), int(cell[1]), int(cell[2]))
        buckets.setdefault(key, []).append(index)
    return {key: np.asarray(value, dtype=np.int64) for key, value in buckets.items()}


def collect_grid_candidates(grid: dict[tuple[int, int, int], np.ndarray], base: tuple[int, int, int], radius: int) -> np.ndarray:
    chunks = []
    bx, by, bz = base
    for dx in range(-radius, radius + 1):
        for dy in range(-radius, radius + 1):
            for dz in range(-radius, radius + 1):
                chunk = grid.get((bx + dx, by + dy, bz + dz))
                if chunk is not None:
                    chunks.append(chunk)
    if not chunks:
        return np.empty(0, dtype=np.int64)
    return np.concatenate(chunks)


def nearest_distances_grid(source: np.ndarray, target: np.ndarray, cell_size: float = 0.035) -> np.ndarray:
    grid = build_grid(source, cell_size)
    distances = np.empty(len(target), dtype=np.float32)
    all_source = np.arange(len(source), dtype=np.int64)
    for index, point in enumerate(target):
        base = tuple(np.floor(point / cell_size).astype(np.int32).tolist())
        candidates = collect_grid_candidates(grid, base, 1)
        if candidates.size == 0:
            candidates = collect_grid_candidates(grid, base, 2)
        if candidates.size == 0:
            candidates = collect_grid_candidates(grid, base, 4)
        if candidates.size == 0:
            candidates = all_source
        deltas = source[candidates] - point
        dist2 = np.einsum("ij,ij->i", deltas, deltas)
        distances[index] = math.sqrt(float(np.min(dist2)))
    return distances


def best_axis_alignment(seg_centers: np.ndarray, pbr_centers: np.ndarray) -> dict:
    seg_norm, seg_basis = canonicalize(seg_centers)
    pbr_norm, pbr_basis = canonicalize(pbr_centers)
    best = None
    for permutation in itertools.permutations((0, 1, 2)):
        for signs in itertools.product((-1, 1), repeat=3):
            candidate = transformed(seg_norm, permutation, signs)
            distances = nearest_distances_grid(candidate, pbr_norm)
            score = float(np.percentile(distances, 75) + distances.mean())
            item = {
                "score": round(score, 6),
                "permutation": list(permutation),
                "signs": list(signs),
                "mean": round(float(distances.mean()), 6),
                "p50": round(float(np.percentile(distances, 50)), 6),
                "p75": round(float(np.percentile(distances, 75)), 6),
                "p90": round(float(np.percentile(distances, 90)), 6),
                "p95": round(float(np.percentile(distances, 95)), 6),
                "max": round(float(distances.max()), 6),
                "seg_basis": seg_basis,
                "pbr_basis": pbr_basis,
            }
            if best is None or item["score"] < best["score"]:
                best = item
    assert best is not None
    return best


def classify_pair(seg: dict, pbr: dict, alignment: dict) -> dict:
    face_ratio = pbr["faces"] / max(seg["faces"], 1)
    vertex_ratio = pbr["vertices"] / max(seg["vertices"], 1)
    scale_ratio = pbr["bounds"]["scale"] / max(seg["bounds"]["scale"], 1e-8)
    same_face_count = seg["faces"] == pbr["faces"]
    topology_note = "same_face_count" if same_face_count else "different_face_count_projection_required"
    if same_face_count and abs(vertex_ratio - 1.0) < 0.02:
        topology_note = "likely_same_topology"
    elif same_face_count:
        topology_note = "same_faces_vertex_split_expected_from_uv"
    p95 = alignment["p95"]
    if p95 <= 0.04:
        verdict = "good"
        message = "The pair is spatially tight; projection/cutting should be reasonable."
    elif p95 <= 0.085:
        verdict = "usable_with_care"
        message = "The pair is close enough to test, but semantic boundaries may need visual review."
    else:
        verdict = "risky"
        message = "The pair is spatially loose; check whether these two GLBs belong to the same Meshy result/state."
    if pbr["images"] == 0 or pbr["texcoord0_primitives"] == 0:
        verdict = "risky"
        message = "PBR GLB lacks images or UVs, so it is not a good textured mother mesh."
    if seg["primitives"] <= 1 and seg["nodes"] <= 1 and seg["meshes"] <= 1:
        verdict = "risky"
        message = "Segmentation GLB appears merged; it may not preserve Meshy split parts."
    return {
        "verdict": verdict,
        "message": message,
        "topology_note": topology_note,
        "face_ratio_pbr_to_seg": round(face_ratio, 6),
        "vertex_ratio_pbr_to_seg": round(vertex_ratio, 6),
        "scale_ratio_pbr_to_seg": round(scale_ratio, 6),
        "same_face_count": same_face_count,
        "same_material_slot_count": seg["materials"] == pbr["materials"],
        "seg_has_split_structure": seg["nodes"] > 1 or seg["meshes"] > 1 or seg["primitives"] > 1,
        "pbr_has_textures": pbr["images"] > 0 and pbr["texcoord0_primitives"] > 0,
    }


def classify_files(folder: Path) -> tuple[Path | None, Path | None, list[Path]]:
    glbs = sorted(folder.glob("*.glb"))
    seg = next((path for path in glbs if "part-segmentation" in path.name.lower() or "seg" in path.name.lower()), None)
    pbr = next((path for path in glbs if "texture" in path.name.lower() or "pbr" in path.name.lower()), None)
    if seg is None and len(glbs) == 2:
        seg = glbs[0]
    if pbr is None and len(glbs) == 2:
        pbr = glbs[1] if glbs[0] == seg else glbs[0]
    return seg, pbr, glbs


def public_glb_report(payload: dict) -> dict:
    clean = dict(payload)
    clean.pop("_sampled_centers", None)
    clean.pop("_all_centers_count", None)
    return clean


def main() -> None:
    args = parse_args()
    started_at = time.perf_counter()
    inbox = Path(args.inbox)
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    pairs = []
    for folder in sorted([path for path in inbox.iterdir() if path.is_dir() and not path.name.startswith("_")]):
        seg_path, pbr_path, glbs = classify_files(folder)
        pair = {
            "state": folder.name,
            "folder": str(folder),
            "glb_files": [path.name for path in glbs],
        }
        if seg_path is None or pbr_path is None:
            pair["verdict"] = "missing_pair"
            pair["message"] = "Expected one segmentation GLB and one PBR/texture GLB."
            pairs.append(pair)
            continue
        try:
            seg = inspect_glb(seg_path, args.sample_faces, args.seed + len(pairs) * 10 + 1)
            pbr = inspect_glb(pbr_path, args.sample_faces, args.seed + len(pairs) * 10 + 2)
            alignment = best_axis_alignment(seg["_sampled_centers"], pbr["_sampled_centers"])
            classification = classify_pair(seg, pbr, alignment)
            pair.update({
                "segmentation_glb": public_glb_report(seg),
                "pbr_glb": public_glb_report(pbr),
                "alignment": alignment,
                "classification": classification,
                "verdict": classification["verdict"],
                "message": classification["message"],
            })
        except Exception as exc:
            pair["verdict"] = "error"
            pair["message"] = str(exc)
        pairs.append(pair)
    summary_counts: dict[str, int] = {}
    for pair in pairs:
        summary_counts[pair["verdict"]] = summary_counts.get(pair["verdict"], 0) + 1
    report = {
        "schema": "SkyIslandPotion.MeshInboxGlbPairAudit.v1",
        "generated_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
        "inbox": str(inbox),
        "rules": {
            "source_folders_are_read_only": True,
            "outputs_are_under_mesh_inbox_analysis_runs": True,
            "alignment_basis": "canonicalized sampled triangle-center nearest distance over axis permutations/sign flips",
        },
        "summary": {
            "pair_count": len(pairs),
            "verdict_counts": summary_counts,
            "elapsed_ms": int(round((time.perf_counter() - started_at) * 1000)),
        },
        "pairs": pairs,
    }
    output.write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps(report["summary"], indent=2))


if __name__ == "__main__":
    main()
